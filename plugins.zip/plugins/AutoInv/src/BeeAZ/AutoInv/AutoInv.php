<?php

namespace BeeAZ\AutoInv;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\Listener;
use pocketmine\event\EventPriority;
use pocketmine\plugin\PluginBase;
use pocketmine\block\BlockTypeIds;

class AutoInv extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }


    /**
     * @param BlockBreakEvent $event
     *
     * @priority HIGHEST
     * 
     */

    public function onBreak(BlockBreakEvent $event) {
        $block = $event->getBlock();
        $player = $event->getPlayer();
        if(count($event->getDrops()) > 0 && !$event->isCancelled()){
        if($block->getTypeId() !== BlockTypeIds::LEGACY_STONECUTTER){
        $drops = $event->getDrops();
        }else $drops = [];
            foreach ($drops as $key => $drop) {
                if ($player->getInventory()->canAddItem($drop)) {
                    $player->getInventory()->addItem($drop);
                    unset($drops[$key]);
                }
            }
        $event->setDrops($drops);
        }
    }

    public function onDeath(PlayerDeathEvent $event): void {
        $event->setKeepInventory(true);
    }
}
