<?php

declare(strict_types=1);

namespace BeeAZ\AZCanhGioi;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\scheduler\ClosureTask;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\ExplodeParticle;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use AZEconomy\AZEconomy;

use BeeAZ\AZCanhGioi\task\BreakthroughTask;

class Main extends PluginBase implements Listener {

    private array $tuviCache = [];
    private array $tierCache = [];
    public array $floatingPlayers = [];

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        @mkdir($this->getDataFolder());

        // Init database structure synchronously on enable
        $db = new \SQLite3($this->getDataFolder() . "data.sqlite");
        $db->busyTimeout(5000);
        $db->exec("CREATE TABLE IF NOT EXISTS players (username TEXT PRIMARY KEY, tuvi INTEGER DEFAULT 0, tier INTEGER DEFAULT 0)");
        $db->close();

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        // Ground/Dropped Item Alchemy Task (checks every 2 seconds)
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->checkGroundAlchemy();
        }), 40);

        // Passive Meditation Task
        $meditation = $this->getConfig()->get("meditation", []);
        if ($meditation["enabled"] ?? true) {
            $interval = (int)($meditation["interval-seconds"] ?? 30);
            $gain = (int)($meditation["tuvi-gain"] ?? 3);
            
            $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function() use ($gain): void {
                foreach ($this->getServer()->getOnlinePlayers() as $player) {
                    $this->addTuvi($player, $gain, "Thiền Định");
                }
            }), 20 * $interval);
        }

        // Auto Save Task (every 3 minutes)
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->saveAllData();
        }), 20 * 60 * 3);
    }

    protected function onDisable(): void {
        $this->saveAllData();
    }

    // --- Command Handling ---

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        $cmdName = strtolower($command->getName());

        if ($cmdName === "canhgioi") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("Lệnh này chỉ dùng cho người chơi.");
                return true;
            }
            $this->sendCanhGioiMenu($sender);
            return true;
        }

        // Admin Commands for testing
        if ($cmdName === "addtuvi") {
            if (!$sender->hasPermission("azcanhgioi.admin")) {
                $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này.");
                return true;
            }
            if (count($args) < 2) {
                $sender->sendMessage("§cHDSD: /addtuvi <người chơi> <lượng>");
                return true;
            }
            $target = $this->getServer()->getPlayerByPrefix($args[0]);
            if ($target === null) {
                $sender->sendMessage("§cKhông tìm thấy người chơi này (hoặc người chơi không trực tuyến).");
                return true;
            }
            $targetName = $target->getName();
            $amount = (int) $args[1];

            $this->setTuvi($targetName, $this->getTuvi($targetName) + $amount);
            $sender->sendMessage("§aĐã cộng §e{$amount} §aTu vi cho §e{$targetName}§a.");
            $target->sendMessage("§aBạn được cộng §e{$amount} §aTu vi từ Admin.");
            $this->applyStats($target);
            return true;
        }

        if ($cmdName === "settuvi") {
            if (!$sender->hasPermission("azcanhgioi.admin")) {
                $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này.");
                return true;
            }
            if (count($args) < 2) {
                $sender->sendMessage("§cHDSD: /settuvi <người chơi> <lượng>");
                return true;
            }
            $target = $this->getServer()->getPlayerByPrefix($args[0]);
            if ($target === null) {
                $sender->sendMessage("§cKhông tìm thấy người chơi này (hoặc người chơi không trực tuyến).");
                return true;
            }
            $targetName = $target->getName();
            $amount = (int) $args[1];

            $this->setTuvi($targetName, $amount);
            $sender->sendMessage("§aĐã đặt Tu vi của §e{$targetName} §athành §e{$amount}§a.");
            $target->sendMessage("§aTu vi của bạn được Admin điều chỉnh thành §e{$amount}§a.");
            $this->applyStats($target);
            return true;
        }

        if ($cmdName === "setcanhgioi") {
            if (!$sender->hasPermission("azcanhgioi.admin")) {
                $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này.");
                return true;
            }
            if (count($args) < 2) {
                $sender->sendMessage("§cHDSD: /setcanhgioi <người chơi> <cấp độ (1-30)>");
                return true;
            }
            $target = $this->getServer()->getPlayerByPrefix($args[0]);
            if ($target === null) {
                $sender->sendMessage("§cKhông tìm thấy người chơi này (hoặc người chơi không trực tuyến).");
                return true;
            }
            $targetName = $target->getName();
            $tier = (int)$args[1];

            $this->setRealmTier($targetName, $tier);
            $sender->sendMessage("§aĐã đặt Cảnh giới của §e{$targetName} §athành Cấp §e{$tier}§a.");
            $target->sendMessage("§aCảnh giới của bạn được Admin thay đổi thành cấp §e{$tier}§a.");
            $this->applyStats($target);
            return true;
        }

        return false;
    }

    // --- Database API Methods ---

    public function isLoaded(Player|string $player): bool {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        return isset($this->tuviCache[$name]);
    }

    public function loadPlayer(Player|string $player): void {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (isset($this->tuviCache[$name])) {
            return;
        }

        $db = new \SQLite3($this->getDataFolder() . "data.sqlite");
        $db->busyTimeout(5000);
        $stmt = $db->prepare("SELECT tuvi, tier FROM players WHERE username = :user");
        $stmt->bindValue(":user", $name);
        $res = $stmt->execute();
        
        $row = $res->fetchArray(SQLITE3_ASSOC);
        $db->close();

        $data = $row ?: ["tuvi" => 0, "tier" => 0];
        $this->tuviCache[$name] = (int)($data["tuvi"] ?? 0);
        $this->tierCache[$name] = (int)($data["tier"] ?? 0);

        if ($player instanceof Player) {
            $this->applyStats($player);
        } else {
            $onlinePlayer = $this->getServer()->getPlayerExact($player);
            if ($onlinePlayer !== null) {
                $this->applyStats($onlinePlayer);
            }
        }
    }

    public function savePlayerData(Player|string $player): void {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (isset($this->tuviCache[$name])) {
            $db = new \SQLite3($this->getDataFolder() . "data.sqlite");
            $db->busyTimeout(5000);
            $stmt = $db->prepare("INSERT OR REPLACE INTO players (username, tuvi, tier) VALUES (:user, :tuvi, :tier)");
            $stmt->bindValue(":user", $name);
            $stmt->bindValue(":tuvi", $this->tuviCache[$name]);
            $stmt->bindValue(":tier", $this->tierCache[$name]);
            $stmt->execute();
            $db->close();
        }
    }

    public function saveAllData(): void {
        $db = new \SQLite3($this->getDataFolder() . "data.sqlite");
        $db->busyTimeout(5000);
        $db->exec("BEGIN TRANSACTION");
        $stmt = $db->prepare("INSERT OR REPLACE INTO players (username, tuvi, tier) VALUES (:user, :tuvi, :tier)");
        
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $name = strtolower($player->getName());
            if (isset($this->tuviCache[$name])) {
                $stmt->bindValue(":user", $name);
                $stmt->bindValue(":tuvi", $this->tuviCache[$name]);
                $stmt->bindValue(":tier", $this->tierCache[$name]);
                $stmt->execute();
            }
        }
        $db->exec("COMMIT");
        $db->close();
    }

    public function getTuvi(Player|string $player): int {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (!isset($this->tuviCache[$name])) {
            $this->loadPlayer($player);
        }
        return $this->tuviCache[$name] ?? 0;
    }

    public function setTuvi(Player|string $player, int $amount): void {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (!isset($this->tuviCache[$name])) {
            $this->loadPlayer($player);
        }
        if ($amount < 0) $amount = 0;
        $this->tuviCache[$name] = $amount;
    }

    public function addTuvi(Player $player, int $amount, string $action): void {
        if ($this->isFloating($player)) return; // No tuvi gains during tribulation
        $current = $this->getTuvi($player);
        $this->setTuvi($player, $current + $amount);

        $msg = str_replace(["{amount}", "{action}"], [(string)$amount, $action], $this->getConfig()->getNested("messages.gain-tuvi", "+{amount} Tu vi ({action})"));
        $player->sendActionBarMessage($msg);
    }

    public function getRealmTier(Player|string $player): int {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (!isset($this->tierCache[$name])) {
            $this->loadPlayer($player);
        }
        return $this->tierCache[$name] ?? 0;
    }

    public function setRealmTier(Player|string $player, int $tier): void {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (!isset($this->tierCache[$name])) {
            $this->loadPlayer($player);
        }
        $this->tierCache[$name] = $tier;
        $this->savePlayerData($name);
    }

    public function getPlayerRealmName(string $name): string {
        $tier = $this->getRealmTier($name);
        $realms = $this->getConfig()->get("realms", []);
        if (isset($realms[$tier])) {
            return (string)$realms[$tier]["name"];
        }
        return "§7Phàm Nhân";
    }

    public function applyStats(Player $player): void {
        $tier = $this->getRealmTier($player);
        $realms = $this->getConfig()->get("realms", []);
        $healthBoost = 0;
        if (isset($realms[$tier])) {
            $healthBoost = (int)($realms[$tier]["health-boost"] ?? 0);
        }
        $player->setMaxHealth(20 + $healthBoost);

        // Update rank tags in AZRank
        $azrank = $this->getServer()->getPluginManager()->getPlugin("AZRank");
        if ($azrank !== null && $azrank->isEnabled()) {
            /** @var \azrank\Main $azrank */
            $azrank->rank->updatePlayer($player);
        }
    }

    // --- Floating Tribulation Logic ---

    public function isFloating(Player $player): bool {
        return isset($this->floatingPlayers[$player->getName()]);
    }

    public function removeFloatingPlayer(Player $player): void {
        unset($this->floatingPlayers[$player->getName()]);
    }

    // --- GUI Menus ---

    public function sendCanhGioiMenu(Player $player): void {
        $form = new MenuForm(
            "§l§dTU TIÊN LỘ",
            "§7Hãy chọn hướng đi tu luyện của đạo hữu:",
            [
                new MenuOption("§d§lCẢNH GIỚI TU TIÊN\n§8Xem tiến độ & Đột phá cảnh giới", new FormIcon("textures/items/totem", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§e§lLÒ LUYỆN ĐAN DƯỢC\n§8Luyện chế đan dược tăng Tu vi", new FormIcon("textures/blocks/cauldron_top", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§a§lTIỆM NGUYÊN LIỆU CỔ\n§8Mua sắm linh dược", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§c§lĐÓNG GIAO DIỆN", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $submitter, int $selected): void {
                switch ($selected) {
                    case 0:
                        $this->sendBreakthroughMenu($submitter);
                        break;
                    case 1:
                        $this->sendAlchemyMenu($submitter);
                        break;
                    case 2:
                        $this->sendAntiqueShopMenu($submitter);
                        break;
                }
            }
        );
        $player->sendForm($form);
    }

    public function sendBreakthroughMenu(Player $player): void {
        $tier = $this->getRealmTier($player);
        $tuvi = $this->getTuvi($player);
        $realms = $this->getConfig()->get("realms", []);

        $realmName = $this->getPlayerRealmName($player->getName());
        $healthBoost = 0;
        $dmgMult = 1.0;

        if (isset($realms[$tier])) {
            $healthBoost = (int)($realms[$tier]["health-boost"] ?? 0);
            $dmgMult = (float)($realms[$tier]["damage-multiplier"] ?? 1.0);
        }

        $dmgPct = round(($dmgMult - 1) * 100);

        $content = "§l§dTU TIÊN CẢNH GIỚI §r§7- Tu Tiên Lộ\n\n";
        $content .= "§f- Cảnh giới hiện tại: " . $realmName . "\n";
        $content .= "§f- Tu vi hiện có: §e" . number_format($tuvi) . " Điểm\n\n";
        $content .= "§l§eĐặc Quyền Cảnh Giới:\n";
        $content .= "§r§f- Cộng thêm sinh lực: §a+" . $healthBoost . " HP §7(" . ($healthBoost / 2) . " Tim)\n";
        $content .= "§r§f- Cường hóa sát thương: §a+" . $dmgPct . "%\n\n";

        $nextTier = $tier + 1;
        $options = [];

        if (isset($realms[$nextTier])) {
            $nextData = $realms[$nextTier];
            $req = (int)($nextData["required-tuvi"] ?? 0);
            $rate = (int)($nextData["success-rate"] ?? 100);
            
            $content .= "§l§bCảnh Giới Tiếp Theo:§r " . ($nextData["name"] ?? "") . "\n";
            $content .= "§f- Yêu cầu Tu vi: §e" . number_format($req) . "\n";
            $content .= "§f- Tỷ lệ đột phá thành công: §a" . $rate . "%\n";
            
            $options[] = new MenuOption(
                "§d§lTIẾN HÀNH ĐỘT PHÁ\n§7Lên cao 3 block, vượt qua lôi kiếp 5 giây",
                new FormIcon("textures/items/totem", FormIcon::IMAGE_TYPE_PATH)
            );
        } else {
            $content .= "§l§aĐạo hữu đã đạt tới đỉnh phong Cảnh giới tu tiên của server!§r";
        }

        $options[] = new MenuOption("§c§lQUAY LẠI", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));

        $form = new MenuForm(
            "§l§dĐỘT PHÁ CẢNH GIỚI",
            $content,
            $options,
            function (Player $submitter, int $selected) use ($tier, $realms, $nextTier): void {
                if (!isset($realms[$nextTier]) || $selected === 1) {
                    $this->sendCanhGioiMenu($submitter);
                    return;
                }

                $nextData = $realms[$nextTier];
                $req = (int)($nextData["required-tuvi"] ?? 0);
                $rate = (int)($nextData["success-rate"] ?? 100);
                $currentTuvi = $this->getTuvi($submitter);
                $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§eTu Tiên§7] §r");

                if ($currentTuvi < $req) {
                    $needed = $req - $currentTuvi;
                    $submitter->sendMessage($prefix . str_replace("{needed}", (string)$needed, $this->getConfig()->getNested("messages.not-enough-tuvi", "")));
                    return;
                }

                if ($this->isFloating($submitter)) {
                    $submitter->sendMessage($prefix . "§cBạn đang trong lôi kiếp đột phá!");
                    return;
                }

                // Start Floating Breakthrough
                $this->floatingPlayers[$submitter->getName()] = true;
                $targetPos = $submitter->getPosition()->add(0, 3, 0);
                $submitter->teleport($targetPos);

                // Broadcast start to whole server
                $this->getServer()->broadcastMessage($prefix . "§fĐạo hữu §b" . $submitter->getName() . " §fđang khiêu chiến lôi kiếp để đột phá lên " . $nextData["name"] . "§f!");

                // Start Task
                $this->getScheduler()->scheduleRepeatingTask(
                    new BreakthroughTask($this, $submitter, $targetPos, $nextTier, $rate, $req),
                    1 // Run every tick
                );
            }
        );

        $player->sendForm($form);
    }

    public function sendAlchemyMenu(Player $player): void {
        $inv = $player->getInventory();
        
        $linhThao = $this->countIngredient($player, "linh_thao");
        $nhanSam = $this->countIngredient($player, "nhan_sam");
        $linhChi = $this->countIngredient($player, "linh_chi");
        $thienThach = $this->countIngredient($player, "thien_thach");

        $content = "§l§eLÒ LUYỆN ĐAN DƯỢC §r§7- Luyện chế Tu Vi Đan\n\n";
        $content .= "§fNguyên liệu hiện có trong túi:\n";
        $content .= "§r§a- Linh Thảo: §e" . $linhThao . "\n";
        $content .= "§r§6- Nhân Sâm Vạn Năm: §e" . $nhanSam . "\n";
        $content .= "§r§d- Linh Chi Ngàn Năm: §e" . $linhChi . "\n";
        $content .= "§r§c- Đá Thiên Thạch: §e" . $thienThach . "\n\n";
        $content .= "§7Chọn một công thức đan dược bên dưới để tiến hành luyện chế:";

        $form = new MenuForm(
            "§l§eLÒ LUYỆN ĐAN",
            $content,
            [
                new MenuOption("§a§lSƠ CẤP TU VI ĐAN\n§8Yêu cầu: 2 Linh Thảo (Tỷ lệ: 90%)", new FormIcon("azcanhgioi/items/rare_candy", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§e§lTRUNG CẤP TU VI ĐAN\n§8Yêu cầu: 3 Linh Thảo + 1 Nhân Sâm (Tỷ lệ: 80%)", new FormIcon("azcanhgioi/items/dynamax_candy", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§d§lCAO CẤP TU VI ĐAN\n§8Yêu cầu: 2 Nhân Sâm + 1 Linh Chi (Tỷ lệ: 65%)", new FormIcon("azcanhgioi/items/wishing_shard", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§c§lTHẦN CẤP TU VI ĐAN\n§8Yêu cầu: 2 Linh Chi + 1 Thiên Thạch (Tỷ lệ: 50%)", new FormIcon("azcanhgioi/items/wishing_star", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§c§lQUAY LẠI", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $submitter, int $selected): void {
                if ($selected === 4) {
                    $this->sendCanhGioiMenu($submitter);
                    return;
                }

                $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§eTu Tiên§7] §r");
                $linhThao = $this->countIngredient($submitter, "linh_thao");
                $nhanSam = $this->countIngredient($submitter, "nhan_sam");
                $linhChi = $this->countIngredient($submitter, "linh_chi");
                $thienThach = $this->countIngredient($submitter, "thien_thach");

                $reqs = [];
                $rate = 100;
                $pillType = "";
                $pillName = "";

                if ($selected === 0) {
                    $reqs = ["linh_thao" => 2];
                    $rate = 90;
                    $pillType = "so_cap";
                    $pillName = "§aSơ Cấp Tu Vi Đan";
                } elseif ($selected === 1) {
                    $reqs = ["linh_thao" => 3, "nhan_sam" => 1];
                    $rate = 80;
                    $pillType = "trung_cap";
                    $pillName = "§eTrung Cấp Tu Vi Đan";
                } elseif ($selected === 2) {
                    $reqs = ["nhan_sam" => 2, "linh_chi" => 1];
                    $rate = 65;
                    $pillType = "cao_cap";
                    $pillName = "§dCao Cấp Tu Vi Đan";
                } elseif ($selected === 3) {
                    $reqs = ["linh_chi" => 2, "thien_thach" => 1];
                    $rate = 50;
                    $pillType = "than_cap";
                    $pillName = "§cThần Cấp Tu Vi Đan";
                }

                // Verify ingredients
                foreach ($reqs as $type => $count) {
                    $currentCount = $this->countIngredient($submitter, $type);
                    if ($currentCount < $count) {
                        $submitter->sendMessage($prefix . "§cĐạo hữu không đủ dược liệu để luyện chế đan dược này.");
                        return;
                    }
                }

                // Deduct ingredients
                foreach ($reqs as $type => $count) {
                    $this->removeIngredient($submitter, $type, $count);
                }

                // Success Roll
                $roll = mt_rand(1, 100);
                if ($roll <= $rate) {
                    $pill = $this->getPillItem($pillType);
                    if ($submitter->getInventory()->canAddItem($pill)) {
                        $submitter->getInventory()->addItem($pill);
                    } else {
                        $submitter->getWorld()->dropItem($submitter->getPosition(), $pill);
                    }
                    $submitter->sendMessage($prefix . "§aLuyện chế thành công viên §l" . $pillName . "§r§a!");
                    $submitter->getWorld()->addSound($submitter->getPosition(), new XpLevelUpSound(20));
                } else {
                    $submitter->sendMessage($prefix . "§cĐan dược nổ lò! Luyện chế thất bại, mất sạch dược liệu.");
                    $submitter->getWorld()->addParticle($submitter->getPosition(), new ExplodeParticle());
                }
            }
        );
        $player->sendForm($form);
    }

    public function sendAntiqueShopMenu(Player $player): void {
        $economy = AZEconomy::getInstance();
        $money = $economy->getMoney($player->getName());
        $coin = 0;
        if (method_exists($economy, "getCoin")) {
            $coin = $economy->getCoin($player->getName());
        }

        $content = "§l§aTIỆM NGUYÊN LIỆU CỔ §r§7- Cung cấp linh thảo ngàn năm\n\n";
        $content .= "§fSố dư: §e" . number_format($money) . " Xu §f| §d" . number_format($coin) . " Coin\n\n";
        $content .= "§7Chọn dược liệu muốn mua:";

        $form = new MenuForm(
            "§l§aTIỆM NGUYÊN LIỆU",
            $content,
            [
                new MenuOption("§a§lLinh Thảo\n§8Giá: 10,000 Xu", new FormIcon("azcanhgioi/items/leaf_stone", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§e§lNhân Sâm Vạn Năm\n§8Giá: 30,000 Xu", new FormIcon("azcanhgioi/items/shiny_stone", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§d§lLinh Chi Ngàn Năm\n§8Giá: 50 Coin", new FormIcon("azcanhgioi/items/dusk_stone", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§c§lĐá Thiên Thạch\n§8Giá: 100 Coin", new FormIcon("azcanhgioi/items/thunder_stone", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§c§lQUAY LẠI", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $submitter, int $selected): void {
                if ($selected === 4) {
                    $this->sendCanhGioiMenu($submitter);
                    return;
                }

                $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§eTu Tiên§7] §r");
                $economy = AZEconomy::getInstance();
                
                $prices = [10000, 30000, 50, 100];
                $currencies = ["money", "money", "coin", "coin"];
                $types = ["linh_thao", "nhan_sam", "linh_chi", "thien_thach"];
                $names = ["§aLinh Thảo", "§eNhân Sâm Vạn Năm", "§dLinh Chi Ngàn Năm", "§cĐá Thiên Thạch"];

                $price = $prices[$selected];
                $currency = $currencies[$selected];
                $type = $types[$selected];
                $name = $names[$selected];

                if ($currency === "money") {
                    $currentMoney = $economy->getMoney($submitter->getName());
                    if ($currentMoney < $price) {
                        $submitter->sendMessage($prefix . "§cĐạo hữu không đủ Xu để mua dược liệu này.");
                        return;
                    }
                    if ($economy->reduceMoney($submitter->getName(), $price)) {
                        $item = $this->getIngredientItem($type);
                        if ($submitter->getInventory()->canAddItem($item)) {
                            $submitter->getInventory()->addItem($item);
                        } else {
                            $submitter->getWorld()->dropItem($submitter->getPosition(), $item);
                        }
                        $submitter->sendMessage($prefix . "§aĐã mua thành công 1 §l" . $name . " §r§avới giá §e" . number_format($price) . " Xu§a.");
                    } else {
                        $submitter->sendMessage($prefix . "§cGiao dịch thất bại.");
                    }
                } else {
                    $currentCoin = method_exists($economy, "getCoin") ? $economy->getCoin($submitter->getName()) : 0;
                    if ($currentCoin < $price) {
                        $submitter->sendMessage($prefix . "§cĐạo hữu không đủ Coin để mua dược liệu này.");
                        return;
                    }
                    if (method_exists($economy, "reduceCoin") && $economy->reduceCoin($submitter->getName(), $price)) {
                        $item = $this->getIngredientItem($type);
                        if ($submitter->getInventory()->canAddItem($item)) {
                            $submitter->getInventory()->addItem($item);
                        } else {
                            $submitter->getWorld()->dropItem($submitter->getPosition(), $item);
                        }
                        $submitter->sendMessage($prefix . "§aĐã mua thành công 1 §l" . $name . " §r§avới giá §d" . number_format($price) . " Coin§a.");
                    } else {
                        $submitter->sendMessage($prefix . "§cGiao dịch thất bại.");
                    }
                }
            }
        );
        $player->sendForm($form);
    }

    // --- Helper Methods ---

    public function countIngredient(Player $player, string $type): int {
        $inv = $player->getInventory();
        $targetItem = $this->getIngredientItem($type);
        $count = 0;
        foreach ($inv->getContents() as $item) {
            if ($item->equals($targetItem, true, false)) {
                $count += $item->getCount();
            }
        }
        return $count;
    }

    public function removeIngredient(Player $player, string $type, int $amount): void {
        $inv = $player->getInventory();
        $targetItem = $this->getIngredientItem($type);
        $removed = 0;
        foreach ($inv->getContents() as $slot => $item) {
            if ($item->equals($targetItem, true, false)) {
                $take = min($item->getCount(), $amount - $removed);
                $item->setCount($item->getCount() - $take);
                $inv->setItem($slot, $item);
                $removed += $take;
                if ($removed >= $amount) break;
            }
        }
    }

    public function getIngredientItem(string $type, int $count = 1): Item {
        $parser = StringToItemParser::getInstance();
        switch ($type) {
            case "linh_thao":
                $item = $parser->parse("az:linh_thao") ?? VanillaItems::EMERALD();
                $item->setCustomName("§a§lLinh Thảo Ngàn Năm");
                $item->setLore(["§7Sử dụng tại Lò Luyện Đan", "§7để chế tạo đan dược tăng cường Tu vi."]);
                break;
            case "nhan_sam":
                $item = $parser->parse("az:nhan_sam") ?? VanillaItems::CARROT();
                $item->setCustomName("§e§lNhân Sâm Vạn Năm");
                $item->setLore(["§7Sử dụng tại Lò Luyện Đan", "§7để chế tạo đan dược tăng cường Tu vi."]);
                break;
            case "linh_chi":
                $item = $parser->parse("az:linh_chi") ?? VanillaItems::MUSHROOM_STEW();
                $item->setCustomName("§c§lLinh Chi Ngàn Năm");
                $item->setLore(["§7Sử dụng tại Lò Luyện Đan", "§7để chế tạo đan dược tăng cường Tu vi."]);
                break;
            case "thien_thach":
                $item = $parser->parse("az:thien_thach") ?? VanillaItems::MAGMA_CREAM();
                $item->setCustomName("§d§lĐá Thiên Thạch Hoàng Kim");
                $item->setLore(["§7Sử dụng tại Lò Luyện Đan", "§7để chế tạo đan dược tăng cường Tu vi."]);
                break;
            default:
                $item = VanillaItems::PAPER();
        }
        $item->setCount($count);
        return $item;
    }

    public function getPillItem(string $type, int $count = 1): Item {
        $parser = StringToItemParser::getInstance();
        switch ($type) {
            case "so_cap":
                $item = $parser->parse("az:pill_so_cap") ?? VanillaItems::SLIME_BALL();
                $item->setCustomName("§a§lSơ Cấp Tu Vi Đan");
                $item->setLore(["§7Đan dược tăng cường sinh lực.", "§7Nhấp chuột phải để nuốt đan.", "§fNhận ngẫu nhiên: §e500 - 1,000 Tu vi"]);
                break;
            case "trung_cap":
                $item = $parser->parse("az:pill_trung_cap") ?? VanillaItems::GLOWSTONE_DUST();
                $item->setCustomName("§e§lTrung Cấp Tu Vi Đan");
                $item->setLore(["§7Đan dược tăng cường kinh mạch.", "§7Nhấp chuột phải để nuốt đan.", "§fNhận ngẫu nhiên: §e3,000 - 5,000 Tu vi"]);
                break;
            case "cao_cap":
                $item = $parser->parse("az:pill_cao_cap") ?? VanillaItems::GHAST_TEAR();
                $item->setCustomName("§c§lCao Cấp Tu Vi Đan");
                $item->setLore(["§7Đan dược tẩy tủy phạt cốt.", "§7Nhấp chuột phải để nuốt đan.", "§fNhận ngẫu nhiên: §e10,000 - 20,000 Tu vi"]);
                break;
            case "than_cap":
                $item = $parser->parse("az:pill_than_cap") ?? VanillaItems::NETHER_STAR();
                $item->setCustomName("§d§lThần Cấp Tu Vi Đan");
                $item->setLore(["§7Thần đan nghịch thiên cải mệnh.", "§7Nhấp chuột phải để nuốt đan.", "§fNhận ngẫu nhiên: §e50,000 - 100,000 Tu vi"]);
                break;
            default:
                $item = VanillaItems::PAPER();
        }
        $item->setCount($count);
        return $item;
    }

    // --- Dropped Item Physics/World Alchemy Logic ---

    private function checkGroundAlchemy(): void {
        $parser = StringToItemParser::getInstance();
        $targetLinhThao = $parser->parse("az:linh_thao");
        $targetNhanSam = $parser->parse("az:nhan_sam");
        $targetLinhChi = $parser->parse("az:linh_chi");
        $targetThienThach = $parser->parse("az:thien_thach");

        if ($targetLinhThao === null || $targetNhanSam === null || $targetLinhChi === null || $targetThienThach === null) {
            return;
        }

        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            $itemEntities = [];
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof \pocketmine\entity\object\ItemEntity) {
                    $itemEntities[] = $entity;
                }
            }

            if (empty($itemEntities)) {
                continue;
            }

            $processed = [];
            foreach ($itemEntities as $i => $entityA) {
                if (in_array($entityA->getId(), $processed, true)) {
                    continue;
                }

                $cluster = [$entityA];
                $processed[] = $entityA->getId();

                foreach ($itemEntities as $j => $entityB) {
                    if ($i === $j || in_array($entityB->getId(), $processed, true)) {
                        continue;
                    }

                    if ($entityA->getPosition()->distance($entityB->getPosition()) <= 2.0) {
                        $cluster[] = $entityB;
                        $processed[] = $entityB->getId();
                    }
                }

                $this->tryCraftCluster($world, $cluster);
            }
        }
    }

    /**
     * @param \pocketmine\world\World $world
     * @param \pocketmine\entity\object\ItemEntity[] $cluster
     */
    private function tryCraftCluster(\pocketmine\world\World $world, array $cluster): void {
        $linhThaoCount = 0;
        $nhanSamCount = 0;
        $linhChiCount = 0;
        $thienThachCount = 0;

        $linhThaoEntities = [];
        $nhanSamEntities = [];
        $linhChiEntities = [];
        $thienThachEntities = [];

        $parser = StringToItemParser::getInstance();
        $targetLinhThao = $parser->parse("az:linh_thao");
        $targetNhanSam = $parser->parse("az:nhan_sam");
        $targetLinhChi = $parser->parse("az:linh_chi");
        $targetThienThach = $parser->parse("az:thien_thach");

        foreach ($cluster as $entity) {
            $item = $entity->getItem();
            if ($item->equals($targetLinhThao, true, false)) {
                $linhThaoCount += $item->getCount();
                $linhThaoEntities[] = $entity;
            } elseif ($item->equals($targetNhanSam, true, false)) {
                $nhanSamCount += $item->getCount();
                $nhanSamEntities[] = $entity;
            } elseif ($item->equals($targetLinhChi, true, false)) {
                $linhChiCount += $item->getCount();
                $linhChiEntities[] = $entity;
            } elseif ($item->equals($targetThienThach, true, false)) {
                $thienThachCount += $item->getCount();
                $thienThachEntities[] = $entity;
            }
        }

        $recipeMatched = null;
        $pillType = "";
        $pillName = "";
        $rate = 100;

        if ($linhChiCount >= 2 && $thienThachCount >= 1) {
            $recipeMatched = ["linh_chi" => 2, "thien_thach" => 1];
            $pillType = "than_cap";
            $pillName = "§cThần Cấp Tu Vi Đan";
            $rate = 50;
        } elseif ($nhanSamCount >= 2 && $linhChiCount >= 1) {
            $recipeMatched = ["nhan_sam" => 2, "linh_chi" => 1];
            $pillType = "cao_cap";
            $pillName = "§dCao Cấp Tu Vi Đan";
            $rate = 65;
        } elseif ($linhThaoCount >= 3 && $nhanSamCount >= 1) {
            $recipeMatched = ["linh_thao" => 3, "nhan_sam" => 1];
            $pillType = "trung_cap";
            $pillName = "§eTrung Cấp Tu Vi Đan";
            $rate = 80;
        } elseif ($linhThaoCount >= 2) {
            $recipeMatched = ["linh_thao" => 2];
            $pillType = "so_cap";
            $pillName = "§aSơ Cấp Tu Vi Đan";
            $rate = 90;
        }

        if ($recipeMatched === null) {
            return;
        }

        $pos = $cluster[0]->getPosition();
        $this->getLogger()->info("§e[Tu Tiên Alchemy] Khớp công thức: " . $pillType . " tại " . $pos->getX() . ", " . $pos->getY() . ", " . $pos->getZ());

        $this->consumeGroundItems($linhThaoEntities, $recipeMatched["linh_thao"] ?? 0);
        $this->consumeGroundItems($nhanSamEntities, $recipeMatched["nhan_sam"] ?? 0);
        $this->consumeGroundItems($linhChiEntities, $recipeMatched["linh_chi"] ?? 0);
        $this->consumeGroundItems($thienThachEntities, $recipeMatched["thien_thach"] ?? 0);

        // Strike visual lightning
        $lightningId = mt_rand(1000000, 9000000);
        $lightningPacket = \pocketmine\network\mcpe\protocol\AddActorPacket::create(
            $lightningId,
            $lightningId,
            "minecraft:lightning_bolt",
            $pos->asVector3(),
            null,
            0.0, 0.0, 0.0, 0.0, [], [],
            new \pocketmine\network\mcpe\protocol\types\entity\PropertySyncData([], []),
            []
        );
        $thunderSoundPacket = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create(
            "ambient.weather.lightning.thunder",
            $pos->getX(),
            $pos->getY(),
            $pos->getZ(),
            1.5,
            1.0,
            null
        );

        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($lightningPacket);
                $p->getNetworkSession()->sendDataPacket($thunderSoundPacket);
            }
        }

        $roll = mt_rand(1, 100);
        $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§eTu Tiên§7] §r");

        if ($roll <= $rate) {
            $pill = $this->getPillItem($pillType);
            $world->dropItem($pos, $pill);

            $part = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $pos->asVector3(), "azcanhgioi:fire_explosion", null);
            $sound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("random.levelup", $pos->getX(), $pos->getY(), $pos->getZ(), 1.0, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($part);
                    $p->getNetworkSession()->sendDataPacket($sound);
                }
            }

            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distance($pos) <= 15) {
                    $p->sendMessage($prefix . "§aTrời giáng lôi kiếp! Lò luyện trời đất đúc thành công một viên §l" . $pillName . "§r§a!");
                }
            }
        } else {
            $part = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $pos->asVector3(), "minecraft:large_explosion", null);
            $sound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("random.explode", $pos->getX(), $pos->getY(), $pos->getZ(), 1.0, 0.8, null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($part);
                    $p->getNetworkSession()->sendDataPacket($sound);
                }
            }

            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distance($pos) <= 15) {
                    $p->sendMessage($prefix . "§cĐan dược nổ lò! Dược liệu rơi trên đất đã bị đánh thành tro bụi.");
                }
            }
        }
    }

    /**
     * @param \pocketmine\entity\object\ItemEntity[] $entities
     * @param int $amount
     */
    private function consumeGroundItems(array $entities, int $amount): void {
        $consumed = 0;
        foreach ($entities as $entity) {
            if ($consumed >= $amount) {
                break;
            }
            $item = $entity->getItem();
            $need = $amount - $consumed;
            $count = $item->getCount();

            $this->getLogger()->info("§e[Tu Tiên Alchemy] Tiêu thụ thực thể ID " . $entity->getId() . " (" . $item->getName() . ") - Số lượng: " . $count . ", Cần: " . $need);

            if ($count <= $need) {
                $this->getLogger()->info("§c[Tu Tiên Alchemy] Thực thể ID " . $entity->getId() . " bị xóa (flagForDespawn)");
                $entity->flagForDespawn();
                $consumed += $count;
            } else {
                $this->getLogger()->info("§a[Tu Tiên Alchemy] Thực thể ID " . $entity->getId() . " giảm số lượng còn: " . ($count - $need));
                $entity->setStackSize($count - $need);
                $consumed += $need;
            }
        }
    }

    // --- Listeners ---

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $this->loadPlayer($player);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        
        $this->removeFloatingPlayer($player);
        $this->savePlayerData($name);

        unset($this->tuviCache[$name]);
        unset($this->tierCache[$name]);
    }

    public function onMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if ($this->isFloating($player)) {
            $event->cancel();
        }
    }

    public function onItemUse(PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $class = get_class($item);
        
        if (strpos($class, "BeeAZ\\AZItemSkins\\item\\Pill") !== false) {
            $event->cancel();
            $inv = $player->getInventory();
            $inv->removeItem($item->setCount(1));
            
            $min = 0; $max = 0; $pillName = "";
            if (strpos($class, "PillSoCap") !== false) {
                $min = 500; $max = 1000;
                $pillName = "§aSơ Cấp Tu Vi Đan";
            } elseif (strpos($class, "PillTrungCap") !== false) {
                $min = 3000; $max = 5000;
                $pillName = "§eTrung Cấp Tu Vi Đan";
            } elseif (strpos($class, "PillCaoCap") !== false) {
                $min = 10000; $max = 20000;
                $pillName = "§dCao Cấp Tu Vi Đan";
            } elseif (strpos($class, "PillThanCap") !== false) {
                $min = 50000; $max = 100000;
                $pillName = "§cThần Cấp Tu Vi Đan";
            }
            
            if ($max > 0) {
                $gain = mt_rand($min, $max);
                $this->addTuvi($player, $gain, "Nuốt Đan Dược");
                
                $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(25));
                $player->getWorld()->addParticle($player->getPosition(), new HappyVillagerParticle());
                
                $player->sendMessage("§aĐã nuốt §l" . $pillName . "§r§a, hấp thu khí hải tăng §e" . number_format($gain) . " §aTu vi!");
            }
        }
    }

    /**
     * @priority MONITOR
     */
    public function onBreak(BlockBreakEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        $cfg = $this->getConfig()->get("block-break", []);
        if ($cfg["enabled"] ?? true) {
            $blocks = $cfg["blocks"] ?? [];
            if (empty($blocks) || in_array($event->getBlock()->getTypeId(), $blocks)) {
                $min = (int)($cfg["min-tuvi"] ?? 1);
                $max = (int)($cfg["max-tuvi"] ?? 2);
                $gain = mt_rand($min, $max);
                $this->addTuvi($player, $gain, "Đào Khối");
            }
        }
    }

    public function onDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        $cause = $entity->getLastDamageCause();
        if ($cause instanceof EntityDamageByEntityEvent) {
            $damager = $cause->getDamager();
            if ($damager instanceof Player) {
                $cfg = $this->getConfig()->get("entity-kill", []);
                if ($cfg["enabled"] ?? true) {
                    $min = (int)($cfg["min-tuvi"] ?? 5);
                    $max = (int)($cfg["max-tuvi"] ?? 15);
                    $gain = mt_rand($min, $max);
                    $this->addTuvi($damager, $gain, "Diệt Yêu");
                }
            }
        }
    }

    public function onDamage(EntityDamageByEntityEvent $event): void {
        $damager = $event->getDamager();
        if ($damager instanceof Player) {
            $tier = $this->getRealmTier($damager);
            $realms = $this->getConfig()->get("realms", []);
            if (isset($realms[$tier])) {
                $mult = (float)($realms[$tier]["damage-multiplier"] ?? 1.0);
                if ($mult > 1.0) {
                    $event->setBaseDamage($event->getBaseDamage() * $mult);
                }
            }
        }
    }
}
