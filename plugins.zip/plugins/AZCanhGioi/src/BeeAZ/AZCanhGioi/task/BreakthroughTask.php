<?php

declare(strict_types=1);

namespace BeeAZ\AZCanhGioi\task;

use pocketmine\scheduler\Task;
use pocketmine\player\Player;
use pocketmine\math\Vector3;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\LavaParticle;
use pocketmine\world\particle\ExplodeParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\sound\ExplodeSound;
use pocketmine\world\sound\BlazeShootSound;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\types\entity\PropertySyncData;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags;
use pocketmine\Server;
use pocketmine\color\Color;
use pocketmine\world\particle\DustParticle;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use BeeAZ\AZCanhGioi\Main;

class BreakthroughTask extends Task {

    private Main $plugin;
    private Player $player;
    private Vector3 $targetPos;
    private int $nextTier;
    private int $rate;
    private int $reqTuvi;
    private int $secondsLeft = 10;
    private int $ticks = 0;
    private bool $wasAllowFlight = false;
    private bool $wasFlying = false;

    public function __construct(Main $plugin, Player $player, Vector3 $targetPos, int $nextTier, int $rate, int $reqTuvi) {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->targetPos = $targetPos;
        $this->nextTier = $nextTier;
        $this->rate = $rate;
        $this->reqTuvi = $reqTuvi;
    }

    public function onRun(): void {
        if (!$this->player->isOnline()) {
            $this->getHandler()->cancel();
            return;
        }

        $this->ticks++;

        if ($this->ticks === 1) {
            $this->wasAllowFlight = $this->player->getAllowFlight();
            $this->wasFlying = $this->player->isFlying();
            $this->player->setAllowFlight(true);
            $this->player->setFlying(true);
            $this->player->teleport($this->targetPos);
        }

        // Spawn charging custom particle effect every 15 ticks centered on player
        $world = $this->player->getWorld();
        if ($this->ticks % 15 === 0) {
            $particleName = $this->getRealmParticle($this->nextTier);
            $pos = $this->targetPos->add(0, 0.5, 0);
            $pk = SpawnParticleEffectPacket::create(0, -1, $pos, $particleName, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($pk);
            }
            if ($this->nextTier >= 26) {
                // God realms also pulse stars
                $pkStars = SpawnParticleEffectPacket::create(0, -1, $pos, "azcanhgioi:stars", null);
                foreach ($world->getPlayers() as $p) {
                    $p->getNetworkSession()->sendDataPacket($pkStars);
                }
            }
        }

        // Action Bar Countdown & Flashing Animation (updates 20 times per second)
        $timeLeft = 10.0 - ($this->ticks / 20.0);
        if ($timeLeft < 0) $timeLeft = 0.0;
        $colors = ["§e", "§6", "§c", "§d", "§b", "§a"];
        $flashColor1 = $colors[$this->ticks % count($colors)];
        $flashColor2 = $colors[($this->ticks + 3) % count($colors)];
        $this->player->sendActionBarMessage($flashColor1 . "⚡ " . $flashColor2 . "ĐANG TIẾN HÀNH ĐỘT PHÁ CẢNH GIỚI... " . $flashColor1 . "(" . number_format($timeLeft, 1) . "s) ⚡");

        // Every 20 ticks (1 second)
        if ($this->ticks % 20 === 0) {
            $this->secondsLeft--;

            // Send player charging animation packet (visible to everyone)
            $animPacket = AnimateEntityPacket::create(
                "animation.humanoid.charging",
                "",
                "",
                0,
                "",
                0.0,
                [$this->player->getId()]
            );
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($animPacket);
            }
            
            // Strike lightning
            $lightningId = mt_rand(1000000, 9000000);
            $packet = AddActorPacket::create(
                $lightningId,
                $lightningId,
                "minecraft:lightning_bolt",
                $this->targetPos,
                null,
                0.0, // pitch
                0.0, // yaw
                0.0, // headYaw
                0.0, // bodyYaw
                [], // attributes
                [], // metadata
                new PropertySyncData([], []), // syncedProperties
                [] // links
            );
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($packet);
            }

            // Lightning & Fake Explosion Sound
            $world->addSound($this->targetPos, new ExplodeSound());

            // Fake Explosion Particles (No block damage)
            for ($i = 0; $i < 6; $i++) {
                $explodeOffset = new Vector3(
                    mt_rand(-25, 25) / 10,
                    mt_rand(-10, 30) / 10,
                    mt_rand(-25, 25) / 10
                );
                $world->addParticle($this->targetPos->add($explodeOffset->x, $explodeOffset->y, $explodeOffset->z), new ExplodeParticle());
            }

            // Titles
            $this->player->sendTitle("§e⚡ LÔI KIẾP ⚡", "§fThử thách thiên địa... §e" . $this->secondsLeft . "s", 0, 22, 0);

            if ($this->secondsLeft <= 0) {
                $this->finishBreakthrough();
                $this->getHandler()->cancel();
            }
        }
    }

    private function finishBreakthrough(): void {
        $this->plugin->removeFloatingPlayer($this->player);

        $realms = $this->plugin->getConfig()->get("realms", []);
        $nextData = $realms[$this->nextTier] ?? [];
        $prefix = $this->plugin->getConfig()->getNested("messages.prefix", "§l§7[§eTu Tiên§7] §r");

        $currentTuvi = $this->plugin->getTuvi($this->player);
        if ($currentTuvi < $this->reqTuvi) {
            $this->player->sendMessage($prefix . "§cBạn đã gián đoạn đột phá do không đủ Tu vi!");
            return;
        }

        $roll = mt_rand(1, 100);
        $world = $this->player->getWorld();
        $pos = $this->player->getPosition();

        if ($roll <= $this->rate) {
            // Success
            $this->plugin->setTuvi($this->player, $currentTuvi - $this->reqTuvi);
            $this->plugin->setRealmTier($this->player, $this->nextTier);
            $this->plugin->applyStats($this->player);

            // Custom Breakthrough Particle Burst on Success
            $world->addSound($pos, new ExplodeSound());
            $particleName = $this->getRealmParticle($this->nextTier);
            
            // Spawn multiple bursts at different heights for maximum flashiness
            $pk1 = SpawnParticleEffectPacket::create(0, -1, $pos, $particleName, null);
            $pk2 = SpawnParticleEffectPacket::create(0, -1, $pos->add(0, 1, 0), $particleName, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($pk1);
                $p->getNetworkSession()->sendDataPacket($pk2);
            }
            
            if ($this->nextTier >= 26) {
                // God realms spawn extra double bursts
                $pkStars = SpawnParticleEffectPacket::create(0, -1, $pos, "azcanhgioi:stars", null);
                $pkAurora = SpawnParticleEffectPacket::create(0, -1, $pos, "azcanhgioi:aurora", null);
                foreach ($world->getPlayers() as $p) {
                    $p->getNetworkSession()->sendDataPacket($pkStars);
                    $p->getNetworkSession()->sendDataPacket($pkAurora);
                }
            }

            // Broadcast message
            $successMsg = str_replace(
                ["{player}", "{new_realm}"],
                [$this->player->getName(), $nextData["name"] ?? ""],
                $this->plugin->getConfig()->getNested("messages.breakthrough-success", "")
            );

            // Show titles
            $this->player->sendTitle("§a§lĐỘT PHÁ THÀNH CÔNG", "§eĐã thăng tiến cảnh giới!", 10, 40, 10);
            
            // Broadcast to whole server with striking effects
            Server::getInstance()->broadcastMessage("\n§e========================================\n" . $prefix . $successMsg . "\n§e========================================\n");
        } else {
            // Failure
            $lost = (int)($this->reqTuvi * 0.15);
            $this->plugin->setTuvi($this->player, max(0, $currentTuvi - $lost));

            // Failure sound & smoke
            $world->addSound($pos, new BlazeShootSound());
            for ($i = 0; $i < 25; $i++) {
                $world->addParticle($pos->add(mt_rand(-12, 12)/10, mt_rand(0, 20)/10, mt_rand(-12, 12)/10), new FlameParticle());
                $world->addParticle($pos->add(mt_rand(-12, 12)/10, mt_rand(0, 20)/10, mt_rand(-12, 12)/10), new ExplodeParticle());
            }

            $failMsg = str_replace("{lost}", (string)$lost, $this->plugin->getConfig()->getNested("messages.breakthrough-failed", ""));
            $this->player->sendMessage($prefix . $failMsg);
            $this->player->sendTitle("§c§lĐỘT PHÁ THẤT BẠI", "§7Tâm ma quấy phá...", 10, 40, 10);
        }
    }

    private function getRealmParticle(int $tier): string {
        if ($tier >= 1 && $tier <= 3) {
            return "azcanhgioi:stars";
        } elseif ($tier >= 4 && $tier <= 6) {
            return "azcanhgioi:leaf_storm";
        } elseif ($tier >= 7 && $tier <= 9) {
            return "azcanhgioi:thunderbolt";
        } elseif ($tier >= 10 && $tier <= 12) {
            return "azcanhgioi:moonblast";
        } elseif ($tier >= 13 && $tier <= 15) {
            return "azcanhgioi:aurora";
        } elseif ($tier >= 16 && $tier <= 18) {
            return "azcanhgioi:meteor";
        } elseif ($tier >= 19 && $tier <= 21) {
            return "azcanhgioi:fire_explosion";
        } elseif ($tier >= 22 && $tier <= 25) {
            return "azcanhgioi:water_explosion";
        } else {
            return "azcanhgioi:aurora"; // God realms (Tier 26+)
        }
    }

    public function onCancel(): void {
        if ($this->player->isOnline()) {
            $this->plugin->removeFloatingPlayer($this->player);
            $this->player->setAllowFlight($this->wasAllowFlight);
            $this->player->setFlying($this->wasFlying);
        }
    }
}
