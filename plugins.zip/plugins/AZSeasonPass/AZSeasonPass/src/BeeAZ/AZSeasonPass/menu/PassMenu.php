<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass\menu;

use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\Server;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use BeeAZ\AZSeasonPass\Main;

class PassMenu {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function sendPassMenu(Player $player, string $passType) : void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        
        $title = $passType === "free" ? "§l§0VÉ THƯỜNG" : "§l§0⚡ VÉ ĐẶC BIỆT ⚡";
        $menu->setName($title);

        $inventory = $menu->getInventory();
        $name = strtolower($player->getName());
        $data = $this->plugin->getDb()->getPlayerData($name);
        $playerLevel = $data['level'];
        
        $hasPass = false;
        if($passType === "free" && in_array($data['pass_type'], [1, 3])) $hasPass = true;
        if($passType === "premium" && in_array($data['pass_type'], [2, 3])) $hasPass = true;

        $rewards = $this->plugin->getCfg()->get("rewards", []);

        $pane = StringToItemParser::getInstance()->parse("gray_stained_glass_pane");
        if($pane !== null) {
            $pane->setCustomName(" ");
            for($i = 0; $i < 54; $i++) $inventory->setItem($i, clone $pane);
        }

        foreach($rewards as $level => $rData) {
            $lvlInt = (int)$level;
            if ($lvlInt > 54) continue;
            
            if(isset($rData[$passType])) {
                $rewardItem = $this->buildRewardItem($rData[$passType], $lvlInt, $passType, $name, $playerLevel, $hasPass);
                $inventory->setItem($lvlInt - 1, $rewardItem);
            }
        }

        $menu->setListener(function(InvMenuTransaction $transaction) use ($name, $playerLevel, $hasPass, $rewards, $passType): InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $item = $transaction->getItemClicked();
            $tag = $item->getNamedTag();

            if($tag->getTag("pass_level") !== null) {
                $reqLevel = $tag->getInt("pass_level");
                $type = $tag->getString("pass_type");

                if($playerLevel < $reqLevel) {
                    $player->sendMessage("§cBạn chưa đạt cấp độ này!");
                    return $transaction->discard();
                }

                if(!$hasPass) {
                    $passNameReq = $type === "free" ? "Vé Thường" : "Vé Đặc Biệt";
                    $player->sendMessage("§cBạn phải mua $passNameReq để nhận phần quà này!");
                    return $transaction->discard();
                }

                if($this->plugin->getDb()->hasClaimed($name, $reqLevel, $type)) {
                    $player->sendMessage("§cBạn đã nhận quà này rồi!");
                    return $transaction->discard();
                }

                $this->plugin->getDb()->setClaimed($name, $reqLevel, $type);
                $rData = $rewards[$reqLevel][$type] ?? [];
                $rType = $rData["type"] ?? "none";

                if ($rType === "command") {
                    $cmd = $rData["command"] ?? "";
                    if ($cmd !== "") {
                        $cmd = str_replace("{player}", $player->getName(), $cmd);
                        $server = Server::getInstance();
                        $server->dispatchCommand(new ConsoleCommandSender($server, $server->getLanguage()), $cmd);
                    }
                    $player->sendMessage("§aĐã nhận quà cấp $reqLevel thành công!");
                    $player->removeCurrentWindow();
                } elseif ($rType === "item") {
                    $giveItem = $this->buildItem($rData);
                    if ($giveItem !== null) {
                        if ($player->getInventory()->canAddItem($giveItem)) {
                            $player->getInventory()->addItem($giveItem);
                        } else {
                            $player->getWorld()->dropItem($player->getPosition(), $giveItem);
                            $player->sendMessage("§c⚠️ Túi đồ đầy, phần thưởng rớt dưới chân!");
                        }
                        $player->sendMessage("§aĐã nhận quà cấp $reqLevel thành công!");
                        $player->removeCurrentWindow();
                    }
                }
            }
            return $transaction->discard();
        });

        $menu->send($player);
    }

    private function buildItem(array $data) : ?Item {
        $itemStr = $data["item"] ?? "dirt";
        $item = null;
        if(class_exists(\BeeAZ\AZMyItems\Main::class)) {
            $item = \BeeAZ\AZMyItems\Main::getInstance()->getItemFromConfig($itemStr);
        }
        if($item === null) {
            $item = StringToItemParser::getInstance()->parse($itemStr);
        }
        if($item === null) return null;
        
        $item = clone $item;
        $item->setCount((int)($data["amount"] ?? 1));
        
        if(isset($data["name"]) && $data["name"] !== "") {
            $item->setCustomName($data["name"]);
        }
        
        if(isset($data["lore"]) && is_array($data["lore"])) {
            $item->setLore($data["lore"]);
        }

        if(isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach($data["enchants"] as $enchantName => $level) {
                $enchantment = StringToEnchantmentParser::getInstance()->parse((string)$enchantName);
                if($enchantment !== null) {
                    $item->addEnchantment(new EnchantmentInstance($enchantment, (int)$level));
                }
            }
        }
        return $item;
    }

    private function buildRewardItem(array $data, int $level, string $type, string $username, int $playerLevel, bool $hasPass) : Item {
        $rType = $data["type"] ?? "none";
        
        if ($rType === "command") {
            $itemStr = $data["item"] ?? "paper";
            $item = StringToItemParser::getInstance()->parse($itemStr) ?? StringToItemParser::getInstance()->parse("barrier");
            $item = clone $item;
            $name = isset($data["name"]) ? $data["name"] : "§l§fQuà " . ($type === "free" ? "Vé Thường" : "Vé Đặc Biệt") . " (Lệnh)";
        } else {
            $itemStr = $data["item"] ?? "barrier";
            $item = null;
            if(class_exists(\BeeAZ\AZMyItems\Main::class)) {
                $item = \BeeAZ\AZMyItems\Main::getInstance()->getItemFromConfig($itemStr);
            }
            if($item === null) {
                $item = StringToItemParser::getInstance()->parse($itemStr);
            }
            $item = $item ?? StringToItemParser::getInstance()->parse("barrier");
            $item = clone $item;
            
            if (isset($data["name"]) && $data["name"] !== "") {
                $name = $data["name"];
            } else {
                $name = $item->hasCustomName() ? $item->getCustomName() : "§l§fQuà " . ($type === "free" ? "Vé Thường" : "Vé Đặc Biệt");
            }
        }

        if ($rType === "item") {
            $item->setCount((int)($data["amount"] ?? 1));
        }

        $lore = $item->getLore();
        if (isset($data["lore"]) && is_array($data["lore"])) {
            foreach ($data["lore"] as $line) {
                $lore[] = $line;
            }
        }

        if (isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach ($data["enchants"] as $enchantName => $levelVal) {
                $enchantment = StringToEnchantmentParser::getInstance()->parse((string)$enchantName);
                if ($enchantment !== null) {
                    $item->addEnchantment(new EnchantmentInstance($enchantment, (int)$levelVal));
                }
                $lore[] = "§r§7  - " . ucfirst($enchantName) . " " . $levelVal;
            }
        }

        $lore[] = "§r§7--------------------";
        $lore[] = "§r§7Yêu cầu cấp: §e" . $level;

        if(!$hasPass) {
            $reqName = $type === "free" ? "Vé Thường" : "Vé Đặc Biệt";
            $lore[] = "§r§c[Yêu cầu mua $reqName]";
        }

        if($playerLevel < $level) {
            $lore[] = "§r§cChưa đạt cấp";
        } elseif ($this->plugin->getDb()->hasClaimed($username, $level, $type)) {
            $lore[] = "§r§aĐã nhận";
        } else {
            $lore[] = "§r§eNhấn để nhận";
            $item->getNamedTag()->setInt("pass_level", $level);
            $item->getNamedTag()->setString("pass_type", $type);
        }

        $item->setCustomName($name);
        $item->setLore($lore);
        return $item;
    }
}