<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use muqsit\invmenu\InvMenuHandler;
use BeeAZ\AZSeasonPass\database\Database;
use BeeAZ\AZSeasonPass\listener\EventListener;
use BeeAZ\AZSeasonPass\command\SeasonCommand;

class Main extends PluginBase {

    private static self $instance;
    private Database $db;
    private Config $cfg;

    protected function onEnable() : void {
        self::$instance = $this;

        if(!InvMenuHandler::isRegistered()){
            InvMenuHandler::register($this);
        }

        date_default_timezone_set('Asia/Ho_Chi_Minh');

        $this->saveResource("config.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        
        $this->db = new Database($this->getDataFolder() . "data.sqlite");
        $this->db->init();

        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getServer()->getCommandMap()->register("azseason", new SeasonCommand($this));
    }

    public static function getInstance() : self {
        return self::$instance;
    }

    protected function onDisable() : void {
        if (isset($this->db)) {
            $this->db->saveAllCached();
        }
    }

    public function getDb() : Database {
        return $this->db;
    }

    public function getCfg() : Config {
        return $this->cfg;
    }
}