<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass\listener;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\Crops;
use BeeAZ\AZSeasonPass\Main;

class EventListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $this->plugin->getDb()->loadToCache($player->getName());
    }

    public function onQuit(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
        $this->plugin->getDb()->saveAndUnload($player->getName());
    }

    /**
     * @priority MONITOR
     */
    public function onBreak(BlockBreakEvent $event) : void {
        if($event->isCancelled()) return;

        $player = $event->getPlayer();
        $block = $event->getBlock();
        $cfg = $this->plugin->getCfg();
        $expToAdd = 0;

        if($block->hasSameTypeId(VanillaBlocks::STONE()) || $block->hasSameTypeId(VanillaBlocks::COBBLESTONE())) {
            $expToAdd = $cfg->getNested("exp.stone", 2);
        } elseif (str_contains(strtolower($block->getName()), "log") || str_contains(strtolower($block->getName()), "wood")) {
            $expToAdd = $cfg->getNested("exp.wood", 5);
        } elseif ($block instanceof Crops && $block->getAge() === $block->getMaxAge()) {
            $expToAdd = $cfg->getNested("exp.crop", 10);
        }

        if($expToAdd > 0) {
            $name = strtolower($player->getName());
            $data = $this->plugin->getDb()->getPlayerData($name);
            
            $currentLevel = $data['level'];
            $currentExp = $data['exp'] + $expToAdd;
            $maxExp = $cfg->getNested("exp.per_level", 1000);

            $leveledUp = false;
            while($currentExp >= $maxExp) {
                $currentExp -= $maxExp;
                $currentLevel++;
                $leveledUp = true;
            }

            $this->plugin->getDb()->savePlayerData($name, $currentLevel, $currentExp, $data['pass_type']);

            if($leveledUp) {
                $player->sendTitle("§l§eLEVEL UP", "§aVé Mùa: §f" . $currentLevel);
            }
        }
    }
}