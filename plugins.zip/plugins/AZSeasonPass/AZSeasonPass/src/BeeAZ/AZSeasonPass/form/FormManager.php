<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass\form;

use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\ModalForm;
use dktapps\pmforms\FormIcon;
use AZEconomy\AZEconomy;
use BeeAZ\AZSeasonPass\Main;
use BeeAZ\AZSeasonPass\menu\PassMenu;

class FormManager {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function sendMainForm(Player $player) : void {
        $name = strtolower($player->getName());
        $data = $this->plugin->getDb()->getPlayerData($name);
        
        $status = "§cChưa kích hoạt";
        if($data['pass_type'] === 1) $status = "§aVé Thường";
        elseif($data['pass_type'] === 2) $status = "§dVé Đặc Biệt";
        elseif($data['pass_type'] === 3) $status = "§aVé Thường §f& §dVé Đặc Biệt";

        $text = "§l§eTHÔNG TIN VÉ MÙA\n\n§fCấp độ hiện tại: §a" . $data['level'] . "\n§fKinh nghiệm: §e" . $data['exp'] . " / " . $this->plugin->getCfg()->getNested("exp.per_level") . "\n§fTrạng thái: " . $status;

        $form = new MenuForm(
            "§l§0VÉ MÙA",
            $text,
            [
                new MenuOption("§l§0⚡ XEM VÉ MÙA ⚡", new FormIcon("textures/items/map_empty", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ MUA VÉ MÙA ⚡", new FormIcon("textures/items/gold_ingot", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $p, int $selectedOption) : void {
                if($selectedOption === 0) {
                    $this->sendViewPassForm($p);
                } elseif ($selectedOption === 1) {
                    $this->sendShopForm($p);
                }
            },
            function(Player $p) : void {}
        );
        $player->sendForm($form);
    }

    public function sendViewPassForm(Player $player) : void {
        $form = new MenuForm(
            "§l§0XEM VÉ MÙA",
            "§fVui lòng chọn loại vé để xem và nhận phần thưởng:",
            [
                new MenuOption("§l§0⚡ VÉ THƯỜNG ⚡", new FormIcon("textures/items/book_normal", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ VÉ ĐẶC BIỆT ⚡", new FormIcon("textures/items/nether_star", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $p, int $selectedOption) : void {
                $menu = new PassMenu($this->plugin);
                if($selectedOption === 0) {
                    $menu->sendPassMenu($p, "free");
                } elseif ($selectedOption === 1) {
                    $menu->sendPassMenu($p, "premium");
                }
            },
            function(Player $p) : void {
                $this->sendMainForm($p);
            }
        );
        $player->sendForm($form);
    }

    public function sendShopForm(Player $player) : void {
        $name = strtolower($player->getName());
        $data = $this->plugin->getDb()->getPlayerData($name);

        if($data['pass_type'] === 3) {
            $player->sendMessage("§cBạn đã sở hữu toàn bộ các loại Vé Mùa rồi!");
            return;
        }

        $moneyPrice = $this->plugin->getCfg()->getNested("prices.money", 50000);
        $coinPrice = $this->plugin->getCfg()->getNested("prices.coin", 500);

        $form = new MenuForm(
            "§l§0MUA VÉ MÙA",
            "§fVui lòng chọn loại vé bạn muốn mua:",
            [
                new MenuOption("§l§0⚡ VÉ THƯỜNG ⚡\n§r§fGiá: §e" . number_format($moneyPrice) . " Xu", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ VÉ ĐẶC BIỆT ⚡\n§r§fGiá: §e" . number_format($coinPrice) . " Coin", new FormIcon("textures/items/gold_nugget", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $p, int $selectedOption) use ($moneyPrice, $coinPrice, $data) : void {
                if($selectedOption === 0) {
                    if($data['pass_type'] === 1 || $data['pass_type'] === 3) {
                        $p->sendMessage("§cBạn đã sở hữu Vé Thường rồi!");
                        return;
                    }
                    $this->sendConfirmForm($p, "normal", $moneyPrice);
                } elseif ($selectedOption === 1) {
                    if($data['pass_type'] === 2 || $data['pass_type'] === 3) {
                        $p->sendMessage("§cBạn đã sở hữu Vé Đặc Biệt rồi!");
                        return;
                    }
                    $this->sendConfirmForm($p, "premium", $coinPrice);
                }
            },
            function(Player $p) : void {
                $this->sendMainForm($p);
            }
        );
        $player->sendForm($form);
    }

    public function sendConfirmForm(Player $player, string $type, int $price) : void {
        $currencyName = $type === "normal" ? "Xu" : "Coin";
        // Để màu sáng (§a Xanh lá, §e Vàng) ở phần text nội dung cho khỏi trùng màu nền đen
        $passName = $type === "normal" ? "§l§a⚡ VÉ THƯỜNG ⚡§r§f" : "§l§e⚡ VÉ ĐẶC BIỆT ⚡§r§f";
        
        $form = new ModalForm(
            "§l§0XÁC NHẬN MUA",
            "§fBạn có chắc chắn muốn mua " . $passName . " với giá §e" . number_format($price) . " " . $currencyName . "§f không?\n\n§7Lưu ý: Vé sẽ bị làm mới (reset) khi kết thúc tháng.",
            function(Player $p, bool $choice) use ($type, $price) : void {
                if($choice) {
                    $this->processPayment($p, $type, $price);
                } else {
                    $this->sendShopForm($p);
                }
            },
            "§l§0⚡ XÁC NHẬN MUA ⚡",
            "§l§0⚡ HỦY BỎ ⚡"
        );
        $player->sendForm($form);
    }

    private function processPayment(Player $p, string $type, int $price) : void {
        $n = strtolower($p->getName());
        $d = $this->plugin->getDb()->getPlayerData($n);
        
        if(!class_exists(AZEconomy::class)) {
            $p->sendMessage("§cLỗi: Hệ thống tiền tệ không hoạt động.");
            return;
        }
        
        $eco = AZEconomy::getInstance();

        if($type === "normal") {
            if($eco->getMoney($p->getName()) >= $price) {
                $eco->reduceMoney($p->getName(), $price);
                $newPassType = $d['pass_type'] === 2 ? 3 : 1;
                $this->plugin->getDb()->savePlayerData($n, $d['level'], $d['exp'], $newPassType);
                $p->sendMessage("§aMua Vé Thường thành công!");
            } else {
                $p->sendMessage("§cBạn không đủ Xu để mua Vé Thường!");
            }
        } elseif ($type === "premium") {
            if($eco->getCoin($p->getName()) >= $price) {
                $eco->reduceCoin($p->getName(), $price);
                $newPassType = $d['pass_type'] === 1 ? 3 : 2;
                $this->plugin->getDb()->savePlayerData($n, $d['level'], $d['exp'], $newPassType);
                $p->sendMessage("§aMua Vé Đặc Biệt thành công!");
            } else {
                $p->sendMessage("§cBạn không đủ Coin để mua Vé Đặc Biệt!");
            }
        }
    }
}