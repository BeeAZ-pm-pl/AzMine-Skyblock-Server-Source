<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use BeeAZ\AZSeasonPass\Main;
use BeeAZ\AZSeasonPass\form\FormManager;

class SeasonCommand extends Command {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("vemua", "Mở hệ thống Vé Mùa", "/vemua", ["azseason"]);
        $this->setPermission("azseason.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : bool {
        if(!$sender instanceof Player) return false;
        
        $formManager = new FormManager($this->plugin);
        $formManager->sendMainForm($sender);
        
        return true;
    }
}