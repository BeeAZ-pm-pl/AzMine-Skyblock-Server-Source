<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass\database;

use \SQLite3;

class Database {

    private SQLite3 $db;

    public function __construct(string $path) {
        $this->db = new SQLite3($path);
    }

    public function init() : void {
        $this->db->exec("CREATE TABLE IF NOT EXISTS players (username TEXT PRIMARY KEY, level INTEGER, exp INTEGER, pass_type INTEGER, last_month TEXT)");
        $this->db->exec("CREATE TABLE IF NOT EXISTS claims (username TEXT, level INTEGER, type TEXT, PRIMARY KEY(username, level, type))");
    }

    public function checkAndResetMonthly(string $username) : void {
        $currentMonth = date("m-Y");
        $stmt = $this->db->prepare("SELECT last_month FROM players WHERE username = :user");
        $stmt->bindValue(":user", $username);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);

        if($row === false) {
            $insert = $this->db->prepare("INSERT INTO players (username, level, exp, pass_type, last_month) VALUES (:user, 1, 0, 0, :month)");
            $insert->bindValue(":user", $username);
            $insert->bindValue(":month", $currentMonth);
            $insert->execute();
        } else {
            if($row['last_month'] !== $currentMonth) {
                $update = $this->db->prepare("UPDATE players SET level = 1, exp = 0, pass_type = 0, last_month = :month WHERE username = :user");
                $update->bindValue(":user", $username);
                $update->bindValue(":month", $currentMonth);
                $update->execute();

                $del = $this->db->prepare("DELETE FROM claims WHERE username = :user");
                $del->bindValue(":user", $username);
                $del->execute();
            }
        }
    }

    private array $cache = [];

    public function loadToCache(string $username) : void {
        $username = strtolower($username);
        $this->checkAndResetMonthly($username);
        $stmt = $this->db->prepare("SELECT * FROM players WHERE username = :user");
        $stmt->bindValue(":user", $username);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);
        if($row !== false) {
            $this->cache[$username] = $row;
        }
    }

    public function saveFromCache(string $username) : void {
        $username = strtolower($username);
        if(isset($this->cache[$username])) {
            $data = $this->cache[$username];
            $stmt = $this->db->prepare("UPDATE players SET level = :lvl, exp = :exp, pass_type = :pass WHERE username = :user");
            $stmt->bindValue(":lvl", $data['level']);
            $stmt->bindValue(":exp", $data['exp']);
            $stmt->bindValue(":pass", $data['pass_type']);
            $stmt->bindValue(":user", $username);
            $stmt->execute();
        }
    }

    public function saveAndUnload(string $username) : void {
        $username = strtolower($username);
        if(isset($this->cache[$username])) {
            $this->saveFromCache($username);
            unset($this->cache[$username]);
        }
    }

    public function saveAllCached() : void {
        foreach(array_keys($this->cache) as $username) {
            $this->saveFromCache($username);
        }
        $this->cache = [];
    }

    public function getPlayerData(string $username) : array {
        $username = strtolower($username);
        if(!isset($this->cache[$username])) {
            $this->loadToCache($username);
        }
        return $this->cache[$username];
    }

    public function savePlayerData(string $username, int $level, int $exp, int $passType) : void {
        $username = strtolower($username);
        $this->cache[$username] = [
            'username' => $username,
            'level' => $level,
            'exp' => $exp,
            'pass_type' => $passType,
            'last_month' => date("m-Y")
        ];
    }


    public function hasClaimed(string $username, int $level, string $type) : bool {
        $stmt = $this->db->prepare("SELECT 1 FROM claims WHERE username = :user AND level = :lvl AND type = :type");
        $stmt->bindValue(":user", $username);
        $stmt->bindValue(":lvl", $level);
        $stmt->bindValue(":type", $type);
        $res = $stmt->execute();
        return $res->fetchArray(SQLITE3_ASSOC) !== false;
    }

    public function setClaimed(string $username, int $level, string $type) : void {
        $stmt = $this->db->prepare("INSERT OR IGNORE INTO claims (username, level, type) VALUES (:user, :lvl, :type)");
        $stmt->bindValue(":user", $username);
        $stmt->bindValue(":lvl", $level);
        $stmt->bindValue(":type", $type);
        $stmt->execute();
    }
}