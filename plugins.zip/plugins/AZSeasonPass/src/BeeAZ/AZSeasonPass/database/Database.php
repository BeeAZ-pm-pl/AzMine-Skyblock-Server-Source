<?php

declare(strict_types=1);

namespace BeeAZ\AZSeasonPass\database;

use \SQLite3;

class Database {

    private SQLite3 $db;

    public function __construct(string $path) {
        $this->db = new SQLite3($path);
    }

    public function init() : void {
        $this->db->exec("CREATE TABLE IF NOT EXISTS players (username TEXT PRIMARY KEY, level INTEGER, exp INTEGER, pass_type INTEGER, last_month TEXT)");
        $this->db->exec("CREATE TABLE IF NOT EXISTS claims (username TEXT, level INTEGER, type TEXT, PRIMARY KEY(username, level, type))");
    }

    public function checkAndResetMonthly(string $username) : void {
        $currentMonth = date("m-Y");
        $stmt = $this->db->prepare("SELECT last_month FROM players WHERE username = :user");
        $stmt->bindValue(":user", $username);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);

        if($row === false) {
            $insert = $this->db->prepare("INSERT INTO players (username, level, exp, pass_type, last_month) VALUES (:user, 1, 0, 0, :month)");
            $insert->bindValue(":user", $username);
            $insert->bindValue(":month", $currentMonth);
            $insert->execute();
        } else {
            if($row['last_month'] !== $currentMonth) {
                $update = $this->db->prepare("UPDATE players SET level = 1, exp = 0, pass_type = 0, last_month = :month WHERE username = :user");
                $update->bindValue(":user", $username);
                $update->bindValue(":month", $currentMonth);
                $update->execute();

                $del = $this->db->prepare("DELETE FROM claims WHERE username = :user");
                $del->bindValue(":user", $username);
                $del->execute();
            }
        }
    }

    public function getPlayerData(string $username) : array {
        $this->checkAndResetMonthly($username);
        $stmt = $this->db->prepare("SELECT * FROM players WHERE username = :user");
        $stmt->bindValue(":user", $username);
        $res = $stmt->execute();
        return $res->fetchArray(SQLITE3_ASSOC);
    }

    public function savePlayerData(string $username, int $level, int $exp, int $passType) : void {
        $stmt = $this->db->prepare("UPDATE players SET level = :lvl, exp = :exp, pass_type = :pass WHERE username = :user");
        $stmt->bindValue(":lvl", $level);
        $stmt->bindValue(":exp", $exp);
        $stmt->bindValue(":pass", $passType);
        $stmt->bindValue(":user", $username);
        $stmt->execute();
    }

    public function hasClaimed(string $username, int $level, string $type) : bool {
        $stmt = $this->db->prepare("SELECT 1 FROM claims WHERE username = :user AND level = :lvl AND type = :type");
        $stmt->bindValue(":user", $username);
        $stmt->bindValue(":lvl", $level);
        $stmt->bindValue(":type", $type);
        $res = $stmt->execute();
        return $res->fetchArray(SQLITE3_ASSOC) !== false;
    }

    public function setClaimed(string $username, int $level, string $type) : void {
        $stmt = $this->db->prepare("INSERT OR IGNORE INTO claims (username, level, type) VALUES (:user, :lvl, :type)");
        $stmt->bindValue(":user", $username);
        $stmt->bindValue(":lvl", $level);
        $stmt->bindValue(":type", $type);
        $stmt->execute();
    }
}