<?php

declare(strict_types=1);

namespace BeeAZ\AZMyItems\ui;

use BeeAZ\AZMyItems\Main;
use pocketmine\player\Player;
use pocketmine\Server;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\FormIcon;
use function count;
use function explode;
use function implode;
use function is_numeric;
use function max;
use function str_replace;

class MyItemsUI {

    /**
     * Open the main menu for AZMyItems
     */
    public static function openMainMenu(Player $player): void {
        $options = [
            new MenuOption("§l§1ĐỔI TÊN VẬT PHẨM\n§r§8Thay đổi tên hiển thị", new FormIcon("textures/items/feather", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§bĐỔI MÔ TẢ (LORE)\n§r§8Thay đổi lore của vật phẩm", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§aLƯU VẬT PHẨM MỚI\n§r§8Lưu vật phẩm đang cầm vào cấu hình", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§6KHO VẬT PHẨM ĐÃ LƯU\n§r§8Xem, lấy hoặc xóa vật phẩm", new FormIcon("textures/items/chest", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§6QUẢN LÝ VẬT PHẨM AZMYITEMS",
            "§fChào mừng bạn đến với hệ thống quản lý vật phẩm của máy chủ.\n\n§eChọn chức năng bạn muốn thực hiện:",
            $options,
            function(Player $submitter, int $selected): void {
                switch ($selected) {
                    case 0:
                        self::openSetNameForm($submitter);
                        break;
                    case 1:
                        self::openSetLoreForm($submitter);
                        break;
                    case 2:
                        self::openSaveItemForm($submitter);
                        break;
                    case 3:
                        self::openSavedItemsMenu($submitter);
                        break;
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * Form to change the hand item's display name
     */
    public static function openSetNameForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage("§c[AZMyItems] Bạn phải cầm một vật phẩm trên tay để chỉnh sửa!");
            return;
        }

        $currentName = $item->hasCustomName() ? str_replace("§", "&", $item->getCustomName()) : "";

        $form = new CustomForm(
            "§l§1ĐỔI TÊN VẬT PHẨM",
            [
                new Label("info", "§7Cầm vật phẩm cần đổi tên trên tay trước khi thực hiện.\n\n§fTên hiển thị hiện tại: §r" . $item->getName() . "\n"),
                new Input("name", "§eNhập tên hiển thị mới (Hỗ trợ mã màu &):", "Ví dụ: &e&lKiếm Thần Vô Song", $currentName)
            ],
            function(Player $submitter, CustomFormResponse $response): void {
                $item = $submitter->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $submitter->sendMessage("§c[AZMyItems] Bạn phải cầm một vật phẩm trên tay để chỉnh sửa!");
                    return;
                }

                $name = $response->getString("name");
                $formattedName = str_replace("&", "§", $name);
                $item->setCustomName($formattedName);
                $submitter->getInventory()->setItemInHand($item);
                $submitter->sendMessage("§a[AZMyItems] Đã đổi tên vật phẩm thành: " . $formattedName);
            },
            function(Player $submitter): void {
                self::openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Form to change the hand item's lore
     */
    public static function openSetLoreForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage("§c[AZMyItems] Bạn phải cầm một vật phẩm trên tay để chỉnh sửa!");
            return;
        }

        $loreLines = [];
        foreach ($item->getLore() as $line) {
            $loreLines[] = str_replace("§", "&", $line);
        }
        $currentLore = implode("|", $loreLines);

        $form = new CustomForm(
            "§l§bĐỔI MÔ TẢ (LORE)",
            [
                new Label("info", "§7Nhập mô tả của vật phẩm. Phân tách các dòng bằng ký tự §c|§7.\n"),
                new Input("lore", "§eNhập lore mới (Hỗ trợ mã màu & và xuống dòng bằng |):", "Ví dụ: Dòng 1|&bDòng 2|&eDòng 3", $currentLore)
            ],
            function(Player $submitter, CustomFormResponse $response): void {
                $item = $submitter->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $submitter->sendMessage("§c[AZMyItems] Bạn phải cầm một vật phẩm trên tay để chỉnh sửa!");
                    return;
                }

                $loreStr = $response->getString("lore");
                $lines = explode("|", $loreStr);
                $formattedLore = [];
                foreach ($lines as $line) {
                    $formattedLore[] = str_replace("&", "§", $line);
                }
                $item->setLore($formattedLore);
                $submitter->getInventory()->setItemInHand($item);
                $submitter->sendMessage("§a[AZMyItems] Đã cập nhật dòng mô tả (lore) của vật phẩm.");
            },
            function(Player $submitter): void {
                self::openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Form to save the hand item to config
     */
    public static function openSaveItemForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage("§c[AZMyItems] Bạn phải cầm một vật phẩm trên tay để lưu!");
            return;
        }

        $form = new CustomForm(
            "§l§aLƯU VẬT PHẨM VÀO FILE",
            [
                new Label("info", "§7Hệ thống sẽ quét vật phẩm đang trên tay bạn bao gồm: Tên hiển thị, Lore, Enchantments và toàn bộ thẻ NBT để lưu vào items.yml.\n"),
                new Input("key", "§eNhập phím lưu (Key viết liền không dấu, dùng để lấy vật phẩm sau này):", "Ví dụ: kiem_sieu_cap")
            ],
            function(Player $submitter, CustomFormResponse $response): void {
                $item = $submitter->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $submitter->sendMessage("§c[AZMyItems] Bạn phải cầm một vật phẩm trên tay để lưu!");
                    return;
                }

                $key = $response->getString("key");
                if ($key === "") {
                    $submitter->sendMessage("§c[AZMyItems] Phím lưu không được để trống!");
                    return;
                }

                Main::getInstance()->saveItemToConfig($key, $item);
                $submitter->sendMessage("§a[AZMyItems] Đã lưu thành công vật phẩm với key: §e{$key}§a.");
            },
            function(Player $submitter): void {
                self::openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Show list of all saved items
     */
    public static function openSavedItemsMenu(Player $player): void {
        $config = Main::getInstance()->getItemsConfig();
        $keys = $config->getAll();

        if (count($keys) === 0) {
            $options = [new MenuOption("§l§cCHƯA CÓ VẬT PHẨM NÀO")] ;
            $form = new MenuForm(
                "§l§6DANH SÁCH VẬT PHẨM ĐÃ LƯU",
                "§cHiện tại chưa có vật phẩm nào được lưu trữ trong items.yml.",
                $options,
                function(Player $submitter, int $selected): void {
                    self::openMainMenu($submitter);
                },
                function(Player $submitter): void {
                    self::openMainMenu($submitter);
                }
            );
            $player->sendForm($form);
            return;
        }

        $options = [];
        $keyIndexMap = [];
        $i = 0;
        foreach ($keys as $key => $data) {
            $customName = isset($data["name"]) && $data["name"] !== "" ? str_replace("&", "§", $data["name"]) : $key;
            $itemId = $data["id"] ?? "Không rõ";
            
            $options[] = new MenuOption("§l§eKey: §d{$key}\n§r§8Tên: §f" . $customName . " §8| ID: §7" . $itemId, new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH));
            $keyIndexMap[$i] = $key;
            $i++;
        }

        $form = new MenuForm(
            "§l§6KHO VẬT PHẨM ĐÃ LƯU",
            "§fChọn một vật phẩm trong kho để Lấy (Take) hoặc Xóa khỏi cấu hình:",
            $options,
            function(Player $submitter, int $selected) use ($keyIndexMap): void {
                if (isset($keyIndexMap[$selected])) {
                    $key = $keyIndexMap[$selected];
                    self::openItemActionMenu($submitter, $key);
                }
            },
            function(Player $submitter): void {
                self::openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Actions for a specific item
     */
    public static function openItemActionMenu(Player $player, string $key): void {
        $config = Main::getInstance()->getItemsConfig();
        $data = $config->get($key);
        $customName = isset($data["name"]) && $data["name"] !== "" ? str_replace("&", "§", $data["name"]) : $key;

        $options = [
            new MenuOption("§l§aLẤY VẬT PHẨM (TAKE)", new FormIcon("textures/ui/arrow_active", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§cXÓA VẬT PHẨM (DELETE)", new FormIcon("textures/ui/realms_red_x", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§0◀ QUAY LẠI", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§5VẬT PHẨM: " . $key,
            "§eThông tin chi tiết:\n" .
            "§f- Phím lưu: §a{$key}\n" .
            "§f- Tên hiển thị: §r" . $customName . "\n" .
            "§f- Loại vật phẩm: §7" . ($data["id"] ?? "Không rõ") . "\n\n" .
            "§7Chọn một hành động bên dưới:",
            $options,
            function(Player $submitter, int $selected) use ($key): void {
                switch ($selected) {
                    case 0:
                        self::openTakeItemInputForm($submitter, $key);
                        break;
                    case 1:
                        // Delete item
                        $config = Main::getInstance()->getItemsConfig();
                        $config->remove($key);
                        $config->save();
                        $submitter->sendMessage("§a[AZMyItems] Đã xóa thành công vật phẩm có key: §e{$key}§a.");
                        self::openSavedItemsMenu($submitter);
                        break;
                    case 2:
                        self::openSavedItemsMenu($submitter);
                        break;
                }
            },
            function(Player $submitter): void {
                self::openSavedItemsMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Input count and target for TakeItem
     */
    public static function openTakeItemInputForm(Player $player, string $key): void {
        $form = new CustomForm(
            "§l§aLẤY VẬT PHẨM: " . $key,
            [
                new Input("player", "§eTên người nhận (để trống nếu tự lấy):", "Nhập tên người chơi...", $player->getName()),
                new Input("amount", "§eNhập số lượng:", "Mặc định: 1", "1")
            ],
            function(Player $submitter, CustomFormResponse $response) use ($key): void {
                $targetName = $response->getString("player");
                $amountStr = $response->getString("amount");

                $targetPlayer = Server::getInstance()->getPlayerByPrefix($targetName);
                if ($targetPlayer === null) {
                    $submitter->sendMessage("§c[AZMyItems] Không tìm thấy người chơi trực tuyến: {$targetName}");
                    return;
                }

                $amount = 1;
                if ($amountStr !== "" && is_numeric($amountStr)) {
                    $amount = max(1, (int)$amountStr);
                }

                $item = Main::getInstance()->getItemFromConfig($key);
                if ($item === null) {
                    $submitter->sendMessage("§c[AZMyItems] Lỗi: Không thể lấy vật phẩm này!");
                    return;
                }

                $item->setCount($amount);

                if ($targetPlayer->getInventory()->canAddItem($item)) {
                    $targetPlayer->getInventory()->addItem($item);
                    $submitter->sendMessage("§a[AZMyItems] Đã trao §ex{$amount} §avật phẩm §e{$key} §acho §e" . $targetPlayer->getName() . "§a.");
                    if ($targetPlayer->getName() !== $submitter->getName()) {
                        $targetPlayer->sendMessage("§aBạn nhận được §ex{$amount} §avật phẩm §e{$key} §atừ quản trị viên.");
                    }
                } else {
                    $submitter->sendMessage("§c[AZMyItems] Rương đồ của người chơi " . $targetPlayer->getName() . " đã đầy!");
                }
            },
            function(Player $submitter) use ($key): void {
                self::openItemActionMenu($submitter, $key);
            }
        );

        $player->sendForm($form);
    }
}
