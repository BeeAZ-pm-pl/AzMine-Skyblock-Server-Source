<?php

declare(strict_types=1);

namespace BeeAZ\AZMyItems\command;

use BeeAZ\AZMyItems\Main;
use BeeAZ\AZMyItems\ui\MyItemsUI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use function count;
use function explode;
use function implode;
use function is_numeric;
use function max;
use function str_replace;

class MyItemsCommand extends Command {

    public function __construct(string $name, string $description = "", string $usageMessage = null, array $aliases = []) {
        parent::__construct($name, $description, $usageMessage, $aliases);
        
        // Match permissions based on command name
        $this->setPermission("azmyitems.command." . $name);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) {
            return true;
        }

        switch ($this->getName()) {
            case "setname":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
                    return true;
                }
                if (count($args) < 1) {
                    $sender->sendMessage("§cCách dùng: /setname <tên vật phẩm>");
                    return true;
                }
                
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage("§cBạn phải cầm một vật phẩm trên tay!");
                    return true;
                }
                
                $name = implode(" ", $args);
                $formattedName = str_replace("&", "§", $name);
                $item->setCustomName($formattedName);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§a[AZMyItems] Đã đổi tên vật phẩm thành: " . $formattedName);
                break;

            case "setlore":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
                    return true;
                }
                if (count($args) < 1) {
                    $sender->sendMessage("§cCách dùng: /setlore <dòng 1|dòng 2|dòng 3...>");
                    return true;
                }
                
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage("§cBạn phải cầm một vật phẩm trên tay!");
                    return true;
                }
                
                $loreString = implode(" ", $args);
                $lines = explode("|", $loreString);
                $formattedLore = [];
                foreach ($lines as $line) {
                    $formattedLore[] = str_replace("&", "§", $line);
                }
                $item->setLore($formattedLore);
                $sender->getInventory()->setItemInHand($item);
                $sender->sendMessage("§a[AZMyItems] Đã cập nhật dòng mô tả (lore) của vật phẩm.");
                break;

            case "saveitem":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
                    return true;
                }
                if (count($args) < 1) {
                    $sender->sendMessage("§cCách dùng: /saveitem <tên_phím_lưu>");
                    return true;
                }
                
                $item = $sender->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $sender->sendMessage("§cBạn phải cầm một vật phẩm trên tay!");
                    return true;
                }
                
                $key = $args[0];
                Main::getInstance()->saveItemToConfig($key, $item);
                $sender->sendMessage("§a[AZMyItems] Đã lưu thành công vật phẩm với key: §e{$key}§a.");
                break;

            case "takeitem":
                if (count($args) < 1) {
                    $sender->sendMessage("§cCách dùng: /takeitem <tên_phím_lưu> [người chơi] [số lượng]");
                    return true;
                }
                
                $key = $args[0];
                $targetPlayer = $sender;
                
                if (isset($args[1])) {
                    $targetPlayer = Server::getInstance()->getPlayerByPrefix($args[1]);
                    if ($targetPlayer === null) {
                        $sender->sendMessage("§cKhông tìm thấy người chơi: {$args[1]}");
                        return true;
                    }
                }
                
                if (!$targetPlayer instanceof Player) {
                    $sender->sendMessage("§cVui lòng chỉ định người chơi nhận vật phẩm.");
                    return true;
                }
                
                $amount = 1;
                if (isset($args[2]) && is_numeric($args[2])) {
                    $amount = max(1, (int)$args[2]);
                }
                
                $item = Main::getInstance()->getItemFromConfig($key);
                if ($item === null) {
                    $sender->sendMessage("§cKhông tìm thấy vật phẩm có key: §e{$key} §ctrong cấu hình.");
                    return true;
                }
                
                $item->setCount($amount);
                
                if ($targetPlayer->getInventory()->canAddItem($item)) {
                    $targetPlayer->getInventory()->addItem($item);
                    $sender->sendMessage("§a[AZMyItems] Đã trao §ex{$amount} §avật phẩm §e{$key} §acho §e" . $targetPlayer->getName() . "§a.");
                    if ($targetPlayer->getName() !== $sender->getName()) {
                        $targetPlayer->sendMessage("§aBạn nhận được §ex{$amount} §avật phẩm §e{$key} §atừ quản trị viên.");
                    }
                } else {
                    $sender->sendMessage("§cTúi đồ của người chơi §e" . $targetPlayer->getName() . " §cđã đầy!");
                }
                break;

            case "myitems":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
                    return true;
                }
                MyItemsUI::openMainMenu($sender);
                break;
        }

        return true;
    }
}
