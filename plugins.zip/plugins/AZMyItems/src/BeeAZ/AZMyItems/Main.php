<?php

declare(strict_types=1);

namespace BeeAZ\AZMyItems;

use BeeAZ\AZMyItems\command\MyItemsCommand;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\utils\SingletonTrait;
use pocketmine\item\Item;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\StringToItemParser;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

class Main extends PluginBase {
    use SingletonTrait;

    private Config $itemsConfig;
    private static ?array $enchantmentNameMap = null;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveResource("items.yml");
        $this->itemsConfig = new Config($this->getDataFolder() . "items.yml", Config::YAML);

        // Unregister conflicting commands first
        $commandMap = $this->getServer()->getCommandMap();
        $conflictingCommands = ["setname", "setlore"];
        foreach ($conflictingCommands as $cmdName) {
            $existingCmd = $commandMap->getCommand($cmdName);
            if ($existingCmd !== null) {
                $commandMap->unregister($existingCmd);
            }
        }

        // Register Commands
        $commandMap->registerAll("azmyitems", [
            new MyItemsCommand("setname", "Đổi tên vật phẩm custom", "/setname <tên>", ["iname", "setnamecustom", "setitemname"]),
            new MyItemsCommand("setlore", "Đổi lore vật phẩm custom", "/setlore <lore>", ["ilore", "setlorecustom", "setitemlore"]),
            new MyItemsCommand("saveitem", "Lưu vật phẩm custom vào danh sách", "/saveitem <key>"),
            new MyItemsCommand("takeitem", "Lấy vật phẩm custom từ danh sách", "/takeitem <key>"),
            new MyItemsCommand("myitems", "Mở giao diện quản lý vật phẩm custom", "/myitems")
        ]);

        $this->getLogger()->info("§aAZMyItems đã khởi chạy thành công!");
    }

    public function getItemsConfig(): Config {
        return $this->itemsConfig;
    }

    /**
     * Get the string alias of an enchantment type
     */
    public static function getEnchantmentName(Enchantment $enchantment): string {
        if (self::$enchantmentNameMap === null) {
            self::$enchantmentNameMap = [];
            $aliases = [
                "blast_protection", "efficiency", "feather_falling", "fire_aspect",
                "fire_protection", "flame", "fortune", "frost_walker", "infinity",
                "knockback", "mending", "power", "projectile_protection", "protection",
                "punch", "respiration", "aqua_affinity", "sharpness", "silk_touch",
                "swift_sneak", "thorns", "unbreaking", "vanishing"
            ];
            foreach ($aliases as $alias) {
                $ench = StringToEnchantmentParser::getInstance()->parse($alias);
                if ($ench !== null) {
                    $id = EnchantmentIdMap::getInstance()->toId($ench);
                    self::$enchantmentNameMap[$id] = $alias;
                }
            }
        }
        
        $id = EnchantmentIdMap::getInstance()->toId($enchantment);
        return self::$enchantmentNameMap[$id] ?? (string)$id;
    }

    /**
     * Save an Item object to the config under a key
     */
    public function saveItemToConfig(string $key, Item $item): void {
        $data = [];
        
        // Find string ID
        $stringId = "minecraft:air";
        $aliases = StringToItemParser::getInstance()->lookupAliases($item);
        if (count($aliases) > 0) {
            $stringId = $aliases[0];
        }
        $data["id"] = $stringId;
        
        // Basic properties
        $data["name"] = $item->hasCustomName() ? str_replace("§", "&", $item->getCustomName()) : "";
        
        $lore = [];
        foreach ($item->getLore() as $line) {
            $lore[] = str_replace("§", "&", $line);
        }
        $data["lore"] = $lore;
        $data["count"] = $item->getCount();
        
        // Enchantments
        $enchants = [];
        foreach ($item->getEnchantments() as $enchInstance) {
            $enchName = self::getEnchantmentName($enchInstance->getType());
            $enchants[$enchName] = $enchInstance->getLevel();
        }
        $data["enchants"] = $enchants;
        
        // Base64 NBT representation
        $serializer = new LittleEndianNbtSerializer();
        $bytes = $serializer->write(new TreeRoot($item->nbtSerialize()));
        $data["nbt_b64"] = base64_encode($bytes);

        $this->itemsConfig->set($key, $data);
        $this->itemsConfig->save();
    }

    /**
     * Load an Item object from config by key
     */
    public function getItemFromConfig(string $key): ?Item {
        if (!$this->itemsConfig->exists($key)) {
            return null;
        }
        $data = $this->itemsConfig->get($key);
        if (!is_array($data)) {
            return null;
        }
        
        // Try to decode NBT Base64 first
        if (isset($data["nbt_b64"]) && is_string($data["nbt_b64"]) && $data["nbt_b64"] !== "") {
            try {
                $bytes = base64_decode($data["nbt_b64"], true);
                if ($bytes !== false) {
                    $nbtTree = (new LittleEndianNbtSerializer())->read($bytes);
                    $item = Item::nbtDeserialize($nbtTree->mustGetCompoundTag());
                    
                    if (isset($data["count"])) {
                        $item->setCount((int)$data["count"]);
                    }
                    // Soft-dependency: rebuild lore cho AZCustomEnchants
                    if (class_exists(\BeeAZ\AZCustomEnchants\manager\StatsManager::class)) {
                        \BeeAZ\AZCustomEnchants\manager\StatsManager::checkAndRebuildLore($item);
                    }
                    return $item;
                }
            } catch (\Throwable $e) {
                $this->getLogger()->warning("Lỗi phục hồi NBT cho phím '{$key}': " . $e->getMessage() . ". Chuyển sang dịch chay bằng chữ.");
            }
        }
        
        // Fallback to text properties parsing
        if (!isset($data["id"])) {
            return null;
        }
        $itemId = (string)$data["id"];
        $item = StringToItemParser::getInstance()->parse($itemId);
        if ($item === null) {
            return null;
        }
        
        if (isset($data["count"])) {
            $item->setCount((int)$data["count"]);
        }
        
        if (isset($data["name"]) && is_string($data["name"]) && $data["name"] !== "") {
            $item->setCustomName(str_replace("&", "§", $data["name"]));
        }
        
        if (isset($data["lore"]) && is_array($data["lore"])) {
            $lore = [];
            foreach ($data["lore"] as $line) {
                $lore[] = str_replace("&", "§", (string)$line);
            }
            $item->setLore($lore);
        }
        
        if (isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach ($data["enchants"] as $enchName => $level) {
                $ench = StringToEnchantmentParser::getInstance()->parse((string)$enchName);
                if ($ench === null) {
                    $normalized = str_replace(" ", "_", (string)$enchName);
                    $ench = StringToEnchantmentParser::getInstance()->parse($normalized);
                }
                if ($ench === null) {
                    $ench = StringToEnchantmentParser::getInstance()->parse(strtolower((string)$enchName));
                }
                if ($ench === null) {
                    $ench = StringToEnchantmentParser::getInstance()->parse(strtolower(str_replace(" ", "_", (string)$enchName)));
                }
                if ($ench === null && class_exists(\DaPigGuy\PiggyCustomEnchants\CustomEnchantManager::class)) {
                    $ench = \DaPigGuy\PiggyCustomEnchants\CustomEnchantManager::getEnchantmentByName((string)$enchName);
                }
                if ($ench === null && is_numeric($enchName)) {
                    try {
                        $ench = EnchantmentIdMap::getInstance()->fromId((int)$enchName);
                    } catch (\InvalidArgumentException $e) {}
                }
                if ($ench !== null) {
                    $item->addEnchantment(new EnchantmentInstance($ench, (int)$level));
                }
            }
        }
        // Soft-dependency: rebuild lore cho AZCustomEnchants nếu plugin đang load
        if (class_exists(\BeeAZ\AZCustomEnchants\manager\StatsManager::class)) {
            \BeeAZ\AZCustomEnchants\manager\StatsManager::checkAndRebuildLore($item);
        }
        
        return $item;
    }
}
