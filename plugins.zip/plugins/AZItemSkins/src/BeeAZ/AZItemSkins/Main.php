<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use pocketmine\world\sound\AnvilUseSound;
use pocketmine\world\sound\XpLevelUpSound;
use AZEconomy\AZEconomy;
use BeeAZ\AZItemSkins\task\DatabaseSaveTask;
use BeeAZ\AZItemSkins\item\CustomItemRegister;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\StartGamePacket;
use pocketmine\network\mcpe\protocol\ResourcePackStackPacket;
use pocketmine\network\mcpe\protocol\types\Experiments;
use pocketmine\event\entity\EntityShootBowEvent;
use pocketmine\event\entity\ProjectileHitEvent;
use pocketmine\entity\projectile\Arrow;

class Main extends PluginBase implements Listener {

    private static self $instance;
    private Config $config;
    private string $dbPath;
    private array $unlockedSkins = []; // Cache: [username => [skinKey1, skinKey2]]
    /** @var array<int, bool> */
    private array $iceArrows = [];
    /** @var array<string, float> */
    private array $staffCooldown = [];
    private string $prefix;
    private string $btnFormat;

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onLoad(): void {
        self::$instance = $this;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->config = $this->getConfig();
        $this->prefix = $this->config->get("prefix", "§d§l[Skin Trang Bị] §r");
        $this->btnFormat = $this->config->get("button_format", "§0⚡ §l{name} §r§0⚡");

        // Initialize SQLite Database
        $this->dbPath = $this->getDataFolder() . "skins.db";
        $db = new \SQLite3($this->dbPath);
        $db->exec("CREATE TABLE IF NOT EXISTS unlocked_skins (player TEXT, skin TEXT, PRIMARY KEY (player, skin))");
        $db->close();

        // Register custom items natively
        $this->registerSkins();

        if (!\muqsit\invmenu\InvMenuHandler::isRegistered()) {
            \muqsit\invmenu\InvMenuHandler::register($this);
        }

        // Register Command
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        // Schedule BowZoomTask to handle FOV zoom during aiming
        $this->getScheduler()->scheduleRepeatingTask(new \BeeAZ\AZItemSkins\task\BowZoomTask(), 2);

        $this->getLogger()->info("§aAZItemSkins đã khởi chạy thành công!");
    }

    private function registerSkins(): void {
        $this->getLogger()->info("§aĐang đăng ký các item skin custom (Native)...");
        $register = CustomItemRegister::getInstance();
        
        $itemsToRegister = [
            \BeeAZ\AZItemSkins\item\SwordDevilGreatsword::class => ["az:sword_devil_greatsword", "§c§lQuỷ Kiếm Thức Tỉnh"],
            \BeeAZ\AZItemSkins\item\SwordPlagueScythe::class => ["az:sword_plague_scythe", "§c§lLưỡi Hái Dịch Bệnh"],
            \BeeAZ\AZItemSkins\item\SwordCrimson::class => ["az:sword_crimson", "§c§lHuyết Ma Kiếm"],
            \BeeAZ\AZItemSkins\item\SwordMagma::class => ["az:sword_magma", "§c§lKiếm Dung Nham"],
            \BeeAZ\AZItemSkins\item\SwordApi::class => ["az:sword_api", "§c§lHỏa Linh Kiếm"],
            \BeeAZ\AZItemSkins\item\SwordLoghtit::class => ["az:sword_loghtit", "§c§lQuang Hoàng Kiếm"],
            \BeeAZ\AZItemSkins\item\SwordSoul::class => ["az:sword_soul", "§c§lTrượng Hồn Phách"],
            \BeeAZ\AZItemSkins\item\SwordTrid::class => ["az:sword_trid", "§c§lĐinh Ba Hải Vương"],
            \BeeAZ\AZItemSkins\item\SwordCrimsonSpear::class => ["az:sword_crimson_spear", "§c§lHuyết Long Thương"],
            \BeeAZ\AZItemSkins\item\SwordDark::class => ["az:sword_dark", "§c§lHắc Ám Đoản Kiếm"],
            \BeeAZ\AZItemSkins\item\SwordKatana::class => ["az:sword_katana", "§c§lThần Kiếm Katana"],
            \BeeAZ\AZItemSkins\item\PillSoCap::class => ["az:pill_so_cap", "§a§lSơ Cấp Tu Vi Đan"],
            \BeeAZ\AZItemSkins\item\PillTrungCap::class => ["az:pill_trung_cap", "§e§lTrung Cấp Tu Vi Đan"],
            \BeeAZ\AZItemSkins\item\PillCaoCap::class => ["az:pill_cao_cap", "§c§lCao Cấp Tu Vi Đan"],
            \BeeAZ\AZItemSkins\item\PillThanCap::class => ["az:pill_than_cap", "§d§lThần Cấp Tu Vi Đan"],
            \BeeAZ\AZItemSkins\item\LinhThao::class => ["az:linh_thao", "§a§lLinh Thảo Ngàn Năm"],
            \BeeAZ\AZItemSkins\item\NhanSam::class => ["az:nhan_sam", "§e§lNhân Sâm Vạn Năm"],
            \BeeAZ\AZItemSkins\item\LinhChi::class => ["az:linh_chi", "§c§lLinh Chi Ngàn Năm"],
            \BeeAZ\AZItemSkins\item\ThienThach::class => ["az:thien_thach", "§d§lĐá Thiên Thạch Hoàng Kim"],
            \BeeAZ\AZItemSkins\item\DaggerThunder::class => ["az:dagger_thunder", "§e§lĐoản Kiếm Lôi Thần"]
        ];

        foreach($itemsToRegister as $class => $data){
            $register->registerItem($class, $data[0], $data[1]);
        }

        // Register custom bows
        $register->registerBow("az:bow_ice", "§b§lCung Băng Tuyết", "az_bow_ice");
    }

    protected function onDisable(): void {
        // Synchronously save cached unlocked skins to DB to avoid data loss
        if (!empty($this->unlockedSkins)) {
            $db = new \SQLite3($this->dbPath);
            $db->exec("BEGIN TRANSACTION");
            $stmt = $db->prepare("INSERT OR IGNORE INTO unlocked_skins (player, skin) VALUES (:player, :skin)");
            if ($stmt !== false) {
                foreach ($this->unlockedSkins as $player => $skins) {
                    foreach ($skins as $skin) {
                        $stmt->bindValue(":player", strtolower($player), SQLITE3_TEXT);
                        $stmt->bindValue(":skin", $skin, SQLITE3_TEXT);
                        $stmt->execute();
                    }
                }
            }
            $db->exec("COMMIT");
            $db->close();
        }
    }

    /**
     * Retrieve a list of unlocked skins for a player
     */
    public function getUnlockedSkins(string $player): array {
        $player = strtolower($player);
        if (isset($this->unlockedSkins[$player])) {
            return $this->unlockedSkins[$player];
        }

        $skins = [];
        $db = new \SQLite3($this->dbPath);
        $stmt = $db->prepare("SELECT skin FROM unlocked_skins WHERE player = :player");
        if ($stmt !== false) {
            $stmt->bindValue(":player", $player, SQLITE3_TEXT);
            $res = $stmt->execute();
            while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
                $skins[] = $row["skin"];
            }
        }
        $db->close();

        $this->unlockedSkins[$player] = $skins;
        return $skins;
    }

    /**
     * Add a skin to player's unlocked skins list
     */
    public function unlockSkin(string $player, string $skinKey): void {
        $player = strtolower($player);
        if (!isset($this->unlockedSkins[$player])) {
            $this->getUnlockedSkins($player);
        }
        if (!in_array($skinKey, $this->unlockedSkins[$player])) {
            $this->unlockedSkins[$player][] = $skinKey;
            
            // Async save to SQLite
            $this->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask(
                $this->dbPath,
                "INSERT OR IGNORE INTO unlocked_skins (player, skin) VALUES (:player, :skin)",
                [":player" => $player, ":skin" => $skinKey]
            ));
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::colorize("&cLệnh này chỉ dùng trong game."));
            return true;
        }

        if ($command->getName() === "muaskin") {
            $this->openMainMenu($sender);
            return true;
        }

        if ($command->getName() === "givecanhgioi") {
            $items = [
                "az:pill_so_cap",
                "az:pill_trung_cap",
                "az:pill_cao_cap",
                "az:pill_than_cap",
                "az:linh_thao",
                "az:nhan_sam",
                "az:linh_chi",
                "az:thien_thach"
            ];
            foreach ($items as $itemId) {
                $item = StringToItemParser::getInstance()->parse($itemId);
                if ($item !== null) {
                    $item->setCount(64);
                    $sender->getInventory()->addItem($item);
                }
            }
            $sender->sendMessage($this->prefix . "§aĐã nhận 64x của tất cả 8 loại đan dược và nguyên liệu tu tiên!");
            return true;
        }

        return false;
    }

    /**
     * Build item from configuration array (with enchants and stats formatting)
     */
    public static function buildItem(array $data): ?Item {
        $customId = $data["custom_id"] ?? "";
        if ($customId === "") return null;

        $item = StringToItemParser::getInstance()->parse($customId);
        if ($item === null) return null;

        $item->setCount(1);

        // Apply custom name and prefix
        $name = $data["name"] ?? "";
        $prefix = $data["prefix"] ?? "";
        $item->setCustomName("§r" . ($prefix !== "" ? $prefix . " " : "") . $name);

        // Apply lore additions
        if (isset($data["lore_additions"]) && is_array($data["lore_additions"])) {
            $lore = [];
            foreach ($data["lore_additions"] as $line) {
                $lore[] = (string)$line;
            }
            $item->setLore($lore);
        }

        // Apply enchants (supporting vanilla, PiggyCustomEnchants, and AZCustomEnchants)
        if (isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach ($data["enchants"] as $enchantName => $level) {
                $enchantment = \pocketmine\item\enchantment\StringToEnchantmentParser::getInstance()->parse((string)$enchantName);
                if ($enchantment !== null) {
                    $item->addEnchantment(new \pocketmine\item\enchantment\EnchantmentInstance($enchantment, (int)$level));
                }
            }
        }

        // Apply AZCustomEnchants stats formatting dynamically if available
        if (class_exists(\BeeAZ\AZCustomEnchants\manager\StatsManager::class)) {
            \BeeAZ\AZCustomEnchants\manager\StatsManager::checkAndRebuildLore($item);
        }

        return $item;
    }

    /**
     * Open the main menu for buying custom items using InvMenu Double Chest
     */
    public function openMainMenu(Player $player): void {
        $skinsConfig = $this->config->get("skins", []);
        if (empty($skinsConfig)) {
            $player->sendMessage($this->prefix . "§cHiện tại cửa hàng không có vật phẩm nào!");
            return;
        }

        $menu = \muqsit\invmenu\InvMenu::create(\muqsit\invmenu\type\InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName("§l§dCỬA HÀNG VẬT PHẨM CUSTOM");
        $inventory = $menu->getInventory();

        // Fill borders with black stained glass panes
        $borderSlots = [
            0, 1, 2, 3, 4, 5, 6, 7, 8,
            9, 17, 18, 26, 27, 35, 36, 44,
            45, 46, 47, 48, 49, 50, 51, 52, 53
        ];
        $pane = StringToItemParser::getInstance()->parse("black_stained_glass_pane");
        if ($pane !== null) {
            $pane->setCustomName(" ");
            foreach ($borderSlots as $slot) {
                $inventory->setItem($slot, clone $pane);
            }
        }

        // Available slots in the center of double chest
        $shopSlots = [
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
        ];

        $idx = 0;
        foreach ($skinsConfig as $skinKey => $data) {
            if (!isset($shopSlots[$idx])) {
                break;
            }
            $price = (int)($data["price"] ?? 0);
            $currency = strtoupper($data["currency"] ?? "coin");

            $customItem = self::buildItem($data);
            if ($customItem === null) {
                continue;
            }

            $slot = $shopSlots[$idx];
            $displayItem = clone $customItem;
            
            $lore = $displayItem->getLore();
            $lore[] = "";
            $lore[] = "§r§8--------------------------";
            $lore[] = "§r§eGiá Bán: §d" . number_format($price) . " " . ($currency === "COIN" ? "Coin" : "Xu");
            $lore[] = "§r§aNhấp chuột để chọn mua vật phẩm!";
            $lore[] = "§r§8--------------------------";
            $displayItem->setLore($lore);

            // Save skin key in NamedTag
            $displayItem->getNamedTag()->setString("AZItemSkinKey", (string)$skinKey);

            $inventory->setItem($slot, $displayItem);
            $idx++;
        }

        $menu->setListener(function(\muqsit\invmenu\transaction\InvMenuTransaction $transaction) use ($skinsConfig): \muqsit\invmenu\transaction\InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $item = $transaction->getItemClicked();
            $tag = $item->getNamedTag();

            if ($tag->getTag("AZItemSkinKey") !== null) {
                $skinKey = $tag->getString("AZItemSkinKey");

                if (isset($skinsConfig[$skinKey])) {
                    $data = $skinsConfig[$skinKey];
                    $price = (int)($data["price"] ?? 0);
                    $currency = strtolower($data["currency"] ?? "coin");

                    $player->removeCurrentWindow();

                    // Delay opening confirmation to prevent client inventory sync glitch
                    $this->getScheduler()->scheduleDelayedTask(
                        new \pocketmine\scheduler\ClosureTask(function() use ($player, $skinKey, $data, $price, $currency): void {
                            if ($player->isOnline()) {
                                $customItem = self::buildItem($data);
                                $displayName = ($customItem !== null && $customItem->hasCustomName()) ? $customItem->getCustomName() : ($data["name"] ?? $skinKey);
                                $this->openConfirmPurchaseForm($player, $skinKey, $data, $price, $currency, $displayName);
                            }
                        }),
                        5
                    );
                }
            }

            return $transaction->discard();
        });

        $menu->send($player);
    }

    /**
     * Confirmation form for buying custom item skin
     */
    public function openConfirmPurchaseForm(Player $player, string $skinKey, array $data, int $price, string $currency, string $displayName): void {
        $options = [
            new MenuOption("§l§aXÁC NHẬN MUA", new FormIcon("textures/ui/confirm", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§cHUỶ GIAO DỊCH", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§aXÁC NHẬN MUA VẬT PHẨM",
            "§eBạn có chắc chắn muốn mua:\n" .
            "§f- Vật phẩm: §r" . $displayName . "\n" .
            "§f- Giá mua: §e" . number_format($price) . " " . ($currency === "coin" ? "Coin" : "Xu") . "\n\n" .
            "§7Số tiền của bạn sẽ bị trừ sau khi xác nhận.",
            $options,
            function(Player $submitter, int $selected) use ($skinKey, $data, $price, $currency, $displayName): void {
                if ($selected === 0) {
                    $eco = AZEconomy::getInstance();
                    if ($currency === "coin") {
                        $balance = $eco->getCoin($submitter->getName());
                        if ($balance < $price) {
                            $submitter->sendMessage($this->prefix . "§cBạn không đủ Coin! Cần: §e" . number_format($price) . " Coin§c, Hiện có: §a" . number_format($balance) . " Coin§c.");
                            return;
                        }
                    } else {
                        $balance = $eco->getMoney($submitter->getName());
                        if ($balance < $price) {
                            $submitter->sendMessage($this->prefix . "§cBạn không đủ Xu! Cần: §e" . number_format($price) . " Xu§c, Hiện có: §a" . number_format($balance) . " Xu§c.");
                            return;
                        }
                    }

                    // Build the actual item to give
                    $item = self::buildItem($data);
                    if ($item === null) {
                        $submitter->sendMessage($this->prefix . "§cKhông thể tạo vật phẩm custom, ID lỗi!");
                        return;
                    }

                    // Check inventory space
                    if (!$submitter->getInventory()->canAddItem($item)) {
                        $submitter->sendMessage($this->prefix . "§cTúi đồ của bạn đã đầy!");
                        return;
                    }

                    // Deduct currency
                    if ($currency === "coin") {
                        $eco->reduceCoin($submitter->getName(), $price);
                    } else {
                        $eco->reduceMoney($submitter->getName(), $price);
                    }

                    // Give item
                    $submitter->getInventory()->addItem($item);
                    $submitter->sendMessage($this->prefix . "§aBạn đã mua thành công §r" . $displayName . " §avới giá §e" . number_format($price) . " " . ($currency === "coin" ? "Coin" : "Xu") . "!");
                    $submitter->getWorld()->addSound($submitter->getLocation(), new XpLevelUpSound(2));
                } else {
                    $this->openMainMenu($submitter);
                }
            },
            function(Player $submitter): void {
                $this->openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }
    /**
     * @priority MONITOR
     */
    public function onPacketReceive(\pocketmine\event\server\DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();
        $session = $event->getOrigin();
        $player = $session->getPlayer();
        if ($player === null) return;
        
        $item = $player->getInventory()->getItemInHand();
        if (str_starts_with(get_class($item), "BeeAZ\\AZItemSkins\\item\\")) {
            $isSwinging = false;
            
            if ($packet instanceof \pocketmine\network\mcpe\protocol\AnimatePacket && $packet->action === \pocketmine\network\mcpe\protocol\AnimatePacket::ACTION_SWING_ARM) {
                $isSwinging = true;
            } elseif ($packet instanceof \pocketmine\network\mcpe\protocol\LevelSoundEventPacket) {
                if ($packet->sound === \pocketmine\network\mcpe\protocol\types\LevelSoundEvent::ATTACK_NODAMAGE || $packet->sound === \pocketmine\network\mcpe\protocol\types\LevelSoundEvent::ATTACK_STRONG) {
                    $isSwinging = true;
                }
            } elseif ($packet instanceof \pocketmine\network\mcpe\protocol\PlayerAuthInputPacket) {
                // Proper check using BitSet->get()
                if ($packet->getInputFlags()->get(\pocketmine\network\mcpe\protocol\types\PlayerAuthInputFlags::MISSED_SWING)) {
                    $isSwinging = true;
                }
            }
            
            if ($isSwinging) {
                $this->broadcastSwing($player);
            }
        }
    }

    /**
     * @priority HIGH
     */
    public function onEntityDamage(\pocketmine\event\entity\EntityDamageEvent $event): void {
        if ($event instanceof \pocketmine\event\entity\EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player) {
                $item = $damager->getInventory()->getItemInHand();
                if (str_starts_with(get_class($item), "BeeAZ\\AZItemSkins\\item\\")) {
                    $this->broadcastSwing($damager);

                    if ($item instanceof \BeeAZ\AZItemSkins\item\SwordSoul) {
                        // Trượng không phải vũ khí chuyên đánh nhau spam chiêu, nên dame cận chiến rất yếu (0.5 tim)
                        $event->setBaseDamage(1.0);
                    }
                }
            }
        }
    }

    public function onPlayerInteract(\pocketmine\event\player\PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        if (str_starts_with(get_class($item), "BeeAZ\\AZItemSkins\\item\\")) {
            $action = $event->getAction();
            if ($action === \pocketmine\event\player\PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                $this->broadcastSwing($player);
            }
        }
    }

    public function onPlayerItemUse(\pocketmine\event\player\PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        
        $itemClass = get_class($item);
        $skillMap = [
            \BeeAZ\AZItemSkins\item\SwordSoul::class => ["Trượng Hồn Phách", 3.0, "castStaffSpell"],
            \BeeAZ\AZItemSkins\item\SwordDevilGreatsword::class => ["Quỷ Kiếm Thức Tỉnh", 5.0, "castDevilSpell"],
            \BeeAZ\AZItemSkins\item\SwordPlagueScythe::class => ["Lưỡi Hái Dịch Bệnh", 5.0, "castPlagueSpell"],
            \BeeAZ\AZItemSkins\item\SwordCrimson::class => ["Huyết Ma Kiếm", 5.0, "castCrimsonSpell"],
            \BeeAZ\AZItemSkins\item\SwordMagma::class => ["Kiếm Dung Nham", 5.0, "castMagmaSpell"],
            \BeeAZ\AZItemSkins\item\SwordApi::class => ["Hỏa Linh Kiếm", 4.0, "castApiSpell"],
            \BeeAZ\AZItemSkins\item\SwordLoghtit::class => ["Quang Hoàng Kiếm", 5.0, "castLoghtitSpell"],
            \BeeAZ\AZItemSkins\item\SwordTrid::class => ["Đinh Ba Hải Vương", 5.0, "castTridSpell"],
            \BeeAZ\AZItemSkins\item\SwordCrimsonSpear::class => ["Huyết Long Thương", 5.0, "castCrimsonSpearSpell"],
            \BeeAZ\AZItemSkins\item\SwordDark::class => ["Hắc Ám Đoản Kiếm", 6.0, "castDarkSpell"],
            \BeeAZ\AZItemSkins\item\SwordKatana::class => ["Thần Kiếm Katana", 4.0, "castKatanaSpell"],
            \BeeAZ\AZItemSkins\item\DaggerThunder::class => ["Đoản Kiếm Lôi Thần", 5.0, "castThunderSpell"],
            \BeeAZ\AZItemSkins\item\BowElemental::class => ["Cung Băng Tuyết", 6.0, "castIceBowSpell"],
        ];

        if (isset($skillMap[$itemClass])) {
            [$itemName, $cooldownTime, $methodName] = $skillMap[$itemClass];
            $now = microtime(true);
            $name = $player->getName();
            $cooldownKey = $name . "_" . $itemClass;
            if (isset($this->staffCooldown[$cooldownKey]) && $now - $this->staffCooldown[$cooldownKey] < $cooldownTime) {
                $remaining = number_format($cooldownTime - ($now - $this->staffCooldown[$cooldownKey]), 1);
                $player->sendActionBarMessage("§c{$itemName} đang hồi chiêu ({$remaining}s)...");
            } else {
                $this->staffCooldown[$cooldownKey] = $now;
                $this->$methodName($player);
            }
        }
    }

    public function onPlayerItemHeld(\pocketmine\event\player\PlayerItemHeldEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $pos = $player->getPosition();

        $anim = null;
        $sound = null;
        $particles = [];

        if ($item instanceof \BeeAZ\AZItemSkins\item\BowElemental && $item->getTextureName() === "az_bow_ice") {
            $sound = "items.hitice";
            $particles = ["rex:pecahice"];
        } else {
            $class = get_class($item);
            $heldEffects = [
                \BeeAZ\AZItemSkins\item\SwordKatana::class => [
                    "animation" => "animation.katana.taruh",
                    "sound" => "items.whoosh",
                    "particles" => ["rex:suer1", "rex:suer2"]
                ],
                \BeeAZ\AZItemSkins\item\SwordDevilGreatsword::class => [
                    "animation" => "animation.gret.taruh",
                    "sound" => "items.zdevslash1",
                    "particles" => ["rex:grethd"]
                ],
                \BeeAZ\AZItemSkins\item\SwordPlagueScythe::class => [
                    "animation" => "animation.plaguevo.taruh",
                    "sound" => "items.plaguevo1",
                    "particles" => ["rex:potionskill"]
                ],
                \BeeAZ\AZItemSkins\item\SwordCrimson::class => [
                    "animation" => "animation.crimson.taruh",
                    "sound" => "items.crim1",
                    "particles" => ["rex:crimhd"]
                ],
                \BeeAZ\AZItemSkins\item\SwordMagma::class => [
                    "animation" => "animation.magma.taruh",
                    "sound" => "items.magmaslash1",
                    "particles" => ["rex:lavakeh"]
                ],
                \BeeAZ\AZItemSkins\item\SwordApi::class => [
                    "animation" => "animation.api.taruh",
                    "sound" => "items.flameslash1",
                    "particles" => ["rex:apihd"]
                ],
                \BeeAZ\AZItemSkins\item\SwordLoghtit::class => [
                    "animation" => "animation.loght.taruh",
                    "sound" => "items.loghtslash1",
                    "particles" => ["rex:tai3"]
                ],
                \BeeAZ\AZItemSkins\item\SwordSoul::class => [
                    "animation" => "animation.soul.taruh",
                    "sound" => "items.soul1",
                    "particles" => ["rex:soulprek2"]
                ],
                \BeeAZ\AZItemSkins\item\SwordTrid::class => [
                    "animation" => "animation.trid.taruh",
                    "sound" => "items.tridslash1",
                    "particles" => ["rex:watai"]
                ],
                \BeeAZ\AZItemSkins\item\SwordCrimsonSpear::class => [
                    "animation" => "animation.crimson_spear.taruh",
                    "sound" => "items.crimsonslash1",
                    "particles" => ["rex:crimson_slash"]
                ],
                \BeeAZ\AZItemSkins\item\SwordDark::class => [
                    "animation" => "animation.player.attack.rotations",
                    "sound" => "items.darkslash1",
                    "particles" => ["rex:dark_slash"]
                ],
                \BeeAZ\AZItemSkins\item\DaggerThunder::class => [
                    "animation" => null,
                    "sound" => "items.ptrmenyala",
                    "particles" => ["rex:thunder1"]
                ]
            ];

            if (isset($heldEffects[$class])) {
                $anim = $heldEffects[$class]["animation"];
                $sound = $heldEffects[$class]["sound"];
                $particles = $heldEffects[$class]["particles"];
            }
        }

        if ($anim !== null) {
            $pkAnim = \pocketmine\network\mcpe\protocol\AnimateEntityPacket::create(
                $anim,
                "",
                "",
                0,
                "",
                0.0,
                [$player->getId()]
            );
            $player->getNetworkSession()->sendDataPacket($pkAnim);
            $player->getWorld()->broadcastPacketToViewers($pos, $pkAnim);
        }

        foreach ($particles as $pName) {
            $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(
                0,
                -1,
                $pos->asVector3()->add(0, 1, 0),
                $pName,
                null
            );
            $player->getNetworkSession()->sendDataPacket($pkPart);
            $player->getWorld()->broadcastPacketToViewers($pos, $pkPart);
        }

        if ($sound !== null) {
            $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create(
                $sound,
                $pos->getX(),
                $pos->getY(),
                $pos->getZ(),
                1.0,
                1.0,
                null
            );
            $player->getNetworkSession()->sendDataPacket($pkSound);
            $player->getWorld()->broadcastPacketToViewers($pos, $pkSound);
        }
    }

    private function broadcastSwing(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        $pos = $player->getPosition();

        $animName = null;
        $soundName = null;
        $particleNames = [];

        if ($item instanceof \BeeAZ\AZItemSkins\item\SwordKatana) {
            $idx = mt_rand(1, 4);
            $animName = "animation.katana.slash" . $idx;
            $particleNames[] = "rex:light_bezing" . $idx;
            $soundName = "items.wind_slash" . $idx;
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordCrimsonSpear) {
            $idx = mt_rand(1, 3);
            $animName = "animation.crimson_spear.slash" . $idx;
            $particleNames[] = ($idx === 3) ? "rex:crimson_slash1" : "rex:crimson_slash";
            $soundName = "items.crimsonslash" . mt_rand(1, 4);
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordDark) {
            $animName = "animation.player.attack.rotations";
            $particleNames[] = "rex:dark_slash";
            $soundName = "items.darkslash" . mt_rand(1, 3);
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordApi) {
            $idx = mt_rand(1, 4);
            $animName = "animation.api.attack" . $idx;
            $soundName = "items.flameslash" . $idx;
            $particleNames[] = "rex:apasi";
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordCrimson) {
            $idx = mt_rand(1, 4);
            $animName = "animation.crimson.attack" . $idx;
            $soundName = "items.crim" . $idx;
            $particleNames[] = ($idx === 4) ? "rex:crimled" : "rex:crimledd";
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordDevilGreatsword) {
            $idx = mt_rand(1, 4);
            $animName = "animation.gret.attack" . $idx;
            $soundName = "items.zdevslash" . $idx;
            $particleNames[] = "rex:gretledd";
            $particleNames[] = "rex:gretpix";
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordLoghtit) {
            $idx = mt_rand(1, 4);
            $animName = "animation.loght.attack" . $idx;
            $soundName = "items.loghtslash" . $idx;
            if ($idx === 1) {
                $particleNames[] = "rex:loght_slash";
            } elseif ($idx === 3) {
                $particleNames[] = "rex:basic1";
            } elseif ($idx === 4) {
                $particleNames[] = "rex:ptlight";
            }
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordMagma) {
            $idx = mt_rand(1, 4);
            $animName = "animation.magma.attack" . $idx;
            $soundName = "items.magmaslash" . $idx;
            $particleNames[] = "rex:kdipmag";
            if ($idx === 4) {
                $particleNames[] = "rex:lavakeh";
            }
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordPlagueScythe) {
            $idx = mt_rand(1, 4);
            $animName = "animation.plaguevo.attack" . $idx;
            $soundName = "items.plaguevo" . $idx;
            $particleNames[] = "rex:kdiplag";
            $particleNames[] = "rex:sekul";
            if ($idx === 3) {
                $particleNames[] = "rex:poislash3";
            } elseif ($idx === 4) {
                $particleNames[] = "rex:poi";
            }
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordTrid) {
            $idx = mt_rand(1, 4);
            $animName = "animation.trid.attack" . $idx;
            $soundName = "items.tridslash" . $idx;
            $particleNames[] = "rex:watai";
            if ($idx === 4) {
                $particleNames[] = "rex:drip";
                $particleNames[] = "rex:hitwata";
            }
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\SwordSoul) {
            $idx = mt_rand(1, 2);
            $animName = "animation.soul.summon" . $idx;
            $soundName = "items.soul1";
            $particleNames[] = "rex:soulimpact";
        } elseif ($item instanceof \BeeAZ\AZItemSkins\item\DaggerThunder) {
            $idx = mt_rand(1, 4);
            $animName = "animation.evo.attack" . $idx;
            $soundName = "items.evo" . mt_rand(1, 2);
            $particleNames[] = "rex:thunderslash" . mt_rand(1, 3);
            if ($idx === 4) {
                $particleNames[] = "rex:thunderexplosion";
            }
        }

        if ($animName !== null) {
            // Play custom animation
            $pkAnim = \pocketmine\network\mcpe\protocol\AnimateEntityPacket::create($animName, "", "", 0, "", 0.0, [$player->getId()]);
            $player->getNetworkSession()->sendDataPacket($pkAnim);
            $player->getWorld()->broadcastPacketToViewers($player->getLocation(), $pkAnim);

            // Spawn custom particles
            foreach ($particleNames as $pName) {
                $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $pos->asVector3(), $pName, null);
                $player->getNetworkSession()->sendDataPacket($pkPart);
                $player->getWorld()->broadcastPacketToViewers($pos, $pkPart);
            }

            // Play custom sound
            if ($soundName !== null) {
                $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create($soundName, $pos->getX(), $pos->getY(), $pos->getZ(), 1.0, 1.0, null);
                $player->getNetworkSession()->sendDataPacket($pkSound);
                $player->getWorld()->broadcastPacketToViewers($pos, $pkSound);
            }
            return;
        }

        // Send ActorEventPacket (ARM_SWING = 4)
        $pk1 = \pocketmine\network\mcpe\protocol\ActorEventPacket::create($player->getId(), \pocketmine\network\mcpe\protocol\types\ActorEvent::ARM_SWING, 0, null);
        // Send AnimatePacket (ACTION_SWING_ARM = 1)
        $pk2 = \pocketmine\network\mcpe\protocol\AnimatePacket::create($player->getId(), \pocketmine\network\mcpe\protocol\AnimatePacket::ACTION_SWING_ARM, 0.0);
        // Send AnimateEntityPacket to force play animation on client
        $pk3 = \pocketmine\network\mcpe\protocol\AnimateEntityPacket::create(
            "animation.player.attack.rotations",
            "",
            "",
            0,
            "",
            0.0,
            [$player->getId()]
        );
        
        $player->getNetworkSession()->sendDataPacket($pk1);
        $player->getNetworkSession()->sendDataPacket($pk2);
        $player->getNetworkSession()->sendDataPacket($pk3);
        
        $player->getWorld()->broadcastPacketToViewers($player->getLocation(), $pk1);
        $player->getWorld()->broadcastPacketToViewers($player->getLocation(), $pk2);
        $player->getWorld()->broadcastPacketToViewers($player->getLocation(), $pk3);
    }

    /**
     * @priority MONITOR
     */
    public function onEntityShootBow(EntityShootBowEvent $event): void {
        $shooter = $event->getEntity();
        if ($shooter instanceof Player) {
            $bow = $event->getBow();
            if ($bow instanceof \BeeAZ\AZItemSkins\item\BowElemental && $bow->getTextureName() === "az_bow_ice") {
                $projectile = $event->getProjectile();
                if ($projectile instanceof Arrow) {
                    $this->iceArrows[$projectile->getId()] = true;
                    
                    $pos = $shooter->getPosition();
                    $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create(
                        "items.hitice",
                        $pos->getX(),
                        $pos->getY(),
                        $pos->getZ(),
                        1.0,
                        1.2,
                        null
                    );
                    $shooter->getNetworkSession()->sendDataPacket($pkSound);
                    $shooter->getWorld()->broadcastPacketToViewers($pos, $pkSound);

                    $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(
                        0,
                        -1,
                        $pos->asVector3()->add(0, 1, 0),
                        "rex:pecahice",
                        null
                    );
                    $shooter->getNetworkSession()->sendDataPacket($pkPart);
                    $shooter->getWorld()->broadcastPacketToViewers($pos, $pkPart);
                }
            }
        }
    }

    /**
     * @priority MONITOR
     */
    public function onProjectileHit(ProjectileHitEvent $event): void {
        $projectile = $event->getEntity();
        if ($projectile instanceof Arrow) {
            if (isset($this->iceArrows[$projectile->getId()])) {
                unset($this->iceArrows[$projectile->getId()]);
                $pos = $projectile->getPosition();
                $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create(
                    "items.hitice",
                    $pos->getX(),
                    $pos->getY(),
                    $pos->getZ(),
                    1.5,
                    0.8,
                    null
                );
                $projectile->getWorld()->broadcastPacketToViewers($pos, $pkSound);

                $pkPart1 = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $pos->asVector3(), "rex:iceduar1", null);
                $pkPart2 = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $pos->asVector3(), "rex:pecahice", null);
                $projectile->getWorld()->broadcastPacketToViewers($pos, $pkPart1);
                $projectile->getWorld()->broadcastPacketToViewers($pos, $pkPart2);
            }
        }
    }

    private function getTargetPosition(Player $player, float $maxDist = 15.0): \pocketmine\math\Vector3 {
        $world = $player->getWorld();
        $eyePos = $player->getEyePos();
        $direction = $player->getDirectionVector();
        $endPos = $eyePos->addVector($direction->multiply($maxDist));
        
        $targetEntity = null;
        $bestDist = $maxDist;
        
        foreach ($world->getNearbyEntities($player->getBoundingBox()->expandedCopy($maxDist, $maxDist, $maxDist), $player) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living) {
                $entityBox = $entity->getBoundingBox()->expandedCopy(0.5, 0.5, 0.5);
                $intercept = $entityBox->calculateIntercept($eyePos, $endPos);
                if ($intercept !== null) {
                    $dist = $eyePos->distance($entity->getPosition());
                    if ($dist < $bestDist) {
                        $bestDist = $dist;
                        $targetEntity = $entity;
                    }
                }
            }
        }
        
        if ($targetEntity !== null) {
            return $targetEntity->getPosition();
        } else {
            $targetBlock = $player->getTargetBlock((int)$maxDist);
            if ($targetBlock !== null) {
                return $targetBlock->getPosition()->add(0.5, 1.0, 0.5);
            } else {
                return $eyePos->addVector($direction->multiply(5));
            }
        }
    }

    private function castStaffSpell(Player $player): void {
        $world = $player->getWorld();
        $targetPos = $this->getTargetPosition($player);
        
        // Broadcast custom casting animation for SwordSoul (summon stance)
        $animName = "animation.soul.summon" . mt_rand(1, 2);
        $pkAnim = \pocketmine\network\mcpe\protocol\AnimateEntityPacket::create($animName, "", "", 0, "", 0.0, [$player->getId()]);
        $player->getNetworkSession()->sendDataPacket($pkAnim);
        $player->getWorld()->broadcastPacketToViewers($player->getLocation(), $pkAnim);
        
        // Spawn massive particles around the target position
        $pkPart1 = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos->add(0, 0.5, 0), "rex:soulimpact", null);
        $pkPart2 = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos->add(0, 0.5, 0), "rex:soulprek2", null);
        $player->getNetworkSession()->sendDataPacket($pkPart1);
        $player->getNetworkSession()->sendDataPacket($pkPart2);
        $world->broadcastPacketToViewers($targetPos, $pkPart1);
        $world->broadcastPacketToViewers($targetPos, $pkPart2);
        
        // Play magic sound
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("items.soul1", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT HỒN PHÁCH BỘC PHÁ! (60 Sát thương)");
        
        // Deal 60.0 magic damage to all Living entities in a 4-block radius
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 60.0);
                $entity->attack($ev);
            }
        }
    }

    private function castDevilSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:huge_explosion_emitter", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("random.explode", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT QUỶ THẦN BỘC PHÁ! (50 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 50.0);
                $entity->attack($ev);
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::BLINDNESS(), 100, 1));
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::SLOWNESS(), 100, 2));
            }
        }
    }

    private function castPlagueSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:villager_angry", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("mob.zombie.say", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT DỊCH BỆNH HOÀNG HÀNH! (45 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 45.0);
                $entity->attack($ev);
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::POISON(), 120, 2));
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::WITHER(), 100, 1));
            }
        }
    }

    private function castCrimsonSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:redstone_ore_dust_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("mob.wither.hurt", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.2, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT HUYẾT MA TRẢM! (35 Sát thương, +10 HP)");
        
        $player->setHealth(min($player->getMaxHealth(), $player->getHealth() + 10.0));
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 35.0);
                $entity->attack($ev);
            }
        }
    }

    private function castMagmaSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:lava_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("fire.ignite", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT DUNG NHAM BỘC KÍCH! (38 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 38.0);
                $entity->attack($ev);
                $entity->setOnFire(5);
            }
        }
    }

    private function castApiSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:basic_flame_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("mob.ghast.fireball", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT HỎA LONG XUẤT THẾ! (30 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 30.0);
                $entity->attack($ev);
                $entity->setOnFire(3);
            }
        }
    }

    private function castLoghtitSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:totem_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("random.totem", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT THẦN QUANG TRẢM! (36 Sát thương, +Regen)");
        
        $player->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::REGENERATION(), 80, 2));
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 36.0);
                $entity->attack($ev);
            }
        }
    }

    private function castTridSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:water_splash_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("ambient.weather.lightning.thunder", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT THỦY TRIỀU PHẪN NỘ! (40 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 40.0);
                $entity->attack($ev);
                
                $xDiff = $entity->getPosition()->getX() - $player->getPosition()->getX();
                $zDiff = $entity->getPosition()->getZ() - $player->getPosition()->getZ();
                $entity->knockBack($xDiff, $zDiff, 1.2);
            }
        }
    }

    private function castCrimsonSpearSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "minecraft:redstone_ore_dust_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("mob.enderdragon.growl", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.3, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT LONG THẦN XUNG KÍCH! (38 Sát thương)");
        
        $player->setMotion($player->getDirectionVector()->multiply(1.5));
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 38.0);
                $entity->attack($ev);
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::SLOWNESS(), 60, 2));
            }
        }
    }

    private function castDarkSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $player->getPosition(), "minecraft:basic_smoke_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($player->getPosition(), $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("mob.endermen.portal", $player->getPosition()->getX(), $player->getPosition()->getY(), $player->getPosition()->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($player->getPosition(), $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT BÓNG TỐI KÍCH! (30 Sát thương)");
        
        $player->teleport($targetPos->add(0, 0.5, 0));
        $player->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::INVISIBILITY(), 80, 1));
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(3, 3, 3);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 30.0);
                $entity->attack($ev);
            }
        }
    }

    private function castKatanaSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $player->getPosition(), "minecraft:critical_particle", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($player->getPosition(), $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("random.bowhit", $player->getPosition()->getX(), $player->getPosition()->getY(), $player->getPosition()->getZ(), 1.0, 1.5, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($player->getPosition(), $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT VÔ ẢNH TRẢM! (42 Sát thương)");
        
        $player->setMotion($player->getDirectionVector()->multiply(2.0));
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 42.0);
                $entity->attack($ev);
            }
        }
    }

    private function castThunderSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("ambient.weather.lightning.thunder", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT THIÊN LÔI OANH KÍCH! (45 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 45.0);
                $entity->attack($ev);
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::SLOWNESS(), 80, 5));
            }
        }
    }

    private function castIceBowSpell(Player $player): void {
        $targetPos = $this->getTargetPosition($player);
        $world = $player->getWorld();
        
        $pkPart = \pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket::create(0, -1, $targetPos, "rex:iceduar1", null);
        $player->getNetworkSession()->sendDataPacket($pkPart);
        $world->broadcastPacketToViewers($targetPos, $pkPart);
        $pkSound = \pocketmine\network\mcpe\protocol\PlaySoundPacket::create("items.hitice", $targetPos->getX(), $targetPos->getY(), $targetPos->getZ(), 1.0, 1.0, null);
        $player->getNetworkSession()->sendDataPacket($pkSound);
        $world->broadcastPacketToViewers($targetPos, $pkSound);
        
        $player->sendActionBarMessage("§a⚡ KÍCH HOẠT BĂNG THIÊN TUYẾT ĐỊA! (35 Sát thương)");
        
        $targetBox = \pocketmine\math\AxisAlignedBB::one()->offset($targetPos->getX(), $targetPos->getY(), $targetPos->getZ())->expandedCopy(4, 4, 4);
        foreach ($world->getNearbyEntities($targetBox) as $entity) {
            if ($entity instanceof \pocketmine\entity\Living && $entity !== $player) {
                if ($this->isNPC($entity)) {
                    continue;
                }
                $ev = new \pocketmine\event\entity\EntityDamageByEntityEvent($player, $entity, \pocketmine\event\entity\EntityDamageEvent::CAUSE_MAGIC, 35.0);
                $entity->attack($ev);
                $entity->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(\pocketmine\entity\effect\VanillaEffects::SLOWNESS(), 100, 3));
            }
        }
    }

    /**
     * @priority MONITOR
     */
    public function onPacketSend(DataPacketSendEvent $event): void {
        foreach ($event->getPackets() as $packet) {
            if ($packet instanceof StartGamePacket) {
                $experiments = $packet->levelSettings->experiments;
                $packet->levelSettings->experiments = new Experiments(
                    array_merge($experiments->getExperiments(), ["data_driven_items" => true]),
                    $experiments->hasPreviouslyUsedExperiments()
                );
            } elseif ($packet instanceof ResourcePackStackPacket) {
                $experiments = $packet->experiments;
                $packet->experiments = new Experiments(
                    array_merge($experiments->getExperiments(), ["data_driven_items" => true]),
                    $experiments->hasPreviouslyUsedExperiments()
                );
            }
        }
    }

    private function isNPC(\pocketmine\entity\Entity $entity): bool {
        return $entity instanceof \BeeAZ\AZTradeNPC\entity\TradeNPC || $entity instanceof \BeeAZ\HumanNPC\HumanNPC;
    }
}
