<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\task;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZItemSkins\item\BowElemental;

class BowZoomTask extends Task {

    public function onRun(): void {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if ($player->isUsingItem()) {
                $item = $player->getInventory()->getItemInHand();
                if ($item instanceof BowElemental && $item->getTextureName() === "az_bow_ice") {
                    // Apply Slowness III (amplifier 2) for 6 ticks (0.3 seconds) to zoom screen
                    // Duration is slightly longer than tick interval (2 ticks) to prevent flickering
                    $effect = new EffectInstance(VanillaEffects::SLOWNESS(), 6, 2, false);
                    $player->getEffects()->add($effect);
                }
            }
        }
    }
}
