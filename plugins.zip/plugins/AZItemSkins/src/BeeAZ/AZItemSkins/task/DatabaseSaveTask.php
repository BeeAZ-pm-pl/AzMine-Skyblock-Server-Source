<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\task;

use pocketmine\scheduler\AsyncTask;

class DatabaseSaveTask extends AsyncTask {

    private string $dbPath;
    private string $query;
    private string $serializedParams;

    public function __construct(string $dbPath, string $query, array $params) {
        $this->dbPath = $dbPath;
        $this->query = $query;
        $this->serializedParams = serialize($params);
    }

    public function onRun(): void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        $db->exec("PRAGMA journal_mode=WAL;");
        $db->exec("PRAGMA synchronous=NORMAL;");

        $params = unserialize($this->serializedParams);
        $stmt = $db->prepare($this->query);
        if ($stmt !== false) {
            foreach ($params as $param => $val) {
                $type = is_int($val) ? SQLITE3_INTEGER : SQLITE3_TEXT;
                $stmt->bindValue($param, $val, $type);
            }
            $stmt->execute();
        }
        $db->close();
    }
}
