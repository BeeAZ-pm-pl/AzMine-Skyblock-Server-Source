<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\item;

use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\StringToItemParser;
use pocketmine\world\format\io\GlobalItemDataHandlers;
use pocketmine\data\bedrock\item\SavedItemData;
use pocketmine\network\mcpe\convert\TypeConverter;
use pocketmine\network\mcpe\protocol\types\ItemTypeEntry;
use pocketmine\network\mcpe\protocol\types\CacheableNbt;
use pocketmine\inventory\CreativeInventory;
use pocketmine\utils\SingletonTrait;

final class CustomItemRegister {
    use SingletonTrait;

    /**
     * Registers a custom item to the server natively
     */
    public function registerItem(string $className, string $identifier, string $name): void {
        $itemId = ItemTypeIds::newId();
        
        /** @var Item $item */
        $item = new $className(new ItemIdentifier($itemId), $name);
        
        // 1. Register in Global Item Data Handlers (for saving/loading from DB/NBT)
        GlobalItemDataHandlers::getDeserializer()->map($identifier, fn() => clone $item);
        GlobalItemDataHandlers::getSerializer()->map($item, fn() => new SavedItemData($identifier));
        
        // 2. Register in StringToItemParser
        StringToItemParser::getInstance()->register($identifier, fn() => clone $item);
        
        // 3. Register in TypeConverter's ItemTypeDictionary
        $this->registerCustomItemMapping($identifier, $itemId, $item);
        
        // 4. Register in Creative Inventory
        CreativeInventory::getInstance()->add($item);
    }

    /**
     * Registers a bow item with custom texture name
     */
    public function registerBow(string $identifier, string $name, string $textureName): void {
        $itemId = ItemTypeIds::newId();
        
        $item = new \BeeAZ\AZItemSkins\item\BowElemental(new ItemIdentifier($itemId), $name, $textureName);
        
        GlobalItemDataHandlers::getDeserializer()->map($identifier, fn() => clone $item);
        GlobalItemDataHandlers::getSerializer()->map($item, fn() => new SavedItemData($identifier));
        StringToItemParser::getInstance()->register($identifier, fn() => clone $item);
        $this->registerCustomItemMapping($identifier, $itemId, $item);
        CreativeInventory::getInstance()->add($item);
    }

    /**
     * Injects custom item into the TypeConverter's ItemTypeDictionary and registers the ItemTypeEntry
     */
    private function registerCustomItemMapping(string $identifier, int $itemId, Item $item): void {
        $dictionary = TypeConverter::getInstance()->getItemTypeDictionary();
        $reflection = new \ReflectionClass($dictionary);

        // Access and update intToStringIdMap
        $intToString = $reflection->getProperty("intToStringIdMap");
        $intToString->setAccessible(true);
        $intToStringValue = $intToString->getValue($dictionary);
        $intToStringValue[$itemId] = $identifier;
        $intToString->setValue($dictionary, $intToStringValue);

        // Access and update stringToIntMap
        $stringToInt = $reflection->getProperty("stringToIntMap");
        $stringToInt->setAccessible(true);
        $stringToIntValue = $stringToInt->getValue($dictionary);
        $stringToIntValue[$identifier] = $itemId;
        $stringToInt->setValue($dictionary, $stringToIntValue);

        // Access and update itemTypes
        $itemTypesProp = $reflection->getProperty("itemTypes");
        $itemTypesProp->setAccessible(true);
        /** @var ItemTypeEntry[] $itemTypesValue */
        $itemTypesValue = $itemTypesProp->getValue($dictionary);

        // Get components NBT from the item
        $nbt = $item->getComponentsNbt($itemId, $identifier);
        
        $entry = new ItemTypeEntry($identifier, $itemId, true, 1, new CacheableNbt($nbt));
        $itemTypesValue[] = $entry;
        
        $itemTypesProp->setValue($dictionary, $itemTypesValue);
    }
}
