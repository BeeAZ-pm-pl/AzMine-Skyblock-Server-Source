<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\item;

use pocketmine\item\Sword;
use pocketmine\item\ToolTier;
use pocketmine\item\ItemIdentifier;

class SwordPlagueScythe extends Sword {
    use CustomItemComponentsTrait;

    public function __construct(ItemIdentifier $identifier, string $name) {
        parent::__construct($identifier, $name, ToolTier::NETHERITE());
        $this->textureName = "az_sword_plague_scythe";
        $this->creativeGroup = "itemGroup.name.sword";
        $this->creativeCategory = 3;
        $this->maxStackSize = 1;
        $this->handEquipped = true;
        $this->isSword = true;
    }
}
