<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\item;

use pocketmine\item\Bow;
use pocketmine\item\ItemIdentifier;

class BowElemental extends Bow {
    use CustomItemComponentsTrait;

    public function __construct(ItemIdentifier $identifier, string $name, string $textureName) {
        parent::__construct($identifier, $name);
        $this->textureName = $textureName;
        $this->creativeGroup = "itemGroup.name.bow";
        $this->creativeCategory = 3;
        $this->maxStackSize = 1;
        $this->handEquipped = true;
        $this->isBow = true;
    }
}
