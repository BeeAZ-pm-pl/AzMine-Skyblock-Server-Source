<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\item;

use pocketmine\item\Item;
use pocketmine\item\ItemIdentifier;

class LinhChi extends Item {
    use CustomItemComponentsTrait;

    public function __construct(ItemIdentifier $identifier, string $name) {
        parent::__construct($identifier, $name);
        $this->textureName = "azcanhgioi_dusk_stone";
        $this->creativeGroup = "itemGroup.name.nature";
        $this->creativeCategory = 4;
        $this->maxStackSize = 64;
        $this->handEquipped = false;
    }
}
