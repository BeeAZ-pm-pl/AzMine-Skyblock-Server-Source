<?php

declare(strict_types=1);

namespace BeeAZ\AZItemSkins\item;

use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\StringTag;

trait CustomItemComponentsTrait {

    private string $textureName;
    private string $creativeGroup;
    private int $creativeCategory = 3; // Equipment
    private int $maxStackSize = 1;
    private bool $handEquipped = true;

    public function getTextureName(): string {
        return $this->textureName;
    }

    // For Armor
    private bool $isArmor = false;
    private int $armorProtection = 0;
    private string $armorSlot = "";

    // For Tools
    private bool $isTool = false;
    private int $miningSpeed = 5;

    // For Swords/Weapons
    private bool $isSword = false;

    // For Bows
    private bool $isBow = false;

    public function getComponentsNbt(int $itemId, string $identifier): CompoundTag {
        $components = CompoundTag::create();
        $properties = CompoundTag::create();

        // 1. Icon - must be a PROPERTY (inside item_properties), matching Customies IconComponent structure
        // IconComponent: "texture" => string, "textures" => { "default" => string, "dyed" => "", "icon_trim" => "" }
        $properties->setTag("minecraft:icon", CompoundTag::create()
            ->setString("texture", $this->textureName)
            ->setTag("textures", CompoundTag::create()
                ->setString("default", $this->textureName)
                ->setString("dyed", "")
                ->setString("icon_trim", "")
            )
        );
        
        // 2. Max Stack Size (Property)
        $properties->setTag("max_stack_size", new IntTag($this->maxStackSize));
        
        // 3. Hand Equipped (Property)
        $properties->setTag("hand_equipped", new ByteTag($this->handEquipped ? 1 : 0));
        
        // 4. Creative Category & Group (Properties)
        $properties->setTag("creative_category", new IntTag($this->creativeCategory));
        $properties->setTag("creative_group", new StringTag($this->creativeGroup));

        // 5. If Armor, add armor components
        if ($this->isArmor) {
            // minecraft:armor (Component)
            $components->setTag("minecraft:armor", CompoundTag::create()
                ->setInt("protection", $this->armorProtection)
                ->setString("texture_type", "none")
            );
            
            // minecraft:wearable (Component)
            $slot = match ($this->armorSlot) {
                "helmet" => "slot.armor.head",
                "chestplate" => "slot.armor.chest",
                "leggings" => "slot.armor.legs",
                "boots" => "slot.armor.feet",
                default => "slot.armor"
            };
            $components->setTag("minecraft:wearable", CompoundTag::create()
                ->setString("slot", $slot)
            );
        }

        // 6. If Tool, add durability and digger components for correct client behavior
        if ($this->isTool) {
            // minecraft:durability (Component) - Netherite durability is 2031
            $components->setTag("minecraft:durability", CompoundTag::create()
                ->setInt("max_durability", 2031)
            );
            
            $tag = "minecraft:is_pickaxe_item_destructible";
            $enchantSlot = "mining_pickaxe";
            if ($this instanceof \pocketmine\item\Shovel) {
                $tag = "minecraft:is_shovel_item_destructible";
                $enchantSlot = "shovel";
            } elseif ($this instanceof \pocketmine\item\Axe) {
                $tag = "minecraft:is_axe_item_destructible";
                $enchantSlot = "axe";
            } elseif ($this instanceof \pocketmine\item\Hoe) {
                $tag = "minecraft:is_hoe_item_destructible";
                $enchantSlot = "hoe";
            }

            // minecraft:digger (Component) - allows fast mining of appropriate blocks
            $components->setTag("minecraft:digger", CompoundTag::create()
                ->setByte("use_efficiency", 1)
                ->setTag("destroy_speeds", new \pocketmine\nbt\tag\ListTag([
                    CompoundTag::create()
                        ->setTag("block", CompoundTag::create()->setString("tags", "query.any_tag('" . $tag . "')"))
                        ->setInt("speed", $this->miningSpeed)
                ]))
            );

            // minecraft:enchantable (Component) - allows enchanting in Enchanting Table and Anvil
            $components->setTag("minecraft:enchantable", CompoundTag::create()
                ->setInt("value", 15) // Enchantability value (Netherite is 15)
                ->setString("slot", $enchantSlot) // Allows correct enchantments on client side
            );

            // minecraft:weapon (Component) - fully structured to prevent schema rejection in 1.20
            $components->setTag("minecraft:weapon", CompoundTag::create()
                ->setTag("on_hit_block", CompoundTag::create()
                    ->setString("event", "minecraft:none")
                )
            );
        }

        // 7. If Sword/Weapon, add correct client side components
        if ($this->isSword) {
            // minecraft:durability (Component)
            $components->setTag("minecraft:durability", CompoundTag::create()
                ->setInt("max_durability", 2031)
            );

            // minecraft:enchantable (Component) - allows sword enchantments
            $components->setTag("minecraft:enchantable", CompoundTag::create()
                ->setInt("value", 15)
                ->setString("slot", "weapon") // Allows sword/weapon enchantments on client side
            );

            // minecraft:weapon (Component)
            $components->setTag("minecraft:weapon", CompoundTag::create()
                ->setTag("on_hit_block", CompoundTag::create()
                    ->setString("event", "minecraft:none")
                )
            );

            // Make sword interactive so client sends right-click packet in air
            $components->setString("minecraft:use_animation", "spell");
            $components->setTag("minecraft:use_modifiers", CompoundTag::create()
                ->setFloat("movement_modifier", 1.0)
                ->setFloat("use_duration", 32.0)
            );
        }

        if ($this->isBow) {
            $components->setString("minecraft:use_animation", "bow");
            $components->setInt("minecraft:frame_count", 4);
            $components->setByte("minecraft:allow_off_hand", 1);

            $components->setTag("minecraft:tags", CompoundTag::create()
                ->setTag("tags", new \pocketmine\nbt\tag\ListTag([
                    new StringTag("minecraft:is_bow")
                ]))
            );

            $components->setTag("minecraft:durability", CompoundTag::create()
                ->setInt("max_durability", 384)
            );

            // minecraft:shooter component makes the client recognize this as a bow (hold-and-release).
            // This is critical: without it, the client won't send the ReleaseItemTransaction packet
            // that PMMP's Bow::onReleaseUsing() needs to fire the arrow.
            // The server-side Bow class handles actual arrow creation; the client-side component
            // just tells the client to use bow draw mechanics (hold right-click to pull, release to fire).
            $components->setTag("minecraft:shooter", CompoundTag::create()
                ->setTag("ammunition", new \pocketmine\nbt\tag\ListTag([
                    CompoundTag::create()
                        ->setString("item", "minecraft:arrow")
                        ->setByte("use_offhand", 1)
                        ->setByte("search_inventory", 1)
                        ->setByte("use_in_creative", 1)
                ]))
                ->setFloat("max_draw_duration", 1.0)
                ->setByte("charge_on_draw", 0)
                ->setByte("scale_power_by_draw_duration", 1)
            );

            // minecraft:use_modifiers component for movement slowdown and use duration
            // Required for minecraft:shooter to function properly
            $components->setTag("minecraft:use_modifiers", CompoundTag::create()
                ->setFloat("movement_modifier", 0.35)
                ->setFloat("use_duration", 72000.0)
            );

            // minecraft:enchantable (Component) - allows bow enchantments
            $components->setTag("minecraft:enchantable", CompoundTag::create()
                ->setInt("value", 10)
                ->setString("slot", "bow")
            );
        }


        // 7. Add item_properties inside components (REQUIRED FOR PMMP NETWORK NBT ENCODING)
        $components->setTag("item_properties", $properties);

        // 8. Build root
        return CompoundTag::create()
            ->setTag("components", $components)
            ->setInt("id", $itemId)
            ->setString("name", $identifier);
    }

    public function applyDamage(int $amount) : bool {
        return false;
    }
}
