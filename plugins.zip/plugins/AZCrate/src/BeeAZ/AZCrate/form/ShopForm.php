<?php

declare(strict_types=1);

namespace BeeAZ\AZCrate\form;

use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Label;
use AZEconomy\AZEconomy;
use pocketmine\item\StringToItemParser;
use BeeAZ\AZCrate\Main;

class ShopForm {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function openShop(Player $player, string $msg = "") : void {
        $shopData = $this->plugin->cfg->get("shop", []);
        if(empty($shopData)) {
            $player->sendMessage("§cChưa có dữ liệu shop trong config.");
            return;
        }

        $options = [];
        $keys = [];
        foreach($shopData as $crateName => $data) {
            $price = $data["price"] ?? 0;
            $type = strtoupper($data["type"] ?? "MONEY");
            $iconPath = $data["icon"] ?? "textures/items/tripwire_hook";
            
            $options[] = new MenuOption("§l§0⚡ MUA KHÓA " . strtoupper($crateName) . " ⚡\n§r§8Giá: $price $type", new FormIcon($iconPath, FormIcon::IMAGE_TYPE_PATH));
            $keys[] = $crateName;
        }

        $content = $msg !== "" ? $msg . "\n\n" : "";
        $content .= "§eChào mừng bạn đến với Cửa Hàng Crate.\n§fVui lòng chọn loại chìa khóa bạn muốn mua:";

        $form = new MenuForm(
            "§l§0SHOP CRATE",
            $content,
            $options,
            function(Player $submitter, int $selected) use ($keys, $shopData) : void {
                $this->openBuyForm($submitter, $keys[$selected], $shopData[$keys[$selected]]);
            }
        );
        $player->sendForm($form);
    }

    public function openBuyForm(Player $player, string $crateName, array $data) : void {
        $price = (int)($data["price"] ?? 0);
        $type = strtolower($data["type"] ?? "money");
        $displayType = strtoupper($type);

        $form = new CustomForm(
            "§l§0MUA KEY " . strtoupper($crateName),
            [
                new Label("info", "§e❖ Mua Chìa Khóa Crate: §b" . $crateName . "\n§e❖ Đơn giá: §a" . $price . " " . $displayType . " / chiếc"),
                new Input("amount", "§fNhập số lượng bạn muốn mua:", "1")
            ],
            function(Player $submitter, CustomFormResponse $response) use ($crateName, $price, $type, $displayType) : void {
                $amountStr = $response->getString("amount");
                if(!is_numeric($amountStr) || (int)$amountStr <= 0) {
                    $this->openShop($submitter, "§cSố lượng nhập vào không hợp lệ.");
                    return;
                }
                
                $amount = (int)$amountStr;
                $totalCost = $price * $amount;
                $eco = AZEconomy::getInstance();
                
                if($type === "money") {
                    if($eco->getMoney($submitter->getName()) < $totalCost) {
                        $this->openShop($submitter, "§cBạn không đủ Money để thanh toán. Cần: $totalCost");
                        return;
                    }
                    $eco->reduceMoney($submitter->getName(), $totalCost);
                } else {
                    if($eco->getCoin($submitter->getName()) < $totalCost) {
                        $this->openShop($submitter, "§cBạn không đủ Coin để thanh toán. Cần: $totalCost");
                        return;
                    }
                    $eco->reduceCoin($submitter->getName(), $totalCost);
                }

                $item = StringToItemParser::getInstance()->parse("tripwire_hook");
                if($item !== null) {
                    $item->setCount($amount);
                    $item->setCustomName("§l§eChìa Khóa Crate: §b" . $crateName);
                    $item->getNamedTag()->setString("AZCrateKey", $crateName);
                    $submitter->getInventory()->addItem($item);

                    $this->openShop($submitter, "§aMua thành công §e$amount §achìa khóa §b$crateName §avới tổng giá §e$totalCost $displayType §a.");
                } else {
                    $this->openShop($submitter, "§cLỗi khởi tạo vật phẩm chìa khóa.");
                }
            },
            function(Player $submitter) : void {
                $this->openShop($submitter);
            }
        );
        $player->sendForm($form);
    }
}