<?php

declare(strict_types=1);

namespace BeeAZ\AZCrate\listener;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\entity\ItemMergeEvent;
use pocketmine\event\entity\EntityDespawnEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\player\Player;
use pocketmine\entity\object\ItemEntity;
use pocketmine\entity\Location;
use pocketmine\item\StringToItemParser;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\block\VanillaBlocks;
use pocketmine\network\mcpe\protocol\BlockEventPacket;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\math\AxisAlignedBB;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\EnchantmentTableParticle;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use BeeAZ\AZCrate\Main;
use BeeAZ\AZCrate\task\CrateTask;

class CrateListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $rewards = $this->plugin->getOfflineRewards($player->getName());
        if(!empty($rewards)) {
            $dropPos = $player->getPosition()->add(0, 1.2, 0);
            foreach($rewards as $item) {
                $leftovers = $player->getInventory()->addItem(clone $item);
                foreach($leftovers as $lo) $player->getWorld()->dropItem($dropPos, clone $lo);
            }
            $this->plugin->clearOfflineRewards($player->getName());
            $player->sendMessage("§a✨ Bạn đã nhận lại vật phẩm Crate từ bộ nhớ tạm!");
        }
    }

    public function onMerge(ItemMergeEvent $event) : void {
        $entity = $event->getEntity();
        $target = $event->getTarget();
        if(!$entity instanceof ItemEntity || !$target instanceof ItemEntity) return;

        $item1 = $entity->getItem();
        $item2 = $target->getItem();
        if($item1->getNamedTag()->getTag("AZCrateText") !== null || $item2->getNamedTag()->getTag("AZCrateText") !== null ||
           $item1->getNamedTag()->getTag("AZCrateDummy") !== null || $item2->getNamedTag()->getTag("AZCrateDummy") !== null ||
           $item1->getNamedTag()->getTag("AZCrateRewardEntity") !== null || $item2->getNamedTag()->getTag("AZCrateRewardEntity") !== null) {
            $event->cancel();
        }
    }

    public function onPickup(EntityItemPickupEvent $event) : void {
        $entity = $event->getOrigin();
        if(!$entity instanceof ItemEntity) return;

        $eid = $entity->getId();
        if(isset($this->plugin->activeCrates[$eid])) {
            $event->cancel();
            $player = $event->getEntity();
            if($player instanceof Player && $this->plugin->activeCrates[$eid]->getPlayer()->getName() === $player->getName()) {
                $this->plugin->activeCrates[$eid]->manualCollect();
            }
            return;
        }

        $item = $entity->getItem();
        if($item->getNamedTag()->getTag("AZCrateText") !== null || $item->getNamedTag()->getTag("AZCrateDummy") !== null || $item->getNamedTag()->getTag("AZCrateRewardEntity") !== null) {
            $event->cancel();
        }
    }

    public function onDespawn(EntityDespawnEvent $event) : void {
        $entity = $event->getEntity();
        if($entity instanceof ItemEntity) {
            $eid = $entity->getId();
            if(isset($this->plugin->activeCrates[$eid])) unset($this->plugin->activeCrates[$eid]);
        }
    }

    public function onBreak(BlockBreakEvent $event) : void {
        $pos = $event->getBlock()->getPosition();
        $hash = $pos->getWorld()->getFolderName() . ":" . $pos->getX() . ":" . $pos->getY() . ":" . $pos->getZ();
        if($this->plugin->isCrateBlock($hash) !== null) {
            if($event->getPlayer()->hasPermission("azcrate.admin") && isset($this->plugin->removeMode[$event->getPlayer()->getName()])) {
                $this->plugin->removeCrateBlock($hash);
                $event->getPlayer()->sendMessage("§aĐã gỡ bỏ block Crate.");
                unset($this->plugin->removeMode[$event->getPlayer()->getName()]);
                $bb = new AxisAlignedBB($pos->x, $pos->y, $pos->z, $pos->x + 1, $pos->y + 2, $pos->z + 1);
                foreach($pos->getWorld()->getNearbyEntities($bb) as $e) {
                    if($e instanceof ItemEntity && $e->getItem()->getNamedTag()->getTag("AZCrateText") !== null) $e->flagForDespawn();
                }
            } else $event->cancel();
        }
    }

    private function buildItem(array $data) : ?Item {
        if (isset($data["myitems_key"]) && is_string($data["myitems_key"])) {
            $myItemsMain = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZMyItems");
            if ($myItemsMain !== null && $myItemsMain->isEnabled()) {
                /** @var \BeeAZ\AZMyItems\Main $myItemsMain */
                $item = $myItemsMain->getItemFromConfig($data["myitems_key"]);
                if ($item !== null) {
                    if (isset($data["amount"])) {
                        $item->setCount((int)$data["amount"]);
                    }
                    return clone $item;
                }
            }
        }

        $item = StringToItemParser::getInstance()->parse($data["item"] ?? "dirt");
        if($item === null) return null;
        $item->setCount((int)($data["amount"] ?? 1));
        if(isset($data["name"])) $item->setCustomName($data["name"]);
        if(isset($data["lore"])) $item->setLore($data["lore"]);
        if(isset($data["enchants"])) {
            foreach($data["enchants"] as $name => $lv) {
                $en = StringToEnchantmentParser::getInstance()->parse((string)$name);
                if($en === null) {
                    $normalized = str_replace(" ", "_", (string)$name);
                    $en = StringToEnchantmentParser::getInstance()->parse($normalized);
                }
                if($en === null) {
                    $en = StringToEnchantmentParser::getInstance()->parse(strtolower((string)$name));
                }
                if($en === null) {
                    $en = StringToEnchantmentParser::getInstance()->parse(strtolower(str_replace(" ", "_", (string)$name)));
                }
                if($en === null && class_exists(\DaPigGuy\PiggyCustomEnchants\CustomEnchantManager::class)) {
                    $en = \DaPigGuy\PiggyCustomEnchants\CustomEnchantManager::getEnchantmentByName((string)$name);
                }
                if($en === null && is_numeric($name)) {
                    try {
                        $en = \pocketmine\data\bedrock\EnchantmentIdMap::getInstance()->fromId((int)$name);
                    } catch (\InvalidArgumentException $e) {}
                }
                if($en !== null) $item->addEnchantment(new EnchantmentInstance($en, (int)$lv));
            }
        }
        // Soft-dependency: rebuild lore cho AZCustomEnchants nếu plugin đang load
        if(class_exists(\BeeAZ\AZCustomEnchants\manager\StatsManager::class)) {
            \BeeAZ\AZCustomEnchants\manager\StatsManager::checkAndRebuildLore($item);
        }
        return clone $item;
    }

    public function onInteract(PlayerInteractEvent $event) : void {
        if($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        $player = $event->getPlayer();
        $pos = $event->getBlock()->getPosition();
        $hash = $pos->getWorld()->getFolderName() . ":" . $pos->getX() . ":" . $pos->getY() . ":" . $pos->getZ();
        $isChest = $event->getBlock()->hasSameTypeId(VanillaBlocks::CHEST()) || $event->getBlock()->hasSameTypeId(VanillaBlocks::ENDER_CHEST());

        if(isset($this->plugin->setMode[$player->getName()])) {
            $event->cancel();
            if(!$isChest) {
                $player->sendMessage("§cPhải là Rương!");
                unset($this->plugin->setMode[$player->getName()]);
                return;
            }
            $crate = $this->plugin->setMode[$player->getName()];
            $this->plugin->addCrateBlock($hash, $crate);
            $player->sendMessage("§aĐã đặt Crate §e$crate §a.");
            unset($this->plugin->setMode[$player->getName()]);
            return;
        }

        if(isset($this->plugin->removeMode[$player->getName()])) {
            $event->cancel();
            if($this->plugin->isCrateBlock($hash) !== null) $this->plugin->removeCrateBlock($hash);
            unset($this->plugin->removeMode[$player->getName()]);
            return;
        }

        $crateName = $this->plugin->isCrateBlock($hash);
        if($crateName !== null) {
            $event->cancel();
            if(isset($this->plugin->opening[$player->getName()])) {
                $player->sendMessage("§c⚠️ Bạn đang trong quá trình mở một rương Crate, hãy đợi hoàn tất!");
                return;
            }
            $tag = $event->getItem()->getNamedTag()->getTag("AZCrateKey");
            $crates = $this->plugin->cfg->get("crates");
            if($tag !== null && $tag->getValue() === $crateName) {
                $this->plugin->opening[$player->getName()] = true;
                $it = $event->getItem();
                $it->setCount(1);
                $player->getInventory()->removeItem($it);
                $rewards = $crates[$crateName]["rewards"];
                $total = 0;
                foreach($rewards as $r) $total += $r["chance"];
                $rand = mt_rand(1, $total); $cur = 0; $chosen = null;
                foreach($rewards as $r) {
                    $cur += $r["chance"];
                    if($rand <= $cur) { $chosen = $r; break; }
                }
                
                $rewardItem = $this->buildItem($chosen);
                if($rewardItem === null) {
                    unset($this->plugin->opening[$player->getName()]);
                    return;
                }
                
                $world = $pos->getWorld();
                $world->broadcastPacketToViewers($pos, BlockEventPacket::create(new BlockPosition((int)$pos->x, (int)$pos->y, (int)$pos->z), 1, 1));
                $this->plugin->getScheduler()->scheduleRepeatingTask(new CrateTask($this->plugin, $player, Location::fromObject($pos->add(0.5, 1.2, 0.5), $world), $rewardItem, $crates[$crateName], $pos), 1);
            } else {
                $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
                $menu->setName("§l§0" . strtoupper($crateName));
                $items = [];
                $total = 0;
                foreach($crates[$crateName]["rewards"] as $r) $total += $r["chance"];
                foreach($crates[$crateName]["rewards"] as $r) {
                    $i = $this->buildItem($r);
                    if($i !== null) {
                        $lore = $i->getLore();
                        $lore[] = "§r§e⚡ Tỷ lệ: §a" . round(($r["chance"] / $total) * 100, 2) . "%";
                        $i->setLore($lore);
                        $items[] = $i;
                    }
                }
                $menu->getInventory()->setContents($items);
                $menu->setListener(InvMenu::readonly());
                $menu->send($player);
            }
        }
    }
}