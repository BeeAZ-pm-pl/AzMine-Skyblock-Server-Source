<?php

declare(strict_types=1);

namespace BeeAZ\AZCrate;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use muqsit\invmenu\InvMenuHandler;
use BeeAZ\AZCrate\command\CrateCommand;
use BeeAZ\AZCrate\listener\CrateListener;
use BeeAZ\AZCrate\form\ShopForm;
use BeeAZ\AZCrate\task\FloatingTextTask;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;

class Main extends PluginBase {

    public array $activeCrates = [];
    public array $opening = [];
    public array $setMode = [];
    public array $removeMode = [];
    public Config $cfg;
    public Config $data;
    public Config $offlineData;
    public ShopForm $shopForm;

    protected function onEnable() : void {
        if(!InvMenuHandler::isRegistered()){
            InvMenuHandler::register($this);
        }

        $this->saveResource("config.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        $this->data = new Config($this->getDataFolder() . "data.yml", Config::YAML);
        $this->offlineData = new Config($this->getDataFolder() . "offline.yml", Config::YAML);
        $this->shopForm = new ShopForm($this);
        
        $this->getServer()->getPluginManager()->registerEvents(new CrateListener($this), $this);
        $this->getServer()->getCommandMap()->register("azcrate", new CrateCommand($this));
        
        $this->getScheduler()->scheduleRepeatingTask(new FloatingTextTask($this), 40);
    }

    public function isCrateBlock(string $hash) : ?string {
        return $this->data->get($hash, null);
    }

    public function addCrateBlock(string $hash, string $crate) : void {
        $this->data->set($hash, $crate);
        $this->data->save();
    }

    public function removeCrateBlock(string $hash) : void {
        $this->data->remove($hash);
        $this->data->save();
    }

    public function addOfflineReward(string $playerName, Item $item) : void {
        $name = strtolower($playerName);
        $rewards = $this->offlineData->get($name, []);
        
        $serializer = new LittleEndianNbtSerializer();
        $base64 = base64_encode($serializer->write(new TreeRoot($item->nbtSerialize())));
        
        $rewards[] = $base64;
        $this->offlineData->set($name, $rewards);
        $this->offlineData->save();
    }

    public function getOfflineRewards(string $playerName) : array {
        $name = strtolower($playerName);
        $rewards = $this->offlineData->get($name, []);
        $items = [];
        $serializer = new LittleEndianNbtSerializer();
        foreach($rewards as $base64) {
            try {
                $nbt = $serializer->read(base64_decode($base64))->mustGetCompoundTag();
                $items[] = Item::nbtDeserialize($nbt);
            } catch (\Exception $e) {}
        }
        return $items;
    }

    public function clearOfflineRewards(string $playerName) : void {
        $this->offlineData->remove(strtolower($playerName));
        $this->offlineData->save();
    }

    public function giveKey(Player $player, string $crate, int $amount) : bool {
        if(!$this->cfg->exists("crates") || !isset($this->cfg->get("crates")[$crate])) {
            return false;
        }
        $item = StringToItemParser::getInstance()->parse("tripwire_hook");
        if($item !== null) {
            $item->setCount($amount);
            $item->setCustomName("§l§eChìa Khóa Crate: §b" . $crate);
            $item->getNamedTag()->setString("AZCrateKey", $crate);
            $player->getInventory()->addItem($item);
            return true;
        }
        return false;
    }
}