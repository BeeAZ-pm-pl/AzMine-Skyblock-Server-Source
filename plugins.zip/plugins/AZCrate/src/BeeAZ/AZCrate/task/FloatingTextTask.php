<?php

declare(strict_types=1);

namespace BeeAZ\AZCrate\task;

use pocketmine\scheduler\Task;
use pocketmine\entity\object\ItemEntity;
use pocketmine\math\AxisAlignedBB;
use pocketmine\entity\Location;
use pocketmine\item\StringToItemParser;
use BeeAZ\AZCrate\Main;

class FloatingTextTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun() : void {
        foreach($this->plugin->data->getAll() as $hash => $crateName) {
            $parts = explode(":", (string)$hash);
            if(count($parts) !== 4) continue;
            
            $worldName = $parts[0];
            $x = (int)$parts[1];
            $y = (int)$parts[2];
            $z = (int)$parts[3];

            $worldManager = $this->plugin->getServer()->getWorldManager();
            $world = $worldManager->getWorldByName($worldName);
            if($world === null || !$world->isChunkLoaded($x >> 4, $z >> 4)) continue;

            $crates = $this->plugin->cfg->get("crates", []);
            $crateNameStr = (string)$crateName;
            if(!isset($crates[$crateNameStr])) continue;

            $itemName = $crates[$crateNameStr]["floating_item"] ?? "chest";
            $itemConfig = StringToItemParser::getInstance()->parse($itemName);
            if($itemConfig === null) continue;

            $bb = new AxisAlignedBB($x, $y, $z, $x + 1, $y + 2, $z + 1);
            $found = false;
            $nameTag = "§l§0⚡ §eCRATE: §b" . strtoupper($crateNameStr) . " §0⚡\n§r§fNhấn để xem phần thưởng";
            
            foreach($world->getNearbyEntities($bb) as $entity) {
                if($entity instanceof ItemEntity) {
                    $tag = $entity->getItem()->getNamedTag()->getTag("AZCrateText");
                    if($tag !== null && $tag->getValue() === $crateNameStr) {
                        if(!$entity->getItem()->equals($itemConfig, false, false)) {
                            $entity->flagForDespawn();
                            break;
                        }
                        $entity->setNameTag($nameTag);
                        $entity->setNameTagAlwaysVisible(true);
                        $found = true;
                        break;
                    }
                }
            }

            if(!$found) {
                $itemConfig->getNamedTag()->setString("AZCrateText", $crateNameStr);
                $loc = Location::fromObject(new \pocketmine\math\Vector3($x + 0.5, $y + 1.2, $z + 0.5), $world, 0, 0);
                $textEntity = new ItemEntity($loc, $itemConfig);
                $textEntity->setGravity(0);
                $textEntity->setCanSaveWithChunk(false);
                $textEntity->setNameTag($nameTag);
                $textEntity->setNameTagAlwaysVisible(true);
                $textEntity->spawnToAll();
            }
        }
    }
}