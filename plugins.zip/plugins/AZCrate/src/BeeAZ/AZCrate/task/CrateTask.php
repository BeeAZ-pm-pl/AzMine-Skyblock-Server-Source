<?php

declare(strict_types=1);

namespace BeeAZ\AZCrate\task;

use pocketmine\scheduler\Task;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\item\Item;
use pocketmine\entity\object\ItemEntity;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\BlockEventPacket;
use pocketmine\network\mcpe\protocol\types\BlockPosition;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\RedstoneParticle;
use pocketmine\world\particle\LavaParticle;
use pocketmine\world\sound\PopSound;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\ClickSound;
use pocketmine\world\sound\ExplodeSound;
use pocketmine\world\sound\BlazeShootSound;
use pocketmine\item\VanillaItems;
use BeeAZ\AZCrate\Main;

class CrateTask extends Task {

    private Main $plugin;
    private Player $player;
    private Location $location;
    private int $tick = 0;
    private array $dummies = [];
    private Item $reward;
    private array $config;
    private Vector3 $blockPos;

    public function __construct(Main $plugin, Player $player, Location $location, Item $reward, array $config, Vector3 $blockPos) {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->location = $location;
        $this->reward = $reward;
        $this->config = $config;
        $this->blockPos = $blockPos;
    }

    public function getPlayer() : Player {
        return $this->player;
    }

    private function getSound(string $name) {
        return match($name) {
            "levelup" => new XpLevelUpSound(30),
            "click" => new ClickSound(),
            "explode" => new ExplodeSound(),
            "blaze" => new BlazeShootSound(),
            default => new PopSound()
        };
    }

    private function getParticle(string $name) {
        return match($name) {
            "villager" => new HappyVillagerParticle(),
            "heart" => new HeartParticle(),
            "redstone" => new RedstoneParticle(),
            "lava" => new LavaParticle(),
            default => new FlameParticle()
        };
    }

    public function manualCollect() : void {
        if($this->tick >= 140) return;
        $this->tick = 140;
        $this->cleanup();
        $this->giveReward();
        $this->getHandler()->cancel();
    }

    private function giveReward() : void {
        if(!$this->player->isOnline()) return;
        
        $inventory = $this->player->getInventory();
        $leftovers = $inventory->addItem(clone $this->reward);
        
        if(count($leftovers) > 0) {
            $dropPos = $this->player->getEyePos();
            $motion = $this->player->getDirectionVector()->multiply(0.4);
            
            foreach($leftovers as $item) {
                $dropped = $this->player->getWorld()->dropItem($dropPos, clone $item);
                $dropped->setMotion($motion);
            }
            $this->player->sendMessage("§c⚠️ Túi đồ đầy hoặc đang ở Creative, phần thưởng thừa đã rớt ra ngoài.");
        } else {
            $this->player->sendMessage("§a✨ Bạn đã nhận được phần thưởng thành công!");
        }
    }

    public function onRun() : void {
        if(!$this->player->isOnline()) {
            $this->plugin->addOfflineReward($this->player->getName(), clone $this->reward);
            $this->cleanup();
            $this->getHandler()->cancel();
            return;
        }

        $world = $this->location->getWorld();

        if($this->tick < 40) {
            if($this->tick % 3 === 0) {
                $arr = [VanillaItems::DIAMOND(), VanillaItems::GOLD_INGOT(), VanillaItems::EMERALD(), VanillaItems::IRON_INGOT()];
                $item = clone $arr[array_rand($arr)];
                $item->getNamedTag()->setString("AZCrateDummy", "true");
                
                $entity = new ItemEntity($this->location, $item);
                $entity->setMotion(new Vector3((mt_rand(-20, 20) / 40), 0.6, (mt_rand(-20, 20) / 40)));
                $entity->setNameTag("§l§e? §c? §b? §a?");
                $entity->setNameTagAlwaysVisible(true);
                $entity->spawnToAll();
                
                $this->dummies[] = $entity;
                $world->addSound($this->location, $this->getSound($this->config['sound_spin'] ?? 'pop'));
                
                $p = $this->getParticle($this->config['particle_spin'] ?? 'lava');
                for($i = 0; $i < 10; $i++) {
                    $world->addParticle($this->location->add(mt_rand(-8, 8)/10, mt_rand(0, 8)/10, mt_rand(-8, 8)/10), $p);
                }
            }
        } elseif ($this->tick === 40) {
            foreach($this->dummies as $entity) {
                if($entity instanceof ItemEntity && !$entity->isClosed()) {
                    $entity->flagForDespawn();
                }
            }
            $this->dummies = [];
            
            $world->addSound($this->location, $this->getSound($this->config['sound_win'] ?? 'levelup'));
            $winParticle = $this->getParticle($this->config['particle_win'] ?? 'villager');
            for($i = 0; $i < 60; $i++) {
                $world->addParticle($this->location->add(mt_rand(-15, 15)/10, mt_rand(0, 15)/10, mt_rand(-15, 15)/10), $winParticle);
            }
            
            $displayItem = clone $this->reward;
            $displayItem->getNamedTag()->setString("AZCrateRewardEntity", "true");
            $rewardEntity = new ItemEntity($this->location, $displayItem);
            $rewardEntity->setMotion(new Vector3((mt_rand(-20, 20) / 40), 0.6, (mt_rand(-20, 20) / 40)));
            $rewardEntity->setNameTag("§l§e✨ " . $this->reward->getName() . " ✨\n§r§fChủ sở hữu: §a" . $this->player->getName());
            $rewardEntity->setNameTagAlwaysVisible(true);
            $rewardEntity->spawnToAll();
            
            $this->plugin->activeCrates[$rewardEntity->getId()] = $this;
            $this->dummies['reward'] = $rewardEntity;
            
            $pk = BlockEventPacket::create(new BlockPosition((int)$this->blockPos->x, (int)$this->blockPos->y, (int)$this->blockPos->z), 1, 0);
            $world->broadcastPacketToViewers($this->blockPos, $pk);

        } elseif ($this->tick > 40 && $this->tick < 140) {
            if($this->tick % 5 === 0 && isset($this->dummies['reward']) && $this->dummies['reward'] instanceof ItemEntity && !$this->dummies['reward']->isClosed()) {
                $world->addParticle($this->dummies['reward']->getPosition(), new HappyVillagerParticle());
            }
        } elseif ($this->tick === 140) {
            $this->cleanup();
            $this->giveReward();
            $this->getHandler()->cancel();
        }
        $this->tick++;
    }

    private function cleanup() : void {
        unset($this->plugin->opening[$this->player->getName()]);
        foreach($this->dummies as $key => $entity) {
            if($entity instanceof ItemEntity) {
                if(!$entity->isClosed()) {
                    $entity->flagForDespawn();
                }
                if($key === 'reward') {
                    unset($this->plugin->activeCrates[$entity->getId()]);
                }
            }
        }
        $this->dummies = [];
    }
}