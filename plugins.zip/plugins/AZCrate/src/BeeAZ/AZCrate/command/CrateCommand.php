<?php

declare(strict_types=1);

namespace BeeAZ\AZCrate\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;
use pocketmine\plugin\PluginOwned;
use pocketmine\plugin\Plugin;
use BeeAZ\AZCrate\Main;

class CrateCommand extends Command implements PluginOwned {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("azcrate", "Quản lý hệ thống Crate", "/azcrate", ["crate"]);
        $this->setPermission("azcrate.shop");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : bool {
        if(!isset($args[0])) {
            $sender->sendMessage("§cLệnh: /azcrate shop | /azcrate set <tên> | /azcrate remove | /azcrate key <tên người chơi> <tên crate> <số lượng>");
            return false;
        }

        switch(strtolower($args[0])) {
            case "shop":
                if(!$sender instanceof Player) {
                    $sender->sendMessage("Lệnh này chỉ có thể sử dụng trong trò chơi.");
                    return false;
                }
                $this->plugin->shopForm->openShop($sender);
                break;

            case "set":
                if(!$sender instanceof Player) {
                    $sender->sendMessage("Lệnh này chỉ có thể sử dụng trong trò chơi.");
                    return false;
                }
                if(!$this->checkPerm($sender, "azcrate.admin")) return false;
                if(!isset($args[1])) {
                    $sender->sendMessage("§cThiếu tên Crate.");
                    return false;
                }
                $crate = $args[1];
                if(!$this->plugin->cfg->exists("crates") || !isset($this->plugin->cfg->get("crates")[$crate])) {
                    $sender->sendMessage("§cCrate này không tồn tại trong config.");
                    return false;
                }
                $this->plugin->setMode[$sender->getName()] = $crate;
                $sender->sendMessage("§aHãy chạm vào một Rương hoặc Rương Ender để đặt Crate §e$crate §a.");
                break;

            case "remove":
                if(!$sender instanceof Player) {
                    $sender->sendMessage("Lệnh này chỉ có thể sử dụng trong trò chơi.");
                    return false;
                }
                if(!$this->checkPerm($sender, "azcrate.admin")) return false;
                $this->plugin->removeMode[$sender->getName()] = true;
                $sender->sendMessage("§aHãy chạm vào block Crate để xóa nó.");
                break;

            case "key":
                if(!$this->checkPerm($sender, "azcrate.admin")) return false;
                if(!isset($args[1], $args[2], $args[3])) {
                    $sender->sendMessage("§cLỗi cú pháp: /azcrate key <tên người chơi> <tên crate> <số lượng>");
                    return false;
                }
                $target = $this->plugin->getServer()->getPlayerByPrefix($args[1]);
                if($target === null) {
                    $sender->sendMessage("§cNgười chơi không trực tuyến.");
                    return false;
                }
                $crate = $args[2];
                $amount = (int)$args[3];
                if($this->plugin->giveKey($target, $crate, $amount)) {
                    $sender->sendMessage("§aĐã gửi §e$amount §achìa khóa §b$crate §acho §e" . $target->getName() . "§a.");
                    $target->sendMessage("§aBạn vừa nhận được §e$amount §achìa khóa §b$crate §a.");
                } else {
                    $sender->sendMessage("§cLỗi gửi chìa khóa Crate (Crate không hợp lệ hoặc lỗi vật phẩm).");
                }
                break;
        }
        return true;
    }

    public function getOwningPlugin() : Plugin {
        return $this->plugin;
    }

    private function checkPerm(CommandSender $sender, string $perm) : bool {
        if($sender->hasPermission($perm)) return true;
        $sender->sendMessage("§cBạn không có quyền dùng lệnh này.");
        return false;
    }
}