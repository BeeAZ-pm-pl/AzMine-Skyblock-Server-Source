<?php

declare(strict_types=1);

namespace BeeAZ\AZBuyRank;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\sound\XpLevelUpSound;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use AZEconomy\AZEconomy;

class Main extends PluginBase {

    protected function onEnable(): void {
        $this->saveDefaultConfig();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "muarank") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("Lệnh này chỉ dùng trong trò chơi.");
                return true;
            }
            $this->sendBuyRankMenu($sender);
            return true;
        }
        return false;
    }

    public function sendBuyRankMenu(Player $player): void {
        $currencyType = $this->getConfig()->get("currency", "coin") === "money" ? "money" : "coin";
        $currencyName = $currencyType === "coin" ? "Coin" : "Xu";
        
        $economy = AZEconomy::getInstance();
        if ($currencyType === "coin") {
            $balance = $economy->getCoin($player->getName());
        } else {
            $balance = $economy->getMoney($player->getName());
        }

        $content = "§l§eCỬA HÀNG RANK VIP §r§7- SkyBlock\n";
        $content .= "§fSố dư của bạn: §e" . number_format($balance) . " " . $currencyName . "\n";
        $content .= "§7Chọn một Rank bên dưới để xem chi tiết đặc quyền và tiến hành mua:\n";

        $options = [];
        $rankKeys = [];
        $ranksConfig = $this->getConfig()->get("ranks", []);

        foreach ($ranksConfig as $key => $data) {
            $displayName = $data["display-name"] ?? $key;
            $price = $data["price"] ?? 0;
            $iconPath = $data["icon-path"] ?? "";
            
            $icon = !empty($iconPath) ? new FormIcon($iconPath, FormIcon::IMAGE_TYPE_PATH) : null;
            $options[] = new MenuOption($displayName . "\n§7Giá: §e" . number_format($price) . " " . $currencyName, $icon);
            $rankKeys[] = $key;
        }

        $form = new MenuForm(
            "§l§eMUA RANK VIP",
            $content,
            $options,
            function (Player $submitter, int $selected) use ($rankKeys): void {
                $this->sendConfirmMenu($submitter, $rankKeys[$selected]);
            }
        );

        $player->sendForm($form);
    }

    public function sendConfirmMenu(Player $player, string $rankKey): void {
        $ranksConfig = $this->getConfig()->get("ranks", []);
        if (!isset($ranksConfig[$rankKey])) {
            $player->sendMessage($this->getConfig()->getNested("messages.prefix", "") . $this->getConfig()->getNested("messages.rank-not-found", "§cRank không hợp lệ."));
            return;
        }

        $data = $ranksConfig[$rankKey];
        $displayName = $data["display-name"] ?? $rankKey;
        $price = $data["price"] ?? 0;
        $desc = $data["description"] ?? "";
        $duration = $data["duration-days"] ?? 0;
        $durationText = $duration > 0 ? "§e" . $duration . " ngày" : "§e§lVĩnh Viễn";

        $currencyType = $this->getConfig()->get("currency", "coin") === "money" ? "money" : "coin";
        $currencyName = $currencyType === "coin" ? "Coin" : "Xu";

        $content = "§l§eXÁC NHẬN GIAO DỊCH\n\n";
        $content .= "§fĐặc quyền Rank " . $displayName . "§f:\n";
        $content .= $desc . "\n\n";
        $content .= "§f- Thời hạn sử dụng: " . $durationText . "\n";
        $content .= "§f- Tổng thanh toán: §e" . number_format($price) . " " . $currencyName . "\n";

        $options = [
            new MenuOption("§a§lĐỒNG Ý MUA\n§7Nhấp để thanh toán ngay", new FormIcon("textures/ui/realms_green_check", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§c§lHỦY BỎ\n§7Quay lại trang trước", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§eXÁC NHẬN MUA RANK",
            $content,
            $options,
            function (Player $submitter, int $selected) use ($rankKey, $price, $displayName, $duration, $currencyType, $currencyName): void {
                if ($selected === 1) {
                    $this->sendBuyRankMenu($submitter);
                    return;
                }

                $economy = AZEconomy::getInstance();
                if ($currencyType === "coin") {
                    $balance = $economy->getCoin($submitter->getName());
                } else {
                    $balance = $economy->getMoney($submitter->getName());
                }

                $prefix = $this->getConfig()->getNested("messages.prefix", "");

                if ($balance < $price) {
                    $needed = $price - $balance;
                    $msg = str_replace(
                        ["{currency}", "{current}", "{needed}"],
                        [$currencyName, (string)$balance, (string)$needed],
                        $this->getConfig()->getNested("messages.not-enough-money", "")
                    );
                    $submitter->sendMessage($prefix . $msg);
                    return;
                }

                $azrank = $this->getServer()->getPluginManager()->getPlugin("AZRank");
                if ($azrank === null || !$azrank->isEnabled()) {
                    $submitter->sendMessage($prefix . $this->getConfig()->getNested("messages.no-azrank", "§cAZRank đang bảo trì."));
                    return;
                }

                // Deduct balance
                if ($currencyType === "coin") {
                    $success = $economy->reduceCoin($submitter->getName(), $price);
                } else {
                    $success = $economy->reduceMoney($submitter->getName(), $price);
                }

                if ($success) {
                    /** @var \azrank\Main $azrank */
                    $azrank->rank->setRank($submitter->getName(), $rankKey, $duration);
                    
                    // Play sound
                    $submitter->getWorld()->addSound($submitter->getPosition(), new XpLevelUpSound(30));

                    // Success Message
                    $successMsg = str_replace(
                        ["{rank}", "{price}", "{currency}"],
                        [$displayName, (string)$price, $currencyName],
                        $this->getConfig()->getNested("messages.buy-success", "")
                    );
                    $submitter->sendMessage($prefix . $successMsg);

                    // Broadcast
                    $broadcastMsg = str_replace(
                        ["{player}", "{rank}"],
                        [$submitter->getName(), $displayName],
                        $this->getConfig()->getNested("messages.broadcast", "")
                    );
                    $this->getServer()->broadcastMessage($prefix . $broadcastMsg);
                }
            }
        );

        $player->sendForm($form);
    }
}
