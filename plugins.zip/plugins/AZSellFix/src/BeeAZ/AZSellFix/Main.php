<?php

declare(strict_types=1);

namespace BeeAZ\AZSellFix;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\Durable;
use pocketmine\item\StringToItemParser;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\utils\Config;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Slider;
use AZEconomy\AZEconomy;

class Main extends PluginBase implements Listener {

    private array $pricesByTypeId = [];
    private array $smeltingByTypeId = [];
    private array $playerToggles = [];
    private array $moneyBuffer = [];

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->loadPlayerToggles();

        // Register event listener
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        // Pre-parse item names for sell prices
        $prices = $this->getConfig()->get("prices", []);
        foreach ($prices as $name => $price) {
            $item = $this->parseItem((string)$name);
            if ($item !== null) {
                $this->pricesByTypeId[$item->getTypeId()] = (float)$price;
            }
        }

        // Pre-parse smelting recipes
        $smelting = $this->getConfig()->get("smelting", []);
        foreach ($smelting as $from => $to) {
            $itemFrom = $this->parseItem((string)$from);
            $itemTo = $this->parseItem((string)$to);
            if ($itemFrom !== null && $itemTo !== null) {
                $this->smeltingByTypeId[$itemFrom->getTypeId()] = $itemTo;
            }
        }
    }

    private function parseItem(string $name): ?Item {
        $parser = StringToItemParser::getInstance();
        $item = $parser->parse($name);
        if ($item !== null) return $item;

        $fallbacks = [
            "sugar_canes" => "sugar_cane",
            "birch" => "birch_log",
        ];
        if (isset($fallbacks[$name])) {
            return $parser->parse($fallbacks[$name]);
        }
        return null;
    }

    private function loadPlayerToggles(): void {
        @mkdir($this->getDataFolder());
        if (file_exists($this->getDataFolder() . "players.json")) {
            $this->playerToggles = json_decode(file_get_contents($this->getDataFolder() . "players.json"), true) ?? [];
        }
    }

    private function savePlayerToggles(): void {
        file_put_contents($this->getDataFolder() . "players.json", json_encode($this->playerToggles, JSON_PRETTY_PRINT));
    }

    public function hasAutoSellEnabled(Player $player): bool {
        if (!$player->hasPermission("azsellfix.command.autosell")) return false;
        return $this->playerToggles[strtolower($player->getName())]["autosell"] ?? false;
    }

    public function hasAutoSmeltEnabled(Player $player): bool {
        if (!$player->hasPermission("azsellfix.command.autosmelt")) return false;
        return $this->playerToggles[strtolower($player->getName())]["autosmelt"] ?? false;
    }

    public function hasAutoFixEnabled(Player $player): bool {
        if (!$player->hasPermission("azsellfix.command.autofix")) return false;
        return $this->playerToggles[strtolower($player->getName())]["autofix"] ?? false;
    }

    public function toggleAutoSell(Player $player): bool {
        $name = strtolower($player->getName());
        $current = $this->playerToggles[$name]["autosell"] ?? false;
        $this->playerToggles[$name]["autosell"] = !$current;
        $this->savePlayerToggles();
        return !$current;
    }

    public function toggleAutoSmelt(Player $player): bool {
        $name = strtolower($player->getName());
        $current = $this->playerToggles[$name]["autosmelt"] ?? false;
        $this->playerToggles[$name]["autosmelt"] = !$current;
        $this->savePlayerToggles();
        return !$current;
    }

    public function toggleAutoFix(Player $player): bool {
        $name = strtolower($player->getName());
        $current = $this->playerToggles[$name]["autofix"] ?? false;
        $this->playerToggles[$name]["autofix"] = !$current;
        $this->savePlayerToggles();
        return !$current;
    }

    public function getSellPrice(Item $item): ?float {
        return $this->pricesByTypeId[$item->getTypeId()] ?? null;
    }

    public function getSmeltedItem(Item $item): ?Item {
        if (isset($this->smeltingByTypeId[$item->getTypeId()])) {
            $smelted = clone $this->smeltingByTypeId[$item->getTypeId()];
            $smelted->setCount($item->getCount());
            return $smelted;
        }
        return null;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Lệnh này chỉ có thể sử dụng trong trò chơi.");
            return true;
        }

        $cmdName = strtolower($command->getName());
        $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§6AZSellFix§7] §r");

        switch ($cmdName) {
            case "sell":
                $sub = isset($args[0]) ? strtolower($args[0]) : "hand";
                $inventory = $sender->getInventory();
                $totalEarned = 0.0;
                $soldItemsCount = 0;

                if ($sub === "all") {
                    foreach ($inventory->getContents() as $slot => $item) {
                        $price = $this->getSellPrice($item);
                        if ($price !== null) {
                            $totalEarned += $price * $item->getCount();
                            $soldItemsCount += $item->getCount();
                            $inventory->clear($slot);
                        }
                    }
                } else {
                    $handItem = $sender->getInventory()->getItemInHand();
                    if ($handItem->isNull()) {
                        $sender->sendMessage($prefix . "§cBạn phải cầm một vật phẩm trên tay để bán.");
                        return true;
                    }
                    $price = $this->getSellPrice($handItem);
                    if ($price === null) {
                        $sender->sendMessage($prefix . "§cVật phẩm này không thể bán.");
                        return true;
                    }
                    foreach ($inventory->getContents() as $slot => $item) {
                        if ($item->getTypeId() === $handItem->getTypeId()) {
                            $price = $this->getSellPrice($item);
                            if ($price !== null) {
                                $totalEarned += $price * $item->getCount();
                                $soldItemsCount += $item->getCount();
                                $inventory->clear($slot);
                            }
                        }
                    }
                }

                if ($soldItemsCount > 0) {
                    $moneyInt = (int)$totalEarned;
                    $remainder = $totalEarned - $moneyInt;

                    AZEconomy::getInstance()->addMoney($sender->getName(), $moneyInt);

                    $name = strtolower($sender->getName());
                    $this->moneyBuffer[$name] = ($this->moneyBuffer[$name] ?? 0.0) + $remainder;

                    $msg = str_replace(
                        ["{count}", "{money}"],
                        [(string)$soldItemsCount, (string)$moneyInt],
                        $this->getConfig()->getNested("messages.sell-success", "§aBạn đã bán thành công §e{count}§a vật phẩm và nhận được §e{money} xu§a!")
                    );
                    $sender->sendMessage($prefix . $msg);
                } else {
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.sell-empty", "§cTúi đồ của bạn không có vật phẩm nào có thể bán."));
                }
                return true;

            case "sellexp":
                $currentLevel = $sender->getXpManager()->getXpLevel();
                $levelsToSell = 0;
                if (!isset($args[0])) {
                    $levelsToSell = $currentLevel;
                } elseif (strtolower($args[0]) === "all") {
                    $levelsToSell = $currentLevel;
                } else {
                    $amountStr = $args[0];
                    if (!is_numeric($amountStr) || (int)$amountStr <= 0) {
                        $sender->sendMessage($prefix . "§cSử dụng: /sellexp [số cấp độ hoặc 'all']");
                        return true;
                    }
                    $levelsToSell = (int)$amountStr;
                }

                if ($levelsToSell <= 0) {
                    $sender->sendMessage($prefix . "§cBạn không có cấp độ EXP nào để bán.");
                    return true;
                }
                
                if ($levelsToSell > $currentLevel) {
                    $sender->sendMessage($prefix . "§cBạn không có đủ {$levelsToSell} cấp độ EXP. Hiện tại bạn chỉ có {$currentLevel} cấp độ.");
                    return true;
                }

                $moneyEarned = $levelsToSell * 2;
                $sender->getXpManager()->setXpLevel($currentLevel - $levelsToSell);
                AZEconomy::getInstance()->addMoney($sender->getName(), $moneyEarned);

                $msg = str_replace(
                    ["{levels}", "{money}"],
                    [(string)$levelsToSell, number_format($moneyEarned)],
                    $this->getConfig()->getNested("messages.sellexp-success-levels", "§aBạn đã bán thành công §e{levels} cấp độ EXP§a và nhận được §e{money} xu§a!")
                );
                $sender->sendMessage($prefix . $msg);
                return true;

            case "autosell":
                $state = $this->toggleAutoSell($sender);
                $msgKey = $state ? "messages.autosell-on" : "messages.autosell-off";
                $sender->sendMessage($prefix . $this->getConfig()->getNested($msgKey, $state ? "ON" : "OFF"));
                return true;

            case "autosmelt":
                $state = $this->toggleAutoSmelt($sender);
                $msgKey = $state ? "messages.autosmelt-on" : "messages.autosmelt-off";
                $sender->sendMessage($prefix . $this->getConfig()->getNested($msgKey, $state ? "ON" : "OFF"));
                return true;

            case "autofix":
                $state = $this->toggleAutoFix($sender);
                $msgKey = $state ? "messages.autofix-on" : "messages.autofix-off";
                $sender->sendMessage($prefix . $this->getConfig()->getNested($msgKey, $state ? "ON" : "OFF"));
                return true;

            case "fix":
                $item = $sender->getInventory()->getItemInHand();
                if (!$item instanceof Durable || $item->getDamage() === 0) {
                    if (!$item instanceof Durable) {
                        $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.fix-no-item", "§cBạn phải cầm một vật phẩm có độ bền trên tay."));
                    } else {
                        $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.fix-full", "§aVật phẩm này đã đầy độ bền, không cần sửa chữa."));
                    }
                    return true;
                }

                $maxDamage = $item->getDamage();
                $costPerDurability = $this->getConfig()->get("fix-cost-per-durability", 10);

                $form = new CustomForm(
                    "§l§1SỬA CHỮA TRANG BỊ",
                    [
                        new Label("info", "§7Vật phẩm: §r" . $item->getName() . "\n" .
                                         "§7Độ bền hiện tại: §a" . ($item->getMaxDurability() - $item->getDamage()) . " / " . $item->getMaxDurability() . "\n" .
                                         "§7Chi phí mỗi điểm độ bền: §e" . $costPerDurability . " xu\n" .
                                         "§7Chi phí sửa tối đa: §e" . ($maxDamage * $costPerDurability) . " xu\n"),
                        new Slider("repair_amount", "§eKéo slider để chọn độ bền cần sửa:", 1.0, (float)$maxDamage, 1.0, (float)$maxDamage)
                    ],
                    function(Player $submitter, CustomFormResponse $response) use ($item, $costPerDurability, $prefix): void {
                        $currentItem = $submitter->getInventory()->getItemInHand();
                        if (!$currentItem instanceof Durable || $currentItem->getDamage() === 0) {
                            return;
                        }

                        $repairAmount = (int)$response->getFloat("repair_amount");
                        if ($repairAmount <= 0) return;
                        if ($repairAmount > $currentItem->getDamage()) {
                            $repairAmount = $currentItem->getDamage();
                        }

                        $cost = $repairAmount * $costPerDurability;
                        $money = AZEconomy::getInstance()->getMoney($submitter->getName());

                        if ($money < $cost) {
                            $msg = str_replace("{cost}", (string)$cost, $this->getConfig()->getNested("messages.fix-no-money", "§cBạn không đủ tiền để sửa chữa! Cần §e{cost} xu§c."));
                            $submitter->sendMessage($prefix . $msg);
                            return;
                        }

                        AZEconomy::getInstance()->reduceMoney($submitter->getName(), $cost);
                        $currentItem->setDamage($currentItem->getDamage() - $repairAmount);
                        $submitter->getInventory()->setItemInHand($currentItem);

                        $msg = str_replace(
                            ["{amount}", "{cost}"],
                            [(string)$repairAmount, (string)$cost],
                            $this->getConfig()->getNested("messages.fix-success", "§aĐã sửa chữa thành công §e{amount}§a độ bền với giá §e{cost} xu§a!")
                        );
                        $submitter->sendMessage($prefix . $msg);
                    }
                );

                $sender->sendForm($form);
                return true;
        }

        return false;
    }

    /**
     * Handle block breaking for autosmelt, autosell, and autofix
     */
    public function onBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();

        // 1. Process AutoSmelt
        if ($this->hasAutoSmeltEnabled($player)) {
            $newDrops = [];
            foreach ($event->getDrops() as $drop) {
                $smelted = $this->getSmeltedItem($drop);
                if ($smelted !== null) {
                    $newDrops[] = $smelted;
                } else {
                    $newDrops[] = $drop;
                }
            }
            $event->setDrops($newDrops);
        }

        // 2. Process AutoSell
        if ($this->hasAutoSellEnabled($player)) {
            $totalSellMoney = 0.0;
            $finalDrops = [];
            foreach ($event->getDrops() as $drop) {
                $price = $this->getSellPrice($drop);
                if ($price !== null) {
                    $totalSellMoney += $price * $drop->getCount();
                } else {
                    $finalDrops[] = $drop;
                }
            }
            $event->setDrops($finalDrops);

            if ($totalSellMoney > 0) {
                $this->addMoneyBuffered($player, $totalSellMoney);
            }
        }

        // 3. Process AutoFix
        if ($this->hasAutoFixEnabled($player)) {
            $this->checkAllEquipment($player);
        }
    }

    /**
     * Check equipment on taking damage (for armor)
     */
    public function onDamage(EntityDamageEvent $event): void {
        $player = $event->getEntity();
        if ($player instanceof Player && $this->hasAutoFixEnabled($player)) {
            $this->checkAllEquipment($player);
        }
    }

    /**
     * Check equipment on dealing damage (for weapons)
     */
    public function onAttack(EntityDamageByEntityEvent $event): void {
        $player = $event->getDamager();
        if ($player instanceof Player && $this->hasAutoFixEnabled($player)) {
            $this->checkAllEquipment($player);
        }
    }

    private function addMoneyBuffered(Player $player, float $amount): void {
        $name = strtolower($player->getName());
        $currentBuffer = $this->moneyBuffer[$name] ?? 0.0;
        $currentBuffer += $amount;

        if ($currentBuffer >= 1.0) {
            $addAmount = (int)$currentBuffer;
            AZEconomy::getInstance()->addMoney($player->getName(), $addAmount);
            $currentBuffer -= $addAmount;

            $actionBarMsg = str_replace("{money}", (string)$addAmount, $this->getConfig()->getNested("messages.autosell-actionbar", "§a+$ {money}"));
            $player->sendActionBarMessage($actionBarMsg);
        }

        $this->moneyBuffer[$name] = $currentBuffer;
    }

    public function checkAllEquipment(Player $player): void {
        $inventory = $player->getInventory();
        $armorInventory = $player->getArmorInventory();
        $costPerDurability = $this->getConfig()->get("fix-cost-per-durability", 10);
        $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§6AZSellFix§7] §r");

        // Check hand item
        $item = $inventory->getItemInHand();
        if ($item instanceof Durable && $item->getDamage() > 0) {
            $remaining = $item->getMaxDurability() - $item->getDamage();
            if ($remaining <= 20) {
                $cost = $item->getDamage() * $costPerDurability;
                $money = AZEconomy::getInstance()->getMoney($player->getName());
                if ($money >= $cost) {
                    AZEconomy::getInstance()->reduceMoney($player->getName(), $cost);
                    $item->setDamage(0);
                    $inventory->setItemInHand($item);
                    
                    $msg = str_replace("{cost}", (string)$cost, $this->getConfig()->getNested("messages.autofix-success", ""));
                    if ($msg !== "") $player->sendMessage($prefix . $msg);
                } else {
                    $msg = str_replace("{cost}", (string)$cost, $this->getConfig()->getNested("messages.autofix-no-money", ""));
                    if ($msg !== "") $player->sendMessage($prefix . $msg);
                }
            }
        }

        // Check armor slots
        $armorContents = $armorInventory->getContents();
        foreach ($armorContents as $slot => $armorItem) {
            if ($armorItem instanceof Durable && $armorItem->getDamage() > 0) {
                $remaining = $armorItem->getMaxDurability() - $armorItem->getDamage();
                if ($remaining <= 20) {
                    $cost = $armorItem->getDamage() * $costPerDurability;
                    $money = AZEconomy::getInstance()->getMoney($player->getName());
                    if ($money >= $cost) {
                        AZEconomy::getInstance()->reduceMoney($player->getName(), $cost);
                        $armorItem->setDamage(0);
                        $armorInventory->setItem($slot, $armorItem);
                        
                        $msg = str_replace(["{item}", "{cost}"], [$armorItem->getName(), (string)$cost], $this->getConfig()->getNested("messages.autofix-armor-success", ""));
                        if ($msg !== "") $player->sendMessage($prefix . $msg);
                    } else {
                        $msg = str_replace(["{item}", "{cost}"], [$armorItem->getName(), (string)$cost], $this->getConfig()->getNested("messages.autofix-armor-no-money", ""));
                        if ($msg !== "") $player->sendMessage($prefix . $msg);
                    }
                }
            }
        }
    }
}
