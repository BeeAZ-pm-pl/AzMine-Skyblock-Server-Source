<?php

declare(strict_types=1);

namespace BeeAZ\AZBank;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Label;
use AZEconomy\AZEconomy;
use BeeAZ\AZBank\task\InterestTask;

class Main extends PluginBase implements Listener {

    private static self $instance;
    private \SQLite3 $db;
    private array $bankCache = []; // Caches online player data: [username_lowercase => ['balance' => int, 'accumulated_time' => int, 'last_interest' => int]]
    private string $prefix = "§d§l[Ngân Hàng] §r";

    protected function onLoad(): void {
        self::$instance = $this;
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->prefix = $this->getConfig()->get("prefix", "§d§l[Ngân Hàng] §r");

        // Verify dependency
        if (!class_exists(AZEconomy::class)) {
            $this->getLogger()->emergency("Không tìm thấy plugin AZEconomy! AZBank bắt buộc phải có AZEconomy.");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        // Initialize SQLite DB
        @mkdir($this->getDataFolder());
        $this->db = new \SQLite3($this->getDataFolder() . "bank.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS bank_accounts (
            username TEXT PRIMARY KEY,
            balance INT DEFAULT 0,
            accumulated_time INT DEFAULT 0,
            last_interest INT DEFAULT 0
        );");

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        // Schedule repeating task every 60 seconds (1200 ticks)
        $this->getScheduler()->scheduleRepeatingTask(new InterestTask($this), 1200);

        // Warm up cache for players already online (in case of reload)
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $this->loadPlayerAccount($player->getName());
        }

        $this->getLogger()->info("§aAZBank v1.0.0 đã hoạt động ổn định!");
    }

    protected function onDisable(): void {
        // Save cache for all online players before database closes
        foreach ($this->bankCache as $username => $data) {
            $this->savePlayerAccount($username);
        }
        $this->bankCache = [];
        if (isset($this->db)) {
            $this->db->close();
        }
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $this->loadPlayerAccount($event->getPlayer()->getName());
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $name = $event->getPlayer()->getName();
        $this->savePlayerAccount($name);
        unset($this->bankCache[strtolower($name)]);
    }

    /**
     * Nạp tài khoản người chơi từ database vào RAM cache
     */
    public function loadPlayerAccount(string $name): void {
        $lowerName = strtolower($name);
        if (isset($this->bankCache[$lowerName])) {
            return;
        }

        $stmt = $this->db->prepare("SELECT balance, accumulated_time, last_interest FROM bank_accounts WHERE username = :username");
        $stmt->bindValue(":username", $lowerName, SQLITE3_TEXT);
        $result = $stmt->execute();

        if ($result !== false && ($row = $result->fetchArray(SQLITE3_ASSOC)) !== false) {
            $this->bankCache[$lowerName] = [
                'balance' => (int)$row['balance'],
                'accumulated_time' => (int)$row['accumulated_time'],
                'last_interest' => (int)$row['last_interest']
            ];
        } else {
            // Create account
            $stmt = $this->db->prepare("INSERT INTO bank_accounts (username, balance, accumulated_time, last_interest) VALUES (:username, 0, 0, :time)");
            $stmt->bindValue(":username", $lowerName, SQLITE3_TEXT);
            $stmt->bindValue(":time", time(), SQLITE3_INTEGER);
            $stmt->execute();

            $this->bankCache[$lowerName] = [
                'balance' => 0,
                'accumulated_time' => 0,
                'last_interest' => time()
            ];
        }
    }

    /**
     * Ghi thông tin tài khoản từ RAM cache xuống database
     */
    public function savePlayerAccount(string $name): void {
        $lowerName = strtolower($name);
        if (!isset($this->bankCache[$lowerName])) {
            return;
        }

        $data = $this->bankCache[$lowerName];
        $stmt = $this->db->prepare("UPDATE bank_accounts SET balance = :balance, accumulated_time = :accumulated_time, last_interest = :last_interest WHERE username = :username");
        $stmt->bindValue(":balance", $data['balance'], SQLITE3_INTEGER);
        $stmt->bindValue(":accumulated_time", $data['accumulated_time'], SQLITE3_INTEGER);
        $stmt->bindValue(":last_interest", $data['last_interest'], SQLITE3_INTEGER);
        $stmt->bindValue(":username", $lowerName, SQLITE3_TEXT);
        $stmt->execute();
    }

    /**
     * Trả về số dư ngân hàng của người chơi (hỗ trợ kiểm tra cả khi offline bằng DB)
     */
    public function getBankBalance(string $name): int {
        $lowerName = strtolower($name);
        if (isset($this->bankCache[$lowerName])) {
            return $this->bankCache[$lowerName]['balance'];
        }

        $stmt = $this->db->prepare("SELECT balance FROM bank_accounts WHERE username = :username");
        $stmt->bindValue(":username", $lowerName, SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($result !== false && ($row = $result->fetchArray(SQLITE3_ASSOC)) !== false) {
            return (int)$row['balance'];
        }
        return 0;
    }

    /**
     * Nhận dữ liệu cache của người chơi đang online
     */
    public function getOnlineCache(string $name): ?array {
        return $this->bankCache[strtolower($name)] ?? null;
    }

    /**
     * Thiết lập cache cho người chơi đang online
     */
    public function setOnlineCache(string $name, array $data): void {
        $this->bankCache[strtolower($name)] = $data;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "bank") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cLệnh này chỉ dùng trong trò chơi!");
                return true;
            }
            $this->openBankMenu($sender);
            return true;
        }
        return false;
    }

    /**
     * Mở Menu Ngân Hàng chính
     */
    public function openBankMenu(Player $player): void {
        $economy = AZEconomy::getInstance();
        $wallet = $economy->getMoney($player->getName());
        $lowerName = strtolower($player->getName());

        $this->loadPlayerAccount($player->getName());
        $cache = $this->bankCache[$lowerName];

        $bank = $cache['balance'];
        $accumTime = $cache['accumulated_time'];
        $rate = $this->getConfig()->get("interest_rate", 0.1);
        $interval = $this->getConfig()->get("interest_interval", 3600);

        $accumMinutes = (int)($accumTime / 60);
        $intervalMinutes = (int)($interval / 60);

        $content = "§fXin chào, §a" . $player->getName() . "!\n" .
                   "§fSố dư ví: §e" . number_format($wallet) . " Xu\n" .
                   "§fSố dư ngân hàng: §a" . number_format($bank) . " Xu\n" .
                   "§fLãi suất: §b" . $rate . "% §fmỗi §b" . $intervalMinutes . " phút §fonline\n" .
                   "§fThời gian tích lũy lãi: §d" . $accumMinutes . "§f/§d" . $intervalMinutes . " phút";

        $form = new MenuForm(
            "§d§lNGÂN HÀNG TIẾT KIỆM",
            $content,
            [
                new MenuOption("§a§lGỬI TIỀN\n§7Gửi Xu vào tiết kiệm", new FormIcon("textures/ui/cash_in", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§c§lRÚT TIỀN\n§7Rút Xu về túi đồ", new FormIcon("textures/ui/cash_out", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§e§lGỬI TOÀN BỘ TIỀN\n§7Nạp hết Xu vào bank", new FormIcon("textures/ui/double_chest", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§6§lRÚT TOÀN BỘ TIỀN\n§7Rút hết Xu về ví", new FormIcon("textures/ui/inventory_icon", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $player, int $selected): void {
                switch ($selected) {
                    case 0:
                        $this->openDepositForm($player);
                        break;
                    case 1:
                        $this->openWithdrawForm($player);
                        break;
                    case 2:
                        $this->depositAll($player);
                        break;
                    case 3:
                        $this->withdrawAll($player);
                        break;
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * Mở form nạp tiền
     */
    public function openDepositForm(Player $player): void {
        $economy = AZEconomy::getInstance();
        $wallet = $economy->getMoney($player->getName());
        $lowerName = strtolower($player->getName());
        $bank = $this->bankCache[$lowerName]['balance'] ?? 0;

        $form = new CustomForm(
            "§a§lGỬI TIỀN TIẾT KIỆM",
            [
                new Label("lbl", "§fSố dư ví: §e" . number_format($wallet) . " Xu\n§fSố dư ngân hàng: §a" . number_format($bank) . " Xu"),
                new Input("amount", "§eNhập số Xu muốn gửi vào ngân hàng:", "Ví dụ: 50000")
            ],
            function(Player $player, CustomFormResponse $response) use ($economy): void {
                $amountStr = trim($response->getString("amount"));
                if ($amountStr === "" || !is_numeric($amountStr)) {
                    $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.invalid_amount"));
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $amount = (int)$amountStr;
                if ($amount <= 0) {
                    $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.invalid_amount"));
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $wallet = $economy->getMoney($player->getName());
                if ($wallet < $amount) {
                    $msg = str_replace("{wallet}", number_format($wallet), $this->getConfig()->getNested("messages.no_money"));
                    $player->sendMessage($this->prefix . $msg);
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $lowerName = strtolower($player->getName());
                if ($economy->reduceMoney($player->getName(), $amount)) {
                    $this->bankCache[$lowerName]['balance'] += $amount;
                    $this->savePlayerAccount($player->getName());

                    $msg = str_replace(
                        ["{amount}", "{balance}"],
                        [number_format($amount), number_format($this->bankCache[$lowerName]['balance'])],
                        $this->getConfig()->getNested("messages.deposit_success")
                    );
                    $player->sendMessage($this->prefix . $msg);
                    $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                } else {
                    $player->sendMessage($this->prefix . "§cCó lỗi xảy ra trong quá trình giao dịch!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * Mở form rút tiền
     */
    public function openWithdrawForm(Player $player): void {
        $economy = AZEconomy::getInstance();
        $wallet = $economy->getMoney($player->getName());
        $lowerName = strtolower($player->getName());
        $bank = $this->bankCache[$lowerName]['balance'] ?? 0;

        $form = new CustomForm(
            "§c§lRÚT TIỀN TIẾT KIỆM",
            [
                new Label("lbl", "§fSố dư ngân hàng: §a" . number_format($bank) . " Xu\n§fSố dư ví: §e" . number_format($wallet) . " Xu"),
                new Input("amount", "§eNhập số Xu muốn rút về ví:", "Ví dụ: 50000")
            ],
            function(Player $player, CustomFormResponse $response) use ($economy): void {
                $amountStr = trim($response->getString("amount"));
                if ($amountStr === "" || !is_numeric($amountStr)) {
                    $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.invalid_amount"));
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $amount = (int)$amountStr;
                if ($amount <= 0) {
                    $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.invalid_amount"));
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $lowerName = strtolower($player->getName());
                $bank = $this->bankCache[$lowerName]['balance'] ?? 0;
                if ($bank < $amount) {
                    $msg = str_replace("{balance}", number_format($bank), $this->getConfig()->getNested("messages.no_balance"));
                    $player->sendMessage($this->prefix . $msg);
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $this->bankCache[$lowerName]['balance'] -= $amount;
                if ($economy->addMoney($player->getName(), $amount)) {
                    $this->savePlayerAccount($player->getName());

                    $msg = str_replace(
                        ["{amount}", "{balance}"],
                        [number_format($amount), number_format($this->bankCache[$lowerName]['balance'])],
                        $this->getConfig()->getNested("messages.withdraw_success")
                    );
                    $player->sendMessage($this->prefix . $msg);
                    $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                } else {
                    // Rollback cache
                    $this->bankCache[$lowerName]['balance'] += $amount;
                    $player->sendMessage($this->prefix . "§cCó lỗi xảy ra trong quá trình giao dịch!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * Gửi toàn bộ tiền
     */
    public function depositAll(Player $player): void {
        $economy = AZEconomy::getInstance();
        $wallet = $economy->getMoney($player->getName());

        if ($wallet <= 0) {
            $msg = str_replace("{wallet}", "0", $this->getConfig()->getNested("messages.no_money"));
            $player->sendMessage($this->prefix . $msg);
            $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
            return;
        }

        $lowerName = strtolower($player->getName());
        if ($economy->reduceMoney($player->getName(), $wallet)) {
            $this->bankCache[$lowerName]['balance'] += $wallet;
            $this->savePlayerAccount($player->getName());

            $msg = str_replace(
                ["{amount}", "{balance}"],
                [number_format($wallet), number_format($this->bankCache[$lowerName]['balance'])],
                $this->getConfig()->getNested("messages.deposit_success")
            );
            $player->sendMessage($this->prefix . $msg);
            $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
        } else {
            $player->sendMessage($this->prefix . "§cCó lỗi xảy ra trong quá trình giao dịch!");
            $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
        }
    }

    /**
     * Rút toàn bộ tiền
     */
    public function withdrawAll(Player $player): void {
        $economy = AZEconomy::getInstance();
        $lowerName = strtolower($player->getName());
        $bank = $this->bankCache[$lowerName]['balance'] ?? 0;

        if ($bank <= 0) {
            $msg = str_replace("{balance}", "0", $this->getConfig()->getNested("messages.no_balance"));
            $player->sendMessage($this->prefix . $msg);
            $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
            return;
        }

        $this->bankCache[$lowerName]['balance'] = 0;
        if ($economy->addMoney($player->getName(), $bank)) {
            $this->savePlayerAccount($player->getName());

            $msg = str_replace(
                ["{amount}", "{balance}"],
                [number_format($bank), "0"],
                $this->getConfig()->getNested("messages.withdraw_success")
            );
            $player->sendMessage($this->prefix . $msg);
            $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
        } else {
            // Rollback cache
            $this->bankCache[$lowerName]['balance'] = $bank;
            $player->sendMessage($this->prefix . "§cCó lỗi xảy ra trong quá trình giao dịch!");
            $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
        }
    }
}
