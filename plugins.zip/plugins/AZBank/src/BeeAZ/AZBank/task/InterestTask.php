<?php

declare(strict_types=1);

namespace BeeAZ\AZBank\task;

use pocketmine\scheduler\Task;
use pocketmine\world\sound\XpLevelUpSound;
use BeeAZ\AZBank\Main;

class InterestTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $config = $this->plugin->getConfig();
        $rate = $config->get("interest_rate", 0.1);
        $interval = $config->get("interest_interval", 3600);
        $minBalance = $config->get("min_balance_for_interest", 1000);
        $prefix = $config->get("prefix", "§d§l[Ngân Hàng] §r");

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $name = $player->getName();
            $cache = $this->plugin->getOnlineCache($name);
            if ($cache === null) {
                continue;
            }

            // Increment playtime by 60 seconds (since task runs every 60s)
            $cache['accumulated_time'] += 60;

            if ($cache['accumulated_time'] >= $interval) {
                $balance = $cache['balance'];
                if ($balance >= $minBalance) {
                    $interest = (int)($balance * ($rate / 100));
                    if ($interest > 0) {
                        $cache['balance'] += $interest;
                        
                        $msg = str_replace("{amount}", number_format($interest), $config->getNested("messages.interest_received"));
                        $player->sendMessage($prefix . $msg);
                        $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                    }
                }
                
                // Reset playtime accumulator and update timestamp
                $cache['accumulated_time'] = 0;
                $cache['last_interest'] = time();

                // Save cache and sync to DB
                $this->plugin->setOnlineCache($name, $cache);
                $this->plugin->savePlayerAccount($name);
            } else {
                $this->plugin->setOnlineCache($name, $cache);
            }
        }
    }
}
