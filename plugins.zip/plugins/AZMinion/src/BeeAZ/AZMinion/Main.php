<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion;

use pocketmine\plugin\PluginBase;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;
use pocketmine\event\block\BlockPlaceEvent;

use muqsit\invmenu\InvMenuHandler;


use BeeAZ\AZMinion\entity\types\BaseMinion;
use BeeAZ\AZMinion\entity\types\MinerMinion;
use BeeAZ\AZMinion\entity\types\FarmerMinion;
use BeeAZ\AZMinion\entity\types\LumberjackMinion;
use BeeAZ\AZMinion\entity\types\FisherMinion;
use BeeAZ\AZMinion\database\Database;
use BeeAZ\AZMinion\ui\MinionShopUI;
use BeeAZ\AZMinion\ui\MinionInventoryUI;

class Main extends PluginBase implements Listener {

    private static self $instance;
    private Database $database;
    
    /** @var BaseMinion[] */
    private array $activeMinions = [];

    protected function onLoad(): void {
        self::$instance = $this;
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        // Register Entity

        EntityFactory::getInstance()->register(MinerMinion::class, function (World $world, CompoundTag $nbt): MinerMinion {
            return new MinerMinion(EntityDataHelper::parseLocation($nbt, $world), \pocketmine\entity\Human::parseSkinNBT($nbt), $nbt);
        }, ['AZMinion:Miner']);

        EntityFactory::getInstance()->register(FarmerMinion::class, function (World $world, CompoundTag $nbt): FarmerMinion {
            return new FarmerMinion(EntityDataHelper::parseLocation($nbt, $world), \pocketmine\entity\Human::parseSkinNBT($nbt), $nbt);
        }, ['AZMinion:Farmer']);

        EntityFactory::getInstance()->register(LumberjackMinion::class, function (World $world, CompoundTag $nbt): LumberjackMinion {
            return new LumberjackMinion(EntityDataHelper::parseLocation($nbt, $world), \pocketmine\entity\Human::parseSkinNBT($nbt), $nbt);
        }, ['AZMinion:Lumberjack']);

        EntityFactory::getInstance()->register(FisherMinion::class, function (World $world, CompoundTag $nbt): FisherMinion {
            return new FisherMinion(EntityDataHelper::parseLocation($nbt, $world), \pocketmine\entity\Human::parseSkinNBT($nbt), $nbt);
        }, ['AZMinion:Fisher']);

        EntityFactory::getInstance()->register(\BeeAZ\AZMinion\entity\MinionHook::class, function (World $world, CompoundTag $nbt): \BeeAZ\AZMinion\entity\MinionHook {
            return new \BeeAZ\AZMinion\entity\MinionHook(
                EntityDataHelper::parseLocation($nbt, $world),
                null,
                $nbt
            );
        }, ['MinionHook', 'azminion_hook']);

        // Initialize Database (chỉ lưu kho đồ)
        $this->database = new Database($this);
        $this->database->init();

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        // Entity tự load từ chunk + tự đăng ký trong initEntity()
    }

    protected function onDisable(): void {
        // Lưu kho đồ của tất cả minion trước khi tắt server
        // Entity state tự lưu vào chunk qua saveNBT()
        foreach ($this->activeMinions as $minion) {
            if (!$minion->isClosed()) {
                $this->database->saveInventory($minion);
            }
        }
    }

    public function getDatabase(): Database {
        return $this->database;
    }

    /**
     * @return BaseMinion[]
     */
    public function getActiveMinions(): array {
        return $this->activeMinions;
    }

    public function registerMinion(BaseMinion $minion): void {
        $this->activeMinions[$minion->getMinionId()] = $minion;
    }

    public function unregisterMinion(string $id): void {
        unset($this->activeMinions[$id]);
    }

    /**
     * Helper to create Minion Spawn Item
     */
    public function createMinionItem(
        string $type,
        int $level = 1,
        int $pages = 1,
        bool $autoSell = false,
        bool $autoSmelt = false,
        bool $autoSellUnlocked = false,
        bool $autoSmeltUnlocked = false
    ): Item {
        $item = VanillaItems::NETHER_STAR();
        
        $typeNames = [
            "miner" => "Miner (Khai Thác)",
            "farmer" => "Farmer (Nông Dân)",
            "lumberjack" => "Lumberjack (Chặt Gỗ)",
            "fisher" => "Fisher (Câu Cá)"
        ];

        $typeName = $typeNames[strtolower($type)] ?? ucfirst($type);
        $totalSlots = $pages * 54;
        
        $lore = [
            "§r§7Cấp độ: §e" . $level,
            "§r§7Kho đồ: §e" . $pages . " trang (" . $totalSlots . " ô)"
        ];
        if ($autoSellUnlocked) {
            $lore[] = "§r§7Auto-Sell: " . ($autoSell ? "§aBẬT" : "§cTẮT");
        }
        if ($autoSmeltUnlocked) {
            $lore[] = "§r§7Auto-Smelt: " . ($autoSmelt ? "§aBẬT" : "§cTẮT");
        }
        $lore[] = "";
        $lore[] = "§r§eĐặt xuống đất để kích hoạt Minion!";

        $item->setCustomName("§r§l§6⚡ Minion " . $typeName . " ⚡");
        $item->setLore($lore);

        $nbt = $item->getNamedTag();
        $nbt->setString("minion_type", strtolower($type));
        $nbt->setInt("minion_level", $level);
        $nbt->setInt("minion_inv_size", $pages);
        $nbt->setInt("minion_auto_sell", $autoSell ? 1 : 0);
        $nbt->setInt("minion_auto_smelt", $autoSmelt ? 1 : 0);
        $nbt->setInt("minion_auto_sell_unlocked", $autoSellUnlocked ? 1 : 0);
        $nbt->setInt("minion_auto_smelt_unlocked", $autoSmeltUnlocked ? 1 : 0);
        $item->setNamedTag($nbt);

        return $item;
    }

    /**
     * Handle command /minion
     */
    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Lệnh này chỉ dùng được trong game.");
            return true;
        }

        if (!isset($args[0])) {
            $sender->sendMessage("§e=== HỆ THỐNG MINION ===");
            $sender->sendMessage("§a/minion shop §7- Mở cửa hàng mua Minion");
            if ($sender->hasPermission("azminion.admin")) {
                $sender->sendMessage("§a/minion give <player> <miner|farmer|lumberjack|fisher> [level] [slots] §7- Nhận Minion");
            }
            return true;
        }

        switch (strtolower($args[0])) {
            case "shop":
                MinionShopUI::openShop($sender);
                break;
            case "give":
                if (!$sender->hasPermission("azminion.admin")) {
                    $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này.");
                    return true;
                }
                if (count($args) < 3) {
                    $sender->sendMessage("§cHD: /minion give <player> <miner|farmer|lumberjack|fisher> [level] [slots]");
                    return true;
                }
                $targetPlayer = $this->getServer()->getPlayerByPrefix($args[1]);
                if ($targetPlayer === null) {
                    $sender->sendMessage("§cKhông tìm thấy người chơi: " . $args[1]);
                    return true;
                }
                $type = strtolower($args[2]);
                if (!in_array($type, ["miner", "farmer", "lumberjack", "fisher"])) {
                    $sender->sendMessage("§cLoại minion không hợp lệ! Chọn: miner, farmer, lumberjack, fisher");
                    return true;
                }
                $level = isset($args[3]) ? (int)$args[3] : 1;
                $pages = isset($args[4]) ? (int)$args[4] : 1;

                $minionItem = $this->createMinionItem($type, $level, $pages);
                if ($targetPlayer->getInventory()->canAddItem($minionItem)) {
                    $targetPlayer->getInventory()->addItem($minionItem);
                } else {
                    $targetPlayer->getWorld()->dropItem($targetPlayer->getPosition(), $minionItem);
                }
                $sender->sendMessage("§aĐã gửi Minion " . $type . " cho §e" . $targetPlayer->getName());
                $targetPlayer->sendMessage("§aBạn đã nhận được một Minion §e" . ucfirst($type) . "§a!");
                break;
            default:
                $sender->sendMessage("§cHD: /minion [shop|give]");
                break;
        }
        return true;
    }

    /**
     * Listener: Spawn Minion on block interact (placing it)
     */
    public function onInteract(PlayerInteractEvent $event): void {
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        
        $player = $event->getPlayer();
        $item = $event->getItem();
        $block = $event->getBlock();
        
        $nbt = $item->getNamedTag();
        if ($nbt->getTag("minion_type") === null) return;

        // Prevent normal use
        $event->cancel();

        // Check building permission using a fake BlockPlaceEvent
        $spawnPos = $block->getSide($event->getFace())->getPosition();
        $targetBlock = $player->getWorld()->getBlock($spawnPos);

        // Check if there is enough space (2 blocks height)
        if ($player->getWorld()->getBlock($spawnPos)->isSolid() || $player->getWorld()->getBlock($spawnPos->add(0, 1, 0))->isSolid()) {
            $player->sendMessage("§cKhông đủ khoảng trống để đặt Minion ở đây!");
            return;
        }

        $transaction = new \pocketmine\world\BlockTransaction($player->getWorld());
        $transaction->addBlock($spawnPos, \pocketmine\block\VanillaBlocks::COBBLESTONE());
        $placeEvent = new BlockPlaceEvent($player, $transaction, $block, $item);
        $placeEvent->call();
        if ($placeEvent->isCancelled()) {
            $player->sendMessage("§cBạn không có quyền đặt Minion ở đây!");
            return;
        }

        // Spawn Minion
        $type = $nbt->getString("minion_type");
        $level = $nbt->getInt("minion_level", 1);
        $invSize = $nbt->getInt("minion_inv_size", 9);
        $autoSell = $nbt->getInt("minion_auto_sell", 0);
        $autoSmelt = $nbt->getInt("minion_auto_smelt", 0);
        $autoSellUnlocked = $nbt->getInt("minion_auto_sell_unlocked", 0);
        $autoSmeltUnlocked = $nbt->getInt("minion_auto_smelt_unlocked", 0);

        $uuid = \ramsey\uuid\Uuid::uuid4()->toString();

        $entityNbt = CompoundTag::create()
            ->setString("Name", $player->getSkin()->getSkinId())
            ->setByteArray("Data", $player->getSkin()->getSkinData())
            ->setByteArray("CapeData", $player->getSkin()->getCapeData())
            ->setString("GeometryName", $player->getSkin()->getGeometryName())
            ->setByteArray("GeometryData", $player->getSkin()->getGeometryData());

        $entityNbt->setString("MinionId", $uuid);
        $entityNbt->setString("Owner", $player->getName());
        $entityNbt->setString("MinionType", $type);
        $entityNbt->setInt("MinionLevel", $level);
        $entityNbt->setInt("MinionInvSize", $invSize);
        $entityNbt->setInt("MinionAutoSell", $autoSell);
        $entityNbt->setInt("MinionAutoSmelt", $autoSmelt);
        $entityNbt->setInt("MinionAutoSellUnlocked", $autoSellUnlocked);
        $entityNbt->setInt("MinionAutoSmeltUnlocked", $autoSmeltUnlocked);
        
        // Spawn coordinates centered on block and looking straight at the target block direction
        $playerFacing = $player->getHorizontalFacing();
        $yaw = 0.0;
        switch ($playerFacing) {
            case \pocketmine\math\Facing::SOUTH:
                $yaw = 0.0;
                break;
            case \pocketmine\math\Facing::WEST:
                $yaw = 90.0;
                break;
            case \pocketmine\math\Facing::NORTH:
                $yaw = 180.0;
                break;
            case \pocketmine\math\Facing::EAST:
                $yaw = 270.0;
                break;
        }
        $loc = Location::fromObject($spawnPos->add(0.5, 0, 0.5), $player->getWorld(), $yaw, 0.0);

        $map = [
            "miner" => MinerMinion::class,
            "farmer" => FarmerMinion::class,
            "lumberjack" => LumberjackMinion::class,
            "fisher" => FisherMinion::class
        ];
        $minionClass = $map[$type] ?? MinerMinion::class;
        $minion = new $minionClass($loc, $player->getSkin(), $entityNbt);
        $minion->spawnToAll();
        // Entity tự đăng ký trong initEntity(), kho đồ mới trống

        // Deduct 1 minion item from player inventory
        $item->pop();
        $player->getInventory()->setItemInHand($item);

        $player->sendMessage("§aĐặt Minion thành công!");
    }

    /**
     * Listener: Handle interacting/hitting the minion to open management inventory
     */
    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof BaseMinion) {
            $event->cancel();

            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if ($damager instanceof Player) {
                    // Open GUI for Minion
                    MinionInventoryUI::openMenu($damager, $entity);
                }
            }
        }
    }
}
