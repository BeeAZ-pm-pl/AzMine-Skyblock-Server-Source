<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\ui;

use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use pocketmine\world\sound\AnvilUseSound;
use pocketmine\world\sound\XpLevelUpSound;

use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;

use AZEconomy\AZEconomy;

use BeeAZ\AZMinion\Main;

class MinionShopUI {

    /**
     * Opens the minion shop for a player
     */
    public static function openShop(Player $player): void {
        $options = [
            new MenuOption("§0⚡ §lMinion Miner §r§0⚡\n§8Giá: 500 Coin", new FormIcon("textures/items/iron_pickaxe", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lMinion Farmer §r§0⚡\n§8Giá: 500 Coin", new FormIcon("textures/items/iron_hoe", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lMinion Lumberjack §r§0⚡\n§8Giá: 500 Coin", new FormIcon("textures/items/iron_axe", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lMinion Fisher §r§0⚡\n§8Giá: 500 Coin", new FormIcon("textures/items/fishing_rod_uncast", FormIcon::IMAGE_TYPE_PATH)),
        ];

        $form = new MenuForm(
            "§0⚡ §lCỬA HÀNG MINION §r§0⚡",
            "§eChọn loại Minion bạn muốn mua bằng Coin:",
            $options,
            function (Player $submitter, int $selected): void {
                $types = ["miner", "farmer", "lumberjack", "fisher"];
                $costs = [10000, 12000, 10000, 15000];

                if (!isset($types[$selected])) return;

                $type = $types[$selected];
                $cost = $costs[$selected];

                $playerCoins = AZEconomy::getInstance()->getCoin($submitter->getName());
                if ($playerCoins < $cost) {
                    $submitter->sendMessage("§cBạn không đủ Coin để mua Minion này! Cần §e" . number_format($cost) . " Coin§c.");
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }

                // Deduct coins and give minion item
                if (AZEconomy::getInstance()->reduceCoin($submitter->getName(), $cost)) {
                    $item = Main::getInstance()->createMinionItem($type);
                    if ($submitter->getInventory()->canAddItem($item)) {
                        $submitter->getInventory()->addItem($item);
                    } else {
                        $submitter->getWorld()->dropItem($submitter->getPosition(), $item);
                    }

                    $submitter->sendMessage("§aBạn đã mua thành công §eMinion " . ucfirst($type) . "§a với giá §e" . number_format($cost) . " Coin§a!");
                    $submitter->getWorld()->addSound($submitter->getPosition(), new XpLevelUpSound(1));
                } else {
                    $submitter->sendMessage("§cGiao dịch thất bại! Đã xảy ra lỗi hệ thống.");
                }
            }
        );

        $player->sendForm($form);
    }
}
