<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\ui;

use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\item\StringToItemParser;
use pocketmine\inventory\Inventory;
use pocketmine\utils\TextFormat;
use pocketmine\world\sound\AnvilUseSound;
use pocketmine\world\sound\XpLevelUpSound;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;

use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;

use AZEconomy\AZEconomy;

use BeeAZ\AZMinion\Main;
use BeeAZ\AZMinion\entity\types\BaseMinion;

class MinionInventoryUI {

    private const PAGE_UPGRADE_COST = 200; // 10,000 coin per page
    private const AUTO_SELL_COST = 100;
    private const AUTO_SMELT_COST = 100;

    /**
     * Opens the management FormUI for a Minion
     */
    public static function openMenu(Player $player, BaseMinion $minion): void {
        $typeName = ucfirst($minion->getMinionType());
        $pages = $minion->getInventoryPages();
        $totalSlots = $pages * 54;
        
        // Count used slots
        $usedSlots = 0;
        for ($i = 0; $i < $totalSlots; $i++) {
            if (!$minion->getMinionInventory()->getItem($i)->isNull()) {
                $usedSlots++;
            }
        }

        // Build options
        $options = [];
        $actions = [];

        // 1. View Inventory
        $options[] = new MenuOption("§0⚡ §lXem Kho Đồ §r§0⚡\n§8Đã dùng: §f{$usedSlots}§8/§f{$totalSlots} ô §8(§e{$pages} trang§8)", new FormIcon("textures/items/minecart_chest", FormIcon::IMAGE_TYPE_PATH));
        $actions[] = "inventory";

        // 2. Manual Sell
        $options[] = new MenuOption("§0⚡ §lBán Vật Phẩm Thủ Công §r§0⚡\n§8Bán toàn bộ kho đồ của Minion", new FormIcon("textures/items/gold_nugget", FormIcon::IMAGE_TYPE_PATH));
        $actions[] = "sell_manually";

        // 2. Farmer Seeds
        if ($minion->getMinionType() === "farmer") {
            $seedCount = 0;
            foreach ($minion->getSeedsInventory()->getContents() as $item) {
                if (!$item->isNull()) $seedCount += $item->getCount();
            }
            $options[] = new MenuOption("§0⚡ §lKho Hạt Giống §r§0⚡\n§8Hạt giống: §f{$seedCount} cái", new FormIcon("textures/items/seeds_wheat", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "seeds";
        }

        // 3. Auto Sell
        if (!$minion->isAutoSellUnlocked()) {
            $options[] = new MenuOption("§0⚡ §lMua Auto-Sell §r§0⚡\n§8Chi phí: §e" . number_format(self::AUTO_SELL_COST) . " Coin", new FormIcon("textures/items/gold_ingot", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "buy_auto_sell";
        } else {
            $status = $minion->isAutoSellEnabled() ? "§aBẬT" : "§cTẮT";
            $options[] = new MenuOption("§0⚡ §lAuto-Sell: {$status} §r§0⚡\n§8Nhấn để bật/tắt", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "toggle_auto_sell";
        }

        // 4. Auto Smelt (miner only)
        if ($minion->getMinionType() === "miner") {
            if (!$minion->isAutoSmeltUnlocked()) {
                $options[] = new MenuOption("§0⚡ §lMua Auto-Smelt §r§0⚡\n§8Chi phí: §e" . number_format(self::AUTO_SMELT_COST) . " Coin", new FormIcon("textures/items/coal", FormIcon::IMAGE_TYPE_PATH));
                $actions[] = "buy_auto_smelt";
            } else {
                $status = $minion->isAutoSmeltEnabled() ? "§aBẬT" : "§cTẮT";
                $options[] = new MenuOption("§0⚡ §lAuto-Smelt: {$status} §r§0⚡\n§8Nhấn để bật/tắt", new FormIcon("textures/blocks/furnace_front_on", FormIcon::IMAGE_TYPE_PATH));
                $actions[] = "toggle_auto_smelt";
            }
        }

        // 5. Upgrade Level
        $maxLevel = 10;
        if ($minion->getMinionLevel() < $maxLevel) {
            $levelCost = $minion->getMinionLevel() * 50;
            $options[] = new MenuOption("§0⚡ §lNâng Cấp Minion (Lv. " . ($minion->getMinionLevel() + 1) . ") §r§0⚡\n§8Chi phí: §e" . number_format($levelCost) . " Coin", new FormIcon("textures/items/experience_bottle", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "upgrade_level";
        } else {
            $options[] = new MenuOption("§0⚡ §lCấp Độ Minion §a(Tối đa) §r§0⚡\n§8Đã đạt cấp tối đa!", new FormIcon("textures/items/experience_bottle", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "max_level";
        }

        // 6. Upgrade Pages
        if ($pages < 5) {
            $cost = self::PAGE_UPGRADE_COST;
            $nextPages = $pages + 1;
            $options[] = new MenuOption("§0⚡ §lNâng Cấp Kho (Trang #{$nextPages}) §r§0⚡\n§8Chi phí: §e" . number_format($cost) . " Coin", new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "upgrade_pages";
        } else {
            $options[] = new MenuOption("§0⚡ §lKho Đồ §a(Tối đa 5 trang) §r§0⚡\n§8Đã đạt cấp tối đa!", new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = "max_pages";
        }

        // 6. Stats
        $options[] = new MenuOption("§0⚡ §lThông Tin Minion §r§0⚡\n§8Cấp độ: §e" . $minion->getMinionLevel(), new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH));
        $actions[] = "stats";

        // 7. Retrieve
        $options[] = new MenuOption("§0⚡ §lThu Hồi Minion §r§0⚡\n§8Nhấn để thu hồi về túi đồ", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));
        $actions[] = "retrieve";

        $content = "§7Chủ sở hữu: §f" . $minion->getOwnerName() . "\n";
        $content .= "§7Loại: §e" . $typeName . " §7| Cấp: §e" . $minion->getMinionLevel() . "\n";
        $content .= "§7Kho: §e{$pages} trang §7(§f{$totalSlots} ô§7)";

        $form = new MenuForm(
            "§0⚡ §lQUẢN LÝ MINION: " . strtoupper($typeName) . " §r§0⚡",
            $content,
            $options,
            function (Player $submitter, int $selected) use ($minion, $actions): void {
                if ($minion->isClosed()) return;
                $action = $actions[$selected] ?? null;
                if ($action === null) return;

                switch ($action) {
                    case "inventory":
                        self::openPageSelector($submitter, $minion);
                        break;
                    case "sell_manually":
                        $totalEarned = 0.0;
                        $soldCount = 0;
                        $inv = $minion->getMinionInventory();
                        
                        for ($i = 0; $i < $minion->getInventoryPages() * 54; $i++) {
                            $item = $inv->getItem($i);
                            if (!$item->isNull()) {
                                $price = $minion->resolveItemPrice($item);
                                if ($price > 0) {
                                    $totalEarned += $price * $item->getCount();
                                    $soldCount += $item->getCount();
                                    $inv->clear($i);
                                }
                            }
                        }
                        
                        if ($soldCount > 0) {
                            $moneyInt = (int)$totalEarned;
                            AZEconomy::getInstance()->addMoney($submitter->getName(), $moneyInt);
                            $submitter->sendMessage("§aĐã bán thành công §e{$soldCount}§a vật phẩm từ kho Minion, nhận được §e" . number_format($moneyInt) . " xu§a!");
                            Main::getInstance()->getDatabase()->saveInventory($minion);
                        } else {
                            $submitter->sendMessage("§cKho đồ Minion không có vật phẩm nào có thể bán!");
                        }
                        self::openMenu($submitter, $minion);
                        break;
                    case "seeds":
                        self::openSeedsInventory($submitter, $minion);
                        break;
                    case "buy_auto_sell":
                        self::buyAutoSell($submitter, $minion);
                        break;
                    case "toggle_auto_sell":
                        $minion->setAutoSellEnabled(!$minion->isAutoSellEnabled());
                        $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                        $status = $minion->isAutoSellEnabled() ? "§aBẬT" : "§cTẮT";
                        $submitter->sendMessage("§aAuto-Sell: {$status}");
                        // State lưu trong entity NBT, không cần SQL
                        self::openMenu($submitter, $minion);
                        break;
                    case "buy_auto_smelt":
                        self::buyAutoSmelt($submitter, $minion);
                        break;
                    case "toggle_auto_smelt":
                        $minion->setAutoSmeltEnabled(!$minion->isAutoSmeltEnabled());
                        $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                        $status = $minion->isAutoSmeltEnabled() ? "§aBẬT" : "§cTẮT";
                        $submitter->sendMessage("§aAuto-Smelt: {$status}");
                        // State lưu trong entity NBT, không cần SQL
                        self::openMenu($submitter, $minion);
                        break;
                    case "upgrade_level":
                        self::upgradeLevel($submitter, $minion);
                        break;
                    case "max_level":
                        $submitter->sendMessage("§aMinion đã đạt cấp độ tối đa (Lv.10)!");
                        break;
                    case "upgrade_pages":
                        self::upgradePages($submitter, $minion);
                        break;
                    case "max_pages":
                        $submitter->sendMessage("§aKho đồ Minion đã đạt cấp tối đa (5 trang)!");
                        break;
                    case "stats":
                        $submitter->sendMessage("§e=== THÔNG TIN MINION ===");
                        $submitter->sendMessage("§7Chủ: §f" . $minion->getOwnerName());
                        $submitter->sendMessage("§7Loại: §e" . ucfirst($minion->getMinionType()));
                        $submitter->sendMessage("§7Cấp: §f" . $minion->getMinionLevel());
                        $submitter->sendMessage("§7Kho: §e" . $minion->getInventoryPages() . " trang");
                        break;
                    case "retrieve":
                        self::retrieveMinion($submitter, $minion);
                        break;
                }
            }
        );
        $player->sendForm($form);
    }

    /**
     * Page selector - if 1 page open directly, otherwise show menu
     */
    public static function openPageSelector(Player $player, BaseMinion $minion): void {
        $pages = $minion->getInventoryPages();
        if ($pages === 1) {
            self::openInventoryPage($player, $minion, 1);
            return;
        }

        $options = [];
        for ($i = 1; $i <= $pages; $i++) {
            // Count items in this page
            $itemCount = 0;
            $startSlot = ($i - 1) * 54;
            for ($s = $startSlot; $s < $startSlot + 54; $s++) {
                if (!$minion->getMinionInventory()->getItem($s)->isNull()) {
                    $itemCount++;
                }
            }
            $options[] = new MenuOption("§0⚡ §lTrang #{$i} §r§0⚡\n§8Đã dùng: §f{$itemCount}§8/§f54 ô", new FormIcon("textures/items/minecart_chest", FormIcon::IMAGE_TYPE_PATH));
        }
        $options[] = new MenuOption("§0⚡ §lQuay Lại §r§0⚡", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));

        $form = new MenuForm(
            "§0⚡ §lCHỌN TRANG KHO ĐỒ §r§0⚡",
            "§7Minion có §e{$pages} trang§7 kho đồ.\n§7Chọn trang bạn muốn xem:",
            $options,
            function (Player $submitter, int $selected) use ($minion, $pages): void {
                if ($minion->isClosed()) return;
                if ($selected >= $pages) {
                    // Back button
                    self::openMenu($submitter, $minion);
                    return;
                }
                self::openInventoryPage($submitter, $minion, $selected + 1);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Opens a clean double chest for a specific inventory page
     */
    public static function openInventoryPage(Player $player, BaseMinion $minion, int $page): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName("§0⚡ §lKho Minion - Trang #" . $page . " §r§0⚡");

        $inventory = $menu->getInventory();
        $startSlot = ($page - 1) * 54;

        // Load items from minion inventory into the GUI
        for ($i = 0; $i < 54; $i++) {
            $item = $minion->getMinionInventory()->getItem($startSlot + $i);
            if (!$item->isNull()) {
                $inventory->setItem($i, clone $item);
            }
        }

        // Allow full interaction (take/place items)
        $menu->setListener(InvMenu::readonly());
        $menu->setListener(function(InvMenuTransaction $transaction) use ($minion, $page): InvMenuTransactionResult {
            return $transaction->continue();
        });

        // Save on close
        $menu->setInventoryCloseListener(function(Player $closer, Inventory $inv) use ($minion, $page): void {
            if ($minion->isClosed()) return;
            
            $startSlot = ($page - 1) * 54;
            for ($i = 0; $i < 54; $i++) {
                $item = $inv->getItem($i);
                $minion->getMinionInventory()->setItem($startSlot + $i, $item);
            }

            Main::getInstance()->getDatabase()->saveInventory($minion);
        });

        $menu->send($player);
    }

    /**
     * Opens a chest for farmer seed storage
     */
    public static function openSeedsInventory(Player $player, BaseMinion $minion): void {
        if ($minion->getMinionType() !== "farmer") {
            $player->sendMessage("§cChỉ Minion Farmer mới có kho hạt giống!");
            return;
        }

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName("§0⚡ §lKho Hạt Giống §r§0⚡");

        $inventory = $menu->getInventory();

        // Fill seed slots (0-4 from seedsInventory)
        $seedsContents = $minion->getSeedsInventory()->getContents();
        for ($i = 0; $i < 5; $i++) {
            if (isset($seedsContents[$i])) {
                $inventory->setItem($i, clone $seedsContents[$i]);
            }
        }

        // Fill remaining slots with glass pane
        for ($i = 5; $i < 27; $i++) {
            $pane = StringToItemParser::getInstance()->parse("gray_stained_glass_pane");
            if ($pane !== null) {
                $pane->setCustomName(" ");
                $inventory->setItem($i, $pane);
            }
        }

        $menu->setListener(function(InvMenuTransaction $transaction) use ($minion): InvMenuTransactionResult {
            $slot = $transaction->getAction()->getSlot();
            
            // Only allow interaction with seed slots (0-4)
            if ($slot >= 5) {
                return $transaction->discard();
            }
            
            // Validate seeds
            $newItem = $transaction->getAction()->getTargetItem();
            if (!$newItem->isNull() && !self::isValidSeed($newItem)) {
                $transaction->getPlayer()->sendMessage("§cBạn chỉ có thể bỏ hạt giống vào ô này!");
                return $transaction->discard();
            }
            return $transaction->continue();
        });

        $menu->setInventoryCloseListener(function(Player $closer, Inventory $inv) use ($minion): void {
            if ($minion->isClosed()) return;
            
            $newSeeds = [];
            for ($i = 0; $i < 5; $i++) {
                $item = $inv->getItem($i);
                if (!$item->isNull()) {
                    $newSeeds[$i] = clone $item;
                }
            }
            $minion->getSeedsInventory()->setContents($newSeeds);
            Main::getInstance()->getDatabase()->saveInventory($minion);
        });

        $menu->send($player);
    }

    /**
     * Buy Auto Sell upgrade
     */
    private static function buyAutoSell(Player $player, BaseMinion $minion): void {
        $cost = self::AUTO_SELL_COST;
        $playerCoins = AZEconomy::getInstance()->getCoin($player->getName());
        if ($playerCoins < $cost) {
            $player->sendMessage("§cBạn không đủ Coin! Cần §e" . number_format($cost) . " Coin§c.");
            return;
        }

        $form = new \dktapps\pmforms\ModalForm(
            "§l§1XÁC NHẬN MUA AUTO-SELL",
            "§fBạn có chắc chắn muốn mua tính năng §eAuto-Sell§f không?\n\n" .
            "§7Chi phí: §e" . number_format($cost) . " Coin\n\n" .
            "§l§eQUYỀN LỢI:\n§a+ Tự động bán vật phẩm thu hoạch được.\n§a+ Tiền bán sẽ cộng trực tiếp vào ví Money.\n§a+ Tránh đầy kho đồ Minion.",
            function (Player $submitter, bool $choice) use ($minion, $cost): void {
                if (!$choice) {
                    self::openMenu($submitter, $minion);
                    return;
                }
                if ($minion->isClosed()) return;
                $playerCoins = AZEconomy::getInstance()->getCoin($submitter->getName());
                if ($playerCoins < $cost) {
                    $submitter->sendMessage("§cBạn không đủ Coin! Cần §e" . number_format($cost) . " Coin§c.");
                    return;
                }

                AZEconomy::getInstance()->reduceCoin($submitter->getName(), $cost);
                $minion->setAutoSellUnlocked(true);
                $minion->setAutoSellEnabled(true);
                $submitter->getWorld()->addSound($submitter->getPosition(), new \pocketmine\world\sound\XpLevelUpSound(30));
                $submitter->sendMessage("§aMua Auto-Sell thành công!");
                self::openMenu($submitter, $minion);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Buy Auto Smelt upgrade
     */
    private static function buyAutoSmelt(Player $player, BaseMinion $minion): void {
        $cost = self::AUTO_SMELT_COST;
        $playerCoins = AZEconomy::getInstance()->getCoin($player->getName());
        if ($playerCoins < $cost) {
            $player->sendMessage("§cBạn không đủ Coin! Cần §e" . number_format($cost) . " Coin§c.");
            return;
        }

        $form = new \dktapps\pmforms\ModalForm(
            "§l§1XÁC NHẬN MUA AUTO-SMELT",
            "§fBạn có chắc chắn muốn mua tính năng §eAuto-Smelt§f không?\n\n" .
            "§7Chi phí: §e" . number_format($cost) . " Coin\n\n" .
            "§l§eQUYỀN LỢI:\n§a+ Quặng khai thác được sẽ tự nung thành phôi.\n§a+ Tăng giá bán khi kết hợp Auto-Sell.",
            function (Player $submitter, bool $choice) use ($minion, $cost): void {
                if (!$choice) {
                    self::openMenu($submitter, $minion);
                    return;
                }
                if ($minion->isClosed()) return;
                $playerCoins = AZEconomy::getInstance()->getCoin($submitter->getName());
                if ($playerCoins < $cost) {
                    $submitter->sendMessage("§cBạn không đủ Coin! Cần §e" . number_format($cost) . " Coin§c.");
                    return;
                }

                AZEconomy::getInstance()->reduceCoin($submitter->getName(), $cost);
                $minion->setAutoSmeltUnlocked(true);
                $minion->setAutoSmeltEnabled(true);
                $submitter->getWorld()->addSound($submitter->getPosition(), new \pocketmine\world\sound\XpLevelUpSound(30));
                $submitter->sendMessage("§aMua Auto-Smelt thành công!");
                self::openMenu($submitter, $minion);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Buy level upgrade
     */
    private static function upgradeLevel(Player $player, BaseMinion $minion): void {
        $currentLevel = $minion->getMinionLevel();
        if ($currentLevel >= 10) {
            $player->sendMessage("§aĐã đạt cấp tối đa!");
            return;
        }

        $cost = $currentLevel * 50;
        $playerCoins = AZEconomy::getInstance()->getCoin($player->getName());
        if ($playerCoins < $cost) {
            $player->sendMessage("§cBạn không đủ Coin để nâng cấp! Cần: " . number_format($cost) . " Coin");
            return;
        }

        $type = $minion->getMinionType();
        $benefits = "";
        $oldCooldown = max(20, 64 - ($currentLevel * 4));
        $newCooldown = max(20, 64 - (($currentLevel + 1) * 4));
        $benefits .= "§a+ Thời gian chờ: §c" . round($oldCooldown / 20, 1) . "s §a-> §e" . round($newCooldown / 20, 1) . "s\n";

        if ($type === "farmer" || $type === "lumberjack") {
            $baseR = $type === "farmer" ? 3 : 5;
            $oldArea = (($baseR + ($currentLevel - 1)) * 2 + 1);
            $newArea = (($baseR + $currentLevel) * 2 + 1);
            $benefits .= "§a+ Khu vực hoạt động: §c{$oldArea}x{$oldArea} §a-> §e{$newArea}x{$newArea}\n";
        }

        $form = new \dktapps\pmforms\ModalForm(
            "§l§1XÁC NHẬN NÂNG CẤP",
            "§fBạn có chắc chắn muốn nâng cấp Minion lên §eLv." . ($currentLevel + 1) . " §fkhông?\n\n" .
            "§7Chi phí: §e" . number_format($cost) . " Coin\n\n" .
            "§l§eQUYỀN LỢI:\n" . $benefits,
            function (Player $submitter, bool $choice) use ($minion, $cost, $currentLevel): void {
                if (!$choice) {
                    self::openMenu($submitter, $minion);
                    return;
                }
                if ($minion->isClosed()) return;
                $playerCoins = AZEconomy::getInstance()->getCoin($submitter->getName());
                if ($playerCoins < $cost) {
                    $submitter->sendMessage("§cBạn không đủ Coin để nâng cấp! Cần: " . number_format($cost) . " Coin");
                    return;
                }

                AZEconomy::getInstance()->reduceCoin($submitter->getName(), $cost);
                $minion->setMinionLevel($currentLevel + 1);
                $minion->updateNameTag();
                $submitter->sendMessage("§aĐã nâng cấp Minion lên Lv." . ($currentLevel + 1) . "!");
                $submitter->getWorld()->addSound($submitter->getPosition(), new \pocketmine\world\sound\XpLevelUpSound(30));
                self::openMenu($submitter, $minion);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Buy additional inventory page
     */
    private static function upgradePages(Player $player, BaseMinion $minion): void {
        $currentPages = $minion->getInventoryPages();
        if ($currentPages >= 5) {
            $player->sendMessage("§aĐã đạt cấp tối đa (5 trang)!");
            return;
        }

        $cost = self::PAGE_UPGRADE_COST;
        $playerCoins = AZEconomy::getInstance()->getCoin($player->getName());
        if ($playerCoins < $cost) {
            $player->sendMessage("§cBạn không đủ Coin! Cần §e" . number_format($cost) . " Coin§c.");
            return;
        }

        $form = new \dktapps\pmforms\ModalForm(
            "§l§1XÁC NHẬN NÂNG CẤP KHO",
            "§fBạn có chắc chắn muốn mở rộng kho đồ Minion lên §eTrang " . ($currentPages + 1) . " §fkhông?\n\n" .
            "§7Chi phí: §e" . number_format($cost) . " Coin\n\n" .
            "§l§eQUYỀN LỢI:\n§a+ Kho đồ: §c" . ($currentPages * 54) . " ô §a-> §e" . (($currentPages + 1) * 54) . " ô",
            function (Player $submitter, bool $choice) use ($minion, $cost, $currentPages): void {
                if (!$choice) {
                    self::openMenu($submitter, $minion);
                    return;
                }
                if ($minion->isClosed()) return;
                $playerCoins = AZEconomy::getInstance()->getCoin($submitter->getName());
                if ($playerCoins < $cost) {
                    $submitter->sendMessage("§cBạn không đủ Coin! Cần §e" . number_format($cost) . " Coin§c.");
                    return;
                }

                AZEconomy::getInstance()->reduceCoin($submitter->getName(), $cost);
                $minion->setInventoryPages($currentPages + 1);
                $submitter->getWorld()->addSound($submitter->getPosition(), new \pocketmine\world\sound\XpLevelUpSound(30));
                $submitter->sendMessage("§aNâng cấp kho lên §e" . ($currentPages + 1) . " trang §athành công!");
                self::openMenu($submitter, $minion);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Retrieve (pick up) the Minion
     */
    private static function retrieveMinion(Player $player, BaseMinion $minion): void {
        // Return all items in minion inventory
        $totalSlots = $minion->getInventoryPages() * 54;
        for ($i = 0; $i < $totalSlots; $i++) {
            $item = $minion->getMinionInventory()->getItem($i);
            if (!$item->isNull()) {
                if ($player->getInventory()->canAddItem($item)) {
                    $player->getInventory()->addItem($item);
                } else {
                    $player->getWorld()->dropItem($player->getPosition(), $item);
                }
            }
        }

        // Return seeds
        foreach ($minion->getSeedsInventory()->getContents() as $item) {
            if (!$item->isNull()) {
                if ($player->getInventory()->canAddItem($item)) {
                    $player->getInventory()->addItem($item);
                } else {
                    $player->getWorld()->dropItem($player->getPosition(), $item);
                }
            }
        }

        // Give Minion Spawn Item — lưu đầy đủ state vào NBT
        $minionItem = Main::getInstance()->createMinionItem(
            $minion->getMinionType(),
            $minion->getMinionLevel(),
            $minion->getInventoryPages(),
            $minion->isAutoSellEnabled(),
            $minion->isAutoSmeltEnabled(),
            $minion->isAutoSellUnlocked(),
            $minion->isAutoSmeltUnlocked()
        );

        if ($player->getInventory()->canAddItem($minionItem)) {
            $player->getInventory()->addItem($minionItem);
        } else {
            $player->getWorld()->dropItem($player->getPosition(), $minionItem);
        }

        // Unregister and Despawn
        $minionId = $minion->getMinionId();
        Main::getInstance()->unregisterMinion($minionId);
        Main::getInstance()->getDatabase()->deleteInventory($minionId);

        $minion->flagForDespawn();
        $player->sendMessage("§aĐã thu hồi Minion thành công!");
    }

    /**
     * Helper to verify if an item is a valid seed
     */
    public static function isValidSeed(Item $item): bool {
        $validIds = [
            \pocketmine\item\VanillaItems::WHEAT_SEEDS()->getTypeId(),
            \pocketmine\item\VanillaItems::BEETROOT_SEEDS()->getTypeId(),
            \pocketmine\item\VanillaItems::MELON_SEEDS()->getTypeId(),
            \pocketmine\item\VanillaItems::PUMPKIN_SEEDS()->getTypeId(),
            \pocketmine\item\VanillaItems::POTATO()->getTypeId(),
            \pocketmine\item\VanillaItems::CARROT()->getTypeId(),
            \pocketmine\block\VanillaBlocks::NETHER_WART()->asItem()->getTypeId()
        ];
        return in_array($item->getTypeId(), $validIds, true);
    }
}
