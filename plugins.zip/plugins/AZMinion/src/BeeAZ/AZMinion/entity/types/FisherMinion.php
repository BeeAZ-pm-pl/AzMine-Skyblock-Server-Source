<?php
declare(strict_types=1);

namespace BeeAZ\AZMinion\entity\types;

use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;
use pocketmine\world\particle\BubbleParticle;
use pocketmine\world\sound\PopSound;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\entity\animation\ArmSwingAnimation;
use pocketmine\nbt\tag\CompoundTag;
use BeeAZ\AZMinion\Main;
use BeeAZ\AZMinion\entity\MinionHook;

class FisherMinion extends BaseMinion {

    private int $fisherState = 0; // 0 = idle, 1 = casting, 2 = waiting, 3 = reeling
    private int $fisherWaitTicks = 0;
    private ?MinionHook $activeHook = null;

    public function getMinionType(): string {
        return "fisher";
    }

    protected function setToolVisual(): void {
        $this->getInventory()->setItemInHand(VanillaItems::FISHING_ROD());
    }

    protected function performWork(): void {
        // Nothing here. Fisher handles work inside onUpdate directly.
    }

    public function onUpdate(int $currentTick): bool {
        if ($this->isClosed() || !$this->isAlive()) {
            return parent::onUpdate($currentTick);
        }

        $hasUpdate = parent::onUpdate($currentTick);

        // Chống rơi
        $this->motion = new Vector3(0, 0, 0);

        if ($this->isInventoryFull()) {
            $this->updateNameTag();
            return $hasUpdate;
        }

        $waterPos = $this->findWaterSource();
        if ($waterPos === null) return $hasUpdate;

        switch ($this->fisherState) {
            case 0:
                $this->castFishingHook($waterPos);
                $this->fisherState = 1;
                $this->fisherWaitTicks = 20; 
                return true;

            case 1:
                $this->fisherWaitTicks--;
                if ($this->fisherWaitTicks <= 0) {
                    $this->fisherState = 2;
                    $this->fisherWaitTicks = mt_rand(5 * 20, 15 * 20);
                }
                return true;

            case 2:
                $this->fisherWaitTicks--;
                if ($currentTick % 40 === 0) {
                    $this->getWorld()->addParticle($waterPos->add(0.5, 0.8, 0.5), new BubbleParticle());
                }
                if ($this->fisherWaitTicks <= 0) {
                    $this->fisherState = 3;
                    $this->fisherWaitTicks = 10; 
                    $this->getWorld()->addParticle($waterPos->add(0.5, 0.8, 0.5), new BubbleParticle());
                    $this->getWorld()->addParticle($waterPos->add(0.5, 0.8, 0.5), new BubbleParticle());
                    $this->getWorld()->addParticle($waterPos->add(0.5, 0.8, 0.5), new BubbleParticle());
                    $this->getWorld()->addSound($waterPos, new PopSound());
                }
                return true;

            case 3:
                $this->fisherWaitTicks--;
                if ($this->fisherWaitTicks <= 0) {
                    $this->reelInHook();
                    $this->broadcastAnimation(new ArmSwingAnimation($this));
                    $this->fishAction($waterPos);
                    $this->fisherState = 0;
                    $this->cooldownTracker = 40; 
                }
                return true;
        }

        return true;
    }

    private function findWaterSource(): ?Vector3 {
        $world = $this->getWorld();
        $r = 2;
        for ($y = -1; $y <= 0; $y++) {
            for ($x = -$r; $x <= $r; $x++) {
                for ($z = -$r; $z <= $r; $z++) {
                    $pos = $this->spawnCenter->add($x, $y, $z);
                    $block = $world->getBlock($pos);
                    if ($block instanceof \pocketmine\block\Water) {
                        return $pos;
                    }
                }
            }
        }
        return null;
    }

    private function castFishingHook(Vector3 $waterPos): void {
        $this->broadcastAnimation(new ArmSwingAnimation($this));
        $this->getWorld()->addSound($this->getPosition(), new PopSound());

        $eyePos = $this->getEyePos();
        $target = $waterPos->add(0.5, 0.5, 0.5);
        $direction = $target->subtractVector($eyePos)->normalize();

        $horizontal = sqrt($direction->x * $direction->x + $direction->z * $direction->z);
        $yaw = atan2($direction->z, $direction->x) * 180 / M_PI - 90;
        $pitch = -atan2($direction->y, $horizontal) * 180 / M_PI;
        
        $this->setRotation($yaw, $pitch);
        $this->teleport($this->getLocation());

        $loc = Location::fromObject($eyePos, $this->getWorld(), $yaw, $pitch);
        $hook = new MinionHook($loc, $this, CompoundTag::create());
        $hook->setMotion($direction->multiply(1.1));
        $hook->spawnToAll();
        $this->activeHook = $hook;
    }

    private function reelInHook(): void {
        if ($this->activeHook !== null && !$this->activeHook->isClosed()) {
            $this->activeHook->flagForDespawn();
            $this->activeHook = null;
        }
    }

    private function fishAction(Vector3 $waterPos): void {
        $item = null;

        if (class_exists(\BeeAZ\AZCustomFishing\utils\FishManager::class)) {
            $fish = \BeeAZ\AZCustomFishing\utils\FishManager::getRandomFish($this->minionLevel);
            $item = VanillaItems::RAW_SALMON();
            $item->setCustomName("§r§b{$fish['name']} §e({$fish['length']} cm)");
            $item->getNamedTag()->setInt("fish_price", $fish['price']);
            
            $plugin = \BeeAZ\AZCustomFishing\Main::getInstance();
            if ($plugin !== null) {
                $loreConfig = $plugin->getConfig()->getNested("items.fish_lore", []);
                $lore = [];
                foreach ($loreConfig as $line) {
                    $lore[] = str_replace("{price}", (string)$fish['price'], $line);
                }
                $item->setLore($lore);
            }
        }

        if ($item === null) {
            $rand = mt_rand(1, 100);
            $item = VanillaItems::RAW_FISH(); 

            if ($rand <= 5) {
                $item = VanillaItems::PUFFERFISH();
            } elseif ($rand <= 20) {
                $item = VanillaItems::RAW_SALMON();
            } elseif ($rand <= 30) {
                $item = VanillaItems::CLOWNFISH();
            }
        }

        $this->getWorld()->addSound($this->getPosition(), new XpLevelUpSound(10));
        
        $this->processDrops([$item]);
        $this->updateNameTag();
    }
}
