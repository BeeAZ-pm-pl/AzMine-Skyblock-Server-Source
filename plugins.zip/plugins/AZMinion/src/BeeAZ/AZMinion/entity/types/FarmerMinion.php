<?php
declare(strict_types=1);

namespace BeeAZ\AZMinion\entity\types;

use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\sound\ItemBreakSound;
use pocketmine\world\sound\PopSound;
use pocketmine\color\Color;
use pocketmine\entity\animation\ArmSwingAnimation;
use pocketmine\block\Block;
use pocketmine\block\Crops;
use pocketmine\block\NetherWart;
use pocketmine\block\Melon;
use pocketmine\block\Pumpkin;
use pocketmine\item\Item;
use BeeAZ\AZMinion\Main;

class FarmerMinion extends BaseMinion {

    private ?Vector3 $moveTarget = null;
    private ?Vector3 $targetBlock = null;

    public function getMinionType(): string {
        return "farmer";
    }

    protected function setToolVisual(): void {
        $this->getInventory()->setItemInHand(VanillaItems::DIAMOND_HOE());
    }

    public function onUpdate(int $currentTick): bool {
        if ($this->isClosed() || !$this->isAlive()) {
            return parent::onUpdate($currentTick);
        }

        // Chống rơi xuống void
        $this->motion = new Vector3(0, 0, 0);

        if ($this->moveTarget !== null) {
            $pos = $this->getPosition();
            $target = $this->moveTarget;
            
            $dx = $target->x - $pos->x;
            $dy = $target->y - $pos->y;
            $dz = $target->z - $pos->z;

            $dist = sqrt($dx * $dx + $dy * $dy + $dz * $dz);
            if ($dist < 0.2) {
                $this->moveTarget = null; // Reached
                $this->cooldownTracker = 0; // Thu hoạch ngay lập tức
            } else {
                $speed = 0.25; 
                $step = min($speed, $dist);
                $moveVec = new Vector3($dx / $dist, $dy / $dist, $dz / $dist);
                $mv = $moveVec->multiply($step);
                $newPos = $pos->add($mv->x, $mv->y, $mv->z);
                
                $this->lookAtAndTurn($target);
                $this->teleport($newPos);
                
                if ($currentTick % 5 === 0) {
                    $this->broadcastAnimation(new ArmSwingAnimation($this));
                }
                
                // Return here so it doesn't do work while moving. But we still need BaseMinion::onUpdate to tick visuals?
                // Actually, just let it fall through and performWork will return early if moveTarget !== null.
            }
        }

        return parent::onUpdate($currentTick);
    }

    protected function performWork(): void {
        if ($this->moveTarget !== null) {
            return; // Vẫn đang di chuyển
        }
        
        $harvestTarget = $this->findFarmerHarvestTarget();
        if ($harvestTarget !== null) {
            $this->targetBlock = $harvestTarget;
            if ($this->isAdjacent($harvestTarget)) {
                $this->harvestCrop($harvestTarget);
            } else {
                $this->startPathfinding($harvestTarget);
            }
            return;
        }

        $plantTarget = $this->findFarmerPlantTarget();
        if ($plantTarget !== null && !$this->isSeedsInventoryEmpty()) {
            $this->targetBlock = $plantTarget;
            if ($this->isAdjacent($plantTarget)) {
                $this->plantCrop($plantTarget);
            } else {
                $this->startPathfinding($plantTarget);
            }
        }
    }

    private function findFarmerHarvestTarget(): ?Vector3 {
        $world = $this->getWorld();
        $cx = (int)floor($this->spawnCenter->x);
        $cy = (int)floor($this->spawnCenter->y);
        $cz = (int)floor($this->spawnCenter->z);
        $r = 3 + ($this->minionLevel - 1); // Mở rộng bán kính mỗi cấp

        for ($x = -$r; $x <= $r; $x++) {
            for ($y = -2; $y <= 2; $y++) {
                for ($z = -$r; $z <= $r; $z++) {
                    $pos = new Vector3($cx + $x, $cy + $y, $cz + $z);
                    $block = $world->getBlock($pos);
                    if ($this->isFullyGrownCrop($block)) {
                        return $pos;
                    }
                }
            }
        }
        return null;
    }

    private function findFarmerPlantTarget(): ?Vector3 {
        $world = $this->getWorld();
        $cx = (int)floor($this->spawnCenter->x);
        $cy = (int)floor($this->spawnCenter->y);
        $cz = (int)floor($this->spawnCenter->z);
        $r = 3 + ($this->minionLevel - 1);

        for ($x = -$r; $x <= $r; $x++) {
            for ($y = -2; $y <= 2; $y++) {
                for ($z = -$r; $z <= $r; $z++) {
                    $pos = new Vector3($cx + $x, $cy + $y, $cz + $z);
                    $block = $world->getBlock($pos);
                    if ($block->getTypeId() === VanillaBlocks::FARMLAND()->getTypeId()) {
                        $upPos = $pos->add(0, 1, 0);
                        if (!$world->getBlock($upPos)->isSolid() && $world->getBlock($upPos)->getTypeId() === VanillaBlocks::AIR()->getTypeId()) {
                            return $upPos;
                        }
                    }
                }
            }
        }
        return null;
    }

    private function isFullyGrownCrop(Block $block): bool {
        if ($block instanceof Crops) {
            return $block->getAge() >= $block->getMaxAge();
        }
        if ($block instanceof NetherWart) {
            return $block->getAge() >= 3;
        }
        if ($block instanceof Melon || $block instanceof Pumpkin) {
            return true;
        }
        return false;
    }

    private function harvestCrop(Vector3 $pos): void {
        $world = $this->getWorld();
        $block = $world->getBlock($pos);

        $this->lookAtAndTurn($pos);
        $this->broadcastAnimation(new ArmSwingAnimation($this));
        
        $world->addSound($pos, new ItemBreakSound(VanillaItems::DIAMOND_HOE()));
        $world->addParticle($pos, new DustParticle(new Color(0, 200, 0)));

        $drops = $block->getDrops(VanillaItems::DIAMOND_HOE());
        
        $seasonPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZSeason");
        if ($seasonPlugin instanceof \az\season\Main) {
            $newDrops = [];
            foreach ($drops as $item) {
                $cropsConfig = $seasonPlugin->getConfig()->get("crops", []);
                $foundConfig = null;
                foreach ($cropsConfig as $key => $data) {
                    $parsed = \pocketmine\item\StringToItemParser::getInstance()->parse($data['id']);
                    if ($parsed !== null && $parsed->getTypeId() === $item->getTypeId()) {
                        $foundConfig = $data;
                        break;
                    }
                }
                
                if ($foundConfig !== null) {
                    $freshness = mt_rand(1, 100);
                    $nbt = $item->getNamedTag();
                    $nbt->setInt("AZFreshness", $freshness);
                    $item->setNamedTag($nbt);
                    
                    $color = "§a";
                    if ($freshness < 50) $color = "§e";
                    if ($freshness < 20) $color = "§c";
                    
                    $item->setCustomName("§r" . $foundConfig['name'] . "\n§r" . $color . "Độ tươi: " . $freshness . "%");
                }
                $newDrops[] = $item;
            }
            $drops = $newDrops;
        }
        
        if ($block instanceof Crops || $block instanceof NetherWart) {
            $world->setBlock($pos, VanillaBlocks::AIR());
            
            $seedItem = $this->retrieveSeedForCrop($block);
            if ($seedItem !== null) {
                $plantedBlock = $this->getCropBlockFromSeed($seedItem);
                if ($plantedBlock !== null) {
                    $world->setBlock($pos, $plantedBlock);
                    $this->removeSeed($seedItem);
                }
            }
        } else {
            $world->setBlock($pos, VanillaBlocks::AIR());
        }

        $this->processDrops($drops);

        $this->updateNameTag();
    }

    protected function processDrops(array $drops): void {
        $remainingDrops = [];
        $seedInv = $this->seedsInventory;

        foreach ($drops as $drop) {
            if (\BeeAZ\AZMinion\ui\MinionInventoryUI::isValidSeed($drop)) {
                for ($i = 0; $i < 5; $i++) {
                    $item = $seedInv->getItem($i);
                    if ($item->isNull() || ($item->equals($drop, true, true) && $item->getCount() < $item->getMaxStackSize())) {
                        $addCount = min($drop->getCount(), $item->getMaxStackSize() - $item->getCount());
                        $drop->setCount($drop->getCount() - $addCount);

                        if ($item->isNull()) {
                            $newItem = clone $drop;
                            $newItem->setCount($addCount);
                            $seedInv->setItem($i, $newItem);
                        } else {
                            $item->setCount($item->getCount() + $addCount);
                            $seedInv->setItem($i, $item);
                        }
                        if ($drop->getCount() <= 0) break;
                    }
                }
            }

            if ($drop->getCount() > 0) {
                $remainingDrops[] = $drop;
            }
        }

        if (!empty($remainingDrops)) {
            parent::processDrops($remainingDrops);
        }
    }

    private function plantCrop(Vector3 $pos): void {
        $seed = $this->getNextAvailableSeed();
        if ($seed === null) return;

        $world = $this->getWorld();
        $cropBlock = $this->getCropBlockFromSeed($seed);
        if ($cropBlock === null) return;

        $this->lookAtAndTurn($pos);
        $this->broadcastAnimation(new ArmSwingAnimation($this));

        $world->setBlock($pos, $cropBlock);
        
        $world->addSound($pos, new PopSound());

        $this->removeSeed($seed);
    }

    private function getNextAvailableSeed(): ?Item {
        foreach ($this->seedsInventory->getContents() as $item) {
            if (!$item->isNull()) {
                return $item;
            }
        }
        return null;
    }

    private function removeSeed(Item $seed): void {
        $inv = $this->seedsInventory;
        foreach ($inv->getContents() as $slot => $item) {
            if ($item->equals($seed, true, false)) {
                $item->pop();
                $inv->setItem($slot, $item);
                break;
            }
        }
    }

    private function retrieveSeedForCrop(Block $crop): ?Item {
        $cropId = $crop->getTypeId();
        $map = [
            VanillaBlocks::WHEAT()->getTypeId() => VanillaItems::WHEAT_SEEDS()->getTypeId(),
            VanillaBlocks::CARROTS()->getTypeId() => VanillaItems::CARROT()->getTypeId(),
            VanillaBlocks::POTATOES()->getTypeId() => VanillaItems::POTATO()->getTypeId(),
            VanillaBlocks::BEETROOTS()->getTypeId() => VanillaItems::BEETROOT_SEEDS()->getTypeId(),
            VanillaBlocks::NETHER_WART()->getTypeId() => VanillaBlocks::NETHER_WART()->asItem()->getTypeId()
        ];
        
        $seedTypeId = $map[$cropId] ?? null;
        if ($seedTypeId === null) return null;

        foreach ($this->seedsInventory->getContents() as $item) {
            if ($item->getTypeId() === $seedTypeId) {
                return $item;
            }
        }
        return null;
    }

    private function getCropBlockFromSeed(Item $seed): ?Block {
        $id = $seed->getTypeId();
        
        if ($id === VanillaItems::WHEAT_SEEDS()->getTypeId()) return VanillaBlocks::WHEAT();
        if ($id === VanillaItems::CARROT()->getTypeId()) return VanillaBlocks::CARROTS();
        if ($id === VanillaItems::POTATO()->getTypeId()) return VanillaBlocks::POTATOES();
        if ($id === VanillaItems::BEETROOT_SEEDS()->getTypeId()) return VanillaBlocks::BEETROOTS();
        if ($id === VanillaBlocks::NETHER_WART()->asItem()->getTypeId()) return VanillaBlocks::NETHER_WART();
        if ($id === VanillaItems::MELON_SEEDS()->getTypeId()) return VanillaBlocks::MELON_STEM();
        if ($id === VanillaItems::PUMPKIN_SEEDS()->getTypeId()) return VanillaBlocks::PUMPKIN_STEM();
        
        return null;
    }

    private function isSeedsInventoryEmpty(): bool {
        foreach ($this->seedsInventory->getContents() as $item) {
            if (!$item->isNull()) return false;
        }
        return true;
    }

    private function isAdjacent(Vector3 $target): bool {
        // Tọa độ làm việc cách mục tiêu dưới 0.3 block
        return $this->getPosition()->distance($target->add(0.5, 0, 0.5)) <= 0.3;
    }

    private function startPathfinding(Vector3 $target): void {
        $this->moveTarget = $target->add(0.5, 0, 0.5);
    }
}
