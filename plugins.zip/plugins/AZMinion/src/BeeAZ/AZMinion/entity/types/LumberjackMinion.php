<?php
declare(strict_types=1);

namespace BeeAZ\AZMinion\entity\types;

use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\sound\ItemBreakSound;
use pocketmine\color\Color;
use pocketmine\entity\animation\ArmSwingAnimation;
use pocketmine\block\Block;
use pocketmine\block\Wood;
use BeeAZ\AZMinion\Main;

class LumberjackMinion extends BaseMinion {

    private ?Vector3 $moveTarget = null;
    private ?Vector3 $targetBlock = null;

    public function getMinionType(): string {
        return "lumberjack";
    }

    protected function setToolVisual(): void {
        $this->getInventory()->setItemInHand(VanillaItems::DIAMOND_AXE());
    }

    public function onUpdate(int $currentTick): bool {
        if ($this->isClosed() || !$this->isAlive()) {
            return parent::onUpdate($currentTick);
        }

        $this->motion = new Vector3(0, 0, 0);

        if ($this->moveTarget !== null) {
            $pos = $this->getPosition();
            $target = $this->moveTarget;
            
            $dx = $target->x - $pos->x;
            $dy = $target->y - $pos->y;
            $dz = $target->z - $pos->z;

            $dist = sqrt($dx * $dx + $dy * $dy + $dz * $dz);
            if ($dist < 0.2) {
                $this->moveTarget = null;
                $this->cooldownTracker = 0; // Chặt ngay lập tức khi bay tới
            } else {
                $speed = 0.25; 
                $step = min($speed, $dist);
                $moveVec = new Vector3($dx / $dist, $dy / $dist, $dz / $dist);
                $mv = $moveVec->multiply($step);
                $newPos = $pos->add($mv->x, $mv->y, $mv->z);
                
                $this->lookAtAndTurn($target);
                $this->teleport($newPos);
                
                if ($currentTick % 5 === 0) {
                    $this->broadcastAnimation(new ArmSwingAnimation($this));
                }
            }
        }

        return parent::onUpdate($currentTick);
    }

    protected function performWork(): void {
        if ($this->moveTarget !== null) {
            return; // Đang bay tới
        }
        $target = $this->findLumberjackTarget();
        if ($target !== null) {
            $this->targetBlock = $target;
            if ($this->isAdjacent($target)) {
                $this->chopLog($target);
            } else {
                $this->startPathfinding($target);
            }
        }
    }

    private function isNaturalSoil(Block $block): bool {
        $id = $block->getTypeId();
        return $id === VanillaBlocks::DIRT()->getTypeId() ||
               $id === VanillaBlocks::GRASS()->getTypeId() ||
               $id === VanillaBlocks::PODZOL()->getTypeId() ||
               $id === VanillaBlocks::MYCELIUM()->getTypeId() ||
               $id === VanillaBlocks::FARMLAND()->getTypeId() ||
               $id === VanillaBlocks::NETHERRACK()->getTypeId() ||
               $id === VanillaBlocks::CRIMSON_NYLIUM()->getTypeId() ||
               $id === VanillaBlocks::WARPED_NYLIUM()->getTypeId() ||
               $id === VanillaBlocks::END_STONE()->getTypeId();
    }



    private function isLeavesOrWart(Block $block): bool {
        if ($block instanceof \pocketmine\block\Leaves) return true;
        $id = $block->getTypeId();
        return $id === VanillaBlocks::NETHER_WART_BLOCK()->getTypeId() ||
               $id === VanillaBlocks::WARPED_WART_BLOCK()->getTypeId() ||
               $id === VanillaBlocks::SHROOMLIGHT()->getTypeId();
    }

    private function findLumberjackTarget(): ?Vector3 {
        $world = $this->getWorld();
        $cx = (int)floor($this->spawnCenter->x);
        $cy = (int)floor($this->spawnCenter->y);
        $cz = (int)floor($this->spawnCenter->z);
        $r = 5 + ($this->minionLevel - 1); // Bán kính quét mở rộng 1 block (3x3 area) mỗi cấp

        $visitedTreeLogs = []; // Cache to avoid redundant traceTree calls

        for ($x = -$r; $x <= $r; $x++) {
            for ($y = -2; $y <= 4; $y++) {
                for ($z = -$r; $z <= $r; $z++) {
                    $pos = new Vector3($cx + $x, $cy + $y, $cz + $z);
                    $key = "{$pos->x},{$pos->y},{$pos->z}";
                    
                    if (isset($visitedTreeLogs[$key])) continue;

                    $block = $world->getBlock($pos);
                    if ($block instanceof Wood) {
                        $treeLogs = $this->traceTree($pos);
                        if (!empty($treeLogs)) {
                            // Mark all logs of this tree as visited
                            foreach ($treeLogs as $log) {
                                $visitedTreeLogs["{$log->x},{$log->y},{$log->z}"] = true;
                            }

                            usort($treeLogs, function(Vector3 $a, Vector3 $b) {
                                return $a->y <=> $b->y;
                            });
                            
                            $lowestLog = $treeLogs[0];
                            $highestLog = $treeLogs[count($treeLogs) - 1];
                            
                            $blockBelow = $world->getBlock($lowestLog->subtract(0, 1, 0));
                            $blockAboveHighest = $world->getBlock($highestLog->add(0, 1, 0));
                            
                            if ($this->isNaturalSoil($blockBelow) && $this->isLeavesOrWart($blockAboveHighest)) {
                                return $lowestLog;
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    private function traceTree(Vector3 $start): array {
        $world = $this->getWorld();
        $queue = [$start];
        $visited = ["{$start->x},{$start->y},{$start->z}" => true];
        $logs = [$start];

        $maxLogs = 64; 

        while (!empty($queue) && count($logs) < $maxLogs) {
            $curr = array_shift($queue);
            
            for ($dx = -1; $dx <= 1; $dx++) {
                for ($dy = -1; $dy <= 1; $dy++) {
                    for ($dz = -1; $dz <= 1; $dz++) {
                        if ($dx === 0 && $dy === 0 && $dz === 0) continue;
                        $pos = $curr->add($dx, $dy, $dz);
                        
                        if ($pos->distanceSquared($this->spawnCenter) > 64) continue;

                        $key = "{$pos->x},{$pos->y},{$pos->z}";
                        if (isset($visited[$key])) continue;

                        $block = $world->getBlock($pos);
                        if ($block instanceof Wood) {
                            $visited[$key] = true;
                            $queue[] = $pos;
                            $logs[] = $pos;
                        }
                    }
                }
            }
        }
        return $logs;
    }

    private function chopLog(Vector3 $pos): void {
        $world = $this->getWorld();
        $block = $world->getBlock($pos);
        if (!$block instanceof Wood) return;

        $this->lookAtAndTurn($pos);
        $this->broadcastAnimation(new ArmSwingAnimation($this));
        
        $world->addSound($pos, new ItemBreakSound(VanillaItems::DIAMOND_AXE()));

        $treeLogs = $this->traceTree($pos);
        $allDrops = [];
        
        foreach ($treeLogs as $logPos) {
            $logBlock = $world->getBlock($logPos);
            if ($logBlock instanceof Wood) {
                $drops = $logBlock->getDrops(VanillaItems::DIAMOND_AXE());
                foreach ($drops as $drop) {
                    $allDrops[] = $drop;
                }
                $world->setBlock($logPos, VanillaBlocks::AIR());
                $world->addParticle($logPos, new DustParticle(new Color(139, 90, 43)));
            }
        }

        $this->processDrops($allDrops);

        $this->updateNameTag();
    }

    private function isAdjacent(Vector3 $target): bool {
        return $this->getPosition()->distance($target->add(0.5, 0, 0.5)) <= 0.3;
    }

    private function startPathfinding(Vector3 $target): void {
        $this->moveTarget = $target->add(0.5, 0, 0.5);
    }
}
