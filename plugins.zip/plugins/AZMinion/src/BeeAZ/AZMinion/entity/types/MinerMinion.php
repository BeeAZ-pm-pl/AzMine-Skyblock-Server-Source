<?php
declare(strict_types=1);

namespace BeeAZ\AZMinion\entity\types;

use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\sound\ItemBreakSound;
use pocketmine\color\Color;
use pocketmine\entity\animation\ArmSwingAnimation;
use BeeAZ\AZMinion\Main;

class MinerMinion extends BaseMinion {

    private ?Vector3 $minerTarget = null;

    public function getMinionType(): string {
        return "miner";
    }

    protected function setToolVisual(): void {
        $this->getInventory()->setItemInHand(VanillaItems::DIAMOND_PICKAXE());
    }

    protected function performWork(): void {
        $target = $this->findMinerTarget();
        if ($target !== null) {
            $this->mineBlock($target);
        }
    }

    private function findMinerTarget(): ?Vector3 {
        $world = $this->getWorld();
        if ($this->minerTarget === null) {
            $facing = $this->getHorizontalFacing();
            $offset = \pocketmine\math\Facing::OFFSET[$facing];
            $this->minerTarget = $this->spawnCenter->add($offset[0], 0, $offset[2]);
        }
        
        $block = $world->getBlock($this->minerTarget);
        if ($block->isSolid() && $block->getTypeId() !== VanillaBlocks::BEDROCK()->getTypeId()) {
            return $this->minerTarget;
        }
        return null;
    }

    private function mineBlock(Vector3 $pos): void {
        $world = $this->getWorld();
        $block = $world->getBlock($pos);
        if ($block->hasSameTypeId(VanillaBlocks::AIR()) || !$block->isSolid()) return;

        $this->lookAtAndTurn($pos);
        $this->broadcastAnimation(new ArmSwingAnimation($this));
        
        $world->addSound($pos, new ItemBreakSound(VanillaItems::DIAMOND_PICKAXE()));
        $world->addParticle($pos, new DustParticle(new Color(120, 120, 120)));

        $drops = $block->getDrops(VanillaItems::DIAMOND_PICKAXE());
        $world->setBlock($pos, VanillaBlocks::AIR());

        $this->processDrops($drops);

        $this->updateNameTag();
    }
}
