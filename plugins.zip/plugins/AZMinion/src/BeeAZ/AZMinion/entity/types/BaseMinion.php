<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\entity\types;

use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\inventory\SimpleInventory;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataCollection;
use pocketmine\player\Player;
use BeeAZ\AZMinion\Main;

abstract class BaseMinion extends Human {

    protected string $minionId = "";
    protected string $ownerName = "";
    protected int $minionLevel = 1;
    protected int $inventoryPages = 1;
    protected bool $autoSell = false;
    protected bool $autoSmelt = false;
    protected bool $autoSellUnlocked = false;
    protected bool $autoSmeltUnlocked = false;

    protected SimpleInventory $minionInventory;
    protected SimpleInventory $seedsInventory;

    protected int $workCooldown = 60; // 3 seconds
    protected int $cooldownTracker = 0;

    protected ?Vector3 $spawnCenter = null;

    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null) {
        $this->setCanSaveWithChunk(true);
        parent::__construct($location, $skin, $nbt);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);

        $this->setScale(0.6); // Scale nhỏ minion

        $this->minionId = $nbt->getString("MinionId", "");
        $this->ownerName = $nbt->getString("Owner", $nbt->getString("MinionOwner", ""));
        $this->minionLevel = $nbt->getInt("MinionLevel", 1);
        $this->inventoryPages = $nbt->getInt("MinionInvSize", 1);
        $this->autoSell = $nbt->getInt("MinionAutoSell", 0) === 1;
        $this->autoSmelt = $nbt->getInt("MinionAutoSmelt", 0) === 1;
        $this->autoSellUnlocked = $nbt->getInt("MinionAutoSellUnlocked", 0) === 1;
        $this->autoSmeltUnlocked = $nbt->getInt("MinionAutoSmeltUnlocked", 0) === 1;

        if ($this->minionId === "") {
            $this->minionId = uniqid("minion_");
        }

        $this->spawnCenter = $this->getPosition()->floor();

        // Inventories
        $this->minionInventory = new SimpleInventory(54 * 5); // Max 5 pages
        $this->seedsInventory = new SimpleInventory(5); // For farmer seeds

        Main::getInstance()->getDatabase()->loadInventory($this);
        Main::getInstance()->registerMinion($this);

        $this->setNameTagAlwaysVisible(true);
        $this->setHasGravity(false);
        $this->getNetworkProperties()->setGenericFlag(\pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags::IMMOBILE, true);

        $this->setToolVisual();
        $this->updateNameTag();
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString("MinionId", $this->minionId);
        $nbt->setString("Owner", $this->ownerName);
        $nbt->setString("MinionType", $this->getMinionType()); // Lấy type từ class con
        $nbt->setInt("MinionLevel", $this->minionLevel);
        $nbt->setInt("MinionInvSize", $this->inventoryPages);
        $nbt->setInt("MinionAutoSell", $this->autoSell ? 1 : 0);
        $nbt->setInt("MinionAutoSmelt", $this->autoSmelt ? 1 : 0);
        $nbt->setInt("MinionAutoSellUnlocked", $this->autoSellUnlocked ? 1 : 0);
        $nbt->setInt("MinionAutoSmeltUnlocked", $this->autoSmeltUnlocked ? 1 : 0);

        return $nbt;
    }

    protected function onDispose(): void {
        if ($this->minionId !== "") {
            Main::getInstance()->getDatabase()->saveInventory($this);
            Main::getInstance()->unregisterMinion($this->minionId);
        }
        parent::onDispose();
    }

    /**
     * Vô hiệu hóa trọng lực để minion lơ lửng, không bị rớt xuống void.
     */
    protected function applyGravity(): void {
        $this->motion->y = 0;
    }

    abstract public function getMinionType(): string;
    abstract protected function setToolVisual(): void;
    abstract protected function performWork(): void;

    public function updateNameTag(): void {
        $typeNames = [
            "miner" => "Miner (Khai Thác)",
            "farmer" => "Farmer (Nông Dân)",
            "lumberjack" => "Lumberjack (Chặt Gỗ)",
            "fisher" => "Fisher (Câu Cá)"
        ];
        $type = $this->getMinionType();
        $typeName = $typeNames[$type] ?? ucfirst($type);

        $status = "§aĐang làm việc...";
        if ($this->isInventoryFull()) {
            $status = "§cTúi đồ đầy!";
        }

        $this->setNameTag(
            "§l§6MINION " . strtoupper($type) . " §e(Lv." . $this->minionLevel . ")\n" .
            "§7Chủ: §f" . $this->ownerName . "\n" .
            "§7Trạng thái: " . $status
        );
    }

    public function onUpdate(int $currentTick): bool {
        if ($this->isClosed() || !$this->isAlive()) {
            return parent::onUpdate($currentTick);
        }

        $hasUpdate = parent::onUpdate($currentTick);

        // Chống di chuyển / trôi nổi
        $this->motion = new Vector3(0, 0, 0);

        if ($this->cooldownTracker > 0) {
            $this->cooldownTracker--;
            return $hasUpdate;
        }

        if ($this->isInventoryFull()) {
            $this->updateNameTag();
            $this->cooldownTracker = 40;
            return $hasUpdate;
        }

        $this->cooldownTracker = $this->getWorkCooldown();
        $this->performWork();

        return true;
    }

    public function lookAtAndTurn(Vector3 $pos): void {
        $this->lookAt($pos->add(0.5, 0.5, 0.5));
        $this->teleport($this->getLocation());
    }

    public function getWorkCooldown(): int {
        return (int)max(20, 64 - ($this->minionLevel * 4));
    }

    public function isInventoryFull(): bool {
        $maxSlots = $this->inventoryPages * 54;
        $used = 0;
        foreach ($this->minionInventory->getContents() as $item) {
            if (!$item->isNull()) $used++;
        }
        return $used >= $maxSlots;
    }

    protected function processDrops(array $drops): void {
        $inv = $this->minionInventory;
        $maxSlots = $this->inventoryPages * 54;

        foreach ($drops as $drop) {
            if ($this->autoSmelt && $this->getMinionType() === "miner") {
                $drop = \BeeAZ\AZMinion\utils\SmeltUtils::getSmeltedItem($drop) ?? $drop;
            }

            if ($this->autoSell) {
                $price = $this->resolveItemPrice($drop);
                if ($price > 0) {
                    $sellAmount = (int)($price * $drop->getCount());
                    \AZEconomy\AZEconomy::getInstance()->addMoney($this->ownerName, $sellAmount);
                    continue; // Bỏ qua việc thêm vào kho
                }
            }

            for ($i = 0; $i < $maxSlots; $i++) {
                $item = $inv->getItem($i);
                if ($item->isNull() || ($item->equals($drop, true, true) && $item->getCount() < $item->getMaxStackSize())) {
                    $addCount = min($drop->getCount(), $item->getMaxStackSize() - $item->getCount());
                    $drop->setCount($drop->getCount() - $addCount);
                    
                    if ($item->isNull()) {
                        $newItem = clone $drop;
                        $newItem->setCount($addCount);
                        $inv->setItem($i, $newItem);
                    } else {
                        $item->setCount($item->getCount() + $addCount);
                        $inv->setItem($i, $item);
                    }
                    if ($drop->getCount() <= 0) break;
                }
            }
        }
    }

    public function resolveItemPrice(Item $item): float {
        // 1. AZCustomFishing (Cá)
        if ($item->getNamedTag()->getTag("fish_price") !== null) {
            return (float)$item->getNamedTag()->getInt("fish_price");
        }

        // 2. AZSeason (Nông sản)
        $seasonPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZSeason");
        if ($seasonPlugin instanceof \az\season\Main) {
            $crops = $seasonPlugin->getConfig()->get("crops", []);
            $season = $seasonPlugin->getSeasonManager()->getCurrentSeason();
            foreach ($crops as $key => $data) {
                $parsed = \pocketmine\item\StringToItemParser::getInstance()->parse($data['id']);
                if ($parsed !== null && $parsed->getTypeId() === $item->getTypeId()) {
                    $basePrice = $data['base-price'];
                    $multiplier = $data['season-multiplier'][$season] ?? 1.0;
                    return (float)($basePrice * $multiplier);
                }
            }
        }

        // 3. AZSellFix (Đồ thường)
        $sellFixPlugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZSellFix");
        if ($sellFixPlugin instanceof \BeeAZ\AZSellFix\Main) {
            $price = $sellFixPlugin->getSellPrice($item);
            if ($price !== null) return (float)$price;
        }

        return 0.0;
    }

    protected function getNeighbors(Vector3 $pos, int $maxR): array {
        $neighbors = [];
        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dy = -1; $dy <= 1; $dy++) {
                for ($dz = -1; $dz <= 1; $dz++) {
                    if ($dx === 0 && $dy === 0 && $dz === 0) continue;
                    $n = $pos->add($dx, $dy, $dz);
                    if ($n->distanceSquared($this->spawnCenter) <= ($maxR * $maxR)) {
                        $neighbors[] = $n;
                    }
                }
            }
        }
        return $neighbors;
    }

    // Getters / Setters
    public function getMinionId(): string { return $this->minionId; }
    public function getOwnerName(): string { return $this->ownerName; }
    public function getMinionLevel(): int { return $this->minionLevel; }
    public function setMinionLevel(int $level): void { $this->minionLevel = $level; }
    public function getInventoryPages(): int { return $this->inventoryPages; }
    public function setInventoryPages(int $pages): void { $this->inventoryPages = $pages; }
    public function isAutoSellEnabled(): bool { return $this->autoSell; }
    public function setAutoSellEnabled(bool $val): void { $this->autoSell = $val; }
    public function isAutoSmeltEnabled(): bool { return $this->autoSmelt; }
    public function setAutoSmeltEnabled(bool $val): void { $this->autoSmelt = $val; }
    public function isAutoSellUnlocked(): bool { return $this->autoSellUnlocked; }
    public function setAutoSellUnlocked(bool $val): void { $this->autoSellUnlocked = $val; }
    public function isAutoSmeltUnlocked(): bool { return $this->autoSmeltUnlocked; }
    public function setAutoSmeltUnlocked(bool $val): void { $this->autoSmeltUnlocked = $val; }
    public function getMinionInventory(): SimpleInventory { return $this->minionInventory; }
    public function getSeedsInventory(): SimpleInventory { return $this->seedsInventory; }
}
