<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\entity;

use pocketmine\entity\projectile\Projectile;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\block\Water;
use pocketmine\math\Vector3;

class MinionHook extends Projectile {

    private bool $inWater = false;
    private int $waterTicks = 0;

    public static function getNetworkTypeId(): string {
        return EntityIds::FISHING_HOOK;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.25, 0.25);
    }

    protected function getInitialDragMultiplier(): float {
        return 0.05;
    }

    protected function getInitialGravity(): float {
        return 0.08;
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);

        $owner = $this->getOwningEntity();
        if ($owner !== null) {
            $this->getNetworkProperties()->setLong(EntityMetadataProperties::OWNER_EID, $owner->getId());
        }
    }

    public function entityBaseTick(int $tickDiff = 1): bool {
        $hasUpdate = parent::entityBaseTick($tickDiff);
        
        $owner = $this->getOwningEntity();
        if ($owner === null || $owner->isClosed()) {
            $this->flagForDespawn();
            return false;
        }

        $pos = $this->getPosition();
        $block = $this->getWorld()->getBlock($pos);
        $blockUp = $this->getWorld()->getBlock($pos->add(0, 0.8, 0));

        if (($block instanceof Water) || ($blockUp instanceof Water)) {
            if (!$this->inWater) {
                $this->inWater = true;
                $m = $this->getMotion();
                $m->x = 0;
                $m->z = 0;
                $m->y *= 0.1;
                $this->setMotion($m);
            }
            
            $this->gravity = -0.02; // Float up
            $this->drag = 0.15;
            
            if ($this->getMotion()->y > 0.05) {
                $this->setMotion($this->getMotion()->multiply(0.8));
            }
            
            $this->waterTicks++;
            // Splash particle occasionally
            if ($this->waterTicks % 15 === 0) {
                $this->getWorld()->addParticle($pos, new \pocketmine\world\particle\BubbleParticle());
            }
        } else {
            $this->inWater = false;
            $this->waterTicks = 0;
            $this->gravity = 0.08;
            $this->drag = 0.05;
        }

        return $hasUpdate;
    }
}
