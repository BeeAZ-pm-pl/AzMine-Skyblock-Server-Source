<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\database;

use pocketmine\scheduler\AsyncTask;

class SaveMinionTask extends AsyncTask {

    private string $dbPath;
    private string $serializedData;

    public function __construct(string $dbPath, array $data) {
        $this->dbPath = $dbPath;
        $this->serializedData = json_encode($data);
    }

    public function onRun(): void {
        $data = json_decode($this->serializedData, true);
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);

        $stmt = $db->prepare("INSERT OR REPLACE INTO minion_storage (id, inventory, seeds) VALUES (:id, :inventory, :seeds)");
        
        $stmt->bindValue(":id", $data["id"]);
        $stmt->bindValue(":inventory", $data["inventory"]);
        $stmt->bindValue(":seeds", $data["seeds"]);
        
        $stmt->execute();
        $db->close();
    }
}
