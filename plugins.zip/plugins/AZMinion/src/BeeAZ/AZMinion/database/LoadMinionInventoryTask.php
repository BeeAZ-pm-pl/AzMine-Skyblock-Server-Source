<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\database;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use BeeAZ\AZMinion\Main;

class LoadMinionInventoryTask extends AsyncTask {

    private string $dbPath;
    private string $minionId;

    public function __construct(string $dbPath, string $minionId) {
        $this->dbPath = $dbPath;
        $this->minionId = $minionId;
    }

    public function onRun(): void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $stmt = $db->prepare("SELECT inventory, seeds FROM minion_storage WHERE id = :id");
        $stmt->bindValue(":id", $this->minionId);
        $res = $stmt->execute();
        
        $row = $res ? $res->fetchArray(SQLITE3_ASSOC) : null;
        $db->close();
        
        $this->setResult([
            "minionId" => $this->minionId,
            "row" => $row
        ]);
    }

    public function onCompletion(): void {
        $server = Server::getInstance();
        $plugin = $server->getPluginManager()->getPlugin("AZMinion");
        if ($plugin instanceof Main && $plugin->isEnabled()) {
            $result = $this->getResult();
            $row = $result["row"];
            $minionId = $result["minionId"];
            
            $inventoryData = $row ? (json_decode($row["inventory"], true) ?? []) : [];
            $seedsData = $row ? (json_decode($row["seeds"], true) ?? []) : [];
            
            $plugin->getDatabase()->onInventoryLoaded($minionId, $inventoryData, $seedsData);
        }
    }
}
