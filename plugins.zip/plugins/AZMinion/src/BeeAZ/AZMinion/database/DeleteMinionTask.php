<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\database;

use pocketmine\scheduler\AsyncTask;

class DeleteMinionTask extends AsyncTask {

    private string $dbPath;
    private string $id;

    public function __construct(string $dbPath, string $id) {
        $this->dbPath = $dbPath;
        $this->id = $id;
    }

    public function onRun(): void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);

        $stmt = $db->prepare("DELETE FROM minions WHERE id = :id");
        $stmt->bindValue(":id", $this->id);
        
        $stmt->execute();
        $db->close();
    }
}
