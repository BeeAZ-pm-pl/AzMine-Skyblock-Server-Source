<?php

declare(strict_types=1);

namespace BeeAZ\AZMinion\database;

use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\item\StringToItemParser;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

use BeeAZ\AZMinion\Main;
use BeeAZ\AZMinion\entity\types\BaseMinion;

class Database {

    private Main $plugin;
    private string $dbPath;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->dbPath = $plugin->getDataFolder() . "minions.db";
    }

    public function init(): void {
        @mkdir($this->plugin->getDataFolder());
        
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        // Chỉ lưu kho đồ của minion, mọi thứ khác lưu trong entity NBT
        $db->exec("CREATE TABLE IF NOT EXISTS minion_storage (
            id TEXT PRIMARY KEY,
            inventory TEXT DEFAULT '{}',
            seeds TEXT DEFAULT '{}'
        )");
        
        $db->close();
    }

    /**
     * Lưu kho đồ (inventory + seeds) vào SQL
     */
    public function saveInventory(BaseMinion $minion): void {
        $inventoryData = [];
        foreach ($minion->getMinionInventory()->getContents() as $slot => $item) {
            $inventoryData[$slot] = self::serializeItem($item);
        }
        
        $seedsData = [];
        foreach ($minion->getSeedsInventory()->getContents() as $slot => $item) {
            $seedsData[$slot] = self::serializeItem($item);
        }

        $data = [
            "id" => $minion->getMinionId(),
            "inventory" => json_encode($inventoryData),
            "seeds" => json_encode($seedsData)
        ];

        $this->plugin->getServer()->getAsyncPool()->submitTask(new SaveMinionTask($this->dbPath, $data));
    }

    /**
     * Load kho đồ từ SQL khi entity khởi tạo (async)
     */
    public function loadInventory(BaseMinion $minion): void {
        $this->plugin->getServer()->getAsyncPool()->submitTask(new LoadMinionInventoryTask($this->dbPath, $minion->getMinionId()));
    }

    /**
     * Callback khi load inventory xong
     */
    public function onInventoryLoaded(string $minionId, array $inventoryData, array $seedsData): void {
        $minion = $this->plugin->getActiveMinions()[$minionId] ?? null;
        if ($minion === null || $minion->isClosed()) return;

        $inventoryItems = [];
        foreach ($inventoryData as $slot => $itemData) {
            $inventoryItems[(int)$slot] = self::deserializeItem($itemData);
        }

        $seedsItems = [];
        foreach ($seedsData as $slot => $itemData) {
            $seedsItems[(int)$slot] = self::deserializeItem($itemData);
        }

        $minion->getMinionInventory()->setContents($inventoryItems);
        $minion->getSeedsInventory()->setContents($seedsItems);
    }

    /**
     * Xóa kho đồ khi thu hồi minion
     */
    public function deleteInventory(string $id): void {
        $this->plugin->getServer()->getAsyncPool()->submitTask(new DeleteMinionTask($this->dbPath, $id));
    }

    /**
     * Item Serialization Helpers
     */
    public static function serializeItem(Item $item): array {
        if ($item->isNull()) {
            return ["id" => "air", "count" => 0];
        }
        
        $id = StringToItemParser::getInstance()->lookupAliases($item)[0] ?? "air";
        $nbtHex = "";
        
        if ($item->hasNamedTag()) {
            $serializer = new LittleEndianNbtSerializer();
            $nbtHex = bin2hex($serializer->write(new TreeRoot($item->getNamedTag())));
        }
        
        return [
            "id" => $id,
            "count" => $item->getCount(),
            "nbt" => $nbtHex
        ];
    }

    public static function deserializeItem(array $data): Item {
        $id = $data["id"] ?? "air";
        if ($id === "air" || $id === "") {
            return VanillaItems::AIR();
        }
        
        $item = StringToItemParser::getInstance()->parse($id);
        if ($item === null) {
            return VanillaItems::AIR();
        }
        
        $item->setCount($data["count"] ?? 1);
        $nbtHex = $data["nbt"] ?? "";
        
        if ($nbtHex !== "") {
            try {
                $serializer = new LittleEndianNbtSerializer();
                $tag = $serializer->read(hex2bin($nbtHex))->mustGetCompoundTag();
                $item->setNamedTag($tag);
            } catch (\Exception $e) {
                // ignore
            }
        }
        
        return $item;
    }
}
