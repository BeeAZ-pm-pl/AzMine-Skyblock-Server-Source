<?php

namespace BeeAZ\AZShop;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\FormIcon;
use AZEconomy\AZEconomy;

class Main extends PluginBase {

    private array $shopData;

    protected function onEnable() : void {
        $this->saveDefaultConfig();
        $this->shopData = $this->getConfig()->get("categories", []);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if ($command->getName() === "shop" && $sender instanceof Player) {
            $this->openCategoryMenu($sender);
            return true;
        }
        return false;
    }

    private function openCategoryMenu(Player $player) : void {
        $eco = AZEconomy::getInstance();
        $money = $eco->getMoney($player->getName());
        
        $options = [];
        $categoryKeys = array_keys($this->shopData);

        foreach ($categoryKeys as $catKey) {
            $catData = $this->shopData[$catKey];
            $name = $catData["name"] ?? "Danh Mục Lỗi";
            
            $icon = null;
            if (isset($catData["icon_type"], $catData["icon_path"]) && $catData["icon_path"] !== "") {
                $iconType = $catData["icon_type"] === "url" ? FormIcon::IMAGE_TYPE_URL : FormIcon::IMAGE_TYPE_PATH;
                $icon = new FormIcon($catData["icon_path"], $iconType);
            }

            // Sấm sét đen in đậm 2 bên
            $options[] = new MenuOption("§l§0⚡ " . $name . " ⚡", $icon);
        }

        $form = new MenuForm(
            "§l§9CỬA HÀNG AZ",
            "§eSố dư của bạn: §a" . number_format($money) . " Money\n\n§7Vui lòng chọn một danh mục:",
            $options,
            function (Player $submitter, int $selected) use ($categoryKeys) : void {
                $this->openItemMenu($submitter, $categoryKeys[$selected]);
            },
            function (Player $submitter) : void {}
        );

        $player->sendForm($form);
    }

    private function openItemMenu(Player $player, string $categoryKey) : void {
        $eco = AZEconomy::getInstance();
        $money = $eco->getMoney($player->getName());
        
        $catData = $this->shopData[$categoryKey];
        $catName = $catData["name"] ?? "Danh Mục";
        $itemsData = $catData["items"] ?? [];
        $itemKeys = array_keys($itemsData);
        
        $options = [];

        foreach ($itemKeys as $key) {
            $data = $itemsData[$key];
            $name = $data["name"] ?? $key;
            $pMoney = $data["price_money"];
            
            $icon = null;
            if (isset($data["icon_type"], $data["icon_path"]) && $data["icon_path"] !== "") {
                $iconType = $data["icon_type"] === "url" ? FormIcon::IMAGE_TYPE_URL : FormIcon::IMAGE_TYPE_PATH;
                $icon = new FormIcon($data["icon_path"], $iconType);
            }

            $options[] = new MenuOption("§l§0⚡ {$name} §l§0⚡\n§r§a" . number_format($pMoney) . " Xu §8/ §c1 Cái", $icon);
        }

        $form = new MenuForm(
            "§l§9" . mb_strtoupper($catName),
            "§eSố dư của bạn: §a" . number_format($money) . " Money\n\n§7Chọn vật phẩm bạn muốn mua:",
            $options,
            function (Player $submitter, int $selected) use ($categoryKey, $itemKeys) : void {
                $this->openQuantityForm($submitter, $categoryKey, $itemKeys[$selected]);
            },
            function (Player $submitter) : void {
                $this->openCategoryMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    private function openQuantityForm(Player $player, string $categoryKey, string $itemKey) : void {
        $data = $this->shopData[$categoryKey]["items"][$itemKey];
        $itemName = $data["name"] ?? "Vật phẩm";
        $priceMoney = (int) $data["price_money"];

        $eco = AZEconomy::getInstance();
        $money = $eco->getMoney($player->getName());

        $form = new CustomForm(
            "§l§0⚡ §cMUA: " . mb_strtoupper($itemName) . " §0⚡",
            [
                new Label("info", "§eTiền của bạn: §a" . number_format($money) . " Xu\n\n§fVật phẩm: §a{$itemName}\n§fĐơn giá: §a" . number_format($priceMoney) . " Money §f/ 1 Cái\n"),
                new Input("quantity", "§eNhập số lượng bạn muốn mua:", "Ví dụ: 1, 64, 128...", "1")
            ],
            function (Player $submitter, CustomFormResponse $response) use ($categoryKey, $itemKey, $itemName, $priceMoney) : void {
                $input = $response->getString("quantity");
                
                if (!is_numeric($input) || (int)$input <= 0) {
                    $submitter->sendMessage("§cSố lượng không hợp lệ! Vui lòng nhập số nguyên dương.");
                    return;
                }

                $quantity = (int)$input;
                $this->processPurchase($submitter, $categoryKey, $itemKey, $quantity);
            },
            function (Player $submitter) use ($categoryKey) : void {
                $this->openItemMenu($submitter, $categoryKey);
            }
        );

        $player->sendForm($form);
    }

    private function processPurchase(Player $player, string $categoryKey, string $itemKey, int $quantity) : void {
        $data = $this->shopData[$categoryKey]["items"][$itemKey];
        $itemName = $data["name"] ?? "Vật phẩm";
        $priceMoney = (int) $data["price_money"];
        $itemId = (string) $data["item_id"];

        $totalMoney = $priceMoney * $quantity;

        $eco = AZEconomy::getInstance();
        $playerName = $player->getName();

        if ($eco->getMoney($playerName) < $totalMoney) {
            $player->sendMessage("§cBạn không có đủ Money. Cần: " . number_format($totalMoney));
            return;
        }

        $baseItem = StringToItemParser::getInstance()->parse($itemId);
        if ($baseItem === null) {
            $player->sendMessage("§cLỗi cấu hình: ID vật phẩm không hợp lệ ({$itemId}).");
            return;
        }

        if (isset($data["custom_name"])) {
            $baseItem->setCustomName($data["custom_name"]);
        }
        if (isset($data["lore"]) && is_array($data["lore"])) {
            $baseItem->setLore($data["lore"]);
        }
        if (isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach ($data["enchants"] as $enchName => $level) {
                $enchantment = \pocketmine\item\enchantment\StringToEnchantmentParser::getInstance()->parse((string)$enchName);
                if ($enchantment !== null) {
                    $baseItem->addEnchantment(new \pocketmine\item\enchantment\EnchantmentInstance($enchantment, (int)$level));
                }
            }
        }

        $itemsToAdd = [];
        $remaining = $quantity;
        $maxStackSize = $baseItem->getMaxStackSize();

        while ($remaining > 0) {
            $amount = min($remaining, $maxStackSize);
            $cloneItem = clone $baseItem;
            $cloneItem->setCount($amount);
            $itemsToAdd[] = $cloneItem;
            $remaining -= $amount;
        }

        if (!$player->getInventory()->canAddItem(...$itemsToAdd)) {
            $player->sendMessage("§cTúi đồ của bạn không đủ chỗ trống để chứa {$quantity} vật phẩm này.");
            return;
        }

        $eco->reduceMoney($playerName, $totalMoney);
        $player->getInventory()->addItem(...$itemsToAdd);
        $player->sendMessage("§aBạn đã mua thành công §ex{$quantity} {$itemName} §atổng giá §6" . number_format($totalMoney) . " Money§a.");
    }
}