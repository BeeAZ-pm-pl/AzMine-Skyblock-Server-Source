<?php

declare(strict_types=1);

namespace BeeAZ\AZJail\task;

use pocketmine\scheduler\AsyncTask;

class AsyncQueryTask extends AsyncTask {

    private string $dbPath;
    private string $query;
    private string $bindings;

    public function __construct(string $dbPath, string $query, array $bindings = []) {
        $this->dbPath = $dbPath;
        $this->query = $query;
        // In PM5/pthreads, arrays must be serialized or stored as thread-safe structures.
        // We serialize the bindings array to a JSON string to keep it safe for thread passing.
        $this->bindings = json_encode($bindings);
    }

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);

        $stmt = $db->prepare($this->query);
        if ($stmt !== false) {
            $bindings = json_decode($this->bindings, true) ?? [];
            foreach ($bindings as $param => $value) {
                if (is_int($value)) {
                    $stmt->bindValue($param, $value, SQLITE3_INTEGER);
                } else {
                    $stmt->bindValue($param, $value, SQLITE3_TEXT);
                }
            }
            $stmt->execute();
        }

        $db->close();
    }
}
