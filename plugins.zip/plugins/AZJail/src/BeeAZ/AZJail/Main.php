<?php

declare(strict_types=1);

namespace BeeAZ\AZJail;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\World;
use pocketmine\world\Position;
use pocketmine\math\Vector3;
use pocketmine\block\VanillaBlocks;
use pocketmine\world\WorldCreationOptions;
use pocketmine\world\generator\Flat;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use BeeAZ\AZJail\task\AsyncQueryTask;

class Main extends PluginBase implements Listener {

    private string $dbPath;
    
    // In-memory cache for ultra-fast checks without blocking the main thread
    private array $jailedPlayers = [];
    private array $bannedPlayers = [];

    protected function onEnable() : void {
        @mkdir($this->getDataFolder(), 0777, true);
        $this->dbPath = $this->getDataFolder() . "database.db";

        // Create tables and load data into memory synchronously on start (only happens once on boot)
        $db = new \SQLite3($this->dbPath);
        $db->exec("CREATE TABLE IF NOT EXISTS jailed_players (username TEXT PRIMARY KEY, jail_time INTEGER, reason TEXT, jailed_by TEXT);");
        $db->exec("CREATE TABLE IF NOT EXISTS banned_players (username TEXT PRIMARY KEY, ban_time INTEGER, reason TEXT, banned_by TEXT);");

        // Load Jails
        $resJails = $db->query("SELECT * FROM jailed_players");
        if ($resJails !== false) {
            while ($row = $resJails->fetchArray(SQLITE3_ASSOC)) {
                $jailTime = (int)$row['jail_time'];
                // Graceful migration from absolute timestamp to remaining seconds
                if ($jailTime > 1000000000) {
                    $jailTime = max(0, $jailTime - time());
                }
                $this->jailedPlayers[strtolower($row['username'])] = [
                    'jail_time' => $jailTime,
                    'reason' => (string)$row['reason'],
                    'jailed_by' => (string)$row['jailed_by']
                ];
            }
        }

        // Load Bans
        $resBans = $db->query("SELECT * FROM banned_players");
        if ($resBans !== false) {
            while ($row = $resBans->fetchArray(SQLITE3_ASSOC)) {
                $this->bannedPlayers[strtolower($row['username'])] = [
                    'ban_time' => (int)$row['ban_time'],
                    'reason' => (string)$row['reason'],
                    'banned_by' => (string)$row['banned_by']
                ];
            }
        }
        $db->close();

        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        // Preload/Generate jail world
        $this->getJailWorld();

        // Repeating task to tick down jail time for online players only (every second)
        $this->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\ClosureTask(function() : void {
            $dbPath = $this->dbPath;
            foreach ($this->getServer()->getOnlinePlayers() as $player) {
                $username = strtolower($player->getName());
                if (isset($this->jailedPlayers[$username])) {
                    $data = $this->jailedPlayers[$username];
                    $remaining = (int)$data['jail_time'];
                    if ($remaining === -1) {
                        continue; // Permanent
                    }
                    $remaining--;
                    if ($remaining <= 0) {
                        $this->unjailPlayer($player->getName());
                    } else {
                        $this->jailedPlayers[$username]['jail_time'] = $remaining;
                        $this->getServer()->getAsyncPool()->submitTask(new AsyncQueryTask(
                            $dbPath,
                            "UPDATE jailed_players SET jail_time = :jail_time WHERE username = :username",
                            [
                                ':username' => $username,
                                ':jail_time' => $remaining
                            ]
                        ));
                    }
                }
            }
        }), 20);
    }

    public function getJailWorld() : ?World {
        $worldManager = $this->getServer()->getWorldManager();
        if (!$worldManager->isWorldLoaded("jail")) {
            if (!$worldManager->loadWorld("jail")) {
                $options = WorldCreationOptions::create();
                $options->setGeneratorClass(Flat::class);
                $worldManager->generateWorld("jail", $options);
                $worldManager->loadWorld("jail");
            }
        }
        $world = $worldManager->getWorldByName("jail");
        if ($world !== null) {
            $world->orderChunkPopulation(6, 6, null)->onCompletion(
                function() use ($world) : void {
                    $this->buildJailCell($world);
                },
                function() : void {}
            );
        }
        return $world;
    }

    private function buildJailCell(World $world) : void {
        $world->loadChunk(6, 6);
        for ($x = 99; $x <= 105; $x++) {
            for ($z = 99; $z <= 105; $z++) {
                for ($y = 8; $y <= 14; $y++) {
                    if ($x === 99 || $x === 105 || $z === 99 || $z === 105 || $y === 8 || $y === 14) {
                        $world->setBlock(new Vector3($x, $y, $z), VanillaBlocks::BEDROCK());
                    } else {
                        $world->setBlock(new Vector3($x, $y, $z), VanillaBlocks::AIR());
                    }
                }
            }
        }
        $world->setBlock(new Vector3(102, 13, 102), VanillaBlocks::SEA_LANTERN());
    }

    // --- Non-Blocking Database & Memory Operations ---

    public function jailPlayer(string $username, int $durationMinutes, string $reason, string $jailedBy) : void {
        $username = strtolower($username);
        $jailTime = $durationMinutes === -1 ? -1 : $durationMinutes * 60;

        // Update Memory Cache
        $this->jailedPlayers[$username] = [
            'jail_time' => $jailTime,
            'reason' => $reason,
            'jailed_by' => $jailedBy
        ];

        // Async Database Write
        $this->getServer()->getAsyncPool()->submitTask(new AsyncQueryTask(
            $this->dbPath,
            "INSERT OR REPLACE INTO jailed_players (username, jail_time, reason, jailed_by) VALUES (:username, :jail_time, :reason, :jailed_by)",
            [
                ':username' => $username,
                ':jail_time' => $jailTime,
                ':reason' => $reason,
                ':jailed_by' => $jailedBy
            ]
        ));

        // Teleport/Notify if online
        $player = $this->getServer()->getPlayerByPrefix($username);
        if ($player !== null) {
            $jailWorld = $this->getJailWorld();
            if ($jailWorld !== null) {
                $player->teleport(new Position(102.5, 10.0, 102.5, $jailWorld));
            }
            $player->sendMessage("§cBạn đã bị tống vào ngục tối!");
            $player->sendMessage("§eLý do: §f" . $reason);
            $player->sendMessage("§eThời hạn: §f" . ($durationMinutes === -1 ? "Vĩnh viễn" : $durationMinutes . " phút"));
        }
    }

    public function unjailPlayer(string $username) : bool {
        $username = strtolower($username);
        
        if (!isset($this->jailedPlayers[$username])) {
            return false;
        }

        // Remove from Memory Cache
        unset($this->jailedPlayers[$username]);

        // Async Database Write
        $this->getServer()->getAsyncPool()->submitTask(new AsyncQueryTask(
            $this->dbPath,
            "DELETE FROM jailed_players WHERE username = :username",
            [':username' => $username]
        ));

        // Teleport out of jail if online
        $player = $this->getServer()->getPlayerByPrefix($username);
        if ($player !== null) {
            $defaultWorld = $this->getServer()->getWorldManager()->getDefaultWorld();
            if ($defaultWorld !== null) {
                $player->teleport($defaultWorld->getSpawnLocation());
            }
            $player->sendMessage("§aBạn đã được giải phóng khỏi ngục tối!");
        }
        return true;
    }

    public function isJailed(string $username, ?int &$remaining = null) : bool {
        $username = strtolower($username);
        if (!isset($this->jailedPlayers[$username])) {
            return false;
        }

        $data = $this->jailedPlayers[$username];
        $jailTime = (int)$data['jail_time'];

        if ($jailTime !== -1 && $jailTime <= 0) {
            // Expired -> Unjail non-blockingly
            $this->unjailPlayer($username);
            return false;
        }

        $remaining = $jailTime;
        return true;
    }

    public function tempBanPlayer(string $username, int $durationMinutes, string $reason, string $bannedBy) : void {
        $username = strtolower($username);
        $banTime = time() + ($durationMinutes * 60);

        // Update Memory Cache
        $this->bannedPlayers[$username] = [
            'ban_time' => $banTime,
            'reason' => $reason,
            'banned_by' => $bannedBy
        ];

        // Async Database Write
        $this->getServer()->getAsyncPool()->submitTask(new AsyncQueryTask(
            $this->dbPath,
            "INSERT OR REPLACE INTO banned_players (username, ban_time, reason, banned_by) VALUES (:username, :ban_time, :reason, :banned_by)",
            [
                ':username' => $username,
                ':ban_time' => $banTime,
                ':reason' => $reason,
                ':banned_by' => $bannedBy
            ]
        ));

        // Kick if online
        $player = $this->getServer()->getPlayerByPrefix($username);
        if ($player !== null) {
            $player->kick("§cTài khoản của bạn đã bị khóa tạm thời!\n§eLý do: §f" . $reason . "\n§eThời gian khóa: §f" . $durationMinutes . " phút");
        }
    }

    public function tempUnbanPlayer(string $username) : bool {
        $username = strtolower($username);
        
        if (!isset($this->bannedPlayers[$username])) {
            return false;
        }

        // Remove from Memory Cache
        unset($this->bannedPlayers[$username]);

        // Async Database Write
        $this->getServer()->getAsyncPool()->submitTask(new AsyncQueryTask(
            $this->dbPath,
            "DELETE FROM banned_players WHERE username = :username",
            [':username' => $username]
        ));
        return true;
    }

    public function isTempBanned(string $username, ?int &$remaining = null) : bool {
        $username = strtolower($username);
        if (!isset($this->bannedPlayers[$username])) {
            return false;
        }

        $data = $this->bannedPlayers[$username];
        $banTime = (int)$data['ban_time'];

        if (time() > $banTime) {
            // Expired -> Unban non-blockingly
            $this->tempUnbanPlayer($username);
            return false;
        }

        $remaining = $banTime - time();
        return true;
    }

    private function formatTime(int $seconds) : string {
        if ($seconds === -1) return "Vĩnh viễn";
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        
        $parts = [];
        if ($h > 0) {
            $parts[] = $h . " giờ";
        }
        if ($m > 0 || $h > 0) {
            $parts[] = $m . " phút";
        }
        $parts[] = $s . " giây";
        
        return implode(" ", $parts);
    }

    // --- Commands Handler ---

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        $cmdName = $command->getName();

        if ($cmdName === "jail") {
            if (count($args) < 1) {
                $sender->sendMessage("§cCách dùng: /jail <tên người chơi> [phút (bỏ trống = vĩnh viễn)] [lý do]");
                return true;
            }
            
            $targetName = $args[0];
            $player = $this->getServer()->getPlayerByPrefix($targetName);
            if ($player !== null) {
                $targetName = $player->getName();
            }

            $minutes = isset($args[1]) && is_numeric($args[1]) ? (int)$args[1] : -1;
            $reason = count($args) > 2 ? implode(" ", array_slice($args, 2)) : "Vi phạm nội quy";
            
            $this->jailPlayer($targetName, $minutes, $reason, $sender->getName());
            $sender->sendMessage("§aĐã giam giữ §e{$targetName} §atrong §6" . ($minutes === -1 ? "Vĩnh viễn" : $minutes . " phút") . " §avì: §f" . $reason);
            return true;
        }

        if ($cmdName === "unjail") {
            if (count($args) < 1) {
                $sender->sendMessage("§cCách dùng: /unjail <tên người chơi>");
                return true;
            }
            
            $targetName = $args[0];
            $player = $this->getServer()->getPlayerByPrefix($targetName);
            if ($player !== null) {
                $targetName = $player->getName();
            }

            if ($this->unjailPlayer($targetName)) {
                $sender->sendMessage("§aĐã giải giải phóng §e{$targetName} §akhỏi ngục tối.");
            } else {
                $sender->sendMessage("§cNgười chơi §e{$targetName} §ckhông ở trong ngục tối.");
            }
            return true;
        }

        if ($cmdName === "tempban") {
            if (count($args) < 2) {
                $sender->sendMessage("§cCách dùng: /tempban <tên người chơi> <phút> [lý do]");
                return true;
            }
            
            $targetName = $args[0];
            $player = $this->getServer()->getPlayerByPrefix($targetName);
            if ($player !== null) {
                $targetName = $player->getName();
            }

            $minutes = (int)$args[1];
            if ($minutes <= 0) {
                $sender->sendMessage("§cSố phút phải lớn hơn 0!");
                return true;
            }
            $reason = count($args) > 2 ? implode(" ", array_slice($args, 2)) : "Vi phạm nội quy";
            
            $this->tempBanPlayer($targetName, $minutes, $reason, $sender->getName());
            $sender->sendMessage("§aĐã khóa tài khoản §e{$targetName} §atrong §6{$minutes} phút §avì: §f{$reason}");
            return true;
        }

        if ($cmdName === "tempunban") {
            if (count($args) < 1) {
                $sender->sendMessage("§cCách dùng: /tempunban <tên người chơi>");
                return true;
            }
            
            $targetName = $args[0];
            $player = $this->getServer()->getPlayerByPrefix($targetName);
            if ($player !== null) {
                $targetName = $player->getName();
            }

            if ($this->tempUnbanPlayer($targetName)) {
                $sender->sendMessage("§aĐã mở khóa tài khoản cho §e{$targetName}.");
            } else {
                $sender->sendMessage("§cTài khoản §e{$targetName} §ckhông bị khóa tạm thời.");
            }
            return true;
        }

        return false;
    }

    // --- Strict Restriction Listeners ---

    public function sendJailTip(Player $player) : void {
        $name = $player->getName();
        if ($this->isJailed($name, $remaining)) {
            $reason = $this->jailedPlayers[strtolower($name)]['reason'] ?? "Vi phạm nội quy";
            $timeStr = $remaining === -1 ? "Vĩnh viễn" : $this->formatTime($remaining);
            $player->sendTip("§c§lBẠN ĐANG BỊ GIAM GIỮ!\n§eLý do: §f{$reason}\n§eThời gian còn lại: §f{$timeStr}");
        }
    }

    public function onJoin(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $name = $player->getName();

        // Auto-jail NhanAZ & ghast noob trigger
        if (strcasecmp($name, "NhanAZ") === 0) {
            if (!$this->isJailed($name)) {
                $this->jailPlayer($name, -1, "Hệ thống tự động giam giữ " . $name, "Console");
            }
        }

        if ($this->isJailed($name)) {
            $jailWorld = $this->getJailWorld();
            if ($jailWorld !== null) {
                $player->teleport(new Position(102.5, 10.0, 102.5, $jailWorld));
            }
            $player->sendMessage("§cBạn vẫn đang bị giam trong ngục tối!");
            $this->sendJailTip($player);
        }
    }

    public function onPreLogin(PlayerPreLoginEvent $event) : void {
        $name = $event->getPlayerInfo()->getUsername();
        if ($this->isTempBanned($name, $remaining)) {
            $event->setKickReason(PlayerPreLoginEvent::KICK_REASON_BANNED, "§cTài khoản của bạn đang bị khóa!\n§eThời gian còn lại: §f" . $this->formatTime($remaining));
        }
    }

    public function onMove(PlayerMoveEvent $event) : void {
        $player = $event->getPlayer();
        if ($this->isJailed($player->getName())) {
            $pos = $player->getPosition();
            $jailWorld = $this->getJailWorld();
            
            if ($pos->getWorld()->getFolderName() !== "jail" || $pos->distance(new Vector3(102.5, 10.0, 102.5)) > 3.0) {
                if ($jailWorld !== null) {
                    $player->teleport(new Position(102.5, 10.0, 102.5, $jailWorld));
                }
            }
            $this->sendJailTip($player);
        }
    }

    public function onBreak(BlockBreakEvent $event) : void {
        $player = $event->getPlayer();
        if ($this->isJailed($player->getName())) {
            $event->cancel();
            $this->sendJailTip($player);
        }
    }

    public function onPlace(BlockPlaceEvent $event) : void {
        $player = $event->getPlayer();
        if ($this->isJailed($player->getName())) {
            $event->cancel();
            $this->sendJailTip($player);
        }
    }

    public function onInteract(PlayerInteractEvent $event) : void {
        $player = $event->getPlayer();
        if ($this->isJailed($player->getName())) {
            $event->cancel();
            $this->sendJailTip($player);
        }
    }

    public function onItemUse(PlayerItemUseEvent $event) : void {
        $player = $event->getPlayer();
        if ($this->isJailed($player->getName())) {
            $event->cancel();
            $this->sendJailTip($player);
        }
    }

    public function onDrop(PlayerDropItemEvent $event) : void {
        $player = $event->getPlayer();
        if ($this->isJailed($player->getName())) {
            $event->cancel();
            $this->sendJailTip($player);
        }
    }

    public function onPickup(EntityItemPickupEvent $event) : void {
        $origin = $event->getOrigin();
        if ($origin instanceof Player && $this->isJailed($origin->getName())) {
            $event->cancel();
            $this->sendJailTip($origin);
        }
    }

    public function onDamage(EntityDamageEvent $event) : void {
        $entity = $event->getEntity();
        if ($entity instanceof Player && $this->isJailed($entity->getName())) {
            $event->cancel();
            $this->sendJailTip($entity);
            return;
        }

        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Player && $this->isJailed($damager->getName())) {
                $event->cancel();
                $this->sendJailTip($damager);
            }
        }
    }

    public function onCommandExecute(CommandEvent $event) : void {
        $sender = $event->getSender();
        if ($sender instanceof Player && $this->isJailed($sender->getName())) {
            $sender->sendMessage("§cBạn đang bị giam giữ, không thể sử dụng lệnh!");
            $event->cancel();
            $this->sendJailTip($sender);
        }
    }
}
