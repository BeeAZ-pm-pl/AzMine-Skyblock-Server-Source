<?php

namespace azbroadcast;

use pocketmine\scheduler\Task;
use pocketmine\Server;

class BroadcastTask extends Task {
    private int $index = 0;
    
    private array $messages = [
        "§fChào mừng bạn đến với máy chủ §l§eSkyBlock AZMine§r§f! Hãy trải nghiệm sinh tồn tuyệt vời cùng bạn bè.",
        "§fSử dụng lệnh §a/is §fđể tạo đảo bay, quản lý và bắt đầu cuộc hành trình sinh tồn của riêng bạn.",
        "§fChế tạo cần câu xịn tại §a/fishing §fđể tham gia hoạt động câu cá giải trí và bán cá kiếm Xu.",
        "§fĐồng hành cùng thú cưng Pokémon đáng yêu bằng cách quản lý chúng qua lệnh §a/pet§f.",
        "§fTạo lập hoặc tham gia bang hội cùng các đồng đội qua lệnh §a/f §fđể cùng nhau phát triển đảo.",
        "§fMua bán vật phẩm an toàn và tiện lợi giữa những người chơi với nhau bằng lệnh §a/ah§f.",
        "§fTham gia làm các thử thách thú vị hằng ngày tại §a/mission §fđể tích lũy vô vàn phần thưởng hấp dẫn.",
        "§fĐiểm danh hằng ngày bằng lệnh §a/diemdanh §fđể không bỏ lỡ những món quà miễn phí chất lượng.",
        "§fThử vận may của bạn với máy quay Jackpot tại §a/jackpot shop §fđể có cơ hội nổ hũ cực lớn!",
        "§fNâng cấp cảnh giới tu vi của bản thân bằng cách tích lũy exp tu luyện qua lệnh §a/canhgioi§f.",
        "§fMua sắm các trang bị, vật phẩm cần thiết tại §a/shop §fhoặc cửa hàng đặc biệt §a/pshop§f.",
        "§fNâng cấp sức mạnh trang bị của bạn bằng hệ thống §a/muachiso §fvà §a/muaskin §fđể đi phó bản dễ dàng hơn.",
        "§fLập tổ đội cùng bạn bè chinh phục phó bản săn Boss nhận bảo vật cực hiếm bằng lệnh §a/dungeon§f.",
        "§fNhớ cất giữ tài sản cẩn thận vào rương. Hệ thống sẽ tự động dọn dẹp vật phẩm rơi trên đất định kỳ để giảm lag!"
    ];

    public function onRun(): void {
        if (!isset($this->messages[$this->index])) {
            $this->index = 0;
        }

        $msg = $this->messages[$this->index];
        $server = Server::getInstance();

        $server->broadcastMessage("§r§7▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        $server->broadcastMessage("§l§b⚡ §e§lTIN TỨC MÁY CHỦ §b⚡§r");
        $server->broadcastMessage(" " . $msg);
        $server->broadcastMessage("§r§7▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");

        $this->index++;
    }
}