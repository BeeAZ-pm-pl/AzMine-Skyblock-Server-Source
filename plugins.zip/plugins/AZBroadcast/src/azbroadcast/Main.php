<?php

namespace azbroadcast;

use pocketmine\plugin\PluginBase;

class Main extends PluginBase {
    protected function onEnable(): void {
        $this->getScheduler()->scheduleRepeatingTask(new BroadcastTask(), 1800);
    }
}