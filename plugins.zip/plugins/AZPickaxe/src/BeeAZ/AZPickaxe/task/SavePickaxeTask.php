<?php

declare(strict_types=1);

namespace BeeAZ\AZPickaxe\task;

use pocketmine\scheduler\AsyncTask;

class SavePickaxeTask extends AsyncTask {

    private string $data;

    public function __construct(
        private string $dbPath,
        array $data
    ) {
        $this->data = serialize($data);
    }

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $db->exec("BEGIN TRANSACTION;");
        $stmt = $db->prepare("INSERT OR REPLACE INTO player_pickaxes (username, level, blocks_progress) VALUES (:name, :level, :blocks_progress)");
        
        $array = unserialize($this->data);
        foreach ($array as $username => $stats) {
            $stmt->bindValue(":name", $username, SQLITE3_TEXT);
            $stmt->bindValue(":level", $stats['level'], SQLITE3_INTEGER);
            $stmt->bindValue(":blocks_progress", $stats['blocks_progress'], SQLITE3_INTEGER);
            $stmt->execute();
        }
        
        $db->exec("COMMIT;");
        $db->close();
    }
}
