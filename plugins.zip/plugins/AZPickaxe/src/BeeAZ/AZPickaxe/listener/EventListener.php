<?php

declare(strict_types=1);

namespace BeeAZ\AZPickaxe\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use BeeAZ\AZPickaxe\Main;

class EventListener implements Listener {

    public function __construct(private Main $plugin) {}

    public function onJoin(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $this->plugin->loadPlayerStats($player->getName());

        if (!$player->hasPlayedBefore()) {
            $this->plugin->givePickaxe($player);
        }
    }

    public function onQuit(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
        $this->plugin->unloadPlayerStats($player->getName());
    }

    /**
     * @priority MONITOR
     */
    public function onBlockBreak(BlockBreakEvent $event) : void {
        if ($event->isCancelled()) {
            return;
        }
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();

        if ($item->isNull()) {
            return;
        }

        $tag = $item->getNamedTag();
        if ($tag->getTag("Owner") === null) {
            return;
        }

        $owner = $tag->getString("Owner");
        if (strtolower($owner) !== strtolower($player->getName())) {
            $player->sendMessage("§c⚡ §lCúp này thuộc sở hữu của §e" . $owner . "§c, bạn không thể sử dụng!");
            $event->cancel();
            return;
        }

        // Increment mining progress
        $username = strtolower($player->getName());
        $level = $this->plugin->getPlayerLevel($username);
        $progress = $this->plugin->getPlayerProgress($username) + 1;

        if ($progress >= 5000) {
            $level++;
            $progress = 0;
            $player->sendMessage("§a⚡ §lCÚP CỦA BẠN ĐÃ TĂNG LÊN CẤP §e" . $level . "§a!");
            
            // Play level up sound
            $pos = $player->getPosition();
            $pk = PlaySoundPacket::create("random.levelup", $pos->x, $pos->y, $pos->z, 1.0, 1.0, null);
            $player->getNetworkSession()->sendDataPacket($pk);
        }

        // Save stats to cache
        $this->plugin->setPlayerStats($username, $level, $progress);

        // Update item enchants and lore
        Main::applyEnchantsAndLore($item, $level, $owner, $progress);

        // Set item back to inventory
        $player->getInventory()->setItemInHand($item);
    }

    public function onItemHeld(PlayerItemHeldEvent $event) : void {
        $player = $event->getPlayer();
        $item = $event->getItem();

        if ($item->isNull()) {
            return;
        }

        $tag = $item->getNamedTag();
        if ($tag->getTag("Owner") === null) {
            return;
        }

        $owner = $tag->getString("Owner");
        if (strtolower($owner) !== strtolower($player->getName())) {
            $player->sendMessage("§c⚡ §lVật phẩm này thuộc sở hữu của §e" . $owner . "§c!");
        }
    }
}
