<?php

declare(strict_types=1);

namespace BeeAZ\AZPickaxe;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\scheduler\ClosureTask;
use BeeAZ\AZPickaxe\listener\EventListener;
use BeeAZ\AZPickaxe\task\SavePickaxeTask;

class Main extends PluginBase {

    private static self $instance;
    private \SQLite3 $db;
    
    // Memory Cache: [username_lowercase => ["level" => int, "blocks_progress" => int]]
    private array $cache = [];
    
    // Dirty list to track who needs database saving: [username_lowercase => true]
    private array $dirty = [];

    public static function getInstance() : self {
        return self::$instance;
    }

    protected function onLoad() : void {
        self::$instance = $this;
    }

    protected function onEnable() : void {
        @mkdir($this->getDataFolder());
        
        // Init SQLite
        $this->db = new \SQLite3($this->getDataFolder() . "pickaxes.db");
        $this->db->busyTimeout(5000);
        $this->db->exec("CREATE TABLE IF NOT EXISTS player_pickaxes (username TEXT PRIMARY KEY, level INTEGER, blocks_progress INTEGER);");

        // Register Events
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);

        // Schedule periodic auto-save task (every 5 minutes)
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function() : void {
            $this->saveAllDirty(true);
        }), 300 * 20);
    }

    protected function onDisable() : void {
        // Synchronous write of all unsaved cached stats
        $this->saveAllDirty(false);
        $this->db->close();
    }

    /**
     * Load player statistics into memory cache.
     */
    public function loadPlayerStats(string $username) : void {
        $username = strtolower($username);
        if (isset($this->cache[$username])) {
            return;
        }

        $stmt = $this->db->prepare("SELECT level, blocks_progress FROM player_pickaxes WHERE username = :name");
        $stmt->bindValue(":name", $username, SQLITE3_TEXT);
        $result = $stmt->execute();
        
        if ($result !== false && ($row = $result->fetchArray(SQLITE3_ASSOC)) !== false) {
            $this->cache[$username] = [
                "level" => (int)$row['level'],
                "blocks_progress" => (int)$row['blocks_progress']
            ];
        } else {
            // First time stats
            $this->cache[$username] = [
                "level" => 1,
                "blocks_progress" => 0
            ];
            // Write initial stats to DB asynchronously
            $this->dirty[$username] = true;
        }
    }

    public function unloadPlayerStats(string $username) : void {
        $username = strtolower($username);
        // Save dirty data of this player first
        if (isset($this->dirty[$username]) && isset($this->cache[$username])) {
            $singleData = [$username => $this->cache[$username]];
            $this->getServer()->getAsyncPool()->submitTask(new SavePickaxeTask(
                $this->getDataFolder() . "pickaxes.db",
                $singleData
            ));
            unset($this->dirty[$username]);
        }
        unset($this->cache[$username]);
    }

    public function getPlayerLevel(string $username) : int {
        $username = strtolower($username);
        return $this->cache[$username]["level"] ?? 1;
    }

    public function getPlayerProgress(string $username) : int {
        $username = strtolower($username);
        return $this->cache[$username]["blocks_progress"] ?? 0;
    }

    public function setPlayerStats(string $username, int $level, int $blocks_progress) : void {
        $username = strtolower($username);
        $this->cache[$username] = [
            "level" => $level,
            "blocks_progress" => $blocks_progress
        ];
        $this->dirty[$username] = true;
    }

    /**
     * Save all dirty data to SQLite.
     * 
     * @param bool $async Use AsyncTask if true, otherwise write synchronously.
     */
    public function saveAllDirty(bool $async = true) : void {
        if (empty($this->dirty)) {
            return;
        }

        $saveData = [];
        foreach (array_keys($this->dirty) as $username) {
            if (isset($this->cache[$username])) {
                $saveData[$username] = $this->cache[$username];
            }
        }

        if (empty($saveData)) {
            $this->dirty = [];
            return;
        }

        if ($async) {
            $this->getServer()->getAsyncPool()->submitTask(new SavePickaxeTask(
                $this->getDataFolder() . "pickaxes.db",
                $saveData
            ));
        } else {
            // Synchronous save
            $this->db->exec("BEGIN TRANSACTION;");
            $stmt = $this->db->prepare("INSERT OR REPLACE INTO player_pickaxes (username, level, blocks_progress) VALUES (:name, :level, :blocks_progress)");
            foreach ($saveData as $username => $stats) {
                $stmt->bindValue(":name", $username, SQLITE3_TEXT);
                $stmt->bindValue(":level", $stats['level'], SQLITE3_INTEGER);
                $stmt->bindValue(":blocks_progress", $stats['blocks_progress'], SQLITE3_INTEGER);
                $stmt->execute();
            }
            $this->db->exec("COMMIT;");
        }

        $this->dirty = [];
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if ($command->getName() === "givecup") {
            if ($sender instanceof Player) {
                $this->givePickaxe($sender);
                $sender->sendMessage("§a⚡ §lĐã nhận Pickaxe Level thành công!");
            } else {
                $sender->sendMessage("§c⚡ §lLệnh này chỉ dành cho người chơi!");
            }
            return true;
        }
        return false;
    }

    public function givePickaxe(Player $player) : void {
        $username = strtolower($player->getName());
        $this->loadPlayerStats($username);
        
        $level = $this->getPlayerLevel($username);
        $progress = $this->getPlayerProgress($username);
        
        $item = VanillaItems::IRON_PICKAXE();
        $item->setUnbreakable(true);

        $tag = $item->getNamedTag();
        $tag->setString("Owner", $player->getName());

        self::applyEnchantsAndLore($item, $level, $player->getName(), $progress);

        if ($player->getInventory()->canAddItem($item)) {
            $player->getInventory()->addItem($item);
            $player->sendMessage("§a⚡ §lBạn nhận được Pickaxe Level của riêng mình!");
        } else {
            $player->getWorld()->dropItem($player->getPosition(), $item);
            $player->sendMessage("§e⚡ §lHành trang đầy, Pickaxe Level của bạn đã rơi dưới đất!");
        }
    }

    /**
     * Apply the progression NBT, enchants, custom name, and lore to the item.
     */
    public static function applyEnchantsAndLore(Item $item, int $level, string $owner, int $blocks) : void {
        // Unbreakable tag just in case vanilla engine relies on NBT
        $item->setUnbreakable(true);

        // Customize display name
        $item->setCustomName("§r§l§e⚡ §dPickaxe Level §e⚡ §e[Cấp " . $level . "]");

        // Calculate and apply Efficiency
        $item->removeEnchantment(VanillaEnchantments::EFFICIENCY());
        if ($level >= 5) {
            $effLevel = 1 + (int)(($level - 5) / 10);
            $item->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), $effLevel));
        }

        // Calculate and apply Fortune
        $item->removeEnchantment(VanillaEnchantments::FORTUNE());
        if ($level >= 15) {
            $fortLevel = 1 + (int)(($level - 15) / 15);
            $item->addEnchantment(new EnchantmentInstance(VanillaEnchantments::FORTUNE(), $fortLevel));
        }

        // Customize lore
        $lore = [
            "§r§fChủ sở hữu: §a" . $owner,
            "§r§fSố block đã đào: §b" . number_format($blocks) . " §7/ §f5,000",
            "§r§fCấp độ cúp: §e" . $level,
            "§r§7(Tự động tăng cấp và thêm enchants khi đào)",
        ];
        $item->setLore($lore);
    }
}
