<?php

declare(strict_types=1);

namespace azdungeon\model;

use pocketmine\world\World;
use azdungeon\model\Party;

class DungeonSession {
    private string $id;
    private Party $party;
    private World $world;
    private int $stage;
    private string $dungeonId;
    private int $startTime;
    private ?int $bossEntityId = null;
    private bool $isStarted = false;
    private ?\pocketmine\math\Vector3 $portalPos = null;

    public function __construct(string $id, Party $party, World $world, string $dungeonId, int $stage = 1) {
        $this->id = $id;
        $this->party = $party;
        $this->world = $world;
        $this->dungeonId = $dungeonId;
        $this->stage = $stage;
        $this->startTime = time();
    }

    public function getId(): string {
        return $this->id;
    }

    public function getParty(): Party {
        return $this->party;
    }

    public function getWorld(): World {
        return $this->world;
    }

    public function getStage(): int {
        return $this->stage;
    }

    public function setStage(int $stage): void {
        $this->stage = $stage;
    }

    public function getDungeonId(): string {
        return $this->dungeonId;
    }

    public function setBossEntityId(int $id): void {
        $this->bossEntityId = $id;
    }

    public function getBossEntityId(): ?int {
        return $this->bossEntityId;
    }

    public function isStarted(): bool {
        return $this->isStarted;
    }

    public function setStarted(bool $started): void {
        $this->isStarted = $started;
    }

    public function getPortalPos(): ?\pocketmine\math\Vector3 {
        return $this->portalPos;
    }

    public function setPortalPos(?\pocketmine\math\Vector3 $pos): void {
        $this->portalPos = $pos;
    }

    public function getStartTime(): int {
        return $this->startTime;
    }
}
