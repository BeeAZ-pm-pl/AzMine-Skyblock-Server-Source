<?php

declare(strict_types=1);

namespace azdungeon\model;

class Party {
    /** @var string[] */
    private array $members = [];
    private string $leader;

    public function __construct(string $leaderName) {
        $this->leader = $leaderName;
        $this->members[] = $leaderName;
    }

    public function getLeader(): string {
        return $this->leader;
    }

    public function setLeader(string $leader): void {
        $this->leader = $leader;
    }

    /** @return string[] */
    public function getMembers(): array {
        return $this->members;
    }

    public function addMember(string $playerName): void {
        if (!in_array($playerName, $this->members)) {
            $this->members[] = $playerName;
        }
    }

    public function removeMember(string $playerName): void {
        $this->members = array_values(array_filter($this->members, fn($m) => $m !== $playerName));
    }

    public function isMember(string $playerName): bool {
        return in_array($playerName, $this->members);
    }
}
