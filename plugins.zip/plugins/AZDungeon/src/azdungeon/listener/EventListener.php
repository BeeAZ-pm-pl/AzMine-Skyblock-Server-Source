<?php

declare(strict_types=1);

namespace azdungeon\listener;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerToggleFlightEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use azdungeon\Main;
use azdungeon\ui\DungeonMenu;
use azboss\entity\BossEntity;

class EventListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    private function isDungeonWorld(string $worldName): bool {
        return strpos($worldName, "dungeon_") === 0;
    }

    // ==================== FIX FLY/SPIDER IN DUNGEON ====================
    public function onTeleportToDungeon(EntityTeleportEvent $event): void {
        $entity = $event->getEntity();
        if (!$entity instanceof Player) return;

        $to = $event->getTo();
        if (!$this->isDungeonWorld($to->getWorld()->getFolderName())) return;

        // Disable fly
        $entity->setFlying(false);
        $entity->setAllowFlight(false);

        // Disable spider mode from AZRankBooster
        $booster = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRankBooster");
        if ($booster !== null && method_exists($booster, "disableSpiderMode")) {
            $booster->disableSpiderMode($entity);
        }
        $entity->setCanClimbWalls(false);
    }

    public function onToggleFlight(PlayerToggleFlightEvent $event): void {
        $player = $event->getPlayer();
        if ($this->isDungeonWorld($player->getWorld()->getFolderName()) && $event->isFlying()) {
            $event->cancel();
            $player->setAllowFlight(false);
            $player->setFlying(false);
            $player->sendMessage("§c§l⚡ §r§cBạn không được phép bay trong phó bản!");
        }
    }

    public function onMoveInDungeon(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if (!$this->isDungeonWorld($player->getWorld()->getFolderName())) return;

        // Force disable fly
        if ($player->isFlying() || $player->getAllowFlight()) {
            $player->setFlying(false);
            $player->setAllowFlight(false);
            $player->sendMessage("§c§l⚡ §r§cBạn không được phép bay trong phó bản!");
        }

        // Force disable spider/wall climb
        if ($player->canClimbWalls()) {
            $player->setCanClimbWalls(false);
            $player->sendMessage("§c§l⚡ §r§cBạn không được phép leo tường trong phó bản!");
        }
    }

    // ==================== ORIGINAL EVENTS ====================
    public function onEntityDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof BossEntity) {
            $worldName = $entity->getWorld()->getFolderName();
            $session = $this->plugin->getDungeonManager()->getSessionByWorld($worldName);
            if ($session !== null && $session->getBossEntityId() === $entity->getId()) {
                $config = new \pocketmine\utils\Config($this->plugin->getDataFolder() . "config.yml", \pocketmine\utils\Config::YAML);
                $dungeonData = $config->get("dungeons", [])[$session->getDungeonId()] ?? [];
                $maxStages = isset($dungeonData['stages']) ? count($dungeonData['stages']) : 1;

                if ($session->getStage() < $maxStages) {
                    $session->setPortalPos($entity->getLocation());
                    $party = $session->getParty();
                    foreach ($party->getMembers() as $memberName) {
                        $p = \pocketmine\Server::getInstance()->getPlayerExact($memberName);
                        if ($p !== null && $p->isOnline()) {
                            $p->sendMessage("§aBoss đã bị tiêu diệt! Vòng tròn dịch chuyển đến Ải tiếp theo đã mở ra!");
                        }
                    }
                } else {
                    $this->plugin->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(function() use ($session): void {
                        $this->plugin->getDungeonManager()->endDungeon($session, true);
                    }), 20); // Delay 1s để tránh crash do Unload World
                }
            }
        }
    }

    public function onPlayerDeath(PlayerDeathEvent $event): void {
        $player = $event->getPlayer();
        $worldName = $player->getWorld()->getFolderName();
        $session = $this->plugin->getDungeonManager()->getSessionByWorld($worldName);

        if ($session !== null) {
            $party = $session->getParty();
            $allDead = true;
            foreach ($party->getMembers() as $memberName) {
                $p = \pocketmine\Server::getInstance()->getPlayerExact($memberName);
                // Check if there is any other member alive in the dungeon
                if ($p !== null && $p->isOnline() && $p->isAlive() && $p->getName() !== $player->getName() && $p->getWorld()->getFolderName() === $worldName) {
                    $allDead = false;
                    break;
                }
            }

            if ($allDead) {
                $this->plugin->getDungeonManager()->endDungeon($session, false);
            }
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $this->plugin->getPartyManager()->leaveParty($player->getName());
        
        $session = $this->plugin->getDungeonManager()->getSessionByPlayer($player->getName());
        if ($session !== null) {
            $party = $session->getParty();
            if (empty($party->getMembers())) {
                // Everyone left, end dungeon
                $this->plugin->getDungeonManager()->endDungeon($session, false);
            }
        }
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        
        if ($item->getTypeId() === VanillaItems::PAPER()->getTypeId()) {
            $name = $item->getCustomName();
            if (strpos($name, "Bản Đồ Phó Bản") !== false) {
                DungeonMenu::open($player);
                $event->cancel();
                return;
            }
        }
        
        if ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            if ($this->plugin->getDungeonManager()->getSessionByWorld($player->getWorld()->getFolderName()) !== null) {
                $event->cancel();
            }
        }
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        if ($this->plugin->getDungeonManager()->getSessionByWorld($player->getWorld()->getFolderName()) !== null) {
            $event->cancel();
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        if ($this->plugin->getDungeonManager()->getSessionByWorld($player->getWorld()->getFolderName()) !== null) {
            $event->cancel();
        }
    }
}

