<?php

declare(strict_types=1);

namespace azdungeon\manager;

use azdungeon\Main;
use azdungeon\model\Party;
use azdungeon\model\DungeonSession;
use pocketmine\Server;
use pocketmine\world\WorldCreationOptions;
use pocketmine\math\Vector3;

class DungeonManager {
    /** @var array<string, DungeonSession> */
    private array $sessions = [];
    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;

        $this->plugin->getScheduler()->scheduleRepeatingTask(new \pocketmine\scheduler\ClosureTask(function(): void {
            foreach ($this->sessions as $sessionId => $session) {
                if ($session->isStarted() && $session->getWorld()->isLoaded()) {
                    if (count($session->getWorld()->getPlayers()) === 0) {
                        $this->endDungeon($session, false);
                        continue;
                    }
                    
                    $remaining = 900 - (time() - $session->getStartTime()); // 15 mins
                    if ($remaining <= 0) {
                        foreach ($session->getParty()->getMembers() as $memberName) {
                            $p = Server::getInstance()->getPlayerExact($memberName);
                            if ($p !== null && $p->isOnline() && $p->getWorld() === $session->getWorld()) {
                                $p->sendMessage("§cPhó bản đã hết thời gian giới hạn!");
                            }
                        }
                        $this->endDungeon($session, false);
                        continue;
                    }

                    $mins = floor($remaining / 60);
                    $secs = $remaining % 60;
                    $timeStr = sprintf("%02d:%02d", $mins, $secs);
                    $tip = "§l§c⏳ THỜI GIAN CÒN LẠI: §e" . $timeStr;

                    $portalPos = $session->getPortalPos();
                    if ($portalPos !== null) {
                        $world = $session->getWorld();
                        // Sinh particle vòng tròn đậm hơn (2 vòng, mỗi vòng 24 hạt)
                        for ($i = 0; $i < 360; $i += 15) {
                            $x = $portalPos->x + 1.5 * cos(deg2rad($i));
                            $z = $portalPos->z + 1.5 * sin(deg2rad($i));
                            $world->addParticle(new \pocketmine\math\Vector3($x, $portalPos->y + 0.5, $z), new \pocketmine\world\particle\FlameParticle());
                            $world->addParticle(new \pocketmine\math\Vector3($x, $portalPos->y + 1.0, $z), new \pocketmine\world\particle\FlameParticle());
                        }
                        
                        // Kiểm tra người chơi bước vào
                        $stepped = false;
                        foreach ($world->getPlayers() as $player) {
                            if ($player->getLocation()->distance($portalPos) < 1.5) {
                                $stepped = true;
                                break;
                            }
                        }
                        
                        if ($stepped) {
                            $this->nextStage($session);
                            continue;
                        }
                    }
                    
                    foreach ($session->getParty()->getMembers() as $memberName) {
                        $p = Server::getInstance()->getPlayerExact($memberName);
                        if ($p !== null && $p->isOnline() && $p->getWorld() === $session->getWorld()) {
                            $p->sendTip($tip);
                        }
                    }
                }
            }
        }), 20); // Kiểm tra mỗi giây
    }

    public function hasEnteredToday(string $playerName): bool {
        $file = $this->plugin->getDataFolder() . "dungeon_limits.json";
        $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
        $today = date("Y-m-d");
        return isset($data[strtolower($playerName)]) && $data[strtolower($playerName)] === $today;
    }

    public function recordEntry(string $playerName): void {
        $file = $this->plugin->getDataFolder() . "dungeon_limits.json";
        $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
        $data[strtolower($playerName)] = date("Y-m-d");
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));
    }

    public function startDungeon(Party $party, string $dungeonId, int $stage = 1): void {
        $sessionId = uniqid("dungeon_");
        $worldManager = Server::getInstance()->getWorldManager();

        $options = WorldCreationOptions::create();
            
        $worldManager->generateWorld($sessionId, $options);
        $worldManager->loadWorld($sessionId);
        $world = $worldManager->getWorldByName($sessionId);

        if ($world === null) {
            $this->sendMessageToParty($party, "§cLỗi: Không thể khởi tạo bản đồ phó bản!");
            return;
        }

        $center = new Vector3(256, 100, 256);
        $world->setSpawnLocation($center);

        $session = new DungeonSession($sessionId, $party, $world, $dungeonId, $stage);
        $this->sessions[$sessionId] = $session;

        foreach ($party->getMembers() as $memberName) {
            $player = Server::getInstance()->getPlayerExact($memberName);
            if ($player !== null && $player->isOnline()) {
                $player->sendMessage("§eĐang khởi tạo không gian phó bản, vui lòng chờ...");
            }
        }

        // Tạo danh sách Chunk cần generate (bán kính 2 chunk xung quanh center = 5x5 chunks)
        $chunkX = $center->getFloorX() >> 4;
        $chunkZ = $center->getFloorZ() >> 4;
        $promises = [];
        
        for ($cx = -2; $cx <= 2; $cx++) {
            for ($cz = -2; $cz <= 2; $cz++) {
                $promises[] = $world->orderChunkPopulation($chunkX + $cx, $chunkZ + $cz, null);
            }
        }

        $totalChunks = count($promises);
        $completedChunks = 0;

        $onChunkLoaded = function() use (&$completedChunks, $totalChunks, $world, $center, $session, $party): void {
            $completedChunks++;
            if ($completedChunks >= $totalChunks) {
                // Đã generate xong toàn bộ chunk, bắt đầu xây Arena
                ArenaBuilder::build($world, $center, 20);
                MobSpawner::spawnBoss($session, $center);

                // Sau khi xây xong mới dịch chuyển người chơi vào
                $spawnPos = new \pocketmine\world\Position($center->x, $center->y, $center->z, $world);
                foreach ($party->getMembers() as $memberName) {
                    $player = Server::getInstance()->getPlayerExact($memberName);
                    if ($player !== null && $player->isOnline()) {
                        $player->teleport($spawnPos);
                        $player->sendMessage("§aPhó bản ải " . $session->getStage() . " đã sẵn sàng! Chúc may mắn!");
                    }
                }
                $session->setStarted(true);
                // Record daily entry for all members
                foreach ($party->getMembers() as $name) {
                    $this->recordEntry($name);
                }
            }
        };

        foreach ($promises as $promise) {
            $promise->onCompletion($onChunkLoaded, function(): void {});
        }
    }

    public function getSessionByWorld(string $worldName): ?DungeonSession {
        return $this->sessions[$worldName] ?? null;
    }

    public function getSessionByPlayer(string $playerName): ?DungeonSession {
        foreach ($this->sessions as $session) {
            if ($session->getParty()->isMember($playerName)) {
                return $session;
            }
        }
        return null;
    }

    public function nextStage(DungeonSession $session): void {
        $session->setStage($session->getStage() + 1);
        $session->setPortalPos(null);
        
        $world = $session->getWorld();
        $center = new Vector3(256, 100, 256);
        
        // Clean up items & dead entities
        foreach ($world->getEntities() as $entity) {
            if (!$entity instanceof \pocketmine\player\Player) {
                $entity->flagForDespawn();
            }
        }
        
        // Teleport everyone to center edge
        $spawnPos = new \pocketmine\world\Position($center->x, $center->y, $center->z + 15, $world);
        foreach ($session->getParty()->getMembers() as $memberName) {
            $p = Server::getInstance()->getPlayerExact($memberName);
            if ($p !== null && $p->isOnline() && $p->getWorld() === $world) {
                if ($p->isAlive()) {
                    $p->teleport($spawnPos);
                    $p->sendMessage("§aBạn đã tiến vào Ải " . $session->getStage() . "!");
                    
                    $pk = \pocketmine\network\mcpe\protocol\ToastRequestPacket::create("§l§eHOÀN THÀNH ẢI " . ($session->getStage() - 1), "§fĐANG BƯỚC VÀO ẢI " . $session->getStage());
                    $p->getNetworkSession()->sendDataPacket($pk);
                }
            }
        }
        
        // Build floor and spawn Boss again
        ArenaBuilder::build($world, $center, 20);
        MobSpawner::spawnBoss($session, $center);
    }

    public function endDungeon(DungeonSession $session, bool $success = false): void {
        $world = $session->getWorld();
        $party = $session->getParty();
        $defaultWorld = Server::getInstance()->getWorldManager()->getDefaultWorld();

        $config = new \pocketmine\utils\Config($this->plugin->getDataFolder() . "config.yml", \pocketmine\utils\Config::YAML);
        $dungeons = $config->get("dungeons", []);
        $dungeonData = $dungeons[$session->getDungeonId()] ?? [];
        $rewards = $dungeonData['rewards'] ?? [];
        $azeco = Server::getInstance()->getPluginManager()->getPlugin("AZEconomy");

        $aliveMembers = [];
        foreach ($party->getMembers() as $memberName) {
            $player = Server::getInstance()->getPlayerExact($memberName);
            if ($player !== null && $player->isOnline() && $player->getWorld()->getFolderName() === $world->getFolderName()) {
                if ($player->isAlive()) {
                    $aliveMembers[] = $player;
                }
            }
        }

        $aliveCount = count($aliveMembers);

        if ($success && $aliveCount > 0) {
            $moneyPerPlayer = isset($rewards['money']) ? (int)($rewards['money'] / $aliveCount) : 0;
            $coinPerPlayer = isset($rewards['coin']) ? (int)($rewards['coin'] / $aliveCount) : 0;

            foreach ($aliveMembers as $player) {
                $player->sendMessage("§aChúc mừng! Party của bạn đã vượt qua phó bản ải " . $session->getStage() . "!");
                
                if ($moneyPerPlayer > 0 && $azeco !== null && method_exists($azeco, "addMoney")) {
                    $azeco->addMoney($player->getName(), $moneyPerPlayer);
                    $player->sendMessage("§a+ " . number_format($moneyPerPlayer) . " Xu (Chia đều)");
                }
                if ($coinPerPlayer > 0 && $azeco !== null && method_exists($azeco, "addCoin")) {
                    $azeco->addCoin($player->getName(), $coinPerPlayer);
                    $player->sendMessage("§a+ " . number_format($coinPerPlayer) . " Coin (Chia đều)");
                }
            }

            // Commands cho trưởng nhóm
            $leaderPlayer = Server::getInstance()->getPlayerExact($party->getLeader());
            if ($leaderPlayer !== null && $leaderPlayer->isOnline() && $leaderPlayer->isAlive() && $leaderPlayer->getWorld()->getFolderName() === $world->getFolderName()) {
                if (isset($rewards['commands']) && is_array($rewards['commands'])) {
                    foreach ($rewards['commands'] as $cmd) {
                        $cmdStr = str_replace("{player}", '"' . $leaderPlayer->getName() . '"', $cmd);
                        Server::getInstance()->dispatchCommand(new \pocketmine\console\ConsoleCommandSender(Server::getInstance(), Server::getInstance()->getLanguage()), $cmdStr);
                    }
                }
                $leaderPlayer->sendMessage("§aBạn nhận được phần thưởng riêng của Trưởng nhóm!");
            }
        }

        // Teleport everyone out
        foreach ($party->getMembers() as $memberName) {
            $player = Server::getInstance()->getPlayerExact($memberName);
            if ($player !== null && $player->isOnline() && $player->getWorld()->getFolderName() === $world->getFolderName()) {
                if (!$success) {
                    $player->sendMessage("§cPhó bản đã kết thúc (Thất bại hoặc bị hủy).");
                }
                if ($player->isAlive()) {
                    $player->teleport($defaultWorld->getSpawnLocation());
                }
            }
        }

        unset($this->sessions[$session->getId()]);
        
        $worldManager = Server::getInstance()->getWorldManager();
        
        $this->plugin->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(function() use ($worldManager, $world): void {
            if ($worldManager->isWorldLoaded($world->getFolderName())) {
                $worldManager->unloadWorld($world, true);
            }
        }), 20); // Delay 1 giây (20 ticks) để thế giới kết thúc tick hiện tại trước khi Unload
        
        // Đợi 3 giây (60 ticks) để chắc chắn PMMP đã nhả lock file và Unload xong, sau đó xóa toàn bộ folder map
        $worldPath = Server::getInstance()->getDataPath() . "worlds/" . $world->getFolderName();
        $this->plugin->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(function() use ($worldPath): void {
            self::deleteDirectory($worldPath);
        }), 60);
    }

    private static function deleteDirectory(string $dir): void {
        if (!is_dir($dir)) {
            return;
        }
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = "$dir/$file";
            is_dir($path) ? self::deleteDirectory($path) : @unlink($path);
        }
        @rmdir($dir);
    }

    private function sendMessageToParty(Party $party, string $message): void {
        foreach ($party->getMembers() as $memberName) {
            $player = Server::getInstance()->getPlayerExact($memberName);
            if ($player !== null && $player->isOnline()) {
                $player->sendMessage($message);
            }
        }
    }
}
