<?php

declare(strict_types=1);

namespace azdungeon\manager;

use azdungeon\model\Party;

class PartyManager {
    /** @var Party[] */
    private array $parties = [];
    /** @var array<string, string> PlayerName => LeaderName */
    private array $playerPartyMap = [];
    /** @var array<string, string> TargetName => InviterName */
    private array $invites = [];

    public function createParty(string $leaderName): ?Party {
        if ($this->getParty($leaderName) !== null) {
            return null;
        }
        $party = new Party($leaderName);
        $this->parties[$leaderName] = $party;
        $this->playerPartyMap[$leaderName] = $leaderName;
        return $party;
    }

    public function getParty(string $playerName): ?Party {
        $leaderName = $this->playerPartyMap[$playerName] ?? null;
        if ($leaderName !== null && isset($this->parties[$leaderName])) {
            return $this->parties[$leaderName];
        }
        return null;
    }

    public function invite(string $inviter, string $target): void {
        $this->invites[$target] = $inviter;
    }

    public function getInvite(string $target): ?string {
        return $this->invites[$target] ?? null;
    }

    public function clearInvite(string $target): void {
        unset($this->invites[$target]);
    }

    public function joinParty(string $playerName, string $leaderName): bool {
        if (!isset($this->parties[$leaderName])) {
            return false;
        }
        $party = $this->parties[$leaderName];
        $party->addMember($playerName);
        $this->playerPartyMap[$playerName] = $leaderName;
        return true;
    }

    public function leaveParty(string $playerName): bool {
        $party = $this->getParty($playerName);
        if ($party === null) return false;

        if ($party->getLeader() === $playerName) {
            $this->disbandParty($playerName);
        } else {
            $party->removeMember($playerName);
            unset($this->playerPartyMap[$playerName]);
        }
        return true;
    }

    public function disbandParty(string $leaderName): void {
        if (isset($this->parties[$leaderName])) {
            $party = $this->parties[$leaderName];
            foreach ($party->getMembers() as $member) {
                unset($this->playerPartyMap[$member]);
            }
            unset($this->parties[$leaderName]);
        }
    }
}
