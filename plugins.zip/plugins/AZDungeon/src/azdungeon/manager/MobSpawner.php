<?php

declare(strict_types=1);

namespace azdungeon\manager;

use azdungeon\model\DungeonSession;
use azboss\Main as AZBoss;
use azboss\entity\BossEntity;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\math\Vector3;
use pocketmine\entity\Location;

class MobSpawner {
    
    public static function spawnBoss(DungeonSession $session, Vector3 $center): void {
        $azboss = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZBoss");
        $azdungeon = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZDungeon");
        
        if (!$azboss instanceof AZBoss || $azdungeon === null) {
            return;
        }

        $config = new \pocketmine\utils\Config($azdungeon->getDataFolder() . "config.yml", \pocketmine\utils\Config::YAML);
        $dungeons = $config->get("dungeons", []);
        
        $dungeonId = $session->getDungeonId();
        $dungeonData = $dungeons[$dungeonId] ?? null;
        
        if ($dungeonData === null) {
            return;
        }

        $stage = $session->getStage();
        $stageData = $dungeonData['stages'][$stage] ?? null;

        if ($stageData === null) {
            $azdungeon->getLogger()->warning("Không tìm thấy cấu hình cho ải $stage của phó bản $dungeonId!");
            return;
        }

        $bossId = $stageData['boss_id'] ?? "default";
        $bossData = $azboss->getBossManager()->getBossData($bossId);
        
        // Tạo Boss bằng factory BossEntity::create để sinh đúng subclass tương ứng
        if ($bossData !== null) {
            $nbt = CompoundTag::create()->setString("BossID", $bossId)->setByte("IsDungeonBoss", 1);
            $loc = new Location($center->x, $center->y + 1, $center->z, $session->getWorld(), 0, 0); 
            
            $boss = BossEntity::create($loc, $nbt);
            $boss->spawnToAll();
            
            $session->setBossEntityId($boss->getId());
        } else {
            $azdungeon->getLogger()->warning("Boss ID $bossId không tồn tại trong AZBoss! Đã bỏ qua bước sinh Boss.");
        }
        
        // Sinh lính cản đường (AZVanillaMobs)
        if (isset($stageData['minions']) && is_array($stageData['minions'])) {
            foreach ($stageData['minions'] as $minionData) {
                $class = $minionData['class'] ?? null;
                $count = $minionData['count'] ?? 1;
                
                // Tăng nhẹ số lượng quái theo stage để tăng độ khó nếu muốn, 
                // nhưng hiện tại ta có thể dùng trực tiếp config vì config mỗi stage đã có.
                
                if ($class !== null && class_exists($class)) {
                    for ($i = 0; $i < $count; $i++) {
                        $rx = $center->x + mt_rand(-8, 8);
                        $rz = $center->z + mt_rand(-8, 8);
                        $mloc = new Location($rx, $center->y + 1, $rz, $session->getWorld(), 0, 0);
                        try {
                            // Cố gắng khởi tạo class quái vật
                            $minion = new $class($mloc);
                            if ($minion instanceof \pocketmine\entity\Entity) {
                                $minion->spawnToAll();
                            }
                        } catch (\Throwable $e) {
                            $azdungeon->getLogger()->error("Lỗi khi spawn lính $class: " . $e->getMessage());
                        }
                    }
                }
            }
        }
    }
}
