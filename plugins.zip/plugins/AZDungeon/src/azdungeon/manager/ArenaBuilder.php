<?php

declare(strict_types=1);

namespace azdungeon\manager;

use pocketmine\world\World;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;

class ArenaBuilder {
    
    public static function build(World $world, Vector3 $center, int $radius): void {
        $floorBlock = VanillaBlocks::STONE_BRICKS();
        $wallBlock = VanillaBlocks::OBSIDIAN();
        $pillarBlock = VanillaBlocks::CHISELED_STONE_BRICKS();
        $lightBlock = VanillaBlocks::SEA_LANTERN();
        
        $minX = $center->getFloorX() - $radius;
        $maxX = $center->getFloorX() + $radius;
        $minZ = $center->getFloorZ() - $radius;
        $maxZ = $center->getFloorZ() + $radius;
        
        $y = $center->getFloorY();
        $height = 15;
        
        for ($x = $minX; $x <= $maxX; $x++) {
            for ($z = $minZ; $z <= $maxZ; $z++) {
                // Sàn
                if (($x - $center->getFloorX()) % 5 === 0 && ($z - $center->getFloorZ()) % 5 === 0) {
                    $world->setBlockAt($x, $y - 1, $z, $lightBlock);
                } else {
                    $world->setBlockAt($x, $y - 1, $z, $floorBlock);
                }
                
                // Trần
                $world->setBlockAt($x, $y + $height, $z, $wallBlock); // Đổi trần thành obsidian cho tối
                
                // Tường
                if ($x === $minX || $x === $maxX || $z === $minZ || $z === $maxZ) {
                    for ($hy = 0; $hy < $height; $hy++) {
                        $world->setBlockAt($x, $y + $hy, $z, $wallBlock);
                    }
                } else {
                    // Dọn dẹp khoảng trống bên trong
                    for ($hy = 0; $hy < $height; $hy++) {
                        $world->setBlockAt($x, $y + $hy, $z, VanillaBlocks::AIR());
                    }
                }
            }
        }
        
        // Thêm 4 cột trang trí ở 4 góc
        $cornerOffset = $radius - 5;
        if ($cornerOffset > 0) {
            $corners = [
                [$center->getFloorX() - $cornerOffset, $center->getFloorZ() - $cornerOffset],
                [$center->getFloorX() + $cornerOffset, $center->getFloorZ() - $cornerOffset],
                [$center->getFloorX() - $cornerOffset, $center->getFloorZ() + $cornerOffset],
                [$center->getFloorX() + $cornerOffset, $center->getFloorZ() + $cornerOffset],
            ];
            
            foreach ($corners as [$cx, $cz]) {
                for ($hy = 0; $hy < $height; $hy++) {
                    $world->setBlockAt($cx, $y + $hy, $cz, $pillarBlock);
                }
            }
        }
    }
}
