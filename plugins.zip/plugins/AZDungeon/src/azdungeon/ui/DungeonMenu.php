<?php

declare(strict_types=1);

namespace azdungeon\ui;

use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use azdungeon\Main;

class DungeonMenu {

    public static function open(Player $player): void {
        $party = Main::getInstance()->getPartyManager()->getParty($player->getName());

        if ($party === null || $party->getLeader() !== $player->getName()) {
            $player->sendMessage("§cChỉ trưởng nhóm mới có thể mở menu phó bản!");
            return;
        }

        $config = new \pocketmine\utils\Config(Main::getInstance()->getDataFolder() . "config.yml", \pocketmine\utils\Config::YAML);
        $dungeons = $config->get("dungeons", []);

        if (empty($dungeons)) {
            $player->sendMessage("§cHiện tại chưa có cấu hình Phó bản nào trong máy chủ.");
            return;
        }

        $options = [];
        $dungeonIds = [];
        foreach ($dungeons as $id => $data) {
            $iconPath = $data['icon'] ?? "textures/ui/icon_recipe_equipment";
            // Lọc bỏ mã màu (ví dụ §c, §a) từ config để ép thành màu đen §0
            $cleanName = preg_replace("/§[0-9a-fk-or]/i", "", $data['name'] ?? $id);
            $options[] = new MenuOption("§0⚡ §l§0" . $cleanName . " §r§0⚡", new FormIcon($iconPath, FormIcon::IMAGE_TYPE_PATH));
            $dungeonIds[] = $id;
        }

        $form = new MenuForm(
            "§l§0⚡ §0CHỌN PHÓ BẢN §0⚡",
            "§7Chọn một phó bản để xem thông tin chi tiết:",
            $options,
            function(Player $submitter, int $selected) use ($dungeonIds, $dungeons, $party): void {
                $dungeonId = $dungeonIds[$selected] ?? null;
                if ($dungeonId !== null) {
                    self::openPreview($submitter, $dungeonId, $dungeons[$dungeonId], $party);
                }
            }
        );
        $player->sendForm($form);
    }

    private static function openPreview(Player $player, string $dungeonId, array $dungeonData, $party): void {
        $name = $dungeonData['name'] ?? $dungeonId;
        
        $entryFee = (int)($dungeonData['entry_fee'] ?? 0);
        $rewards = $dungeonData['rewards'] ?? [];
        
        $moneyReward = isset($rewards['money']) ? number_format((int)$rewards['money']) . " Xu" : "Không có";
        $coinReward = isset($rewards['coin']) ? number_format((int)$rewards['coin']) . " Coin" : "Không có";
        $hasCommand = isset($rewards['commands']) ? "§aCó phần thưởng đặc biệt cho Trưởng nhóm" : "§cKhông có";

        $minionsCount = 0;
        $bossList = [];
        if (isset($dungeonData['stages']) && is_array($dungeonData['stages'])) {
            foreach ($dungeonData['stages'] as $s => $stageData) {
                if (isset($stageData['minions']) && is_array($stageData['minions'])) {
                    foreach ($stageData['minions'] as $m) {
                        $minionsCount += (int)($m['count'] ?? 1);
                    }
                }
                if (isset($stageData['boss_id'])) {
                    $bossList[] = $stageData['boss_id'];
                }
            }
        }
        
        $bossId = implode(", ", array_unique($bossList));
        if (empty($bossId)) $bossId = "Chưa rõ";

        $content = "§l§cTHÔNG TIN PHÓ BẢN: §r$name\n\n";
        $content .= "§f- Kẻ địch chính: §c$bossId\n";
        $content .= "§f- Tổng lính cản đường: §e$minionsCount quái vật\n";
        $content .= "§f- Phí vào cửa: §e" . number_format($entryFee) . " Xu\n\n";
        
        $content .= "§l§aPHẦN THƯỞNG (Chia đều cho người sống):\n";
        $content .= "§f- Tiền Xu: §e$moneyReward\n";
        $content .= "§f- Coin Nạp: §e$coinReward\n";
        $content .= "§f- Khác: $hasCommand\n";

        $options = [
            new MenuOption("§0⚡ §l§0ĐỒNG Ý VÀO CỬA §r§0⚡", new FormIcon("textures/ui/confirm", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §l§0QUAY LẠI §r§0⚡", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§0⚡ §0XÁC NHẬN PHÓ BẢN §0⚡",
            $content,
            $options,
            function(Player $submitter, int $selected) use ($dungeonId, $dungeonData, $party, $entryFee): void {
                if ($selected === 0) {
                    // Check daily limit for all party members
                    $dm = Main::getInstance()->getDungeonManager();
                    $blocked = [];
                    foreach ($party->getMembers() as $memberName) {
                        if ($dm->hasEnteredToday($memberName)) {
                            $blocked[] = $memberName;
                        }
                    }
                    if (!empty($blocked)) {
                        $submitter->sendMessage("§cCác thành viên sau đã đi phó bản hôm nay rồi: §e" . implode(", ", $blocked));
                        $submitter->sendMessage("§cMỗi người chỉ được vào phó bản §e1 lần/ngày§c!");
                        return;
                    }

                    if ($entryFee > 0) {
                        $azeco = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin("AZEconomy");
                        if ($azeco !== null && method_exists($azeco, "getMoney") && method_exists($azeco, "reduceMoney")) {
                            $currentMoney = $azeco->getMoney($submitter->getName());
                            if ($currentMoney < $entryFee) {
                                $submitter->sendMessage("§cBạn không có đủ " . number_format($entryFee) . " Xu để bắt đầu phó bản này!");
                                return;
                            }
                            $azeco->reduceMoney($submitter->getName(), $entryFee);
                            $submitter->sendMessage("§aBạn đã trả §e" . number_format($entryFee) . " Xu §ađể mở phó bản!");
                        }
                    }

                    Main::getInstance()->getDungeonManager()->startDungeon($party, $dungeonId, 1);
                } else {
                    self::open($submitter);
                }
            }
        );
        $player->sendForm($form);
    }
}
