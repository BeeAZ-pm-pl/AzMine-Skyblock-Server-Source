<?php

declare(strict_types=1);

namespace azdungeon\ui;

use pocketmine\player\Player;
use pocketmine\Server;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Dropdown;
use azdungeon\Main;

class PartyMenu {

    public static function open(Player $player): void {
        $party = Main::getInstance()->getPartyManager()->getParty($player->getName());

        if ($party === null) {
            $form = new MenuForm(
                "§l§dPARTY MENU",
                "§7Bạn chưa có tổ đội nào.",
                [
                    new MenuOption("§0⚡ §l§0Tạo Tổ Đội §r§0⚡"),
                    new MenuOption("§0⚡ §l§0Đóng §r§0⚡")
                ],
                function(Player $submitter, int $selected): void {
                    if ($selected === 0) {
                        Main::getInstance()->getPartyManager()->createParty($submitter->getName());
                        $submitter->sendMessage("§aBạn đã tạo một tổ đội mới!");
                        self::open($submitter);
                    }
                }
            );
            $player->sendForm($form);
        } else {
            $isLeader = $party->getLeader() === $player->getName();
            $members = implode("\n§f- ", $party->getMembers());

            $options = [];
            if ($isLeader) {
                $options[] = new MenuOption("§0⚡ §l§0Mời Người Chơi §r§0⚡");
                $options[] = new MenuOption("§0⚡ §l§0Bắt Đầu Phó Bản §r§0⚡");
                $options[] = new MenuOption("§0⚡ §l§0Giải Tán Tổ Đội §r§0⚡");
            } else {
                $options[] = new MenuOption("§0⚡ §l§0Rời Tổ Đội §r§0⚡");
            }

            $form = new MenuForm(
                "§l§dPARTY CỦA BẠN",
                "§eTrưởng Nhóm: §f" . $party->getLeader() . "\n§eThành viên:\n§f- " . $members,
                $options,
                function(Player $submitter, int $selected) use ($isLeader, $party): void {
                    if ($isLeader) {
                        if ($selected === 0) {
                            self::openInviteForm($submitter);
                        } elseif ($selected === 1) {
                            DungeonMenu::open($submitter);
                        } elseif ($selected === 2) {
                            Main::getInstance()->getPartyManager()->disbandParty($submitter->getName());
                            $submitter->sendMessage("§cBạn đã giải tán tổ đội!");
                        }
                    } else {
                        if ($selected === 0) {
                            Main::getInstance()->getPartyManager()->leaveParty($submitter->getName());
                            $submitter->sendMessage("§cBạn đã rời tổ đội!");
                        }
                    }
                }
            );
            $player->sendForm($form);
        }
    }

    private static function openInviteForm(Player $player): void {
        $onlinePlayers = [];
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if ($p->getName() !== $player->getName()) {
                $onlinePlayers[] = $p->getName();
            }
        }

        if (empty($onlinePlayers)) {
            $player->sendMessage("§cKhông có người chơi khác đang online để mời!");
            return;
        }

        $form = new CustomForm(
            "§l§dMỜI VÀO PARTY",
            [
                new Dropdown("player_name", "Chọn người chơi muốn mời:", $onlinePlayers)
            ],
            function(Player $submitter, CustomFormResponse $response) use ($onlinePlayers): void {
                $selectedIndex = $response->getInt("player_name");
                $targetName = $onlinePlayers[$selectedIndex] ?? null;
                if ($targetName === null) {
                    return;
                }
                $target = Server::getInstance()->getPlayerExact($targetName);
                
                if ($target === null) {
                    $submitter->sendMessage("§cNgười chơi không online hoặc không tồn tại!");
                    return;
                }
                
                if ($target->getName() === $submitter->getName()) {
                    $submitter->sendMessage("§cBạn không thể tự mời chính mình!");
                    return;
                }

                Main::getInstance()->getPartyManager()->invite($submitter->getName(), $target->getName());
                $submitter->sendMessage("§aĐã gửi lời mời party đến §e" . $target->getName());
                $target->sendMessage("§aBạn nhận được lời mời party từ §e" . $submitter->getName() . "§a. Dùng lệnh §e/party accept§a để đồng ý.");
            }
        );
        $player->sendForm($form);
    }
}
