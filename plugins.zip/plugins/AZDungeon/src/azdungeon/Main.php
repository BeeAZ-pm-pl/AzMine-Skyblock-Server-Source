<?php

declare(strict_types=1);

namespace azdungeon;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use azdungeon\manager\PartyManager;
use azdungeon\manager\DungeonManager;
use azdungeon\command\DungeonCommand;
use azdungeon\listener\EventListener;

class Main extends PluginBase {
    use SingletonTrait;

    private PartyManager $partyManager;
    private DungeonManager $dungeonManager;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveResource("config.yml");
        $this->cleanupLeftoverWorlds();

        $this->partyManager = new PartyManager();
        $this->dungeonManager = new DungeonManager($this);

        $this->getServer()->getCommandMap()->register("azdungeon", new DungeonCommand());
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);

        $this->getLogger()->info("§aAZDungeon đã được bật!");
    }

    public function getPartyManager(): PartyManager {
        return $this->partyManager;
    }

    public function getDungeonManager(): DungeonManager {
        return $this->dungeonManager;
    }

    private function cleanupLeftoverWorlds(): void {
        $worldsDir = $this->getServer()->getDataPath() . "worlds/";
        if (!is_dir($worldsDir)) return;
        
        $count = 0;
        foreach (scandir($worldsDir) as $folder) {
            if (strpos($folder, "dungeon_") === 0) {
                $worldPath = $worldsDir . $folder;
                if ($this->getServer()->getWorldManager()->isWorldLoaded($folder)) {
                    continue; // Skip loaded worlds just in case
                }
                $this->deleteDirectory($worldPath);
                $count++;
            }
        }
        
        if ($count > 0) {
            $this->getLogger()->info("§aĐã dọn dẹp $count thư mục phó bản còn sót lại!");
        }
    }

    private function deleteDirectory(string $dir): void {
        if (!is_dir($dir)) return;
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = "$dir/$file";
            is_dir($path) ? $this->deleteDirectory($path) : @unlink($path);
        }
        @rmdir($dir);
    }
}
