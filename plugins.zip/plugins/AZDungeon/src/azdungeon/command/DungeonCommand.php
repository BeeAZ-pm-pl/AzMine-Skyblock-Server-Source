<?php

declare(strict_types=1);

namespace azdungeon\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use azdungeon\Main;
use azdungeon\ui\PartyMenu;
use azdungeon\ui\DungeonMenu;

class DungeonCommand extends Command {

    public function __construct() {
        parent::__construct("azdungeon", "Quản lý phó bản và tổ đội", "/dungeon or /party", ["dungeon", "party"]);
        $this->setPermission("azdungeon.cmd");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cChỉ người chơi mới có thể dùng lệnh này.");
            return;
        }

        if (isset($args[0]) && strtolower($args[0]) === "reload") {
            if ($sender->hasPermission("azdungeon.admin") || $sender->getServer()->isOp($sender->getName())) {
                Main::getInstance()->reloadConfig();
                $sender->sendMessage("§aĐã tải lại cấu hình AZDungeon thành công!");
                return;
            } else {
                $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này.");
                return;
            }
        }

        if (isset($args[0]) && strtolower($args[0]) === "givemap") {
            if ($sender->hasPermission("azdungeon.admin") || $sender->getServer()->isOp($sender->getName())) {
                $targetName = $args[1] ?? $sender->getName();
                $target = $sender->getServer()->getPlayerExact($targetName);
                if ($target !== null) {
                    $item = \pocketmine\item\VanillaItems::PAPER();
                    $item->setCustomName("§l§eBản Đồ Phó Bản\n§r§7Chuột phải để mở Menu Phó Bản");
                    $target->getInventory()->addItem($item);
                    $sender->sendMessage("§aĐã đưa Bản Đồ Phó Bản cho " . $target->getName());
                } else {
                    $sender->sendMessage("§cKhông tìm thấy người chơi.");
                }
                return;
            }
        }

        if (isset($args[0]) && strtolower($args[0]) === "accept") {
            $inviter = Main::getInstance()->getPartyManager()->getInvite($sender->getName());
            if ($inviter !== null) {
                $party = Main::getInstance()->getPartyManager()->getParty($inviter);
                if ($party !== null) {
                    Main::getInstance()->getPartyManager()->joinParty($sender->getName(), $inviter);
                    $sender->sendMessage("§aBạn đã gia nhập tổ đội của §e" . $inviter);
                    $partyLeader = \pocketmine\Server::getInstance()->getPlayerExact($inviter);
                    if ($partyLeader !== null) {
                        $partyLeader->sendMessage("§aNgười chơi §e" . $sender->getName() . " §ađã gia nhập tổ đội!");
                    }
                } else {
                    $sender->sendMessage("§cTổ đội này đã bị giải tán hoặc không còn tồn tại.");
                }
                Main::getInstance()->getPartyManager()->clearInvite($sender->getName());
            } else {
                $sender->sendMessage("§cBạn không có lời mời party nào.");
            }
            return;
        }

        if ($commandLabel === "dungeon") {
            DungeonMenu::open($sender);
        } else {
            PartyMenu::open($sender);
        }
    }
}
