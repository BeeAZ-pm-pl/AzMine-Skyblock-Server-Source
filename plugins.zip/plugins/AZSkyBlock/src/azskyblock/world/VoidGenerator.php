<?php

namespace azskyblock\world;

use pocketmine\world\generator\Generator;
use pocketmine\world\ChunkManager;

class VoidGenerator extends Generator {
    public function __construct(int $seed, string $preset) {
        parent::__construct($seed, $preset);
    }

    public function generateChunk(ChunkManager $world, int $chunkX, int $chunkZ): void {}

    public function populateChunk(ChunkManager $world, int $chunkX, int $chunkZ): void {}
}