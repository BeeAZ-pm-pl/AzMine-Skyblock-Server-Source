<?php

declare(strict_types=1);

namespace azskyblock\task;

use pocketmine\scheduler\AsyncTask;

class SkyBlockDeleteTask extends AsyncTask {
    public function __construct(
        private string $dbPath,
        private string $id,
        private int $x,
        private int $z
    ) {}

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $stmt = $db->prepare("INSERT INTO deleted_islands (x, z) VALUES (:x, :z)");
        $stmt->bindValue(":x", $this->x, SQLITE3_INTEGER);
        $stmt->bindValue(":z", $this->z, SQLITE3_INTEGER);
        $stmt->execute();
        
        $stmt = $db->prepare("DELETE FROM islands WHERE id = :id");
        $stmt->bindValue(":id", $this->id, SQLITE3_TEXT);
        $stmt->execute();
        
        $db->close();
    }
}
