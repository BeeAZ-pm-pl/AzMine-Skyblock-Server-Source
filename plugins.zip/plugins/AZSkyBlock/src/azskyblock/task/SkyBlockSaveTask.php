<?php

declare(strict_types=1);

namespace azskyblock\task;

use pocketmine\scheduler\AsyncTask;

class SkyBlockSaveTask extends AsyncTask {
    public function __construct(
        private string $dbPath,
        private string $dataJson
    ) {}

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $data = json_decode($this->dataJson, true);
        if (!is_array($data)) return;

        $stmt = $db->prepare("INSERT OR REPLACE INTO islands (id, owner, x, y, z, world, members, level, border, pvp, locked, warp_x, warp_y, warp_z, points) VALUES (:id, :owner, :x, :y, :z, :world, :members, :level, :border, :pvp, :locked, :wx, :wy, :wz, :points)");
        $stmt->bindValue(":id", $data['id'], SQLITE3_TEXT);
        $stmt->bindValue(":owner", $data['owner'], SQLITE3_TEXT);
        $stmt->bindValue(":x", $data['x'], SQLITE3_INTEGER);
        $stmt->bindValue(":y", $data['y'], SQLITE3_INTEGER);
        $stmt->bindValue(":z", $data['z'], SQLITE3_INTEGER);
        $stmt->bindValue(":world", $data['world'], SQLITE3_TEXT);
        $stmt->bindValue(":members", json_encode($data['members']), SQLITE3_TEXT);
        $stmt->bindValue(":level", $data['level'], SQLITE3_INTEGER);
        $stmt->bindValue(":border", $data['border'], SQLITE3_INTEGER);
        $stmt->bindValue(":pvp", $data['pvp'], SQLITE3_INTEGER);
        $stmt->bindValue(":locked", $data['locked'], SQLITE3_INTEGER);
        $stmt->bindValue(":wx", $data['warp_x'], SQLITE3_INTEGER);
        $stmt->bindValue(":wy", $data['warp_y'], SQLITE3_INTEGER);
        $stmt->bindValue(":wz", $data['warp_z'], SQLITE3_INTEGER);
        $stmt->bindValue(":points", $data['points'], SQLITE3_INTEGER);
        $stmt->execute();
        
        $db->close();
    }
}
