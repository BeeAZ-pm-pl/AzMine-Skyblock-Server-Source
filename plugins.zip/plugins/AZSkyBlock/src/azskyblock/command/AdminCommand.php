<?php

namespace azskyblock\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use azskyblock\Main;

class AdminCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("isa", "Admin Island", "/isa help");
        $this->setPermission("azskyblock.admin");
    }

    public function execute(CommandSender $sender, string $label, array $args): bool {
        if (!$sender instanceof Player || !$this->testPermission($sender)) return false;
        
        if (empty($args[0])) {
            $this->sendHelp($sender);
            return false;
        }

        switch ($args[0]) {
            case "pos1":
                $this->plugin->schema->pos1[$sender->getName()] = $sender->getPosition();
                $sender->sendMessage("Pos1 set.");
                break;
            case "pos2":
                $this->plugin->schema->pos2[$sender->getName()] = $sender->getPosition();
                $sender->sendMessage("Pos2 set.");
                break;
            case "setspawn":
            case "setspawnisland":
                $this->plugin->schema->spawn[$sender->getName()] = $sender->getPosition();
                $sender->sendMessage("Schema spawn set.");
                break;
            case "saveschema":
                if (isset($args[1])) {
                    if ($this->plugin->schema->saveSchema($args[1], $sender->getName())) {
                        $sender->sendMessage("Saved schema.");
                    } else {
                        $sender->sendMessage("Failed to save.");
                    }
                } else {
                    $sender->sendMessage("Usage: /isa saveschema <name>");
                }
                break;
            case "delete":
                if (isset($args[1])) {
                    $id = $this->plugin->island->getIslandByPlayer($args[1]);
                    if ($id) {
                        $this->plugin->island->deleteIsland($id);
                        $sender->sendMessage("Deleted.");
                    } else {
                        $sender->sendMessage("Player does not have an island.");
                    }
                } else {
                    $sender->sendMessage("Usage: /isa delete <player>");
                }
                break;
            case "help":
            default:
                $this->sendHelp($sender);
                break;
        }
        return true;
    }

    private function sendHelp(Player $sender): void {
        $sender->sendMessage("Admin SkyBlock Commands:");
        $sender->sendMessage("/isa pos1 - Set position 1");
        $sender->sendMessage("/isa pos2 - Set position 2");
        $sender->sendMessage("/isa setspawn - Set schema spawn point");
        $sender->sendMessage("/isa saveschema <name> - Save selected area as schema");
        $sender->sendMessage("/isa delete <player> - Delete a player's island");
    }
}