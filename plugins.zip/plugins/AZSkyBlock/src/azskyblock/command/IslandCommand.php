<?php

namespace azskyblock\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use azskyblock\Main;
use azskyblock\form\MenuFormUI;

class IslandCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("is", "Island command", "/is", ["island","sb", "skyblock"]);
        $this->setPermission("azskyblock.command.is");
    }

    public function execute(CommandSender $sender, string $label, array $args): bool {
        if (!$sender instanceof Player || !$this->testPermission($sender)) return false;
        MenuFormUI::send($sender, $this->plugin);
        return true;
    }
}