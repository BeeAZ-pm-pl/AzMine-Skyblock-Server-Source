<?php

namespace azskyblock;

use pocketmine\plugin\PluginBase;
use azskyblock\manager\DatabaseManager;
use azskyblock\manager\IslandManager;
use azskyblock\manager\SchemaManager;
use azskyblock\manager\BorderManager;
use azskyblock\manager\EconomyManager;
use azskyblock\manager\TopManager;
use azskyblock\listener\EventListener;
use azskyblock\command\IslandCommand;
use azskyblock\command\AdminCommand;
use azskyblock\world\VoidGenerator;
use pocketmine\utils\Config;
use pocketmine\world\generator\GeneratorManager;
use pocketmine\world\WorldCreationOptions;

class Main extends PluginBase {
    private static self $instance;
    public DatabaseManager $db;
    public IslandManager $island;
    public SchemaManager $schema;
    public BorderManager $border;
    public EconomyManager $eco;
    public TopManager $top;
    public Config $cfg;

    protected function onEnable(): void {
        self::$instance = $this;
        $this->saveResource("config.yml");
        $this->saveResource("schemas/normal.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        @mkdir($this->getDataFolder() . "schemas/");
        
        try {
            GeneratorManager::getInstance()->addGenerator(VoidGenerator::class, "az_void", fn() => null);
        } catch (\InvalidArgumentException $e) {
            $this->getLogger()->warning("Generator az_void đã tồn tại, bỏ qua đăng ký.");
        }
        
        $wm = $this->getServer()->getWorldManager();
        if (!$wm->isWorldGenerated("skyblock")) {
            $wm->generateWorld("skyblock", WorldCreationOptions::create()->setGeneratorClass(VoidGenerator::class));
        }
        if (!$wm->isWorldLoaded("skyblock")) {
            $wm->loadWorld("skyblock");
        }
        
        $this->db = new DatabaseManager($this);
        $this->island = new IslandManager($this);
        $this->schema = new SchemaManager($this);
        $this->border = new BorderManager($this);
        $this->eco = new EconomyManager($this);
        $this->top = new TopManager($this);

        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getServer()->getCommandMap()->register("azskyblock", new IslandCommand($this));
        $this->getServer()->getCommandMap()->register("azskyblock", new AdminCommand($this));
    }

    protected function onDisable(): void {
        if (isset($this->db)) {
            $this->db->saveAllSynchronously();
        }
    }

    public static function getInstance(): self {
        return self::$instance;
    }
}