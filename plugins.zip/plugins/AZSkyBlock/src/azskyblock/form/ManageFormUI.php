<?php

namespace azskyblock\form;

use azskyblock\Main;
use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Toggle;
use dktapps\pmforms\element\Label;

class ManageFormUI
{
    public static function send(Player $player, Main $plugin, string $islandId): void
    {
        $data = $plugin->db->cache[$islandId];
        $isOwner = strtolower($data['owner']) === strtolower($player->getName());

        $options = [
            new MenuOption("§0⚡ §lQuay Lại §r§0⚡\n§8Về menu chính", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lThêm Thành Viên §r§0⚡\n§8Mời bạn bè", new FormIcon("textures/ui/FriendsIcon", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lĐuổi Thành Viên §r§0⚡\n§8Xóa người chơi", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lCài Đặt Đảo §r§0⚡\n§8Khóa đảo, PvP", new FormIcon("textures/ui/gear", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lĐặt Điểm Dịch Chuyển §r§0⚡\n§8Setwarp tại đây", new FormIcon("textures/ui/icon_map", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lNâng Cấp Đảo §r§0⚡\n§8Mở rộng giới hạn", new FormIcon("textures/ui/anvil_icon", FormIcon::IMAGE_TYPE_PATH))
        ];

        $content = "§e⚡ §lQUẢN LÝ CHI TIẾT §r§e⚡\n\n§fQuyền hạn: " . ($isOwner ? "§aChủ Đảo" : "§eThành Viên") . "\n§fKích thước rào chắn: §a" . $data['border'] . "x" . $data['border'] . " Block\n§fTrạng thái khóa: " . ($data['locked'] ? "§cĐã khóa" : "§aMở") . "\n§fTrạng thái PvP: " . ($data['pvp'] ? "§cBật" : "§aTắt") . "\n\n§eChọn chức năng cần cấu hình:";

        $form = new MenuForm(
            "§0⚡ §lQUẢN LÝ ĐẢO §r§0⚡",
            $content,
            $options,
            function (Player $submitter, int $selected) use ($plugin, $islandId, $isOwner): void {
                if ($selected === 0) {
                    MenuFormUI::send($submitter, $plugin);
                    return;
                }

                if (!$isOwner && $selected !== 4) {
                    $submitter->sendMessage("§c⚡ §lChỉ chủ đảo mới có quyền thực hiện việc này!");
                    self::send($submitter, $plugin, $islandId);
                    return;
                }

                if ($selected === 1) self::sendAddMember($submitter, $plugin, $islandId);
                elseif ($selected === 2) self::sendKickMember($submitter, $plugin, $islandId);
                elseif ($selected === 3) self::sendSettings($submitter, $plugin, $islandId);
                elseif ($selected === 4) {
                    $pos = $submitter->getPosition();
                    $plugin->db->cache[$islandId]['warp_x'] = $pos->getX();
                    $plugin->db->cache[$islandId]['warp_y'] = $pos->getY();
                    $plugin->db->cache[$islandId]['warp_z'] = $pos->getZ();
                    $plugin->db->saveIsland($islandId);
                    $submitter->sendMessage("§a⚡ §lĐã đặt điểm dịch chuyển mới!");
                    self::send($submitter, $plugin, $islandId);
                } elseif ($selected === 5) self::sendUpgrade($submitter, $plugin, $islandId);
            },
            function (Player $submitter) use ($plugin): void {
                MenuFormUI::send($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendUpgrade(Player $player, Main $plugin, string $islandId): void
    {
        $data = $plugin->db->cache[$islandId];
        $baseCost = $plugin->cfg->getNested("upgrade.cost.base", 10000);
        $multiplier = $plugin->cfg->getNested("upgrade.cost.multiplier", 1.5);
        $maxBorder = $plugin->cfg->getNested("border.max", 400);

        if ($data['border'] >= $maxBorder) {
            $player->sendMessage("§c⚡ §lĐảo của bạn đã đạt cấp độ tối đa!");
            self::send($player, $plugin, $islandId);
            return;
        }

        $cost = $baseCost * pow($multiplier, $data['level'] - 1);

        $form = new CustomForm(
            "§0⚡ §lNÂNG CẤP ĐẢO §r§0⚡",
            [
                new Label("info", "§eCấp hiện tại: §f" . $data['level'] . "\n§eKích thước hiện tại: §f" . $data['border'] . "x" . $data['border'] . "\n§ePhí nâng cấp: §e" . number_format($cost) . " Coin\n\n§fNâng cấp sẽ mở rộng rào chắn thêm 20 block."),
                new Toggle("confirm", "§aXác nhận thanh toán và nâng cấp")
            ],
            function (Player $submitter, CustomFormResponse $response) use ($plugin, $islandId, $cost): void {
                if ($response->getBool("confirm")) {
                    if ($plugin->eco->reduceCoin($submitter->getName(), $cost)) {
                        $plugin->db->cache[$islandId]['level'] += 1;
                        $plugin->db->cache[$islandId]['border'] += 20;
                        $plugin->db->saveIsland($islandId);
                        $submitter->sendMessage("§a⚡ §lNâng cấp đảo thành công!");
                    } else {
                        $submitter->sendMessage("§c⚡ §lBạn không đủ Coin để nâng cấp đảo!");
                    }
                }
                self::send($submitter, $plugin, $islandId);
            },
            function (Player $submitter) use ($plugin, $islandId): void {
                self::send($submitter, $plugin, $islandId);
            }
        );
        $player->sendForm($form);
    }

    public static function sendAddMember(Player $player, Main $plugin, string $islandId): void
    {
        $form = new CustomForm(
            "§0⚡ §lTHÊM THÀNH VIÊN §r§0⚡",
            [new Input("player_name", "§eNhập tên người chơi muốn thêm:", "VD: Steve")],
            function (Player $submitter, CustomFormResponse $response) use ($plugin, $islandId): void {
                $name = $response->getString("player_name");
                if (!empty($name)) {
                    if (strtolower($name) === strtolower($submitter->getName())) {
                        $submitter->sendMessage("§c⚡ §lBạn không thể tự thêm chính mình!");
                    } elseif ($plugin->island->getIslandByPlayer($name) !== null) {
                        $submitter->sendMessage("§c⚡ §lNgười chơi này đã tham gia hoặc sở hữu một đảo khác rồi!");
                    } elseif ($plugin->island->addMember($islandId, $name)) {
                        $submitter->sendMessage("§a⚡ §lĐã thêm người chơi §f$name §ađảo của bạn!");
                    } else {
                        $submitter->sendMessage("§c⚡ §lNgười chơi này đã có trong danh sách!");
                    }
                }
                self::send($submitter, $plugin, $islandId);
            },
            function (Player $submitter) use ($plugin, $islandId): void {
                self::send($submitter, $plugin, $islandId);
            }
        );
        $player->sendForm($form);
    }

    public static function sendKickMember(Player $player, Main $plugin, string $islandId): void
    {
        $members = $plugin->db->cache[$islandId]['members'];
        if (empty($members)) {
            $player->sendMessage("§c⚡ §lĐảo của bạn chưa có thành viên nào để đuổi!");
            self::send($player, $plugin, $islandId);
            return;
        }

        $options = [];
        foreach ($members as $m) {
            $options[] = new MenuOption("§c⚡ §lĐuổi $m", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));
        }

        $form = new MenuForm(
            "§0⚡ §lĐUỔI THÀNH VIÊN §r§0⚡",
            "§eChọn thành viên mà bạn muốn đuổi khỏi đảo:",
            $options,
            function (Player $submitter, int $selected) use ($plugin, $islandId, $members): void {
                $name = $members[$selected];
                $plugin->island->removeMember($islandId, $name);
                $submitter->sendMessage("§a⚡ §lĐã thẳng tay đuổi §f$name §akhỏi đảo!");
                self::send($submitter, $plugin, $islandId);
            },
            function (Player $submitter) use ($plugin, $islandId): void {
                self::send($submitter, $plugin, $islandId);
            }
        );
        $player->sendForm($form);
    }

    public static function sendSettings(Player $player, Main $plugin, string $islandId): void
    {
        $data = $plugin->db->cache[$islandId];
        $form = new CustomForm(
            "§0⚡ §lCÀI ĐẶT ĐẢO §r§0⚡",
            [
                new Toggle("lock", "§eKhoá đảo (Chặn người lạ dịch chuyển đến)", (bool)$data['locked']),
                new Toggle("pvp", "§cCho phép bật PvP trên đảo", (bool)$data['pvp'])
            ],
            function (Player $submitter, CustomFormResponse $response) use ($plugin, $islandId): void {
                $plugin->db->cache[$islandId]['locked'] = $response->getBool("lock") ? 1 : 0;
                $plugin->db->cache[$islandId]['pvp'] = $response->getBool("pvp") ? 1 : 0;
                $plugin->db->saveIsland($islandId);
                $submitter->sendMessage("§a⚡ §lĐã lưu thành công các cài đặt cho đảo!");
                self::send($submitter, $plugin, $islandId);
            },
            function (Player $submitter) use ($plugin, $islandId): void {
                self::send($submitter, $plugin, $islandId);
            }
        );
        $player->sendForm($form);
    }
}
