<?php

namespace azskyblock\form;

use azskyblock\Main;
use pocketmine\player\Player;
use pocketmine\world\Position;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Input;

class MenuFormUI {
    public static function send(Player $player, Main $plugin): void {
        $ownedIsland = $plugin->island->getOwnedIsland($player->getName());
        $memberIslands = $plugin->island->getMemberIslands($player->getName());
        
        $options = [];
        $actions = [];
        
        if ($ownedIsland === null && empty($memberIslands)) {
            $content = "§fChào mừng §a" . $player->getName() . " §fđến với hệ thống SkyBlock!\n§eBạn chưa có đảo, hãy bắt đầu hành trình sinh tồn của mình ngay bây giờ.";
            
            $options[] = new MenuOption("§0⚡ §lTạo Đảo §r§0⚡\n§8Nhấn để bắt đầu", new FormIcon("textures/items/diamond_pickaxe", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = ['type' => 'create'];
        } else {
            $content = "§e⚡ §lTHÔNG TIN ĐẢO §r§e⚡\n\n";
            if ($ownedIsland !== null) {
                $level = $ownedIsland['level'] ?? 1;
                $points = $ownedIsland['points'] ?? 0;
                $members = count($ownedIsland['members']);
                $content .= "§fChủ đảo: §a" . $ownedIsland['owner'] . "\n§fCấp độ: §a" . $level . "\n§fĐiểm đảo: §a" . $points . "\n§fThành viên: §a" . $members . "\n\n";
                
                $options[] = new MenuOption("§0⚡ §lVề Đảo §r§0⚡\n§8Dịch chuyển về đảo của bạn", new FormIcon("textures/items/bed_red", FormIcon::IMAGE_TYPE_PATH));
                $actions[] = ['type' => 'teleport', 'data' => $ownedIsland, 'msg' => '§a⚡ §lĐã dịch chuyển về đảo của bạn!'];
            }
            
            if (!empty($memberIslands)) {
                $content .= "§eBạn đang làm thành viên của: §f";
                $owners = [];
                foreach ($memberIslands as $mIsland) {
                    $owners[] = $mIsland['owner'];
                    
                    $options[] = new MenuOption("§0⚡ §lVề Đảo Thành Viên §r§0⚡\n§8Chủ đảo: " . $mIsland['owner'], new FormIcon("textures/items/bed_red", FormIcon::IMAGE_TYPE_PATH));
                    $actions[] = ['type' => 'teleport', 'data' => $mIsland, 'msg' => '§a⚡ §lĐã dịch chuyển về đảo của ' . $mIsland['owner'] . '!'];
                }
                $content .= implode(", ", $owners) . "\n\n";
            }
            
            $content .= "§eChọn một thao tác bên dưới:";
        }

        $options[] = new MenuOption("§0⚡ §lGhé Thăm §r§0⚡\n§8Thăm đảo người khác", new FormIcon("textures/items/ender_eye", FormIcon::IMAGE_TYPE_PATH));
        $actions[] = ['type' => 'visit'];

        $manageIslandId = $ownedIsland !== null ? $ownedIsland['id'] : (!empty($memberIslands) ? $memberIslands[0]['id'] : null);
        if ($manageIslandId !== null) {
            $options[] = new MenuOption("§0⚡ §lQuản Lý §r§0⚡\n§8Cài đặt & Nâng cấp", new FormIcon("textures/items/comparator", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = ['type' => 'manage', 'id' => $manageIslandId];
        }

        $options[] = new MenuOption("§0⚡ §lTop Đảo §r§0⚡\n§8Bảng xếp hạng", new FormIcon("textures/items/nether_star", FormIcon::IMAGE_TYPE_PATH));
        $actions[] = ['type' => 'top'];

        $form = new MenuForm(
            "§0⚡ §lSkyBlock §r§0⚡",
            $content,
            $options,
            function(Player $submitter, int $selected) use ($plugin, $actions): void {
                $action = $actions[$selected] ?? null;
                if ($action === null) return;
                
                switch ($action['type']) {
                    case 'create':
                        self::sendSelectSchema($submitter, $plugin);
                        break;
                    case 'teleport':
                        $data = $action['data'];
                        $world = $plugin->getServer()->getWorldManager()->getWorldByName($data['world']);
                        if ($world !== null) {
                            $submitter->teleport(new Position($data['warp_x'], $data['warp_y'], $data['warp_z'], $world));
                            $submitter->sendMessage($action['msg']);
                        } else {
                            $submitter->sendMessage("§c⚡ §lThế giới đảo không khả dụng!");
                        }
                        break;
                    case 'visit':
                        self::sendVisitForm($submitter, $plugin);
                        break;
                    case 'manage':
                        ManageFormUI::send($submitter, $plugin, $action['id']);
                        break;
                    case 'top':
                        self::sendTop($submitter, $plugin);
                        break;
                }
            }
        );
        $player->sendForm($form);
    }

    public static function sendSelectSchema(Player $player, Main $plugin): void {
        $schemas = $plugin->schema->getSchemasInfo();
        $options = [];
        $schemaKeys = [];
        
        foreach ($schemas as $key => $info) {
            $icon = null;
            if (!empty($info['icon'])) {
                $icon = new FormIcon($info['icon'], FormIcon::IMAGE_TYPE_PATH);
            }
            $options[] = new MenuOption($info['name'] . "\n" . $info['description'], $icon);
            $schemaKeys[] = $key;
        }
        
        $form = new MenuForm(
            "§0⚡ §lCHỌN MẪU ĐẢO §r§0⚡",
            "§eHãy chọn một mẫu đảo để bắt đầu hành trình của bạn:",
            $options,
            function(Player $submitter, int $selected) use ($plugin, $schemaKeys): void {
                $schema = $schemaKeys[$selected];
                $plugin->island->createIsland($submitter, $schema);
            },
            function(Player $submitter) use ($plugin): void {
                self::send($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendTop(Player $player, Main $plugin): void {
        $tops = $plugin->top->getTopIslands(10);
        $content = "§eBảng xếp hạng điểm đảo máy chủ:\n\n";
        $i = 1;
        foreach ($tops as $owner => $points) {
            $content .= "§fTop $i. §a$owner §f- §e$points Điểm\n";
            $i++;
        }
        
        $form = new CustomForm(
            "§0⚡ §lTOP ĐẢO §r§0⚡",
            [new Label("top_label", $content)],
            function(Player $submitter, \dktapps\pmforms\CustomFormResponse $response) use ($plugin): void {
                self::send($submitter, $plugin);
            },
            function(Player $submitter) use ($plugin): void {
                self::send($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendVisitForm(Player $player, Main $plugin): void {
        $form = new CustomForm(
            "§0⚡ §lGHÉ THĂM ĐẢO §r§0⚡",
            [
                new Input("target_player", "§eNhập tên chủ đảo bạn muốn ghé thăm:", "VD: Steve")
            ],
            function(Player $submitter, \dktapps\pmforms\CustomFormResponse $response) use ($plugin): void {
                $targetName = trim($response->getString("target_player"));
                if (empty($targetName)) {
                    $submitter->sendMessage("§c⚡ §lTên người chơi không được để trống!");
                    self::send($submitter, $plugin);
                    return;
                }

                $targetIslandId = null;
                $targetData = null;
                foreach ($plugin->db->cache as $id => $data) {
                    if (strtolower($data['owner']) === strtolower($targetName)) {
                        $targetIslandId = $id;
                        $targetData = $data;
                        break;
                    }
                }

                if ($targetIslandId === null || $targetData === null) {
                    $submitter->sendMessage("§c⚡ §lKhông tìm thấy đảo của người chơi §f" . $targetName . "§c!");
                    self::send($submitter, $plugin);
                    return;
                }

                if ($targetData['locked'] && !$plugin->island->isMember($targetIslandId, $submitter->getName()) && !$submitter->getServer()->isOp($submitter->getName())) {
                    $submitter->sendMessage("§c⚡ §lĐảo của §f" . $targetData['owner'] . " §chiện đang khóa, không thể ghé thăm!");
                    self::send($submitter, $plugin);
                    return;
                }

                $world = $plugin->getServer()->getWorldManager()->getWorldByName($targetData['world']);
                if ($world !== null) {
                    $submitter->teleport(new Position($targetData['warp_x'], $targetData['warp_y'], $targetData['warp_z'], $world));
                    $submitter->sendMessage("§a⚡ §lĐã dịch chuyển đến đảo của §f" . $targetData['owner'] . "§a!");
                } else {
                    $submitter->sendMessage("§c⚡ §lThế giới đảo không khả dụng!");
                }
            },
            function(Player $submitter) use ($plugin): void {
                self::send($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }
}