<?php

namespace azskyblock\utils;

use pocketmine\utils\Config;

class Utils {

    public static function saveYaml(string $path, array $data): void {
        $config = new Config($path, Config::YAML);
        $config->setAll($data);
        $config->save();
    }

    public static function parseYaml(string $path): array {
        if (!\file_exists($path)) return [];
        $config = new Config($path, Config::YAML);
        return $config->getAll();
    }

    public static function formatMoney(int $amount): string {
        return number_format($amount) . " $";
    }
}