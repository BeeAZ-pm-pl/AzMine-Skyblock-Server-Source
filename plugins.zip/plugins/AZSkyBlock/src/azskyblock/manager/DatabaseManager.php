<?php

namespace azskyblock\manager;

use azskyblock\Main;
use azskyblock\task\SkyBlockSaveTask;
use azskyblock\task\SkyBlockDeleteTask;

class DatabaseManager {
    private \SQLite3 $db;
    public array $cache = [];
    public array $deleted = [];

    public function __construct(private Main $plugin) {
        $this->db = new \SQLite3($plugin->getDataFolder() . "skyblock.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS islands (id TEXT PRIMARY KEY, owner TEXT, x INT, y INT, z INT, world TEXT, members TEXT, level INT, border INT, pvp INT, locked INT, warp_x INT, warp_y INT, warp_z INT, points INT)");
        $this->db->exec("CREATE TABLE IF NOT EXISTS deleted_islands (x INT, z INT)");
        $this->loadAll();
    }

    private function loadAll(): void {
        $res = $this->db->query("SELECT * FROM islands");
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $row['members'] = json_decode($row['members'], true);
            $row['x'] = (int)$row['x'];
            $row['y'] = (int)$row['y'];
            $row['z'] = (int)$row['z'];
            $row['level'] = (int)$row['level'];
            $row['border'] = (int)$row['border'];
            $row['pvp'] = (int)$row['pvp'];
            $row['locked'] = (int)$row['locked'];
            $row['warp_x'] = (int)$row['warp_x'];
            $row['warp_y'] = (int)$row['warp_y'];
            $row['warp_z'] = (int)$row['warp_z'];
            $row['points'] = (int)$row['points'];
            $this->cache[$row['id']] = $row;
        }
        $res = $this->db->query("SELECT * FROM deleted_islands");
        while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
            $this->deleted[] = ["x" => (int)$row['x'], "z" => (int)$row['z']];
        }
    }

    public function saveIsland(string $id): void {
        if (!isset($this->cache[$id])) return;
        $d = $this->cache[$id];
        
        $this->plugin->getServer()->getAsyncPool()->submitTask(new SkyBlockSaveTask(
            $this->plugin->getDataFolder() . "skyblock.db",
            json_encode($d)
        ));
    }

    public function deleteIsland(string $id): void {
        if (!isset($this->cache[$id])) return;
        $d = $this->cache[$id];
        
        $this->plugin->getServer()->getAsyncPool()->submitTask(new SkyBlockDeleteTask(
            $this->plugin->getDataFolder() . "skyblock.db",
            $id,
            (int)$d['x'],
            (int)$d['z']
        ));
        
        $this->deleted[] = ["x" => $d['x'], "z" => $d['z']];
        unset($this->cache[$id]);
    }

    public function saveAllSynchronously(): void {
        foreach ($this->cache as $id => $d) {
            $stmt = $this->db->prepare("INSERT OR REPLACE INTO islands (id, owner, x, y, z, world, members, level, border, pvp, locked, warp_x, warp_y, warp_z, points) VALUES (:id, :owner, :x, :y, :z, :world, :members, :level, :border, :pvp, :locked, :wx, :wy, :wz, :points)");
            $stmt->bindValue(":id", $d['id'], SQLITE3_TEXT);
            $stmt->bindValue(":owner", $d['owner'], SQLITE3_TEXT);
            $stmt->bindValue(":x", $d['x'], SQLITE3_INTEGER);
            $stmt->bindValue(":y", $d['y'], SQLITE3_INTEGER);
            $stmt->bindValue(":z", $d['z'], SQLITE3_INTEGER);
            $stmt->bindValue(":world", $d['world'], SQLITE3_TEXT);
            $stmt->bindValue(":members", json_encode($d['members']), SQLITE3_TEXT);
            $stmt->bindValue(":level", $d['level'], SQLITE3_INTEGER);
            $stmt->bindValue(":border", $d['border'], SQLITE3_INTEGER);
            $stmt->bindValue(":pvp", $d['pvp'], SQLITE3_INTEGER);
            $stmt->bindValue(":locked", $d['locked'], SQLITE3_INTEGER);
            $stmt->bindValue(":wx", $d['warp_x'], SQLITE3_INTEGER);
            $stmt->bindValue(":wy", $d['warp_y'], SQLITE3_INTEGER);
            $stmt->bindValue(":wz", $d['warp_z'], SQLITE3_INTEGER);
            $stmt->bindValue(":points", $d['points'], SQLITE3_INTEGER);
            $stmt->execute();
        }
    }
}