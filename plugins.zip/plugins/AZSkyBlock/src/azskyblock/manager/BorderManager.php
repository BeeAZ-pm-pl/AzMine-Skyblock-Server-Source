<?php

namespace azskyblock\manager;

use azskyblock\Main;
use pocketmine\world\Position;

class BorderManager {
    public function __construct(private Main $plugin) {}

    public function getIslandAt(Position $pos): ?string {
        foreach ($this->plugin->db->cache as $id => $d) {
            if ($pos->getWorld()->getFolderName() !== $d['world']) continue;
            $b = $d['border'];
            if ($pos->getFloorX() >= $d['x'] - $b && $pos->getFloorX() <= $d['x'] + $b && $pos->getFloorZ() >= $d['z'] - $b && $pos->getFloorZ() <= $d['z'] + $b) return $id;
        }
        return null;
    }
}