<?php

namespace azskyblock\manager;

use azskyblock\Main;
use pocketmine\world\Position;
use pocketmine\item\StringToItemParser;
use pocketmine\block\VanillaBlocks;
use azskyblock\utils\Utils;

class SchemaManager {
    public array $pos1 = [];
    public array $pos2 = [];
    public array $spawn = [];

    public function __construct(private Main $plugin) {}

    public function getSchemasInfo(): array {
        $files = glob($this->plugin->getDataFolder() . "schemas/*.yml");
        $info = [];
        foreach ($files as $file) {
            $data = Utils::parseYaml($file);
            $filename = basename($file, ".yml");
            $info[$filename] = [
                "name" => $data['name'] ?? "§e⚡ Đảo " . ucfirst($filename),
                "description" => $data['description'] ?? "§8Không có mô tả",
                "icon" => $data['icon'] ?? ""
            ];
        }
        return $info;
    }

    public function saveSchema(string $name, string $player): bool {
        if (!isset($this->pos1[$player]) || !isset($this->pos2[$player])) return false;
        $p1 = $this->pos1[$player];
        $p2 = $this->pos2[$player];
        if ($p1->getWorld()->getFolderName() !== $p2->getWorld()->getFolderName()) return false;
        
        $w = $p1->getWorld();
        $minX = min($p1->getFloorX(), $p2->getFloorX());
        $minZ = min($p1->getFloorZ(), $p2->getFloorZ());
        $maxX = max($p1->getFloorX(), $p2->getFloorX());
        $maxZ = max($p1->getFloorZ(), $p2->getFloorZ());
        $minY = min($p1->getFloorY(), $p2->getFloorY());
        $maxY = max($p1->getFloorY(), $p2->getFloorY());

        $width = $maxX - $minX + 1;
        $height = $maxY - $minY + 1;
        $length = $maxZ - $minZ + 1;

        $blocks = [];
        for ($x = 0; $x < $width; $x++) {
            for ($y = 0; $y < $height; $y++) {
                for ($z = 0; $z < $length; $z++) {
                    $b = $w->getBlockAt($minX + $x, $minY + $y, $minZ + $z);
                    if ($b->getTypeId() === 0) {
                        $blocks[] = "air";
                    } else {
                        $item = $b->asItem();
                        $aliases = StringToItemParser::getInstance()->lookupAliases($item);
                        $id = count($aliases) > 0 ? $aliases[0] : "dirt"; 
                        $blocks[] = $id;
                    }
                }
            }
        }
        
        $spawnData = ["x" => 0, "y" => $minY + 1, "z" => 0];
        if (isset($this->spawn[$player])) {
            $sp = $this->spawn[$player];
            if ($sp->getWorld()->getFolderName() === $w->getFolderName()) {
                $spawnData = [
                    "x" => $sp->getFloorX() - $minX,
                    "y" => $sp->getFloorY(),
                    "z" => $sp->getFloorZ() - $minZ
                ];
            }
        }

        $data = [
            "name" => "§a⚡ Đảo Mới",
            "description" => "§8Đảo tùy chỉnh",
            "icon" => "textures/blocks/grass_side_carried",
            "width" => $width,
            "height" => $height,
            "length" => $length,
            "start_y" => $minY,
            "spawn" => $spawnData,
            "blocks" => $blocks
        ];
        Utils::saveYaml($this->plugin->getDataFolder() . "schemas/$name.yml", $data);
        return true;
    }

    public function pasteSchema(string $name, Position $pos): void {
        $file = $this->plugin->getDataFolder() . "schemas/$name.yml";
        if (!file_exists($file)) return;
        $data = Utils::parseYaml($file);
        
        $w = $pos->getWorld();
        $px = $pos->getFloorX();
        $pz = $pos->getFloorZ();
        
        $width = $data['width'] ?? 1;
        $height = $data['height'] ?? 1;
        $length = $data['length'] ?? 1;
        $startY = $data['start_y'] ?? 74;
        $blocks = $data['blocks'] ?? [];

        $index = 0;
        $totalBlocks = count($blocks);

        for ($x = 0; $x < $width; $x++) {
            for ($y = 0; $y < $height; $y++) {
                for ($z = 0; $z < $length; $z++) {
                    if ($index >= $totalBlocks) break 3;
                    
                    $id = $blocks[$index++];
                    
                    if ($id !== "air") {
                        $axisOverride = null;
                        if (str_ends_with($id, "_x")) {
                            $axisOverride = \pocketmine\math\Axis::X;
                            $id = substr($id, 0, -2);
                        } elseif (str_ends_with($id, "_z")) {
                            $axisOverride = \pocketmine\math\Axis::Z;
                            $id = substr($id, 0, -2);
                        }

                        $cleanId = str_replace("minecraft:", "", $id);
                        $item = StringToItemParser::getInstance()->parse($cleanId);
                        $block = VanillaBlocks::DIRT();
                        if ($item !== null && !$item->isNull()) {
                            $block = $item->getBlock();
                        }

                        if ($axisOverride !== null && method_exists($block, "setAxis")) {
                            $block->setAxis($axisOverride);
                        }

                        if (method_exists($block, "setAge") && method_exists($block, "getMaxAge")) {
                            $block->setAge($block->getMaxAge());
                        }
                        
                        try {
                            $w->setBlockAt($px + $x, $startY + $y, $pz + $z, $block, false);
                        } catch (\Exception $e) {}
                    }
                }
            }
        }
    }

    public function getSpawn(string $name): array {
        $file = $this->plugin->getDataFolder() . "schemas/$name.yml";
        if (!file_exists($file)) return ["x" => 0, "y" => 75, "z" => 0];
        $data = Utils::parseYaml($file);
        $spawn = $data['spawn'] ?? [];
        return ["x" => $spawn['x'] ?? 0, "y" => $spawn['y'] ?? 75, "z" => $spawn['z'] ?? 0];
    }

    public function getList(): array {
        $files = glob($this->plugin->getDataFolder() . "schemas/*.yml");
        return array_map(function($f) { return basename($f, ".yml"); }, $files);
    }
}