<?php

namespace azskyblock\manager;

use azskyblock\Main;

class TopManager {
    public function __construct(private Main $plugin) {}

    public function calculatePoints(string $islandId): void {
        // Disabled: points are now updated in real-time in the SQLite database
    }

    public function getTopIslands(int $limit = 10): array {
        $tops = [];
        foreach ($this->plugin->db->cache as $id => $data) {
            $tops[$data['owner']] = $data['points'] ?? 0;
        }
        arsort($tops);
        return array_slice($tops, 0, $limit, true);
    }
}