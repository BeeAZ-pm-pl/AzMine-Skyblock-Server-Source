<?php

namespace azskyblock\manager;

use azskyblock\Main;
use AZEconomy\AZEconomy;

class EconomyManager {
    public function __construct(private Main $plugin) {}

    public function reduceMoney(string $player, int $amount): bool {
        $eco = AZEconomy::getInstance();
        if ($eco !== null) {
            return $eco->reduceMoney($player, $amount);
        }
        return false;
    }

    public function getMoney(string $player): int {
        $eco = AZEconomy::getInstance();
        if ($eco !== null) {
            return $eco->getMoney($player);
        }
        return 0;
    }

    public function reduceCoin(string $player, int $amount): bool {
        $eco = AZEconomy::getInstance();
        if ($eco !== null) {
            return $eco->reduceCoin($player, $amount);
        }
        return false;
    }

    public function getCoin(string $player): int {
        $eco = AZEconomy::getInstance();
        if ($eco !== null) {
            return $eco->getCoin($player);
        }
        return 0;
    }
}