<?php

namespace azskyblock\manager;

use azskyblock\Main;
use pocketmine\player\Player;
use pocketmine\world\Position;
use pocketmine\world\ChunkLoader;
use pocketmine\scheduler\ClosureTask;
use pocketmine\item\StringToItemParser;
use pocketmine\block\VanillaBlocks;

class IslandManager implements ChunkLoader {
    private array $last_island = [];
    private array $current_island_cache = [];
    private ?array $player_island_map = null;

    public function __construct(private Main $plugin) {}

    public function getLoaderId(): int { return spl_object_id($this); }
    public function isLoaderActive(): bool { return true; }

    public function rebuildPlayerIslandMap(): void {
        $this->player_island_map = [];
        foreach ($this->plugin->db->cache as $id => $data) {
            if (is_array($data['members'])) {
                foreach ($data['members'] as $member) {
                    $this->player_island_map[strtolower($member)] = $id;
                }
            }
        }
        foreach ($this->plugin->db->cache as $id => $data) {
            $owner = strtolower($data['owner']);
            $this->player_island_map[$owner] = $id;
        }
    }

    public function getIslandByPlayer(string $player): ?string {
        if ($this->player_island_map === null) {
            $this->rebuildPlayerIslandMap();
        }
        return $this->player_island_map[strtolower($player)] ?? null;
    }

    public function getOwnedIsland(string $player): ?array {
        $pName = strtolower($player);
        foreach ($this->plugin->db->cache as $id => $data) {
            if (strtolower($data['owner']) === $pName) {
                return $data;
            }
        }
        return null;
    }

    public function getMemberIslands(string $player): array {
        $result = [];
        $pName = strtolower($player);
        foreach ($this->plugin->db->cache as $id => $data) {
            if (strtolower($data['owner']) === $pName) {
                continue;
            }
            if (is_array($data['members'])) {
                foreach ($data['members'] as $member) {
                    if (strtolower($member) === $pName) {
                        $result[] = $data;
                        break;
                    }
                }
            }
        }
        return $result;
    }

    public function getIslandAt(int $x, int $z): ?array {
        foreach ($this->plugin->db->cache as $id => $data) {
            $dist = $data['border'] ?? 100;
            if ($x >= ($data['x'] - $dist) && $x <= ($data['x'] + $dist) &&
                $z >= ($data['z'] - $dist) && $z <= ($data['z'] + $dist)) {
                return $data;
            }
        }
        return null;
    }

    public function handlePopup(Player $player): void {
        $pos = $player->getPosition();
        if ($pos->getWorld()->getFolderName() !== "skyblock") return;

        $pName = $player->getName();
        $x = $pos->getFloorX();
        $z = $pos->getFloorZ();

        if (isset($this->current_island_cache[$pName]) && $this->current_island_cache[$pName] !== null) {
            $c = $this->current_island_cache[$pName];
            $dist = $c['border'] ?? 100;
            if ($x >= ($c['x'] - $dist) && $x <= ($c['x'] + $dist) && $z >= ($c['z'] - $dist) && $z <= ($c['z'] + $dist)) {
                return;
            }
        }

        $island = $this->getIslandAt($x, $z);
        $name = ($island !== null) ? $island['owner'] : null;

        if (!isset($this->last_island[$pName])) $this->last_island[$pName] = null;

        if ($name !== $this->last_island[$pName]) {
            if ($name !== null) {
                if (strtolower($name) === strtolower($pName)) {
                    $player->sendTitle("§a⚡ §lĐẢO CỦA BẠN §r§a⚡", "§fChào mừng bạn trở về!");
                } else {
                    $player->sendTitle("§e⚡ §lĐẢO CỦA §f" . strtoupper($name), "§6Hãy cẩn thận và lịch sự!");
                }
            }
            $this->last_island[$pName] = $name;
        }

        $this->current_island_cache[$pName] = $island;
    }

    private function hasIslandAtGrid(int $x, int $z): bool {
        foreach ($this->plugin->db->cache as $d) {
            if ((int)$d['x'] === $x && (int)$d['z'] === $z) {
                return true;
            }
        }
        foreach ($this->plugin->db->deleted as $d) {
            if ((int)$d['x'] === $x && (int)$d['z'] === $z) {
                return true;
            }
        }
        return false;
    }

    public function createIsland(Player $player, string $schema): void {
        $dist = $this->plugin->cfg->get("distance", 200);
        $spawn = $this->plugin->schema->getSpawn($schema);
        $world = $this->plugin->getServer()->getWorldManager()->getWorldByName("skyblock");
        
        if ($world === null) return;

        $x = 0;
        $z = 0;
        $radius = 0;
        $found = false;

        while (!$found) {
            if ($radius === 0) {
                if (!$this->hasIslandAtGrid(0, 0)) {
                    $found = true;
                }
            } else {
                for ($i = -$radius; $i <= $radius; $i++) {
                    if (!$this->hasIslandAtGrid($i * $dist, -$radius * $dist)) { $x = $i * $dist; $z = -$radius * $dist; $found = true; break; }
                    if (!$this->hasIslandAtGrid($i * $dist, $radius * $dist)) { $x = $i * $dist; $z = $radius * $dist; $found = true; break; }
                    if (!$this->hasIslandAtGrid(-$radius * $dist, $i * $dist)) { $x = -$radius * $dist; $z = $i * $dist; $found = true; break; }
                    if (!$this->hasIslandAtGrid($radius * $dist, $i * $dist)) { $x = $radius * $dist; $z = $i * $dist; $found = true; break; }
                }
            }
            if (!$found) $radius++;
        }

        $sx = $spawn['x'] ?? 0;
        $sy = $spawn['y'] ?? 75;
        $sz = $spawn['z'] ?? 0;
        
        $warpX = $x + $sx;
        $warpY = $sy;
        $warpZ = $z + $sz;

        $id = uniqid("is_");
        $this->plugin->db->cache[$id] = [
            "id" => $id, "owner" => $player->getName(), "x" => $x, "y" => $sy, "z" => $z, 
            "world" => "skyblock", "members" => [], "level" => 1, 
            "border" => $this->plugin->cfg->getNested("border.default", 50), 
            "pvp" => 0, "locked" => 0, "warp_x" => $warpX, "warp_y" => $warpY, "warp_z" => $warpZ, "points" => 0
        ];
        $this->plugin->db->saveIsland($id);
        $this->player_island_map = null;

        $cx = $x >> 4;
        $cz = $z >> 4;

        for ($i = -1; $i <= 1; $i++) {
            for ($j = -1; $j <= 1; $j++) {
                $world->registerChunkLoader($this, $cx + $i, $cz + $j);
            }
        }

        $player->teleport(new Position($x, $sy + 10, $z, $world));
        $player->sendMessage("§e⚡ §lĐang khởi tạo nền móng đảo, xin đợi 2 giây...");

        $this->plugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player, $schema, $x, $z, $world, $cx, $cz, $warpX, $warpY, $warpZ): void {
            
            $this->plugin->schema->pasteSchema($schema, new Position($x, 0, $z, $world)); 
            
            if ($player->isOnline()) {
                $player->teleport(new Position($warpX, $warpY, $warpZ, $world));
                $player->sendMessage("§a⚡ §lĐảo của bạn đã sẵn sàng!");
                
                $startItems = $this->plugin->cfg->get("start-items", []);
                foreach ($startItems as $itemData) {
                    $itemId = $itemData['id'] ?? "";
                    $amount = (int)($itemData['amount'] ?? 1);
                    $item = StringToItemParser::getInstance()->parse($itemId);
                    if ($item !== null) {
                        $item->setCount($amount);
                        $player->getInventory()->addItem($item);
                    }
                }
            }

            for ($i = -1; $i <= 1; $i++) {
                for ($j = -1; $j <= 1; $j++) {
                    $world->unregisterChunkLoader($this, $cx + $i, $cz + $j);
                }
            }
        }), 40);
    }

    public function deleteIsland(string $id): void {
        if (isset($this->plugin->db->cache[$id])) {
            $d = $this->plugin->db->cache[$id];
            $x = (int)$d['x'];
            $z = (int)$d['z'];
            $world = $this->plugin->getServer()->getWorldManager()->getWorldByName("skyblock");
            if ($world !== null) {
                $radius = 20; // 40x40 area centered at $x, $z
                $minX = $x - $radius;
                $maxX = $x + $radius;
                $minZ = $z - $radius;
                $maxZ = $z + $radius;
                $minY = 50;
                $maxY = 120;
                
                $columns = [];
                for ($cx = $minX; $cx <= $maxX; $cx++) {
                    for ($cz = $minZ; $cz <= $maxZ; $cz++) {
                        $columns[] = [$cx, $cz];
                    }
                }
                
                $chunkSize = 100;
                $total = count($columns);
                $index = 0;
                
                $scheduler = $this->plugin->getScheduler();
                $run = null;
                $run = function() use (&$index, $columns, $total, $chunkSize, $minY, $maxY, $world, $scheduler, &$run): void {
                    $limit = min($index + $chunkSize, $total);
                    for ($i = $index; $i < $limit; $i++) {
                        [$cx, $cz] = $columns[$i];
                        for ($y = $minY; $y <= $maxY; $y++) {
                            $world->setBlockAt($cx, $y, $cz, VanillaBlocks::AIR(), false);
                        }
                    }
                    $index = $limit;
                    if ($index < $total) {
                        $scheduler->scheduleDelayedTask(new ClosureTask($run), 1);
                    }
                };
                $scheduler->scheduleDelayedTask(new ClosureTask($run), 1);
            }
        }
        $this->plugin->db->deleteIsland($id);
        $this->player_island_map = null;
    }

    public function isMember(string $id, string $player): bool {
        $d = $this->plugin->db->cache[$id];
        return strtolower($d['owner']) === strtolower($player) || in_array(strtolower($player), array_map('strtolower', $d['members']));
    }

    public function addMember(string $id, string $player): bool {
        $members = array_map('strtolower', $this->plugin->db->cache[$id]['members']);
        if (!in_array(strtolower($player), $members)) {
            $this->plugin->db->cache[$id]['members'][] = $player;
            $this->plugin->db->saveIsland($id);
            $this->player_island_map = null;
            return true;
        }
        return false;
    }

    public function removeMember(string $id, string $player): bool {
        $members = array_map('strtolower', $this->plugin->db->cache[$id]['members']);
        $key = array_search(strtolower($player), $members);
        if ($key !== false) {
            unset($this->plugin->db->cache[$id]['members'][$key]);
            $this->plugin->db->cache[$id]['members'] = array_values($this->plugin->db->cache[$id]['members']);
            $this->plugin->db->saveIsland($id);
            $this->player_island_map = null;
            return true;
        }
        return false;
    }
}