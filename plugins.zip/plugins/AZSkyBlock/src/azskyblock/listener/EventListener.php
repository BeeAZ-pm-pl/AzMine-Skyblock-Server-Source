<?php

namespace azskyblock\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\player\Player;
use pocketmine\world\Position;
use azskyblock\Main;

class EventListener implements Listener {
    public function __construct(private Main $plugin) {}

    public function onMove(PlayerMoveEvent $event): void {
        $from = $event->getFrom();
        $to = $event->getTo();
        if ($from->getFloorX() !== $to->getFloorX() || $from->getFloorZ() !== $to->getFloorZ()) {
            $this->plugin->island->handlePopup($event->getPlayer());
        }
    }

    private function canModify(Player $player, Position $pos): bool {
        if ($pos->getWorld()->getFolderName() !== "skyblock") return true;
        if ($this->plugin->getServer()->isOp($player->getName())) return true;
        $island = $this->plugin->island->getIslandAt($pos->getFloorX(), $pos->getFloorZ());
        if ($island === null) return false;
        return $this->plugin->island->isMember($island['id'], $player->getName());
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $pos = $event->getBlock()->getPosition();
        if (!$this->canModify($event->getPlayer(), $pos)) {
            $event->cancel();
            $event->getPlayer()->sendMessage("§c⚡ §lBạn không có quyền phá block ở đây!");
            return;
        }
    }

    /**
     * @priority MONITOR
     */
    public function onBlockBreakMonitor(BlockBreakEvent $event): void {
        if ($event->isCancelled()) return;
        $pos = $event->getBlock()->getPosition();
        $island = $this->plugin->island->getIslandAt($pos->getFloorX(), $pos->getFloorZ());
        if ($island !== null) {
            $id = $island['id'];
            $blockName = strtolower(str_replace(' ', '_', $event->getBlock()->getName()));
            $values = $this->plugin->cfg->get("block-values", []);
            if (isset($values[$blockName])) {
                $value = (int)$values[$blockName];
                if (isset($this->plugin->db->cache[$id])) {
                    $points = max(0, ($this->plugin->db->cache[$id]['points'] ?? 0) - $value);
                    $this->plugin->db->cache[$id]['points'] = $points;
                    $this->plugin->db->saveIsland($id);
                }
            }
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        $world = $player->getWorld();
        
        foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            $pos = new Position($x, $y, $z, $world);
            if (!$this->canModify($player, $pos)) {
                $event->cancel();
                $player->sendMessage("§c⚡ §lBạn không có quyền đặt block ở đây!");
                return;
            }
        }
    }

    /**
     * @priority MONITOR
     */
    public function onBlockPlaceMonitor(BlockPlaceEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        $world = $player->getWorld();
        foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            $island = $this->plugin->island->getIslandAt($x, $z);
            if ($island !== null) {
                $id = $island['id'];
                $blockName = strtolower(str_replace(' ', '_', $block->getName()));
                $values = $this->plugin->cfg->get("block-values", []);
                if (isset($values[$blockName])) {
                    $value = (int)$values[$blockName];
                    if (isset($this->plugin->db->cache[$id])) {
                        $points = ($this->plugin->db->cache[$id]['points'] ?? 0) + $value;
                        $this->plugin->db->cache[$id]['points'] = $points;
                        $this->plugin->db->saveIsland($id);
                    }
                }
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event): void {
        if (!$this->canModify($event->getPlayer(), $event->getBlock()->getPosition())) {
            $event->cancel();
        }
    }

    public function onDamage(EntityDamageEvent $event): void {
        if ($event instanceof EntityDamageByEntityEvent) {
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if ($entity instanceof Player && $damager instanceof Player) {
                if ($entity->getWorld()->getFolderName() === "skyblock") {
                    $island = $this->plugin->island->getIslandAt($entity->getPosition()->getFloorX(), $entity->getPosition()->getFloorZ());
                    if ($island === null || empty($island['pvp'])) {
                        $event->cancel();
                        $damager->sendMessage("§c⚡ §lKhu vực này không cho phép PvP!");
                    }
                }
            }
        }
    }
}