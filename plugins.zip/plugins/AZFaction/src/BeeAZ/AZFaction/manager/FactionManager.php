<?php

declare(strict_types=1);

namespace BeeAZ\AZFaction\manager;

use BeeAZ\AZFaction\Main;

class FactionManager {

    private Main $plugin;
    public int $createCost = 500;
    private array $invites = [];
    private array $killCache = [];

    public array $buffPrices = [
        "autosmelt" => 5000,
        "x2exp" => 10000
    ];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function addInvite(string $playerName, string $faction) : void {
        $p = strtolower($playerName);
        if(!isset($this->invites[$p])) {
            $this->invites[$p] = [];
        }
        if(!in_array($faction, $this->invites[$p])) {
            $this->invites[$p][] = $faction;
        }
    }

    public function getInvites(string $playerName) : array {
        return $this->invites[strtolower($playerName)] ?? [];
    }

    public function hasInvite(string $playerName, string $faction) : bool {
        $p = strtolower($playerName);
        return isset($this->invites[$p]) && in_array($faction, $this->invites[$p]);
    }

    public function removeInvite(string $playerName, string $faction) : void {
        $p = strtolower($playerName);
        if(isset($this->invites[$p])) {
            $this->invites[$p] = array_values(array_diff($this->invites[$p], [$faction]));
        }
    }

    public function isValidKill(string $killer, string $victim) : bool {
        $killer = strtolower($killer);
        $victim = strtolower($victim);

        if(isset($this->killCache[$killer])) {
            $lastData = $this->killCache[$killer];
            if($lastData['victim'] === $victim && (time() - $lastData['time']) < 300) {
                return false;
            }
        }

        $this->killCache[$killer] = [
            'victim' => $victim,
            'time' => time()
        ];
        return true;
    }

    public function checkLevelUp(string $faction) : void {
        $db = $this->plugin->getDatabase();
        $data = $db->getFactionData($faction);
        if($data !== null) {
            $kills = (int)$data['kills'];
            $currentLevel = (int)$data['level'];
            $requiredKills = $currentLevel * 50;

            if($kills >= $requiredKills) {
                $db->updateLevel($faction, $currentLevel + 1);
            }
        }
    }
}