<?php

declare(strict_types=1);

namespace BeeAZ\AZFaction\database;

class Database {

    private \SQLite3 $db;
    private array $playerFactionCache = [];

    public function __construct(string $path) {
        $this->db = new \SQLite3($path);
        $this->initTables();
    }

    private function initTables() : void {
        $this->db->exec("CREATE TABLE IF NOT EXISTS factions (
            name TEXT PRIMARY KEY,
            leader TEXT,
            coin INT DEFAULT 0,
            kills INT DEFAULT 0,
            level INT DEFAULT 1
        );");
        
        $this->db->exec("CREATE TABLE IF NOT EXISTS members (
            username TEXT PRIMARY KEY,
            faction TEXT,
            role TEXT DEFAULT 'Member'
        );");

        $this->db->exec("CREATE TABLE IF NOT EXISTS buffs (
            faction TEXT,
            buff_type TEXT,
            expire_time INT
        );");
    }

    public function getPlayerFaction(string $playerName) : ?string {
        $name = strtolower($playerName);
        if (isset($this->playerFactionCache[$name])) {
            return $this->playerFactionCache[$name] === "" ? null : $this->playerFactionCache[$name];
        }
        $stmt = $this->db->prepare("SELECT faction FROM members WHERE username = :name");
        $stmt->bindValue(":name", $name, SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($result !== false && $row = $result->fetchArray(SQLITE3_ASSOC)) {
            $faction = (string)$row['faction'];
            $this->playerFactionCache[$name] = $faction;
            return $faction;
        }
        $this->playerFactionCache[$name] = "";
        return null;
    }

    public function getFactionData(string $faction) : ?array {
        $stmt = $this->db->prepare("SELECT * FROM factions WHERE name = :fname");
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($result !== false && $row = $result->fetchArray(SQLITE3_ASSOC)) {
            return $row;
        }
        return null;
    }

    public function getPlayerRole(string $playerName) : string {
        $stmt = $this->db->prepare("SELECT role FROM members WHERE username = :name");
        $stmt->bindValue(":name", strtolower($playerName), SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($result !== false && $row = $result->fetchArray(SQLITE3_ASSOC)) {
            return (string)$row['role'];
        }
        return "Member";
    }

    public function factionExists(string $fname) : bool {
        $stmt = $this->db->prepare("SELECT name FROM factions WHERE name = :fname COLLATE NOCASE");
        $stmt->bindValue(":fname", $fname, SQLITE3_TEXT);
        $result = $stmt->execute();
        return $result !== false && $result->fetchArray(SQLITE3_ASSOC) !== false;
    }

    public function createFaction(string $fname, string $leader) : void {
        $stmt = $this->db->prepare("INSERT INTO factions (name, leader) VALUES (:fname, :leader)");
        $stmt->bindValue(":fname", $fname, SQLITE3_TEXT);
        $stmt->bindValue(":leader", strtolower($leader), SQLITE3_TEXT);
        $stmt->execute();
    }

    public function addMember(string $playerName, string $faction, string $role = "Member") : void {
        $stmt = $this->db->prepare("INSERT OR REPLACE INTO members (username, faction, role) VALUES (:name, :fname, :role)");
        $stmt->bindValue(":name", strtolower($playerName), SQLITE3_TEXT);
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->bindValue(":role", $role, SQLITE3_TEXT);
        $stmt->execute();
        $this->playerFactionCache[strtolower($playerName)] = $faction;
    }

    public function removeMember(string $playerName) : void {
        $stmt = $this->db->prepare("DELETE FROM members WHERE username = :name");
        $stmt->bindValue(":name", strtolower($playerName), SQLITE3_TEXT);
        $stmt->execute();
        $this->playerFactionCache[strtolower($playerName)] = "";
    }

    public function setRole(string $playerName, string $role) : void {
        $stmt = $this->db->prepare("UPDATE members SET role = :role WHERE username = :name");
        $stmt->bindValue(":role", $role, SQLITE3_TEXT);
        $stmt->bindValue(":name", strtolower($playerName), SQLITE3_TEXT);
        $stmt->execute();
    }

    public function getFactionMembers(string $faction) : array {
        $stmt = $this->db->prepare("SELECT username FROM members WHERE faction = :fname");
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $result = $stmt->execute();
        $members = [];
        if ($result !== false) {
            while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $members[] = (string)$row['username'];
            }
        }
        return $members;
    }

    public function disbandFaction(string $faction) : void {
        $stmt1 = $this->db->prepare("DELETE FROM factions WHERE name = :fname");
        $stmt1->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt1->execute();

        $stmt2 = $this->db->prepare("DELETE FROM members WHERE faction = :fname");
        $stmt2->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt2->execute();

        $stmt3 = $this->db->prepare("DELETE FROM buffs WHERE faction = :fname");
        $stmt3->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt3->execute();

        $this->playerFactionCache = [];
    }

    public function addFactionCoin(string $faction, int $amount) : void {
        $stmt = $this->db->prepare("UPDATE factions SET coin = coin + :amount WHERE name = :fname");
        $stmt->bindValue(":amount", $amount, SQLITE3_INTEGER);
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->execute();
    }

    public function reduceFactionCoin(string $faction, int $amount) : void {
        $stmt = $this->db->prepare("UPDATE factions SET coin = coin - :amount WHERE name = :fname");
        $stmt->bindValue(":amount", $amount, SQLITE3_INTEGER);
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->execute();
    }

    public function addKill(string $faction) : void {
        $stmt = $this->db->prepare("UPDATE factions SET kills = kills + 1 WHERE name = :fname");
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->execute();
    }

    public function updateLevel(string $faction, int $level) : void {
        $stmt = $this->db->prepare("UPDATE factions SET level = :lvl WHERE name = :fname");
        $stmt->bindValue(":lvl", $level, SQLITE3_INTEGER);
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->execute();
    }

    public function getTopFactions(int $limit = 10) : array {
        $result = $this->db->query("SELECT name, level, kills FROM factions ORDER BY level DESC, kills DESC LIMIT $limit");
        $top = [];
        if($result !== false) {
            while($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $top[] = $row;
            }
        }
        return $top;
    }

    public function addBuff(string $faction, string $buffType, int $durationDays) : void {
        $expire = time() + ($durationDays * 86400);
        $stmt = $this->db->prepare("INSERT INTO buffs (faction, buff_type, expire_time) VALUES (:fname, :type, :exp)");
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->bindValue(":type", $buffType, SQLITE3_TEXT);
        $stmt->bindValue(":exp", $expire, SQLITE3_INTEGER);
        $stmt->execute();
    }

    public function hasActiveBuff(string $faction, string $buffType) : bool {
        $stmt = $this->db->prepare("SELECT expire_time FROM buffs WHERE faction = :fname AND buff_type = :type ORDER BY expire_time DESC LIMIT 1");
        $stmt->bindValue(":fname", $faction, SQLITE3_TEXT);
        $stmt->bindValue(":type", $buffType, SQLITE3_TEXT);
        $result = $stmt->execute();
        
        if ($result !== false && $row = $result->fetchArray(SQLITE3_ASSOC)) {
            if (time() < $row['expire_time']) {
                return true;
            } else {
                $del = $this->db->prepare("DELETE FROM buffs WHERE faction = :fname AND expire_time <= :now");
                $del->bindValue(":fname", $faction, SQLITE3_TEXT);
                $del->bindValue(":now", time(), SQLITE3_INTEGER);
                $del->execute();
            }
        }
        return false;
    }

    public function close() : void {
        $this->db->close();
    }
}