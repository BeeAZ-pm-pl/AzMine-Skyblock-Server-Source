<?php

declare(strict_types=1);

namespace BeeAZ\AZFaction\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginOwned;
use BeeAZ\AZFaction\Main;

class FactionCommand extends Command implements PluginOwned {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("f", "Menu Bang Hoi", "/f", ["faction", "clan"]);
        $this->setPermission("azfaction.command");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : bool {
        if(!$this->testPermission($sender)) return false;

        if($sender instanceof Player) {
            $this->plugin->getFormManager()->openMainForm($sender);
            return true;
        }
        return false;
    }

    public function getOwningPlugin() : Main {
        return $this->plugin;
    }
}