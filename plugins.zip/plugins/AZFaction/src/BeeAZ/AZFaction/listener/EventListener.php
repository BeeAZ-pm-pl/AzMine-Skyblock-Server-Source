<?php

declare(strict_types=1);

namespace BeeAZ\AZFaction\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use BeeAZ\AZFaction\Main;

class EventListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onDeath(PlayerDeathEvent $event) : void {
        $victim = $event->getPlayer();
        $cause = $victim->getLastDamageCause();

        if($cause instanceof EntityDamageByEntityEvent) {
            $killer = $cause->getDamager();
            if($killer instanceof Player) {
                $db = $this->plugin->getDatabase();
                $faction = $db->getPlayerFaction($killer->getName());
                
                if($faction !== null) {
                    if($this->plugin->getFactionManager()->isValidKill($killer->getName(), $victim->getName())) {
                        $db->addKill($faction);
                        $this->plugin->getFactionManager()->checkLevelUp($faction);
                    }
                }
            }
        }
    }

    /**
     * @priority HIGH
     */
    public function onBlockBreak(BlockBreakEvent $event) : void {
        if($event->isCancelled()) return;
        $player = $event->getPlayer();
        $db = $this->plugin->getDatabase();
        $faction = $db->getPlayerFaction($player->getName());

        if($faction !== null) {
            if($db->hasActiveBuff($faction, "x2exp")) {
                $event->setXpDropAmount($event->getXpDropAmount() * 2);
            }

            if($db->hasActiveBuff($faction, "autosmelt")) {
                $drops = $event->getDrops();
                $modified = false;

                foreach($drops as $key => $item) {
                    if($item->getTypeId() === VanillaItems::RAW_IRON()->getTypeId()) {
                        $drops[$key] = VanillaItems::IRON_INGOT()->setCount($item->getCount());
                        $modified = true;
                    } elseif($item->getTypeId() === VanillaItems::RAW_GOLD()->getTypeId()) {
                        $drops[$key] = VanillaItems::GOLD_INGOT()->setCount($item->getCount());
                        $modified = true;
                    } elseif($item->getTypeId() === VanillaItems::RAW_COPPER()->getTypeId()) {
                        $drops[$key] = VanillaItems::COPPER_INGOT()->setCount($item->getCount());
                        $modified = true;
                    }
                }

                if($modified) {
                    $event->setDrops($drops);
                }
            }
        }
    }
}