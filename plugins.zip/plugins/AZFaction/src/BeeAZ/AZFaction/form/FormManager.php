<?php

declare(strict_types=1);

namespace BeeAZ\AZFaction\form;

use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\ModalForm;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Dropdown;
use AZEconomy\AZEconomy;
use BeeAZ\AZFaction\Main;

class FormManager {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function openMainForm(Player $player, string $msg = "") : void {
        $faction = $this->plugin->getDatabase()->getPlayerFaction($player->getName());

        if ($faction === null) {
            $this->openNoFactionForm($player, $msg);
        } else {
            $this->openFactionMenuForm($player, $faction, $msg);
        }
    }

    public function openNoFactionForm(Player $player, string $msg = "") : void {
        $cost = $this->plugin->getFactionManager()->createCost;
        $content = $msg !== "" ? $msg . "\n\n" : "";
        $content .= "§eBạn chưa gia nhập bang hội nào.\n§fHãy chọn một hành động bên dưới:";
        
        $form = new MenuForm(
            "§l§0CHƯA CÓ BANG HỘI",
            $content,
            [
                new MenuOption("§l§0⚡ TẠO BANG HỘI ⚡\n§r§8Phí: " . $cost . " Coin", new FormIcon("textures/items/diamond_sword", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ LỜI MỜI ⚡\n§r§8Xem các yêu cầu gia nhập", new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ XẾP HẠNG ⚡\n§r§8Top các bang hội mạnh nhất", new FormIcon("textures/items/gold_ingot", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ HƯỚNG DẪN ⚡\n§r§8Tìm hiểu cách vận hành", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $submitter, int $selected) : void {
                if($selected === 0) $this->openCreateFactionForm($submitter);
                if($selected === 1) $this->openInvitesListForm($submitter);
                if($selected === 2) $this->openTopForm($submitter);
                if($selected === 3) $this->openGuideForm($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function openFactionMenuForm(Player $player, string $faction, string $msg = "") : void {
        $db = $this->plugin->getDatabase();
        $data = $db->getFactionData($faction);
        
        if($data === null) {
            $db->removeMember($player->getName());
            $this->openNoFactionForm($player, "§cBang hội lỗi, đã tự động thoát.");
            return;
        }

        $role = $db->getPlayerRole($player->getName());
        
        $info = $msg !== "" ? $msg . "\n\n" : "";
        $info .= "§e❖ Bang: §b" . $faction . "\n";
        $info .= "§e❖ Level: §a" . $data['level'] . " §f| §eKills: §c" . $data['kills'] . "\n";
        $info .= "§e❖ Quỹ Coin: §6" . $data['coin'] . "\n";
        $info .= "§e❖ Quyền: §d" . $role;

        $options = [
            new MenuOption("§l§0⚡ QUYÊN GÓP ⚡\n§r§8Đóng góp vào quỹ chung", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§0⚡ CỬA HÀNG BUFF ⚡\n§r§8Mua hiệu ứng cho bang", new FormIcon("textures/items/potion_bottle_splash_heal", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§0⚡ XẾP HẠNG ⚡\n§r§8Bảng vinh danh", new FormIcon("textures/items/gold_ingot", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§0⚡ HƯỚNG DẪN ⚡\n§r§8Xem thông tin", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§0⚡ RỜI BANG ⚡\n§r§8Thoát khỏi tập thể", new FormIcon("textures/blocks/barrier", FormIcon::IMAGE_TYPE_PATH))
        ];

        if ($role === "Leader" || $role === "Co-Leader") {
            array_unshift($options, new MenuOption("§l§0⚡ QUẢN LÝ BANG ⚡\n§r§8Công cụ quản trị", new FormIcon("textures/items/iron_sword", FormIcon::IMAGE_TYPE_PATH)));
        }

        $form = new MenuForm(
            "§l§0BANG HỘI: " . $faction,
            $info,
            $options,
            function(Player $submitter, int $selected) use ($role, $faction) : void {
                $optName = ($role === "Leader" || $role === "Co-Leader") ? $selected : $selected + 1;
                
                if($optName === 0) $this->openManageForm($submitter, $faction, $role);
                if($optName === 1) $this->openDonateForm($submitter, $faction);
                if($optName === 2) $this->openBuffShopForm($submitter, $faction, $role);
                if($optName === 3) $this->openTopForm($submitter);
                if($optName === 4) $this->openGuideForm($submitter);
                if($optName === 5) {
                    if($role === "Leader") {
                        $this->openMainForm($submitter, "§cChủ bang không thể rời bang.");
                    } else {
                        $this->plugin->getDatabase()->removeMember($submitter->getName());
                        $this->openMainForm($submitter, "§aĐã rời bang thành công.");

                        $azrank = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRank");
                        if ($azrank !== null) {
                            $azrank->rank->updatePlayer($submitter);
                        }
                    }
                }
            }
        );
        $player->sendForm($form);
    }

    public function openManageForm(Player $player, string $faction, string $role, string $msg = "") : void {
        $options = [
            new MenuOption("§l§0⚡ MỜI THÀNH VIÊN ⚡\n§r§8Thêm người chơi mới", new FormIcon("textures/items/totem", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§0⚡ ĐUỔI THÀNH VIÊN ⚡\n§r§8Xóa người ra khỏi bang", new FormIcon("textures/items/iron_sword", FormIcon::IMAGE_TYPE_PATH))
        ];

        if($role === "Leader") {
            $options[] = new MenuOption("§l§0⚡ CẤP CHỨC VỤ ⚡\n§r§8Phân quyền thành viên", new FormIcon("textures/items/gold_sword", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ GIẢI TÁN BANG ⚡\n§r§8Xóa vĩnh viễn bang", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));
        }

        $content = $msg !== "" ? $msg . "\n\n" : "";
        $content .= "§bKhu vực dành cho quản lý bang hội:";

        $form = new MenuForm(
            "§l§0QUẢN TRỊ BANG",
            $content,
            $options,
            function(Player $submitter, int $selected) use ($faction, $role) : void {
                if($selected === 0) $this->openInviteForm($submitter, $faction, $role);
                if($selected === 1) $this->openKickForm($submitter, $faction, $role);
                if($selected === 2 && $role === "Leader") $this->openSetRoleForm($submitter, $faction, $role);
                if($selected === 3 && $role === "Leader") $this->confirmDisband($submitter, $faction);
            },
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function confirmDisband(Player $player, string $faction) : void {
        $form = new ModalForm(
            "§l§0XÁC NHẬN GIẢI TÁN",
            "§fBạn có chắc chắn muốn giải tán bang §e" . $faction . "§f không?\n§cToàn bộ cấp độ và quỹ coin sẽ bị xóa sạch!",
            function(Player $submitter, bool $choice) use ($faction) : void {
                if($choice){
                    $db = $this->plugin->getDatabase();
                    $members = $db->getFactionMembers($faction);
                    $db->disbandFaction($faction);
                    $this->openMainForm($submitter, "§cBang hội đã bị giải tán vĩnh viễn.");

                    $azrank = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRank");
                    if ($azrank !== null) {
                        foreach ($members as $memberName) {
                            $memberPlayer = $this->plugin->getServer()->getPlayerExact($memberName);
                            if ($memberPlayer !== null) {
                                $azrank->rank->updatePlayer($memberPlayer);
                            }
                        }
                    }
                } else {
                    $this->openManageForm($submitter, $faction, "Leader", "§aĐã hủy thao tác giải tán.");
                }
            }
        );
        $player->sendForm($form);
    }

    public function openCreateFactionForm(Player $player) : void {
        $cost = $this->plugin->getFactionManager()->createCost;
        $form = new CustomForm(
            "§l§0TẠO BANG HỘI",
            [
                new Label("info", "§ePhí thành lập: §a" . $cost . " Coin"),
                new Input("fname", "§fNhập tên bang hội muốn đặt:", "Tên bang...")
            ],
            function(Player $submitter, CustomFormResponse $response) use ($cost) : void {
                $fname = trim($response->getString("fname"));
                if(strlen($fname) < 1 || strlen($fname) > 30) {
                    $this->openMainForm($submitter, "§cĐộ dài tên bang hội không hợp lệ.");
                    return;
                }
                $db = $this->plugin->getDatabase();
                if($db->factionExists($fname)) {
                    $this->openMainForm($submitter, "§cTên bang hội này đã tồn tại.");
                    return;
                }
                $eco = AZEconomy::getInstance();
                if($eco->getCoin($submitter->getName()) < $cost) {
                    $this->openMainForm($submitter, "§cBạn không đủ Coin để tạo bang.");
                    return;
                }
                $eco->reduceCoin($submitter->getName(), $cost);
                $db->createFaction($fname, $submitter->getName());
                $db->addMember($submitter->getName(), $fname, "Leader");
                $this->openMainForm($submitter, "§aChúc mừng bạn đã lập bang §e$fname!");

                $azrank = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRank");
                if ($azrank !== null) {
                    $azrank->rank->updatePlayer($submitter);
                }
            },
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function openInviteForm(Player $player, string $faction, string $role) : void {
        $playerList = [];
        foreach($this->plugin->getServer()->getOnlinePlayers() as $p) {
            if($p->getName() !== $player->getName() && $this->plugin->getDatabase()->getPlayerFaction($p->getName()) === null) {
                $playerList[] = $p->getName();
            }
        }

        if(empty($playerList)) {
            $this->openManageForm($player, $faction, $role, "§cHiện không có người chơi online nào chưa có bang hội.");
            return;
        }

        $form = new CustomForm(
            "§l§0MỜI THÀNH VIÊN",
            [new Dropdown("target", "§fChọn người chơi muốn mời:", $playerList)],
            function(Player $submitter, CustomFormResponse $response) use ($faction, $role, $playerList) : void {
                $targetName = $playerList[$response->getInt("target")];
                $target = $this->plugin->getServer()->getPlayerExact($targetName);
                
                if($target === null || !$target->isOnline()) {
                    $this->openManageForm($submitter, $faction, $role, "§cNgười chơi đã thoát game.");
                    return;
                }
                if($this->plugin->getDatabase()->getPlayerFaction($target->getName()) !== null) {
                    $this->openManageForm($submitter, $faction, $role, "§cNgười này vừa mới gia nhập bang khác.");
                    return;
                }
                if($this->plugin->getFactionManager()->hasInvite($target->getName(), $faction)) {
                    $this->openManageForm($submitter, $faction, $role, "§cĐã gửi lời mời cho người này trước đó.");
                    return;
                }
                $this->plugin->getFactionManager()->addInvite($target->getName(), $faction);
                $target->sendMessage("§aBạn vừa nhận được lời mời vào bang §e$faction §a.");
                $this->openManageForm($submitter, $faction, $role, "§aĐã gửi lời mời đến §e" . $target->getName() . "§a.");
            },
            function(Player $submitter) use ($faction, $role) : void { $this->openManageForm($submitter, $faction, $role); }
        );
        $player->sendForm($form);
    }

    public function openInvitesListForm(Player $player) : void {
        $name = $player->getName();
        $invites = $this->plugin->getFactionManager()->getInvites($name);

        if(empty($invites)) {
            $this->openMainForm($player, "§cBạn không có lời mời gia nhập nào.");
            return;
        }

        $options = [];
        foreach($invites as $f) {
            $options[] = new MenuOption("§l§0⚡ BANG " . $f . " ⚡\n§r§8Nhấn để xem", new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH));
        }

        $form = new MenuForm(
            "§l§0DANH SÁCH LỜI MỜI",
            "§fBạn đang có " . count($invites) . " lời mời gia nhập:",
            $options,
            function(Player $submitter, int $selected) use ($invites) : void {
                $this->openInviteActionForm($submitter, $invites[$selected]);
            },
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function openInviteActionForm(Player $player, string $faction) : void {
        $form = new MenuForm(
            "§l§0XỬ LÝ LỜI MỜI",
            "§fBang hội §e$faction §fđang muốn mời bạn tham gia tập thể của họ.",
            [
                new MenuOption("§l§0⚡ CHẤP NHẬN ⚡", new FormIcon("textures/ui/confirm", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ TỪ CHỐI ⚡", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $submitter, int $selected) use ($faction) : void {
                $name = $submitter->getName();
                if($selected === 0){
                    if($this->plugin->getDatabase()->getPlayerFaction($name) !== null) {
                        $this->openMainForm($submitter, "§cBạn đã ở trong một bang hội khác.");
                        return;
                    }
                    $this->plugin->getDatabase()->addMember($name, $faction);
                    $this->plugin->getFactionManager()->removeInvite($name, $faction);
                    $this->openMainForm($submitter, "§aGia nhập bang §e$faction §athành công.");

                    $azrank = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRank");
                    if ($azrank !== null) {
                        $azrank->rank->updatePlayer($submitter);
                    }
                } else {
                    $this->plugin->getFactionManager()->removeInvite($name, $faction);
                    $this->openInvitesListForm($submitter);
                }
            },
            function(Player $submitter) : void { $this->openInvitesListForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function openKickForm(Player $player, string $faction, string $role) : void {
        $members = [];
        $res = $this->plugin->getDatabase()->getFactionMembers($faction);
        foreach($res as $m) {
            if(strtolower($m) !== strtolower($player->getName())) {
                $members[] = $m;
            }
        }

        if(empty($members)) {
            $this->openManageForm($player, $faction, $role, "§cBang hội không có thành viên nào khác để đuổi.");
            return;
        }

        $form = new CustomForm(
            "§l§0ĐUỔI THÀNH VIÊN",
            [new Dropdown("target", "§fChọn thành viên cần loại bỏ:", $members)],
            function(Player $submitter, CustomFormResponse $response) use ($faction, $role, $members) : void {
                $target = $members[$response->getInt("target")];
                $db = $this->plugin->getDatabase();
                
                if($db->getPlayerFaction($target) !== $faction) {
                    $this->openManageForm($submitter, $faction, $role, "§cNgười này không còn trong bang.");
                    return;
                }
                $targetRole = $db->getPlayerRole($target);
                if($role === "Co-Leader" && ($targetRole === "Leader" || $targetRole === "Co-Leader")) {
                    $this->openManageForm($submitter, $faction, $role, "§cBạn không đủ thẩm quyền.");
                    return;
                }
                $db->removeMember($target);
                $this->openManageForm($submitter, $faction, $role, "§aĐã đuổi §e$target §ara khỏi bang.");

                $targetPlayer = $this->plugin->getServer()->getPlayerExact($target);
                if ($targetPlayer !== null) {
                    $azrank = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRank");
                    if ($azrank !== null) {
                        $azrank->rank->updatePlayer($targetPlayer);
                    }
                }
            },
            function(Player $submitter) use ($faction, $role) : void { $this->openManageForm($submitter, $faction, $role); }
        );
        $player->sendForm($form);
    }

    public function openSetRoleForm(Player $player, string $faction, string $role) : void {
        $members = [];
        $res = $this->plugin->getDatabase()->getFactionMembers($faction);
        foreach($res as $m) {
            if(strtolower($m) !== strtolower($player->getName())) {
                $members[] = $m;
            }
        }

        if(empty($members)) {
            $this->openManageForm($player, $faction, $role, "§cBang hội không có thành viên nào khác.");
            return;
        }

        $form = new CustomForm(
            "§l§0CẤP CHỨC VỤ",
            [
                new Dropdown("target", "§fChọn thành viên:", $members),
                new Dropdown("role", "§fChọn chức vụ", ["Co-Leader", "Member"])
            ],
            function(Player $submitter, CustomFormResponse $response) use ($faction, $role, $members) : void {
                $target = $members[$response->getInt("target")];
                $newRole = $response->getInt("role") === 0 ? "Co-Leader" : "Member";
                $db = $this->plugin->getDatabase();
                
                if($db->getPlayerFaction($target) !== $faction) {
                    $this->openManageForm($submitter, $faction, $role, "§cNgười này không còn trong bang.");
                    return;
                }
                $db->setRole($target, $newRole);
                $this->openManageForm($submitter, $faction, $role, "§aĐã cập nhật chức vụ cho §e$target §a thành§b $newRole §a.");
            },
            function(Player $submitter) use ($faction, $role) : void { $this->openManageForm($submitter, $faction, $role); }
        );
        $player->sendForm($form);
    }

    public function openDonateForm(Player $player, string $faction) : void {
        $form = new CustomForm(
            "§l§0QUYÊN GÓP QUỸ",
            [new Input("amount", "§fNhập số lượng Coin muốn đóng góp:", "100")],
            function(Player $submitter, CustomFormResponse $response) use ($faction) : void {
                $val = $response->getString("amount");
                if (!is_numeric($val) || (int)$val <= 0) {
                    $this->openMainForm($submitter, "§cSố lượng Coin không hợp lệ.");
                    return;
                }
                $amount = (int)$val;
                $eco = AZEconomy::getInstance();
                if($eco->getCoin($submitter->getName()) < $amount) {
                    $this->openMainForm($submitter, "§cTài khoản không đủ Coin.");
                    return;
                }
                $eco->reduceCoin($submitter->getName(), $amount);
                $this->plugin->getDatabase()->addFactionCoin($faction, $amount);
                $this->openMainForm($submitter, "§aCảm ơn bạn đã đóng góp §e$amount Coin.");
            },
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function openTopForm(Player $player) : void {
        $top = $this->plugin->getDatabase()->getTopFactions(10);
        $text = "§bDanh sách 10 bang hội dẫn đầu:\n\n";
        foreach($top as $i => $row) $text .= "§e#" . ($i+1) . " §f" . $row['name'] . " §7(Lv." . $row['level'] . ")\n";
        $form = new CustomForm(
            "§l§0BẢNG XẾP HẠNG",
            [new Label("lbl", $text)],
            function(Player $submitter, CustomFormResponse $response) : void {},
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function openBuffShopForm(Player $player, string $faction, string $role) : void {
        $prices = $this->plugin->getFactionManager()->buffPrices;
        $form = new MenuForm(
            "§l§0CỬA HÀNG BUFF",
            "§fSử dụng quỹ bang để mua hiệu ứng:",
            [
                new MenuOption("§l§0⚡ AUTO SMELT ⚡\n§r§8Giá: " . $prices['autosmelt'] . " Coin", new FormIcon("textures/items/iron_ingot", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ X2 EXP ⚡\n§r§8Giá: " . $prices['x2exp'] . " Coin", new FormIcon("textures/items/experience_bottle", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $submitter, int $selected) use ($faction, $role, $prices) : void {
                if($role !== "Leader" && $role !== "Co-Leader") {
                    $this->openMainForm($submitter, "§cChỉ có quản lý mới được mua Buff.");
                    return;
                }
                $type = $selected === 0 ? "autosmelt" : "x2exp";
                $db = $this->plugin->getDatabase();
                $data = $db->getFactionData($faction);
                if($data['coin'] < $prices[$type]) {
                    $this->openMainForm($submitter, "§cQuỹ bang không đủ Coin.");
                    return;
                }
                $db->reduceFactionCoin($faction, $prices[$type]);
                $db->addBuff($faction, $type, 1);
                $this->openMainForm($submitter, "§aĐã kích hoạt Buff §e$type §athành công!");
            },
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }

    public function openGuideForm(Player $player) : void {
        $guide = "§b1. Level Bang: §fTăng qua việc Kill người chơi (50 Kills/Level).\n";
        $guide .= "§b2. Quỹ Bang: §fDùng Coin để quyên góp, chủ bang dùng quỹ này mua Buff.\n";
        $guide .= "§b3. Buff: §fKhi mua, toàn bộ thành viên online đều được hưởng lợi.";
        $form = new CustomForm(
            "§l§0HƯỚNG DẪN CHI TIẾT",
            [new Label("lbl", $guide)],
            function(Player $submitter, CustomFormResponse $response) : void {},
            function(Player $submitter) : void { $this->openMainForm($submitter); }
        );
        $player->sendForm($form);
    }
}