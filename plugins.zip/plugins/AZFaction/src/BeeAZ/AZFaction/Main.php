<?php

declare(strict_types=1);

namespace BeeAZ\AZFaction;

use pocketmine\plugin\PluginBase;
use BeeAZ\AZFaction\database\Database;
use BeeAZ\AZFaction\manager\FactionManager;
use BeeAZ\AZFaction\form\FormManager;
use BeeAZ\AZFaction\command\FactionCommand;
use BeeAZ\AZFaction\listener\EventListener;

class Main extends PluginBase {

    private Database $database;
    private FactionManager $factionManager;
    private FormManager $formManager;

    protected function onEnable() : void {
        @mkdir($this->getDataFolder());
        
        $this->database = new Database($this->getDataFolder() . "faction.db");
        $this->factionManager = new FactionManager($this);
        $this->formManager = new FormManager($this);

        $this->getServer()->getCommandMap()->register("azfaction", new FactionCommand($this));
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
    }

    protected function onDisable() : void {
        $this->database->close();
    }

    public function getDatabase() : Database {
        return $this->database;
    }

    public function getFactionManager() : FactionManager {
        return $this->factionManager;
    }

    public function getFormManager() : FormManager {
        return $this->formManager;
    }
}