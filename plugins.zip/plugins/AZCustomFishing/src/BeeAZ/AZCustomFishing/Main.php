<?php

namespace BeeAZ\AZCustomFishing;

use pocketmine\plugin\PluginBase;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;
use pocketmine\item\StringToItemParser;
use pocketmine\world\format\io\GlobalItemDataHandlers;
use pocketmine\item\ItemTypeIds;
use pocketmine\scheduler\ClosureTask;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use BeeAZ\AZCustomFishing\entity\CustomHook;
use BeeAZ\AZCustomFishing\item\CustomFishingRod;
use BeeAZ\AZCustomFishing\command\FishingCommand;
use BeeAZ\AZCustomFishing\command\GiveRodCommand;
use BeeAZ\AZCustomFishing\database\Database;
use BeeAZ\AZCustomFishing\utils\EconomyManager;

class Main extends PluginBase {
    private static self $instance;
    public array $fishingSession = [];
    public array $eventParticipants = [];
    public bool $eventActive = false;
    public int $eventTimer = 0;
    public Database $db;
    public Config $fishConfig;
    private string $lastEventDate = "";
    public bool $eventRegistering = false;
    private int $registerReminderTimer = 0;

    protected function onLoad(): void {
        self::$instance = $this;
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        $timezone = $this->getConfig()->getNested("settings.timezone", "");
        if ($timezone !== "" && in_array($timezone, timezone_identifiers_list(), true)) {
            date_default_timezone_set($timezone);
        }

        $this->saveResource("fish.json");
        $this->fishConfig = new Config($this->getDataFolder() . "fish.json", Config::JSON);
        $this->db = new Database($this);

        $ecoPlugin = $this->getConfig()->get("economy", "AZEconomy");
        $ecoClasses = [
            "AZEconomy" => \AZEconomy\AZEconomy::class,
            "SimpleEconomy" => \NhanAZ\SimpleEconomy\Main::class,
            "EconomyAPI" => \onebone\economyapi\EconomyAPI::class,
            "BedrockEconomy" => \cooldogedev\BedrockEconomy\api\BedrockEconomyAPI::class
        ];

        if (!isset($ecoClasses[$ecoPlugin]) || !class_exists($ecoClasses[$ecoPlugin])) {
            $this->getLogger()->error("Lỗi: Không tìm thấy class của plugin kinh tế '$ecoPlugin'. Vui lòng kiểm tra file config.yml!");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        EntityFactory::getInstance()->register(CustomHook::class, function (World $world, CompoundTag $nbt): CustomHook {
            return new CustomHook(EntityDataHelper::parseLocation($nbt, $world), null, $nbt);
        }, ['AZCustomFishingHook', 'minecraft:fishing_hook']);

        GlobalItemDataHandlers::getDeserializer()->map(ItemTypeIds::FISHING_ROD, fn() => new CustomFishingRod());
        StringToItemParser::getInstance()->register("custom_fishing_rod", fn() => new CustomFishingRod());
        
        $parser = \pocketmine\item\enchantment\StringToEnchantmentParser::getInstance();
        $lure = $parser->parse("lure");
        if ($lure === null) {
            $lure = new \pocketmine\item\enchantment\Enchantment("Lure", \pocketmine\item\enchantment\Rarity::RARE, \pocketmine\item\enchantment\ItemFlags::FISHING_ROD, \pocketmine\item\enchantment\ItemFlags::NONE, 5);
            \pocketmine\data\bedrock\EnchantmentIdMap::getInstance()->register(62, $lure);
            $parser->register("lure", fn() => $lure);
        }
        $parser->register("lures", fn() => $lure);

        $luck = $parser->parse("luck_of_the_sea");
        if ($luck === null) {
            $luck = new \pocketmine\item\enchantment\Enchantment("Luck of the Sea", \pocketmine\item\enchantment\Rarity::RARE, \pocketmine\item\enchantment\ItemFlags::FISHING_ROD, \pocketmine\item\enchantment\ItemFlags::NONE, 5);
            \pocketmine\data\bedrock\EnchantmentIdMap::getInstance()->register(61, $luck);
            $parser->register("luck_of_the_sea", fn() => $luck);
        }
        $parser->register("luckofthesea", fn() => $luck);
        $parser->register("luckofsea", fn() => $luck);

        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        $this->getServer()->getCommandMap()->registerAll("AZCustomFishing", [
            new FishingCommand($this),
            new GiveRodCommand($this)
        ]);

        $this->eventTimer = $this->getConfig()->getNested("event.interval", 3600);
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(fn() => $this->checkEventTime()), 20);
    }

    public function getMessage(string $key, array $replacements = []): string {
        $msg = $this->getConfig()->getNested("messages.$key", $key);
        $prefix = $this->getConfig()->getNested("messages.prefix", "");
        $msg = str_replace("{prefix}", $prefix, $msg);
        foreach ($replacements as $search => $replace) {
            $msg = str_replace("{" . $search . "}", (string)$replace, $msg);
        }
        return $msg;
    }

    public function checkEventTime(): void {
        if (!$this->getConfig()->getNested("event.enabled", true)) return;

        $dt = new \DateTime("now", new \DateTimeZone("Asia/Ho_Chi_Minh"));
        $today = $dt->format("Y-m-d");

        if ($this->eventActive) {
            $this->eventTimer--;
            if ($this->eventTimer <= 0) $this->endEvent();
        } elseif ($this->eventRegistering) {
            $currentHour = (int)$dt->format("H");
            $currentMinute = (int)$dt->format("i");
            if ($currentHour > 20 || ($currentHour === 20 && $currentMinute >= 30)) {
                $this->eventRegistering = false;
                $this->eventParticipants = [];
                $this->getServer()->broadcastMessage("§a[Sự kiện Câu Cá]§c Đã quá 20h30 và không đủ người tham gia (cần ít nhất 5 người). Sự kiện đã bị hủy!");
                return;
            }
            $this->registerReminderTimer--;
            if ($this->registerReminderTimer <= 0) {
                $this->registerReminderTimer = 120; // 2 minutes
                $count = count($this->eventParticipants);
                $this->getServer()->broadcastMessage("§a[Sự kiện Câu Cá]§f Đang chờ đăng ký tham gia sự kiện! Hãy gõ lệnh §e/fishing thamgia§f để tham gia. Tiến trình: §b$count/5§f người.");
            }
        } else {
            $currentHour = (int)$dt->format("H");
            $currentMinute = (int)$dt->format("i");
            if ($currentHour === 20 && $currentMinute === 0 && $this->lastEventDate !== $today) {
                $this->startRegistration();
                $this->lastEventDate = $today;
            }
        }
    }

    public function startRegistration(): void {
        $this->eventRegistering = true;
        $this->eventActive = false;
        $this->eventParticipants = [];
        $this->registerReminderTimer = 1; // Show first warning immediately
    }

    public function joinEvent(Player $player): void {
        if (!$this->eventRegistering) {
            $player->sendMessage("§c⚠️ Sự kiện câu cá hiện không trong giai đoạn đăng ký!");
            return;
        }
        $name = $player->getName();
        if (isset($this->eventParticipants[$name])) {
            $player->sendMessage("§c⚠️ Bạn đã đăng ký tham gia sự kiện này rồi!");
            return;
        }
        $this->eventParticipants[$name] = 0;
        $player->sendMessage("§a[AZ]§f Đăng ký tham gia sự kiện câu cá thành công!");
        $count = count($this->eventParticipants);
        $this->getServer()->broadcastMessage("§a[Sự kiện Câu Cá]§f Người chơi §b{$name}§f đã đăng ký tham gia! (Tiến trình: §e$count/5§f người).");
        if ($count >= 5) {
            $this->startEvent();
        }
    }

    public function startEvent(): void {
        $this->eventActive = true;
        $this->eventRegistering = false;
        $this->eventTimer = 1800; // 30 minutes
        $this->getServer()->broadcastMessage("§a[Sự kiện Câu Cá]§f Đã đủ 5 người đăng ký! Sự kiện câu cá chính thức BẮT ĐẦU và sẽ diễn ra trong §b30 phút§f. Chỉ những người chơi đã đăng ký mới có thể câu cá!");
    }

    public function endEvent(): void {
        $this->eventActive = false;
        $this->eventRegistering = false;
        $this->eventTimer = $this->getConfig()->getNested("event.interval", 3600);
        $this->getServer()->broadcastMessage($this->getMessage("event_end"));
        $topPlayer = "";
        $topScore = 0;
        foreach ($this->eventParticipants as $player => $score) {
            if ($score > $topScore) {
                $topScore = $score;
                $topPlayer = $player;
            }
        }
        if ($topPlayer !== "") {
            $this->getServer()->broadcastMessage($this->getMessage("event_top", ["player" => $topPlayer, "score" => $topScore]));
            $playerObj = $this->getServer()->getPlayerExact($topPlayer);
            if ($playerObj !== null) {
                EconomyManager::addMoney($playerObj, 10000);
            }
            $this->getServer()->broadcastMessage($this->getMessage("event_reward", ["player" => $topPlayer, "reward" => 10000]));
        }
        $this->eventParticipants = [];
    }

    public function registerParticipant(string $name): void {
        // Obsoleted, but kept for compatibility
    }

    public function handleEventCatch(Player $player, float $len, string $fishName): void {
        $name = $player->getName();
        $pts = (int)($len);
        $this->db->addPoints($name, $pts);
        if ($this->eventActive && isset($this->eventParticipants[$name])) {
            $this->eventParticipants[$name] += $pts;
            $player->sendActionBarMessage($this->getMessage("event_add_point", ["points" => $pts]));
        }
    }

    public function saveRecord(Player $player, string $fishName, float $len): void {
        $this->db->updateMaxFish($player->getName(), $fishName, $len, time());
    }
}
