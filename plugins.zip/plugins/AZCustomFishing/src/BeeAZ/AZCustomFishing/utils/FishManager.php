<?php

declare(strict_types=1);

namespace BeeAZ\AZCustomFishing\utils;

use BeeAZ\AZCustomFishing\Main;

class FishManager {
    public static function getRodInfo(int $tier): array {
        return Main::getInstance()->getConfig()->get("rods", [])[$tier] ?? ["name" => "Cần câu cơ bản", "price" => 1000, "wait_min" => 100, "wait_max" => 200, "break_chance" => 5, "max_size" => 50];
    }
    public static function getRandomFish(int $tier, int $luckLevel = 0): array {
        $rodInfo = self::getRodInfo($tier);
        $maxSizeRod = $rodInfo['max_size'] ?? 50;

        // Determine allowed categories based on tier
        if ($tier <= 5) {
            $allowedCategories = ["1"];
        } elseif ($tier <= 12) {
            $allowedCategories = ["1", "2"];
        } else {
            $allowedCategories = ["1", "2", "3"];
        }

        // Gather all fish from allowed categories that fit the rod's max size
        $fishPool = [];
        $fishConfig = Main::getInstance()->fishConfig->getAll();
        foreach ($allowedCategories as $cat) {
            if (isset($fishConfig[$cat])) {
                foreach ($fishConfig[$cat] as $fishKey => $fishData) {
                    if (($fishData['base_length'] ?? 0) <= $maxSizeRod) {
                        $fishData['category'] = $cat;
                        $fishPool[] = $fishData;
                    }
                }
            }
        }

        // Fallback default if empty
        if (empty($fishPool)) {
            $fishPool = [["name" => "Cá tạp", "base_length" => 5.0, "base_price" => 5, "category" => "1"]];
        }

        // Weighted selection based on category
        $weightedPool = [];
        foreach ($fishPool as $fish) {
            $weight = 1;
            if (($fish['category'] ?? "1") === "2") {
                $weight = 3;
            } elseif (($fish['category'] ?? "1") === "3") {
                $weight = 5 + ($luckLevel * 2);
            }
            for ($i = 0; $i < $weight; $i++) {
                $weightedPool[] = $fish;
            }
        }

        $fishData = $weightedPool[array_rand($weightedPool)];

        $luckMultiplier = 1.0 + ($luckLevel * 0.15);
        $effectiveMax = $maxSizeRod * $luckMultiplier;
        
        $baseLen = $fishData['base_length'] ?? 5.0;
        
        // Generate random size: 70% to 130% of base_length
        $minLen = $baseLen * 0.7;
        $maxLen = $baseLen * 1.3 * $luckMultiplier;
        
        if ($maxLen > $effectiveMax) {
            $maxLen = $effectiveMax;
        }
        if ($minLen > $maxLen) {
            $minLen = $maxLen * 0.7;
        }

        $minVal = (int)($minLen * 10);
        $maxVal = (int)($maxLen * 10);
        if ($maxVal < $minVal) {
            $maxVal = $minVal + 10;
        }
        
        $length = round(mt_rand($minVal, $maxVal) / 10, 1);
        
        $rawPrice = ($fishData['base_price'] ?? 5) * ($length / $baseLen) * $luckMultiplier;
        
        $price = (int)($rawPrice / (1 + ($rawPrice / 3500)));
        
        if ($price < 1) $price = 1;

        return ["name" => $fishData['name'] ?? "Cá tạp", "length" => $length, "price" => $price];
    }
}
