<?php

declare(strict_types=1);

namespace BeeAZ\AZCustomFishing;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\inventory\CraftItemEvent;
use AZEconomy\AZEconomy;
use pocketmine\item\FishingRod;
use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\world\sound\ThrowSound;
use pocketmine\scheduler\Task;
use BeeAZ\AZCustomFishing\entity\CustomHook;

class EventListener implements Listener
{
    public function onCraft(CraftItemEvent $event): void
    {
        foreach ($event->getOutputs() as $output) {
            if ($output instanceof FishingRod) {
                $player = $event->getPlayer();
                $money = AZEconomy::getInstance()->getMoney($player->getName());
                if ($money < 3000) {
                    $event->cancel();
                    $player->sendMessage("§c⚠️ Bạn cần 3,000 xu để chế tạo Cần câu!");
                    return;
                }
                AZEconomy::getInstance()->reduceMoney($player->getName(), 3000);
                $player->sendMessage("§a[AZ]§f Chế tạo Cần câu thành công! Phí chế tạo: §e-3,000 xu§f.");
                return;
            }
        }
    }

    public function onUseRod(PlayerItemUseEvent $ev): void
    {
        $player = $ev->getPlayer();
        $item = $ev->getItem();
        if ($item instanceof FishingRod) {
            $ev->cancel();
            $name = $player->getName();

            $main = Main::getInstance();


            $tier = $item->getNamedTag()->getTag("tier") !== null ? $item->getNamedTag()->getInt("tier") : 1;
            $session = $main->fishingSession;

            if (isset($session[$name])) {
                $hook = $player->getWorld()->getEntity($session[$name]);
                if ($hook instanceof CustomHook && !$hook->isClosed()) {
                    $hook->reelLine($tier);
                } else {
                    unset($main->fishingSession[$name]);
                }
                if (!$player->isCreative()) {
                    $item->applyDamage(1);
                    $player->getInventory()->setItemInHand($item);
                }
            } else {
                $loc = Location::fromObject($player->getEyePos(), $player->getWorld(), $player->getLocation()->getYaw(), $player->getLocation()->getPitch());
                $hook = new CustomHook($loc, $player);
                $hook->rodTier = $tier;
                $hook->setMotion($player->getDirectionVector()->multiply(1.6));
                $hook->spawnToAll();
                $player->getWorld()->addSound($player->getPosition(), new ThrowSound());
                $main->fishingSession[$name] = $hook->getId();
                $main->registerParticipant($name);
            }
        }
    }

    public function onInventoryTransaction(InventoryTransactionEvent $event): void
    {
        $player = $event->getTransaction()->getSource();
        Main::getInstance()->getScheduler()->scheduleDelayedTask(new class($player) extends Task {
            public function __construct(private Player $player) {}
            public function onRun(): void {
                if ($this->player->isOnline()) {
                    $inv = $this->player->getInventory();
                    $hand = $inv->getItemInHand();
                    if (EventListener::checkAndRebuildLore($hand)) {
                        $inv->setItemInHand($hand);
                    }
                    foreach ($inv->getContents() as $slot => $item) {
                        if (EventListener::checkAndRebuildLore($item)) {
                            $inv->setItem($slot, $item);
                        }
                    }
                }
            }
        }, 1);
    }

    public function onItemHeld(PlayerItemHeldEvent $event): void
    {
        $player = $event->getPlayer();
        Main::getInstance()->getScheduler()->scheduleDelayedTask(new class($player) extends Task {
            public function __construct(private Player $player) {}
            public function onRun(): void {
                if ($this->player->isOnline()) {
                    $inv = $this->player->getInventory();
                    $hand = $inv->getItemInHand();
                    if (EventListener::checkAndRebuildLore($hand)) {
                        $inv->setItemInHand($hand);
                    }
                }
            }
        }, 1);
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        $inv = $player->getInventory();
        foreach ($inv->getContents() as $slot => $item) {
            if (self::checkAndRebuildLore($item)) {
                $inv->setItem($slot, $item);
            }
        }
    }

    public static function checkAndRebuildLore(Item $item): bool
    {
        if ($item->isNull()) {
            return false;
        }

        $lure = \pocketmine\item\enchantment\StringToEnchantmentParser::getInstance()->parse("lure");
        $luck = \pocketmine\item\enchantment\StringToEnchantmentParser::getInstance()->parse("luck_of_the_sea");

        $hasLure = $lure !== null && $item->hasEnchantment($lure);
        $hasLuck = $luck !== null && $item->hasEnchantment($luck);

        $lore = $item->getLore();
        $newLore = [];
        foreach ($lore as $line) {
            $cleanLine = \pocketmine\utils\TextFormat::clean($line);
            $cleanLine = trim(strtolower($cleanLine));
            if (strpos($cleanLine, "lure") === 0 || strpos($cleanLine, "luck of the sea") === 0) {
                continue;
            }
            $newLore[] = $line;
        }

        if ($hasLure) {
            $lvl = $item->getEnchantmentLevel($lure);
            $newLore[] = "§7Lure " . self::getRomanNumeral($lvl);
        }

        if ($hasLuck) {
            $lvl = $item->getEnchantmentLevel($luck);
            $newLore[] = "§7Luck of the Sea " . self::getRomanNumeral($lvl);
        }

        if ($newLore !== $lore) {
            $item->setLore($newLore);
            return true;
        }
        return false;
    }

    private static function getRomanNumeral(int $num): string
    {
        $romans = [
            10 => 'X', 9 => 'IX', 5 => 'V', 4 => 'IV', 1 => 'I'
        ];
        $res = '';
        foreach ($romans as $value => $roman) {
            while ($num >= $value) {
                $res .= $roman;
                $num -= $value;
            }
        }
        return $res !== '' ? $res : (string)$num;
    }
}
