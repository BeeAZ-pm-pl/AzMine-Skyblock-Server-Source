<?php

declare(strict_types=1);

namespace BeeAZ\AZBuyStats;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Input;
use AZEconomy\AZEconomy;
use BeeAZ\AZCustomEnchants\manager\StatsManager;

class Main extends PluginBase {

    private string $prefix = "§d§l[Chỉ Số] §r";

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->prefix = $this->getConfig()->getNested("messages.prefix", "§d§l[Chỉ Số] §r");

        // Verify dependencies
        if (!class_exists(AZEconomy::class)) {
            $this->getLogger()->emergency("AZEconomy không được tìm thấy! Plugin này yêu cầu AZEconomy.");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        if (!class_exists(StatsManager::class)) {
            $this->getLogger()->emergency("AZCustomEnchants không được tìm thấy! Plugin này yêu cầu AZCustomEnchants.");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "muachiso") {
            if (!$sender instanceof Player) {
                $sender->sendMessage($this->getConfig()->getNested("messages.only_player", "Lệnh này chỉ có thể sử dụng trong trò chơi."));
                return true;
            }
            $this->openMainForm($sender);
            return true;
        }
        return false;
    }

    /**
     * Mở menu chính chọn chỉ số muốn mua
     */
    private function openMainForm(Player $player): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.no_item", "§cBạn phải cầm một vật phẩm trên tay để mua chỉ số!"));
            $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
            return;
        }

        $money = AZEconomy::getInstance()->getMoney($player->getName());
        $itemStats = StatsManager::getItemStats($item);

        $prices = $this->getConfig()->get("prices", []);
        $maxLimits = $this->getConfig()->get("max_limits", []);

        $statsNames = [
            "hp" => "Máu (HP)",
            "defense" => "Phòng Thủ (DEFENSE)",
            "pvp" => "Sát Thương Người (PVP)",
            "pve" => "Sát Thương Quái (PVE)",
            "crit" => "Chí Mạng (CRIT)"
        ];

        $options = [];
        $statKeys = [];

        foreach ($statsNames as $key => $name) {
            $price = $prices[$key] ?? 0;
            $currentLvl = (int)($itemStats[$key] ?? 0);
            $maxLvl = $maxLimits[$key] ?? 100;

            $btnText = "§0⚡ §l" . $name . " §r§0⚡\n§7Cấp hiện tại: §a" . $currentLvl . "/" . $maxLvl . " §8| §e" . number_format($price) . " Xu";
            $iconPath = "textures/items/diamond"; // Default fallback
            if ($key === "hp") {
                $iconPath = "textures/items/apple";
            } elseif ($key === "defense") {
                $iconPath = "textures/items/iron_chestplate";
            } elseif ($key === "pvp") {
                $iconPath = "textures/items/diamond_sword";
            } elseif ($key === "pve") {
                $iconPath = "textures/items/iron_sword";
            } elseif ($key === "crit") {
                $iconPath = "textures/items/blaze_powder";
            }

            $options[] = new MenuOption($btnText, new FormIcon($iconPath, FormIcon::IMAGE_TYPE_PATH));
            $statKeys[] = $key;
        }

        $itemName = $item->hasCustomName() ? $item->getCustomName() : $item->getName();
        $content = str_replace(
            ["{item}", "{money}"],
            [$itemName, number_format($money)],
            $this->getConfig()->getNested("ui.main.content")
        );

        $form = new MenuForm(
            $this->getConfig()->getNested("ui.main.title", "§d§lMUA CHỈ SỐ TRANG BỊ"),
            $content,
            $options,
            function(Player $submitter, int $selected) use ($statKeys, $statsNames): void {
                $statKey = $statKeys[$selected];
                $statName = $statsNames[$statKey];
                $this->openUpgradeForm($submitter, $statKey, $statName);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Mở form xác nhận mua số lượng cấp độ chỉ số
     */
    private function openUpgradeForm(Player $player, string $statKey, string $statName): void {
        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.no_item", "§cBạn phải cầm một vật phẩm trên tay để mua chỉ số!"));
            $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
            return;
        }

        $money = AZEconomy::getInstance()->getMoney($player->getName());
        $itemStats = StatsManager::getItemStats($item);
        
        $price = $this->getConfig()->getNested("prices.$statKey", 10000);
        $maxLvl = $this->getConfig()->getNested("max_limits.$statKey", 100);
        $currentLvl = (int)($itemStats[$statKey] ?? 0);

        $content = str_replace(
            ["{stat}", "{price}", "{current}", "{max}", "{money}"],
            [$statName, number_format($price), (string)$currentLvl, (string)$maxLvl, number_format($money)],
            $this->getConfig()->getNested("ui.upgrade.content")
        );

        $form = new CustomForm(
            str_replace("{stat}", $statName, $this->getConfig()->getNested("ui.upgrade.title", "§e§lNÂNG CẤP CHỈ SỐ: {stat}")),
            [
                new Label("lbl_info", $content),
                new Input("amount_input", "Nhập số lượng cấp độ muốn mua thêm:", $this->getConfig()->getNested("ui.upgrade.input_placeholder", "Nhập số lượng cấp (VD: 5)..."), $this->getConfig()->getNested("ui.upgrade.input_default", "1"))
            ],
            function(Player $submitter, CustomFormResponse $response) use ($statKey, $statName, $price, $maxLvl, $currentLvl): void {
                // Double check hand item
                $currentItem = $submitter->getInventory()->getItemInHand();
                if ($currentItem->isNull()) {
                    $submitter->sendMessage($this->prefix . $this->getConfig()->getNested("messages.no_item", "§cBạn phải cầm một vật phẩm trên tay để mua chỉ số!"));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }

                $input = trim($response->getString("amount_input"));
                if (!is_numeric($input)) {
                    $submitter->sendMessage($this->prefix . $this->getConfig()->getNested("messages.invalid_amount"));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }

                $amount = (int)$input;
                if ($amount <= 0) {
                    $submitter->sendMessage($this->prefix . $this->getConfig()->getNested("messages.invalid_amount"));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }

                if ($currentLvl + $amount > $maxLvl) {
                    $submitter->sendMessage($this->prefix . str_replace("{max}", (string)$maxLvl, $this->getConfig()->getNested("messages.limit_reached")));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }

                $cost = $amount * $price;
                $money = AZEconomy::getInstance()->getMoney($submitter->getName());
                if ($money < $cost) {
                    $submitter->sendMessage($this->prefix . str_replace(
                        ["{needed}", "{current}"],
                        [number_format($cost), number_format($money)],
                        $this->getConfig()->getNested("messages.no_money")
                    ));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }

                $success = AZEconomy::getInstance()->reduceMoney($submitter->getName(), $cost);
                if (!$success) {
                    $submitter->sendMessage($this->prefix . "§cĐã xảy ra lỗi trong quá trình giao dịch. Vui lòng thử lại!");
                    return;
                }

                // Update stats
                $itemStats = StatsManager::getItemStats($currentItem);
                $itemStats[$statKey] = $currentLvl + $amount;
                StatsManager::setItemStats($currentItem, $itemStats);
                StatsManager::checkAndRebuildLore($currentItem);

                $submitter->getInventory()->setItemInHand($currentItem);
                $submitter->getWorld()->addSound($submitter->getPosition(), new XpLevelUpSound(1));

                $submitter->sendMessage($this->prefix . str_replace(
                    ["{amount}", "{stat}", "{cost}"],
                    [(string)$amount, $statName, number_format($cost)],
                    $this->getConfig()->getNested("messages.buy_success")
                ));
            }
        );

        $player->sendForm($form);
    }
}
