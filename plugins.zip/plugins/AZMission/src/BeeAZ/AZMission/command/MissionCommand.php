<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginOwned;
use pocketmine\plugin\PluginOwnedTrait;
use BeeAZ\AZMission\Main;
use BeeAZ\AZMission\ui\MissionUI;

class MissionCommand extends Command implements PluginOwned {
    use PluginOwnedTrait;

    public function __construct(private Main $plugin) {
        parent::__construct(
            "mission",
            "Mở giao diện hệ thống nhiệm vụ",
            "/mission",
            ["nv", "nhiemvu"]
        );
        $this->setPermission("azmission.command.user");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) {
            return false;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§cLệnh này chỉ có thể sử dụng trong trò chơi.");
            return true;
        }

        MissionUI::sendMainMenu($sender, $this->plugin);
        return true;
    }
}
