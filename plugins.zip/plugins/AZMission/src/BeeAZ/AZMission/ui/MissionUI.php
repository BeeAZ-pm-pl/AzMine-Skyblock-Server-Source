<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\ui;

use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use BeeAZ\AZMission\Main;
use BeeAZ\AZMission\mission\Mission;

class MissionUI {

    /**
     * Send the main categories menu to the player
     */
    public static function sendMainMenu(Player $player, Main $plugin): void {
        $manager = $plugin->getMissionManager();
        $progressData = $manager->getPlayerProgressData($player);

        // Count completion stats to display on main menu
        $counts = [
            'daily' => ['total' => 0, 'completed' => 0],
            'weekly' => ['total' => 0, 'completed' => 0],
            'repeatable' => ['total' => 0, 'completed' => 0],
            'story' => ['total' => 0, 'completed' => 0],
        ];

        foreach ($manager->getMissions() as $mission) {
            $grp = $mission->getGroup();
            if (isset($counts[$grp])) {
                $counts[$grp]['total']++;
                $prog = $manager->getProgress($player, $mission->getId());
                if ($prog['status'] === 2) {
                    $counts[$grp]['completed']++;
                }
            }
        }

        $options = [
            new MenuOption("§l§eNhiệm Vụ Hằng Ngày\n§r§8Tiến trình: " . $counts['daily']['completed'] . "/" . $counts['daily']['total'], new FormIcon("textures/items/clock_item", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§bNhiệm Vụ Hằng Tuần\n§r§8Tiến trình: " . $counts['weekly']['completed'] . "/" . $counts['weekly']['total'], new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§aNhiệm Vụ Cốt Truyện\n§r§8Tiến trình: " . $counts['story']['completed'] . "/" . $counts['story']['total'], new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
        ];

        $form = new MenuForm(
            "§l§6HỆ THỐNG NHIỆM VỤ",
            "§fChào mừng bạn đến với hệ thống nhiệm vụ. Hãy hoàn thành các nhiệm vụ bên dưới để nhận phần thưởng xứng đáng!\n\n§eChọn danh mục nhiệm vụ:",
            $options,
            function(Player $submitter, int $selected) use ($plugin): void {
                $categories = ['daily', 'weekly', 'story'];
                if (isset($categories[$selected])) {
                    self::sendCategoryList($submitter, $plugin, $categories[$selected]);
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * Send list of missions inside a specific category
     */
    public static function sendCategoryList(Player $player, Main $plugin, string $categoryKey): void {
        $manager = $plugin->getMissionManager();
        
        /** @var Mission[] $categoryMissions */
        $categoryMissions = [];
        foreach ($manager->getMissions() as $mission) {
            if ($mission->getGroup() === $categoryKey) {
                $categoryMissions[] = $mission;
            }
        }

        $titleMap = [
            'daily' => "§l§eNHIỆM VỤ HẰNG NGÀY",
            'weekly' => "§l§bNHIỆM VỤ HẰNG TUẦN",
            'repeatable' => "§l§dNHIỆM VỤ LẶP LẠI",
            'story' => "§l§aNHIỆM VỤ CỐT TRUYỆN"
        ];

        $options = [];
        foreach ($categoryMissions as $mission) {
            $prog = $manager->getProgress($player, $mission->getId());
            $status = $prog['status'];
            
            if ($status === 1) {
                $statusText = "§l§a[HOÀN THÀNH - NHẤN ĐỂ NHẬN THƯỞNG]";
                $iconPath = "textures/items/paper";
            } elseif ($status === 2) {
                $statusText = "§8[Đã nhận thưởng]";
                $iconPath = "textures/items/map_empty";
            } else {
                $statusText = "§e[Đang làm: " . $prog['progress'] . "/" . $mission->getAmount() . "]";
                $iconPath = "textures/items/book_portfolio";
            }
            
            $options[] = new MenuOption(
                $mission->getTitle() . "\n" . $statusText,
                new FormIcon($iconPath, FormIcon::IMAGE_TYPE_PATH)
            );
        }

        $form = new MenuForm(
            $titleMap[$categoryKey] ?? "§l§6DANH SÁCH NHIỆM VỤ",
            "§fChọn một nhiệm vụ để xem chi tiết hoặc nhận quà nếu đã hoàn thành:",
            $options,
            function(Player $submitter, int $selected) use ($plugin, $categoryKey, $categoryMissions): void {
                if (isset($categoryMissions[$selected])) {
                    $mission = $categoryMissions[$selected];
                    $manager = $plugin->getMissionManager();
                    $prog = $manager->getProgress($submitter, $mission->getId());
                    
                    if ($prog['status'] === 1) {
                        // Attempt to claim reward
                        if ($manager->claimReward($submitter, $mission->getId())) {
                            // Refresh list upon successful claim
                            self::sendCategoryList($submitter, $plugin, $categoryKey);
                        }
                    } else {
                        // Open detail page
                        self::sendMissionDetail($submitter, $plugin, $categoryKey, $mission);
                    }
                }
            },
            function(Player $submitter) use ($plugin): void {
                self::sendMainMenu($submitter, $plugin);
            }
        );

        $player->sendForm($form);
    }

    /**
     * Send detailed information about a mission
     */
    public static function sendMissionDetail(Player $player, Main $plugin, string $categoryKey, Mission $mission): void {
        $manager = $plugin->getMissionManager();
        $prog = $manager->getProgress($player, $mission->getId());

        $typeMap = [
            'break_block' => "Đập Block",
            'place_block' => "Đặt Block",
            'kill_mob' => "Tiêu diệt Quái Vật",
            'craft_item' => "Chế tạo Vật Phẩm",
            'consume_item' => "Ăn/Uống Vật Phẩm",
            'fish' => "Câu cá",
            'chat' => "Gửi tin nhắn chat"
        ];

        $statusMap = [
            0 => "§eĐang thực hiện",
            1 => "§aĐã hoàn thành (Chưa nhận quà)",
            2 => "§8Đã hoàn thành & Đã nhận quà"
        ];

        $targetDisplay = $mission->getTarget();
        if (strtolower($targetDisplay) === "any") {
            $targetDisplay = "Bất kỳ";
        }

        $rewardsText = "";
        $money = $mission->getMoneyReward();
        if ($money > 0) {
            $rewardsText .= "  §f- Tiền: §e" . number_format($money) . " xu\n";
        }

        $items = $mission->getItemRewards();
        if (count($items) > 0) {
            $rewardsText .= "  §f- Vật phẩm:\n";
            foreach ($items as $itemStr) {
                $parts = explode(":", $itemStr);
                $itemName = $parts[0];
                $count = isset($parts[1]) ? (int)$parts[1] : 1;
                $rewardsText .= "    §7+ " . $itemName . " x" . $count . "\n";
            }
        }

        if (empty($rewardsText)) {
            $rewardsText = "  §cKhông có phần thưởng trực tiếp.\n";
        }

        $content = "§6§lChi Tiết Nhiệm Vụ:\n" .
            "§fTên: §r" . $mission->getTitle() . "\n" .
            "§fMô tả: §7" . $mission->getDescription() . "\n\n" .
            "§e§lYêu Cầu:\n" .
            "§f- Hành động: §a" . ($typeMap[$mission->getType()] ?? $mission->getType()) . "\n" .
            "§f- Đối tượng: §a" . $targetDisplay . "\n" .
            "§f- Tiến trình: §a" . $prog['progress'] . "§f / §a" . $mission->getAmount() . "\n" .
            "§f- Trạng thái: " . ($statusMap[$prog['status']] ?? "Không rõ") . "\n\n" .
            "§b§lPhần Thưởng:\n" . $rewardsText . "\n" .
            "§8Hoàn thành nhiệm vụ rồi nhấn nút nhận quà từ danh sách ngoài.";

        $options = [
            new MenuOption("§l§0◀ QUAY LẠI", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§6CHI TIẾT NHIỆM VỤ",
            $content,
            $options,
            function(Player $submitter, int $selected) use ($plugin, $categoryKey): void {
                self::sendCategoryList($submitter, $plugin, $categoryKey);
            },
            function(Player $submitter) use ($plugin, $categoryKey): void {
                self::sendCategoryList($submitter, $plugin, $categoryKey);
            }
        );

        $player->sendForm($form);
    }
}
