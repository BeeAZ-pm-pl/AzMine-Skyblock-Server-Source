<?php

declare(strict_types=1);

namespace BeeAZ\AZMission;

use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;
use BeeAZ\AZCustomFishing\event\CustomFishEvent;

class FishingEventListener implements Listener {

    public function __construct(private Main $plugin) {}

    /**
     * Listen to AZCustomFishing's CustomFishEvent
     *
     * @priority MONITOR
     */
    public function onFish(CustomFishEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        
        foreach ($event->getLoot() as $lootItem) {
            $aliases = StringToItemParser::getInstance()->lookupAliases($lootItem);
            $targetName = !empty($aliases) ? $aliases[0] : "";
            
            $this->plugin->getMissionManager()->incrementProgress(
                $player,
                "fish",
                $targetName,
                $lootItem->getCount()
            );
        }
    }
}
