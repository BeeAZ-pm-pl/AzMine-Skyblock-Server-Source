<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\bossbar;

use pocketmine\entity\Entity;
use pocketmine\network\mcpe\protocol\BossEventPacket;
use pocketmine\player\Player;
use BeeAZ\AZMission\Main;

class BossBarManager {

    /** @var array<string, int> Map player name -> bossbar entity runtime ID */
    private array $bossbarEntityIds = [];

    /** @var array<string, bool> Map player name -> is bossbar visible */
    private array $visibleBossBars = [];

    public function __construct(private Main $plugin) {}

    public function getBossBarId(Player $player): int {
        return $player->getId();
    }

    /**
     * Send or update the BossBar for a player
     */
    public function sendBossBar(Player $player, string $title, float $percentage): void {
        if (!$player->isOnline()) return;

        $name = strtolower($player->getName());
        $id = $this->getBossBarId($player);
        $percentage = max(0.0, min(1.0, $percentage)); // Cap between 0.0 and 1.0

        $config = $this->plugin->getConfig()->get("bossbar", []);
        $color = (int)($config['color'] ?? 5);
        $overlay = (int)($config['overlay'] ?? 0);

        if (!isset($this->visibleBossBars[$name]) || !$this->visibleBossBars[$name]) {
            // Show new BossBar
            $packet = BossEventPacket::show(
                $id,
                $title,
                $percentage,
                $color,
                $overlay
            );
            $player->getNetworkSession()->sendDataPacket($packet);
            
            // Modern Bedrock clients require explicit player registration to display the BossBar
            $registerPacket = BossEventPacket::registerPlayer($id, $player->getId());
            $player->getNetworkSession()->sendDataPacket($registerPacket);
            
            $this->visibleBossBars[$name] = true;
        } else {
            // Update existing BossBar
            $healthPacket = BossEventPacket::healthPercent($id, $percentage);
            $titlePacket = BossEventPacket::title($id, $title);
            
            $player->getNetworkSession()->sendDataPacket($healthPacket);
            $player->getNetworkSession()->sendDataPacket($titlePacket);
        }
    }

    /**
     * Hide and remove the BossBar for a player
     */
    public function removeBossBar(Player $player): void {
        $name = strtolower($player->getName());
        if (isset($this->visibleBossBars[$name]) && $this->visibleBossBars[$name]) {
            $id = $this->getBossBarId($player);
            
            // Unregister player from BossBar
            $unregisterPacket = BossEventPacket::unregisterPlayer($id, $player->getId());
            $player->getNetworkSession()->sendDataPacket($unregisterPacket);
            
            $packet = BossEventPacket::hide($id);
            $player->getNetworkSession()->sendDataPacket($packet);
            
            $this->visibleBossBars[$name] = false;
        }
    }

    /**
     * Clean up player session data
     */
    public function unloadPlayer(Player $player): void {
        $name = strtolower($player->getName());
        $this->removeBossBar($player);
        unset($this->bossbarEntityIds[$name]);
        unset($this->visibleBossBars[$name]);
    }
}
