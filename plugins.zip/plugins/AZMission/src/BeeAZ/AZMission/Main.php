<?php

declare(strict_types=1);

namespace BeeAZ\AZMission;

use pocketmine\plugin\PluginBase;
use BeeAZ\AZMission\database\Database;
use BeeAZ\AZMission\bossbar\BossBarManager;
use BeeAZ\AZMission\mission\MissionManager;
use BeeAZ\AZMission\command\MissionCommand;

class Main extends PluginBase {

    private static self $instance;

    private Database $database;
    private BossBarManager $bossBarManager;
    private MissionManager $missionManager;

    protected function onLoad(): void {
        self::$instance = $this;
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->saveDefaultConfig();

        // Timezone setup
        $timezone = $this->getConfig()->get("timezone", "Asia/Ho_Chi_Minh");
        if ($timezone !== "" && in_array($timezone, timezone_identifiers_list(), true)) {
            date_default_timezone_set($timezone);
        }

        // Initialize components
        $this->database = new Database($this->getDataFolder() . "missions.db");
        $this->bossBarManager = new BossBarManager($this);
        $this->missionManager = new MissionManager($this);

        // Register default events listener
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);

        // Soft-dependency: check and register CustomFishing event listener
        if ($this->getServer()->getPluginManager()->getPlugin("AZCustomFishing") !== null) {
            $this->getServer()->getPluginManager()->registerEvents(new FishingEventListener($this), $this);
            $this->getLogger()->info("Đã tích hợp với plugin AZCustomFishing thành công!");
        }

        // Register commands
        $this->getServer()->getCommandMap()->register("azmission", new MissionCommand($this));

        $this->getLogger()->info("Plugin AZMission đã kích hoạt thành công!");
    }

    protected function onDisable(): void {
        if (isset($this->database)) {
            $this->database->close();
        }
        $this->getLogger()->info("Plugin AZMission đã tắt thành công!");
    }

    /**
     * Get Database instance
     */
    public function getDatabase(): Database {
        return $this->database;
    }

    /**
     * Get BossBarManager instance
     */
    public function getBossBarManager(): BossBarManager {
        return $this->bossBarManager;
    }

    /**
     * Get MissionManager instance
     */
    public function getMissionManager(): MissionManager {
        return $this->missionManager;
    }

    /**
     * Get configured messages prefix
     */
    public function getPrefix(): string {
        return $this->getConfig()->getNested("messages.prefix", "§l§7[§6AZMission§7] §r");
    }
}
