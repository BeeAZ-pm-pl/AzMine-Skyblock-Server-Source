<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\mission;

use pocketmine\player\Player;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\item\StringToItemParser;
use pocketmine\Server;
use BeeAZ\AZMission\Main;

class MissionManager {

    /** @var array<string, Mission> Map mission_id -> Mission object */
    private array $missions = [];

    /** @var array<string, array<string, array>> Map player name -> mission_id -> progress data */
    private array $playerProgress = [];

    /** @var array<string, string> Map player name -> currently tracked mission_id on BossBar */
    private array $activeTrackedMission = [];

    public function __construct(private Main $plugin) {
        $this->loadMissions();
    }

    /**
     * Load all mission templates from config
     */
    public function loadMissions(): void {
        $this->missions = [];
        $configMissions = $this->plugin->getConfig()->get("missions", []);
        
        foreach ($configMissions as $group => $list) {
            if (!is_array($list)) continue;
            foreach ($list as $id => $data) {
                $this->missions[$id] = new Mission(
                    (string)$id,
                    (string)$group,
                    (string)($data['title'] ?? $id),
                    (string)($data['description'] ?? ""),
                    (string)($data['type'] ?? ""),
                    (string)($data['target'] ?? ""),
                    (int)($data['amount'] ?? 1),
                    (array)($data['rewards'] ?? [])
                );
            }
        }
    }

    /**
     * Get all loaded missions
     * @return array<string, Mission>
     */
    public function getMissions(): array {
        return $this->missions;
    }

    /**
     * Get a mission by its ID
     */
    public function getMission(string $id): ?Mission {
        return $this->missions[$id] ?? null;
    }

    /**
     * Initialize player session progress, executing resets dynamically
     */
    public function initPlayerProgress(Player $player, array $dbData): void {
        $name = strtolower($player->getName());
        $now = time();
        $currentDayStr = date("Y-m-d", $now);
        $currentWeekStr = date("o-W", $now);
        
        $this->playerProgress[$name] = [];
        
        foreach ($this->missions as $id => $mission) {
            if (isset($dbData[$id])) {
                $row = $dbData[$id];
                $lastUpdate = (int)$row['last_update'];
                
                // Check daily/weekly resets
                $needReset = false;
                if ($mission->getGroup() === "daily") {
                    if (date("Y-m-d", $lastUpdate) !== $currentDayStr) {
                        $needReset = true;
                    }
                } elseif ($mission->getGroup() === "weekly") {
                    if (date("o-W", $lastUpdate) !== $currentWeekStr) {
                        $needReset = true;
                    }
                }
                
                if ($needReset) {
                    $row['progress'] = 0;
                    $row['status'] = 0;
                    $row['last_update'] = $now;
                    
                    // Save reset to DB
                    $this->plugin->getDatabase()->savePlayerProgress(
                        $player->getName(),
                        $id,
                        0,
                        0,
                        (int)$row['completed_count'],
                        $now
                    );
                }
                
                $this->playerProgress[$name][$id] = $row;
            } else {
                // Initialize new mission data
                $row = [
                    'progress' => 0,
                    'status' => 0,
                    'completed_count' => 0,
                    'last_update' => $now
                ];
                
                $this->playerProgress[$name][$id] = $row;
                $this->plugin->getDatabase()->savePlayerProgress(
                    $player->getName(),
                    $id,
                    0,
                    0,
                    0,
                    $now
                );
            }
        }

        // Auto-assign first incomplete mission to BossBar with a 20-tick delay to ensure the player has finished joining/terrain building
        $firstIncomplete = $this->getFirstIncompleteMission($player);
        if ($firstIncomplete !== null) {
            $this->activeTrackedMission[$name] = $firstIncomplete;
            $this->plugin->getScheduler()->scheduleDelayedTask(new class($player, $this) extends \pocketmine\scheduler\Task {
                public function __construct(
                    private Player $player,
                    private MissionManager $manager
                ) {}
                public function onRun(): void {
                    if ($this->player->isOnline()) {
                        $this->manager->updateBossBar($this->player);
                    }
                }
            }, 20);
        }
    }

    /**
     * Unload player session
     */
    public function unloadPlayerProgress(Player $player): void {
        $name = strtolower($player->getName());
        unset($this->playerProgress[$name]);
        unset($this->activeTrackedMission[$name]);
    }

    /**
     * Get player's progress details for a specific mission
     */
    public function getProgress(Player $player, string $missionId): array {
        $name = strtolower($player->getName());
        return $this->playerProgress[$name][$missionId] ?? [
            'progress' => 0,
            'status' => 0,
            'completed_count' => 0,
            'last_update' => time()
        ];
    }

    /**
     * Get all progress details for a player
     */
    public function getPlayerProgressData(Player $player): array {
        $name = strtolower($player->getName());
        return $this->playerProgress[$name] ?? [];
    }

    /**
     * Find the first incomplete/unclaimed mission for a player
     */
    public function getFirstIncompleteMission(Player $player): ?string {
        $name = strtolower($player->getName());
        // Priority order: story -> daily -> weekly -> repeatable
        $groups = ["story", "daily", "weekly", "repeatable"];
        foreach ($groups as $group) {
            foreach ($this->missions as $mission) {
                if ($mission->getGroup() === $group) {
                    $prog = $this->getProgress($player, $mission->getId());
                    if ($prog['status'] === 0 || $prog['status'] === 1) {
                        return $mission->getId();
                    }
                }
            }
        }
        return null;
    }

    /**
     * Set the player's active tracked mission ID
     */
    public function setActiveTrackedMission(Player $player, string $missionId): void {
        $name = strtolower($player->getName());
        if (isset($this->missions[$missionId])) {
            $this->activeTrackedMission[$name] = $missionId;
            $this->updateBossBar($player);
        }
    }

    /**
     * Update/Render BossBar for the player
     */
    public function updateBossBar(Player $player): void {
        if (!$player->isOnline()) return;

        $name = strtolower($player->getName());
        
        // If they have no active tracked mission or it's completed and claimed, auto-find next
        $trackedId = $this->activeTrackedMission[$name] ?? null;
        if ($trackedId !== null) {
            $prog = $this->getProgress($player, $trackedId);
            if ($prog['status'] === 2) {
                $trackedId = null;
            }
        }

        if ($trackedId === null) {
            $firstIncomplete = $this->getFirstIncompleteMission($player);
            if ($firstIncomplete !== null) {
                $this->activeTrackedMission[$name] = $firstIncomplete;
                $trackedId = $firstIncomplete;
            } else {
                // No missions left to complete
                $this->plugin->getBossBarManager()->removeBossBar($player);
                return;
            }
        }

        $mission = $this->missions[$trackedId] ?? null;
        if ($mission === null) {
            $this->plugin->getBossBarManager()->removeBossBar($player);
            return;
        }

        $prog = $this->getProgress($player, $trackedId);

        $bossbarConfig = $this->plugin->getConfig()->get("bossbar", []);
        $barLength = (int)($bossbarConfig['bar_length'] ?? 10);
        $charFill = $bossbarConfig['char_fill'] ?? "|";
        $charEmpty = $bossbarConfig['char_empty'] ?? ".";
        $colorFill = $bossbarConfig['color_fill'] ?? "§a";
        $colorEmpty = $bossbarConfig['color_empty'] ?? "§7";

        $ratio = $prog['progress'] / $mission->getAmount();
        $ratio = max(0.0, min(1.0, $ratio));
        $fillCount = (int)round($ratio * $barLength);
        $emptyCount = $barLength - $fillCount;

        $barStr = "§r" . $colorFill . str_repeat($charFill, $fillCount) . $colorEmpty . str_repeat($charEmpty, $emptyCount);
        $titleTemplate = $bossbarConfig['title'] ?? "§l§eNHIỆM VỤ: §f{title} §a({progress}/{target}) §r{bar}";

        if ($prog['status'] === 1) {
            $titleText = "§aHoàn Thành! Gõ /mission để nhận thưởng";
        } else {
            $titleText = $mission->getTitle();
        }

        $bossbarText = str_replace(
            ["{title}", "{progress}", "{target}", "{percentage}", "{bar}"],
            [$titleText, (string)$prog['progress'], (string)$mission->getAmount(), (string)(int)($ratio * 100), $barStr],
            $titleTemplate
        );

        $this->plugin->getBossBarManager()->sendBossBar($player, $bossbarText, $ratio);
    }

    /**
     * Increment progress for matching missions
     */
    public function incrementProgress(Player $player, string $type, string $target, int $amount = 1): void {
        if ($amount <= 0) return;
        $name = strtolower($player->getName());
        if (!isset($this->playerProgress[$name])) return;

        $now = time();
        $progressUpdated = false;
        
        foreach ($this->missions as $id => $mission) {
            if ($mission->getType() !== $type) continue;
            
            $prog = $this->getProgress($player, $id);
            if ($prog['status'] !== 0) continue; // Only track incomplete
            
            if ($this->matchTarget($mission->getTarget(), $target)) {
                $newProgress = $prog['progress'] + $amount;
                $targetAmount = $mission->getAmount();
                
                $status = 0;
                if ($newProgress >= $targetAmount) {
                    $newProgress = $targetAmount;
                    $status = 1; // Completed, pending claim
                    
                    // Visual/Audio celebration
                    $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(1));
                    $toastMsg = str_replace(
                        "{title}",
                        $mission->getTitle(),
                        $this->plugin->getConfig()->getNested("messages.completed_toast", "")
                    );
                    $player->sendMessage($this->plugin->getPrefix() . $toastMsg);
                }
                
                $this->playerProgress[$name][$id] = [
                    'progress' => $newProgress,
                    'status' => $status,
                    'completed_count' => $prog['completed_count'],
                    'last_update' => $now
                ];
                
                // Save to db asynchronously
                $this->plugin->getDatabase()->savePlayerProgress(
                    $player->getName(),
                    $id,
                    $newProgress,
                    $status,
                    $prog['completed_count'],
                    $now
                );

                // Focus BossBar to this progressed mission
                $this->activeTrackedMission[$name] = $id;
                $progressUpdated = true;
            }
        }

        if ($progressUpdated) {
            $this->updateBossBar($player);
        }
    }

    /**
     * Helper to match mission target with triggered target
     */
    private function matchTarget(string $missionTarget, string $eventTarget): bool {
        $missionTarget = strtolower(trim($missionTarget));
        $eventTarget = strtolower(trim($eventTarget));
        
        if ($missionTarget === "any" || $missionTarget === "") {
            return true;
        }
        
        // Strip namespace prefixes if present for comparison
        $mTarget = $missionTarget;
        $eTarget = $eventTarget;
        if (str_contains($mTarget, ":")) {
            $parts = explode(":", $mTarget);
            $mTarget = end($parts);
        }
        if (str_contains($eTarget, ":")) {
            $parts = explode(":", $eTarget);
            $eTarget = end($parts);
        }
        
        if ($mTarget === $eTarget) {
            return true;
        }

        // Try parsing as items to resolve aliases
        $itemParser = StringToItemParser::getInstance();
        $missionItem = $itemParser->parse($missionTarget);
        $eventItem = $itemParser->parse($eventTarget);
        if ($missionItem !== null && $eventItem !== null) {
            if ($missionItem->equals($eventItem)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Claim reward for a mission
     */
    public function claimReward(Player $player, string $missionId): bool {
        $name = strtolower($player->getName());
        $mission = $this->getMission($missionId);
        if ($mission === null) return false;

        $prog = $this->getProgress($player, $missionId);
        if ($prog['status'] !== 1) {
            $player->sendMessage($this->plugin->getPrefix() . $this->plugin->getConfig()->getNested("messages.not_completed", "Nhiệm vụ chưa hoàn thành!"));
            return false;
        }

        // Verify inventory space first
        $itemRewards = [];
        foreach ($mission->getItemRewards() as $itemStr) {
            $parts = explode(":", $itemStr);
            $itemName = $parts[0];
            $count = isset($parts[1]) ? (int)$parts[1] : 1;
            
            $item = StringToItemParser::getInstance()->parse($itemName);
            if ($item !== null) {
                $item->setCount($count);
                $itemRewards[] = $item;
            }
        }

        // Check if player has space for all items
        $inventory = $player->getInventory();
        foreach ($itemRewards as $item) {
            if (!$inventory->canAddItem($item)) {
                $player->sendMessage($this->plugin->getPrefix() . $this->plugin->getConfig()->getNested("messages.inventory_full", "Túi đồ đầy!"));
                return false;
            }
        }

        // Give items
        foreach ($itemRewards as $item) {
            $inventory->addItem($item);
        }

        // Give money (AZEconomy)
        $money = $mission->getMoneyReward();
        if ($money > 0) {
            if (class_exists(\AZEconomy\AZEconomy::class)) {
                \AZEconomy\AZEconomy::getInstance()->addMoney($player->getName(), $money);
            } else {
                $this->plugin->getLogger()->warning("AZEconomy not found, skipping money reward for " . $player->getName());
            }
        }

        // Run commands
        $server = Server::getInstance();
        foreach ($mission->getCommandRewards() as $cmd) {
            $cmd = str_replace("{player}", '"' . $player->getName() . '"', $cmd);
            $server->dispatchCommand(new ConsoleCommandSender($server, $server->getLanguage()), $cmd);
        }

        // Update progress state
        $now = time();
        $newCount = $prog['completed_count'] + 1;
        
        if ($mission->getGroup() === "repeatable") {
            // Repeatable resets to 0 immediately
            $this->playerProgress[$name][$missionId] = [
                'progress' => 0,
                'status' => 0,
                'completed_count' => $newCount,
                'last_update' => $now
            ];
            
            $this->plugin->getDatabase()->savePlayerProgress(
                $player->getName(),
                $missionId,
                0,
                0,
                $newCount,
                $now
            );
        } else {
            // Non-repeatable becomes claimed (2)
            $this->playerProgress[$name][$missionId] = [
                'progress' => $mission->getAmount(),
                'status' => 2,
                'completed_count' => $newCount,
                'last_update' => $now
            ];
            
            $this->plugin->getDatabase()->savePlayerProgress(
                $player->getName(),
                $missionId,
                $mission->getAmount(),
                2,
                $newCount,
                $now
            );
        }

        // Message
        $successMsg = str_replace(
            "{title}",
            $mission->getTitle(),
            $this->plugin->getConfig()->getNested("messages.claimed_reward", "")
        );
        $player->sendMessage($this->plugin->getPrefix() . $successMsg);
        
        // Play level up sound on claim too
        $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(1));

        // Update BossBar (it will auto find next or hide/reset)
        $this->updateBossBar($player);
        return true;
    }
}
