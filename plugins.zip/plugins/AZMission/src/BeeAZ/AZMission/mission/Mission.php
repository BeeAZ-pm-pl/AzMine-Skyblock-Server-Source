<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\mission;

class Mission {

    public function __construct(
        private string $id,
        private string $group,
        private string $title,
        private string $description,
        private string $type,
        private string $target,
        private int $amount,
        private array $rewards
    ) {}

    public function getId(): string {
        return $this->id;
    }

    public function getGroup(): string {
        return $this->group;
    }

    public function getTitle(): string {
        return $this->title;
    }

    public function getDescription(): string {
        return $this->description;
    }

    public function getType(): string {
        return $this->type;
    }

    public function getTarget(): string {
        return $this->target;
    }

    public function getAmount(): int {
        return $this->amount;
    }

    public function getRewards(): array {
        return $this->rewards;
    }

    public function getMoneyReward(): int {
        return (int)($this->rewards['money'] ?? 0);
    }

    public function getCommandRewards(): array {
        return (array)($this->rewards['commands'] ?? []);
    }

    public function getItemRewards(): array {
        return (array)($this->rewards['items'] ?? []);
    }
}
