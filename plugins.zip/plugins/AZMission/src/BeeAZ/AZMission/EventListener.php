<?php

declare(strict_types=1);

namespace BeeAZ\AZMission;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;

class EventListener implements Listener {

    public function __construct(private Main $plugin) {}

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        
        // Load data synchronously on join to prevent async race conditions during gameplay
        $dbData = $this->plugin->getDatabase()->loadPlayerProgress($player->getName());
        $this->plugin->getMissionManager()->initPlayerProgress($player, $dbData);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        
        // Unload player data and clean up BossBar
        $this->plugin->getBossBarManager()->unloadPlayer($player);
        $this->plugin->getMissionManager()->unloadPlayerProgress($player);
    }

    /**
     * @priority MONITOR
     */
    public function onBreak(BlockBreakEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        $item = $event->getBlock()->asItem();
        
        $aliases = StringToItemParser::getInstance()->lookupAliases($item);
        $targetName = !empty($aliases) ? $aliases[0] : "";
        
        $this->plugin->getMissionManager()->incrementProgress($player, "break_block", $targetName);
    }

    /**
     * @priority MONITOR
     */
    public function onPlace(BlockPlaceEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        
        $item = null;
        foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            $item = $block->asItem();
            break;
        }
        
        if ($item === null) return;
        
        $aliases = StringToItemParser::getInstance()->lookupAliases($item);
        $targetName = !empty($aliases) ? $aliases[0] : "";
        
        $this->plugin->getMissionManager()->incrementProgress($player, "place_block", $targetName);
    }

    public function onDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        $cause = $entity->getLastDamageCause();
        
        if ($cause instanceof EntityDamageByEntityEvent) {
            $damager = $cause->getDamager();
            if ($damager instanceof Player) {
                // Get short name of entity class (e.g. Zombie, Skeleton, Cow, Pig)
                $entityClass = (new \ReflectionClass($entity))->getShortName();
                $this->plugin->getMissionManager()->incrementProgress($damager, "kill_mob", $entityClass);
            }
        }
    }

    /**
     * @priority MONITOR
     */
    public function onCraft(CraftItemEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        
        foreach ($event->getOutputs() as $output) {
            $aliases = StringToItemParser::getInstance()->lookupAliases($output);
            $targetName = !empty($aliases) ? $aliases[0] : "";
            
            $this->plugin->getMissionManager()->incrementProgress(
                $player, 
                "craft_item", 
                $targetName, 
                $output->getCount()
            );
        }
    }

    /**
     * @priority MONITOR
     */
    public function onConsume(PlayerItemConsumeEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        $item = $event->getItem();
        
        $aliases = StringToItemParser::getInstance()->lookupAliases($item);
        $targetName = !empty($aliases) ? $aliases[0] : "";
        
        $this->plugin->getMissionManager()->incrementProgress($player, "consume_item", $targetName);
    }

    /**
     * @priority MONITOR
     */
    public function onChat(PlayerChatEvent $event): void {
        if ($event->isCancelled()) return;
        $player = $event->getPlayer();
        
        $this->plugin->getMissionManager()->incrementProgress($player, "chat", "any");
    }
}
