<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\database;

use pocketmine\Server;

class Database {

    private \SQLite3 $db;
    private string $dbPath;

    public function __construct(string $path) {
        $this->dbPath = $path;
        $this->db = new \SQLite3($path);
        $this->db->busyTimeout(5000);
        
        // Create progress table
        $this->db->exec("CREATE TABLE IF NOT EXISTS missions_progress (
            username TEXT,
            mission_id TEXT,
            progress INTEGER,
            status INTEGER,
            completed_count INTEGER,
            last_update INTEGER,
            PRIMARY KEY(username, mission_id)
        )");
    }

    /**
     * Load player progress synchronously
     * 
     * @param string $username
     * @return array
     */
    public function loadPlayerProgress(string $username): array {
        $username = strtolower($username);
        $stmt = $this->db->prepare("SELECT * FROM missions_progress WHERE LOWER(username) = :username");
        $stmt->bindValue(":username", $username, SQLITE3_TEXT);
        $result = $stmt->execute();
        
        $progressData = [];
        if ($result !== false) {
            while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $progressData[$row['mission_id']] = [
                    'progress' => (int)$row['progress'],
                    'status' => (int)$row['status'],
                    'completed_count' => (int)$row['completed_count'],
                    'last_update' => (int)$row['last_update']
                ];
            }
        }
        return $progressData;
    }

    /**
     * Asynchronously save a player's mission progress
     */
    public function savePlayerProgress(
        string $username,
        string $missionId,
        int $progress,
        int $status,
        int $completedCount,
        int $lastUpdate
    ): void {
        Server::getInstance()->getAsyncPool()->submitTask(new MissionSaveTask(
            $this->dbPath,
            "save_progress",
            serialize([
                'username' => strtolower($username),
                'mission_id' => $missionId,
                'progress' => $progress,
                'status' => $status,
                'completed_count' => $completedCount,
                'last_update' => $lastUpdate
            ])
        ));
    }

    /**
     * Close the database
     */
    public function close(): void {
        $this->db->close();
    }
}
