<?php

declare(strict_types=1);

namespace BeeAZ\AZMission\database;

use pocketmine\scheduler\AsyncTask;

class MissionSaveTask extends AsyncTask {

    private string $serializedData;

    /**
     * @param string $dbPath
     * @param string $action
     * @param string $serializedData
     */
    public function __construct(
        private string $dbPath,
        private string $action,
        string $serializedData
    ) {
        $this->serializedData = $serializedData;
    }

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);

        $data = unserialize($this->serializedData);

        switch ($this->action) {
            case "save_progress":
                $stmt = $db->prepare("INSERT OR REPLACE INTO missions_progress (username, mission_id, progress, status, completed_count, last_update) VALUES (:username, :mission_id, :progress, :status, :completed_count, :last_update)");
                $stmt->bindValue(":username", $data['username'], SQLITE3_TEXT);
                $stmt->bindValue(":mission_id", $data['mission_id'], SQLITE3_TEXT);
                $stmt->bindValue(":progress", $data['progress'], SQLITE3_INTEGER);
                $stmt->bindValue(":status", $data['status'], SQLITE3_INTEGER);
                $stmt->bindValue(":completed_count", $data['completed_count'], SQLITE3_INTEGER);
                $stmt->bindValue(":last_update", $data['last_update'], SQLITE3_INTEGER);
                $stmt->execute();
                break;

            case "save_all_progress":
                // Save an array of rows
                $db->exec("BEGIN TRANSACTION");
                $stmt = $db->prepare("INSERT OR REPLACE INTO missions_progress (username, mission_id, progress, status, completed_count, last_update) VALUES (:username, :mission_id, :progress, :status, :completed_count, :last_update)");
                foreach ($data as $row) {
                    $stmt->bindValue(":username", $row['username'], SQLITE3_TEXT);
                    $stmt->bindValue(":mission_id", $row['mission_id'], SQLITE3_TEXT);
                    $stmt->bindValue(":progress", $row['progress'], SQLITE3_INTEGER);
                    $stmt->bindValue(":status", $row['status'], SQLITE3_INTEGER);
                    $stmt->bindValue(":completed_count", $row['completed_count'], SQLITE3_INTEGER);
                    $stmt->bindValue(":last_update", $row['last_update'], SQLITE3_INTEGER);
                    $stmt->execute();
                }
                $db->exec("COMMIT");
                break;

            case "delete_progress":
                $stmt = $db->prepare("DELETE FROM missions_progress WHERE username = :username AND mission_id = :mission_id");
                $stmt->bindValue(":username", $data['username'], SQLITE3_TEXT);
                $stmt->bindValue(":mission_id", $data['mission_id'], SQLITE3_TEXT);
                $stmt->execute();
                break;
        }

        $db->close();
    }
}
