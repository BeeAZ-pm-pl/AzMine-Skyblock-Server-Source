<?php

declare(strict_types=1);

namespace BeeAZ\AZWarp;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use pocketmine\world\Position;

class Main extends PluginBase {

    protected function onEnable() : void {
        $this->saveDefaultConfig();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if ($command->getName() === "warp") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cLệnh này chỉ dành cho người chơi trong game!");
                return true;
            }
            $this->openWarpMenu($sender);
            return true;
        }
        return false;
    }

    public function openWarpMenu(Player $player) : void {
        $config = $this->getConfig();
        $title = $config->get("title", "§l§1⚡ MENU DỊCH CHUYỂN ⚡");
        $description = $config->get("description", "§eChọn địa điểm bạn muốn dịch chuyển đến:");
        $warps = $config->get("warps", []);

        $options = [];
        $warpKeys = array_keys($warps);

        foreach ($warpKeys as $key) {
            $data = $warps[$key];
            $name = $data["name"] ?? $key;
            $desc = $data["description"] ?? "";
            
            $icon = null;
            if (isset($data["icon_type"], $data["icon_path"]) && $data["icon_path"] !== "") {
                $iconType = $data["icon_type"] === "url" ? FormIcon::IMAGE_TYPE_URL : FormIcon::IMAGE_TYPE_PATH;
                $icon = new FormIcon($data["icon_path"], $iconType);
            }

            $btnText = $name;
            if ($desc !== "") {
                $btnText .= "\n" . $desc;
            }

            $options[] = new MenuOption($btnText, $icon);
        }

        $form = new MenuForm(
            $title,
            $description,
            $options,
            function (Player $submitter, int $selected) use ($warps, $warpKeys) : void {
                $key = $warpKeys[$selected];
                $data = $warps[$key];
                $worldName = $data["world"] ?? null;

                if ($worldName === null || $worldName === "") {
                    $submitter->sendMessage("§cLỗi: Không có thế giới đích nào được thiết lập cho địa điểm này!");
                    return;
                }

                $worldManager = $this->getServer()->getWorldManager();

                if (!$worldManager->isWorldLoaded($worldName)) {
                    if (!$worldManager->loadWorld($worldName)) {
                        $submitter->sendMessage("§cKhông thể tải thế giới '{$worldName}'!");
                        return;
                    }
                }

                $world = $worldManager->getWorldByName($worldName);
                if ($world === null) {
                    $submitter->sendMessage("§cThế giới '{$worldName}' không tồn tại hoặc lỗi tải!");
                    return;
                }

                $x = $data["x"] ?? null;
                $y = $data["y"] ?? null;
                $z = $data["z"] ?? null;

                if ($x !== null && $y !== null && $z !== null) {
                    $pos = new Position((float)$x, (float)$y, (float)$z, $world);
                } else {
                    $pos = $world->getSpawnLocation();
                }

                $submitter->teleport($pos);
                
                $name = $data["name"] ?? $key;
                $cleanName = str_replace(["§l", "§c", "§6", "⚔", "💰"], "", $name);
                $cleanName = trim($cleanName);
                
                $submitter->sendMessage("§aDịch chuyển thành công đến §e" . $cleanName . "§a!");
            },
            function (Player $submitter) : void {
                // Do nothing when closed
            }
        );

        $player->sendForm($form);
    }
}
