<?php

declare(strict_types=1);

namespace azworldprotect;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerToggleFlightEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\entity\EntityTeleportEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\entity\EntityTrampleFarmlandEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;
use pocketmine\math\Facing;
use pocketmine\block\Block;

class EventListener implements Listener {
    
    /** @var array<string, float> */
    private array $lastGroundY = [];

    public function __construct(private Main $plugin) {}

    private function isProtected(string $world): bool {
        return in_array($world, $this->plugin->cfg->get("protected-worlds", []));
    }

    private function canBypass(Player $player): bool {
        return $player->hasPermission("azworldprotect.bypass");
    }

    private function isClimbable(Block $block): bool {
        $name = strtolower($block->getName());
        return strpos($name, "ladder") !== false || 
               strpos($name, "vine") !== false || 
               strpos($name, "scaffolding") !== false || 
               strpos($name, "water") !== false || 
               strpos($name, "liquid") !== false;
    }

    public function onBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        if ($this->isProtected($player->getWorld()->getFolderName()) && !$this->canBypass($player)) {
            $event->cancel();
        }
    }

    public function onPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        if ($this->isProtected($player->getWorld()->getFolderName()) && !$this->canBypass($player)) {
            $event->cancel();
        }
    }

    public function onTrample(EntityTrampleFarmlandEvent $event): void {
        if ($this->isProtected($event->getEntity()->getWorld()->getFolderName())) {
            $event->cancel();
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        unset($this->lastGroundY[$event->getPlayer()->getName()]);
    }

    // ==================== BAN ITEM ====================
    public function onItemUse(PlayerItemUseEvent $event): void {
        $player = $event->getPlayer();
        if ($this->canBypass($player)) return;

        $world = $player->getWorld()->getFolderName();
        $bannedItems = $this->plugin->cfg->getNested("ban-items." . $world, []);
        if (empty($bannedItems)) return;

        $item = $event->getItem();
        $aliases = StringToItemParser::getInstance()->lookupAliases($item);
        
        foreach ($bannedItems as $banned) {
            $banned = strtolower((string)$banned);
            if (in_array($banned, $aliases, true)) {
                $event->cancel();
                $player->sendMessage("§c§l⚡ §r§cVật phẩm §e" . $item->getName() . " §cbị cấm sử dụng tại thế giới này!");
                return;
            }
        }
    }

    // ==================== BAN FLY ====================
    public function onToggleFlight(PlayerToggleFlightEvent $event): void {
        $player = $event->getPlayer();
        if ($this->canBypass($player)) return;

        $world = $player->getWorld()->getFolderName();
        $banFlyWorlds = $this->plugin->cfg->get("ban-fly", []);
        
        if (in_array($world, $banFlyWorlds) && $event->isFlying()) {
            $event->cancel();
            $player->setAllowFlight(false);
            $player->setFlying(false);
            $player->sendMessage("§c§l⚡ §r§cBạn không được phép bay tại thế giới này!");
        }
    }

    public function onTeleport(EntityTeleportEvent $event): void {
        $player = $event->getEntity();
        if (!$player instanceof Player) return;
        if ($this->canBypass($player)) return;

        $from = $event->getFrom();
        $to = $event->getTo();
        if ($from->getWorld()->getId() === $to->getWorld()->getId()) return;

        $world = $to->getWorld()->getFolderName();
        $banFlyWorlds = $this->plugin->cfg->get("ban-fly", []);
        if (in_array($world, $banFlyWorlds)) {
            $player->setFlying(false);
            $player->setAllowFlight(false);
            unset($this->lastGroundY[$player->getName()]);
        }
    }

    // ==================== BAN SPIDER (WALL CLIMB) & FLY FORCE ENFORCE ====================
    public function onMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if ($this->canBypass($player)) return;

        $world = $player->getWorld()->getFolderName();

        // 1. Force ban fly check on move (in case they bypassed onToggleFlight or entered world with fly on)
        $banFlyWorlds = $this->plugin->cfg->get("ban-fly", []);
        if (in_array($world, $banFlyWorlds) && ($player->isFlying() || $player->getAllowFlight())) {
            $player->setFlying(false);
            $player->setAllowFlight(false);
            $player->sendMessage("§c§l⚡ §r§cBạn không được phép bay tại thế giới này!");
            return;
        }

        // 2. Wall climb protection
        $banSpiderWorlds = $this->plugin->cfg->get("ban-spider", []);
        if (!in_array($world, $banSpiderWorlds)) return;

        $from = $event->getFrom();
        $to = $event->getTo();
        $dy = $to->getY() - $from->getY();

        $name = $player->getName();
        $pos = $player->getPosition();

        // Check if player is on ground (block below is solid)
        $blockBelow = $player->getWorld()->getBlock($pos->subtract(0, 0.1, 0));
        
        if (!$blockBelow->isTransparent() && !$this->isClimbable($blockBelow)) {
            $this->lastGroundY[$name] = $pos->getY();
        }

        // Only check climbing if moving upward, not flying
        if ($dy <= 0.0 || $player->isFlying() || $player->getAllowFlight()) return;

        $playerBlock = $player->getWorld()->getBlock($pos);
        if ($this->isClimbable($playerBlock) || $this->isClimbable($blockBelow)) {
            return; // Climbing ladder/vine/water is allowed
        }

        $groundY = $this->lastGroundY[$name] ?? $pos->getY();
        $heightInAir = $pos->getY() - $groundY;

        // If height in air exceeds jump limit (1.8 blocks)
        if ($heightInAir > 1.8) {
            $hasAdjacentWall = false;
            foreach ([Facing::NORTH, Facing::SOUTH, Facing::EAST, Facing::WEST] as $face) {
                $sideBlock = $playerBlock->getSide($face);
                if (!$sideBlock->isTransparent()) {
                    $hasAdjacentWall = true;
                    break;
                }
            }

            if ($hasAdjacentWall) {
                $event->cancel();
                $player->sendMessage("§c§l⚡ §r§cBạn không được phép leo tường tại thế giới này!");
            }
        }
    }

    // ==================== BAN PVP ====================
    public function onDamage(EntityDamageByEntityEvent $event): void {
        $entity = $event->getEntity();
        $damager = $event->getDamager();

        if ($entity instanceof Player && $damager instanceof Player) {
            $world = $entity->getWorld()->getFolderName();
            $banPvpWorlds = $this->plugin->cfg->get("ban-pvp", []);
            
            if (in_array($world, $banPvpWorlds)) {
                $event->cancel();
                $damager->sendMessage("§c§l⚡ §r§cPVP đã bị cấm tại thế giới này!");
            }
        }
    }
}