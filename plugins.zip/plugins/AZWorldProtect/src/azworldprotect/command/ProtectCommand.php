<?php

namespace azworldprotect\command;

use azworldprotect\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class ProtectCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("azworldprotect", "Quản lý AZWorldProtect", "/azwp <add|remove|list|banitem|banfly|banspider> [world] [item]", ["azwp", "wp"]);
        $this->setPermission("azworldprotect.command");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return false;

        if (count($args) < 1) {
            $this->sendHelp($sender);
            return false;
        }

        switch (strtolower($args[0])) {
            case "add":
                if (count($args) < 2) {
                    $sender->sendMessage("§c⚡ §lVui lòng nhập tên thế giới!");
                    return false;
                }
                if ($this->plugin->addWorld($args[1])) {
                    $sender->sendMessage("§a⚡ §lĐã thêm thế giới §f" . $args[1] . " §avào danh sách bảo vệ!");
                } else {
                    $sender->sendMessage("§c⚡ §lThế giới này đã có trong danh sách bảo vệ!");
                }
                break;

            case "remove":
            case "del":
                if (count($args) < 2) {
                    $sender->sendMessage("§c⚡ §lVui lòng nhập tên thế giới!");
                    return false;
                }
                if ($this->plugin->removeWorld($args[1])) {
                    $sender->sendMessage("§a⚡ §lĐã xóa thế giới §f" . $args[1] . " §akhỏi danh sách bảo vệ!");
                } else {
                    $sender->sendMessage("§c⚡ §lThế giới này không nằm trong danh sách bảo vệ!");
                }
                break;

            case "list":
                $worlds = $this->plugin->getWorlds();
                if (empty($worlds)) {
                    $sender->sendMessage("§c⚡ §lHiện chưa có thế giới nào được bảo vệ!");
                } else {
                    $sender->sendMessage("§e⚡ §lDanh sách thế giới được bảo vệ: §f" . implode(", ", $worlds));
                }
                
                $banFly = $this->plugin->cfg->get("ban-fly", []);
                $banSpider = $this->plugin->cfg->get("ban-spider", []);
                $banItems = $this->plugin->cfg->get("ban-items", []);
                
                if (!empty($banFly)) {
                    $sender->sendMessage("§e⚡ §lBan Fly: §f" . implode(", ", $banFly));
                }
                if (!empty($banSpider)) {
                    $sender->sendMessage("§e⚡ §lBan Spider: §f" . implode(", ", $banSpider));
                }
                if (!empty($banItems)) {
                    foreach ($banItems as $world => $items) {
                        $sender->sendMessage("§e⚡ §lBan Items [§f" . $world . "§e]: §7" . implode(", ", $items));
                    }
                }
                break;

            // ==================== BAN ITEM ====================
            case "banitem":
                if (count($args) < 3) {
                    $sender->sendMessage("§e⚡ §lSử dụng: /azwp banitem <add|remove> <world> <item_id>");
                    return false;
                }
                $sub = strtolower($args[1]);
                if ($sub === "add") {
                    if (count($args) < 4) {
                        $sender->sendMessage("§c⚡ §lCần nhập: /azwp banitem add <world> <item_id>");
                        return false;
                    }
                    $world = $args[2];
                    $itemId = strtolower($args[3]);
                    $list = $this->plugin->cfg->getNested("ban-items." . $world, []);
                    if (!in_array($itemId, $list)) {
                        $list[] = $itemId;
                        $this->plugin->cfg->setNested("ban-items." . $world, $list);
                        $this->plugin->cfg->save();
                        $sender->sendMessage("§a⚡ §lĐã thêm §e" . $itemId . " §avào danh sách cấm tại §f" . $world);
                    } else {
                        $sender->sendMessage("§c⚡ §lItem §e" . $itemId . " §cđã có trong danh sách cấm!");
                    }
                } elseif ($sub === "remove" || $sub === "del") {
                    if (count($args) < 4) {
                        $sender->sendMessage("§c⚡ §lCần nhập: /azwp banitem remove <world> <item_id>");
                        return false;
                    }
                    $world = $args[2];
                    $itemId = strtolower($args[3]);
                    $list = $this->plugin->cfg->getNested("ban-items." . $world, []);
                    $key = array_search($itemId, $list);
                    if ($key !== false) {
                        unset($list[$key]);
                        $this->plugin->cfg->setNested("ban-items." . $world, array_values($list));
                        $this->plugin->cfg->save();
                        $sender->sendMessage("§a⚡ §lĐã gỡ §e" . $itemId . " §akhỏi danh sách cấm tại §f" . $world);
                    } else {
                        $sender->sendMessage("§c⚡ §lItem §e" . $itemId . " §ckhông nằm trong danh sách cấm!");
                    }
                } else {
                    $sender->sendMessage("§e⚡ §lSử dụng: /azwp banitem <add|remove> <world> <item_id>");
                }
                break;

            // ==================== BAN FLY ====================
            case "banfly":
                if (count($args) < 3) {
                    $sender->sendMessage("§e⚡ §lSử dụng: /azwp banfly <add|remove> <world>");
                    return false;
                }
                $sub = strtolower($args[1]);
                $world = $args[2];
                $list = $this->plugin->cfg->get("ban-fly", []);
                if ($sub === "add") {
                    if (!in_array($world, $list)) {
                        $list[] = $world;
                        $this->plugin->cfg->set("ban-fly", $list);
                        $this->plugin->cfg->save();
                        $sender->sendMessage("§a⚡ §lĐã bật cấm bay tại §f" . $world);
                    } else {
                        $sender->sendMessage("§c⚡ §lThế giới §f" . $world . " §cđã có trong danh sách cấm bay!");
                    }
                } elseif ($sub === "remove" || $sub === "del") {
                    $key = array_search($world, $list);
                    if ($key !== false) {
                        unset($list[$key]);
                        $this->plugin->cfg->set("ban-fly", array_values($list));
                        $this->plugin->cfg->save();
                        $sender->sendMessage("§a⚡ §lĐã gỡ cấm bay tại §f" . $world);
                    } else {
                        $sender->sendMessage("§c⚡ §lThế giới §f" . $world . " §ckhông có trong danh sách cấm bay!");
                    }
                } else {
                    $sender->sendMessage("§e⚡ §lSử dụng: /azwp banfly <add|remove> <world>");
                }
                break;

            // ==================== BAN SPIDER ====================
            case "banspider":
                if (count($args) < 3) {
                    $sender->sendMessage("§e⚡ §lSử dụng: /azwp banspider <add|remove> <world>");
                    return false;
                }
                $sub = strtolower($args[1]);
                $world = $args[2];
                $list = $this->plugin->cfg->get("ban-spider", []);
                if ($sub === "add") {
                    if (!in_array($world, $list)) {
                        $list[] = $world;
                        $this->plugin->cfg->set("ban-spider", $list);
                        $this->plugin->cfg->save();
                        $sender->sendMessage("§a⚡ §lĐã bật cấm leo tường tại §f" . $world);
                    } else {
                        $sender->sendMessage("§c⚡ §lThế giới §f" . $world . " §cđã có trong danh sách cấm leo tường!");
                    }
                } elseif ($sub === "remove" || $sub === "del") {
                    $key = array_search($world, $list);
                    if ($key !== false) {
                        unset($list[$key]);
                        $this->plugin->cfg->set("ban-spider", array_values($list));
                        $this->plugin->cfg->save();
                        $sender->sendMessage("§a⚡ §lĐã gỡ cấm leo tường tại §f" . $world);
                    } else {
                        $sender->sendMessage("§c⚡ §lThế giới §f" . $world . " §ckhông có trong danh sách cấm leo tường!");
                    }
                } else {
                    $sender->sendMessage("§e⚡ §lSử dụng: /azwp banspider <add|remove> <world>");
                }
                break;

            default:
                $this->sendHelp($sender);
                break;
        }

        return true;
    }

    private function sendHelp(CommandSender $sender): void {
        $sender->sendMessage("§e§l⚡ AZWorldProtect ⚡");
        $sender->sendMessage("§7/azwp add <world> §f- Thêm thế giới bảo vệ");
        $sender->sendMessage("§7/azwp remove <world> §f- Gỡ thế giới bảo vệ");
        $sender->sendMessage("§7/azwp list §f- Xem danh sách");
        $sender->sendMessage("§7/azwp banitem add/remove <world> <item> §f- Cấm item");
        $sender->sendMessage("§7/azwp banfly add/remove <world> §f- Cấm bay");
        $sender->sendMessage("§7/azwp banspider add/remove <world> §f- Cấm leo tường");
    }
}