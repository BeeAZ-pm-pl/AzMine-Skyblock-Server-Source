<?php

namespace azworldprotect;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use azworldprotect\command\ProtectCommand;

class Main extends PluginBase {
    public Config $cfg;

    protected function onEnable(): void {
        $this->saveResource("config.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getServer()->getCommandMap()->register("azworldprotect", new ProtectCommand($this));
    }

    public function getWorlds(): array {
        return $this->cfg->get("protected-worlds", []);
    }

    public function addWorld(string $world): bool {
        $worlds = $this->getWorlds();
        if (!in_array($world, $worlds)) {
            $worlds[] = $world;
            $this->cfg->set("protected-worlds", $worlds);
            $this->cfg->save();
            return true;
        }
        return false;
    }

    public function removeWorld(string $world): bool {
        $worlds = $this->getWorlds();
        $key = array_search($world, $worlds);
        if ($key !== false) {
            unset($worlds[$key]);
            $this->cfg->set("protected-worlds", array_values($worlds));
            $this->cfg->save();
            return true;
        }
        return false;
    }
}