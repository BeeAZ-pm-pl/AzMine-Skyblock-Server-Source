<?php

namespace azscorehud\api;

use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;

class ScoreboardAPI {
    public static function send(Player $player, string $title, array $lines): void {
        self::remove($player);

        $pk = new SetDisplayObjectivePacket();
        $pk->displaySlot = "sidebar";
        $pk->objectiveName = "azscore";
        $pk->displayName = $title;
        $pk->criteriaName = "dummy";
        $pk->sortOrder = 0;
        $player->getNetworkSession()->sendDataPacket($pk);

        $entries = [];
        foreach ($lines as $score => $line) {
            $entry = new ScorePacketEntry();
            $entry->objectiveName = "azscore";
            $entry->type = ScorePacketEntry::TYPE_FAKE_PLAYER;
            $entry->customName = $line;
            $entry->score = $score;
            $entry->scoreboardId = $score;
            $entries[] = $entry;
        }

        $pk2 = new SetScorePacket();
        $pk2->type = SetScorePacket::TYPE_CHANGE;
        $pk2->entries = $entries;
        $player->getNetworkSession()->sendDataPacket($pk2);
    }

    public static function remove(Player $player): void {
        $pk = new RemoveObjectivePacket();
        $pk->objectiveName = "azscore";
        $player->getNetworkSession()->sendDataPacket($pk);
    }
}