<?php

declare(strict_types=1);

namespace azscorehud\task;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use azscorehud\Main;

class ScoreboardLoadTask extends AsyncTask {

    public function __construct(
        private string $dbPath,
        private string $username
    ) {}

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $stmt = $db->prepare("SELECT settings FROM scoreboard_settings WHERE username = :username");
        $stmt->bindValue(":username", strtolower($this->username), SQLITE3_TEXT);
        $res = $stmt->execute();
        
        $settings = null;
        if ($res !== false) {
            $row = $res->fetchArray(SQLITE3_ASSOC);
            if ($row !== false && isset($row["settings"])) {
                $settings = json_decode($row["settings"], true);
            }
        }
        
        $db->close();
        $this->setResult($settings);
    }

    public function onCompletion() : void {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("AZScorehud");
        if ($plugin instanceof Main && $plugin->isEnabled()) {
            $plugin->onSettingsLoaded($this->username, $this->getResult());
        }
    }
}
