<?php

declare(strict_types=1);

namespace azscorehud\task;

use pocketmine\scheduler\AsyncTask;

class ScoreboardSaveTask extends AsyncTask {

    public function __construct(
        private string $dbPath,
        private string $username,
        private string $settingsJson
    ) {}

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $stmt = $db->prepare("INSERT OR REPLACE INTO scoreboard_settings (username, settings) VALUES (:username, :settings)");
        $stmt->bindValue(":username", strtolower($this->username), SQLITE3_TEXT);
        $stmt->bindValue(":settings", $this->settingsJson, SQLITE3_TEXT);
        $stmt->execute();
        
        $db->close();
    }
}
