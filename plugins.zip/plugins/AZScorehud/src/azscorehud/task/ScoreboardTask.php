<?php

namespace azscorehud\task;

use azscorehud\Main;
use pocketmine\scheduler\Task;
use azscorehud\api\ScoreboardAPI;

class ScoreboardTask extends Task {
    private int $tick = 0;
    private array $colors = ["§c", "§6", "§e", "§a", "§b", "§9", "§d"];

    public function __construct(private Main $plugin) {}

    public function onRun(): void {
        $color1 = $this->colors[$this->tick % count($this->colors)];
        $color2 = $this->colors[($this->tick + 1) % count($this->colors)];
        
        $title = "§r" . mb_chr(0xE100);
        $this->tick++;

        $onlineCount = count($this->plugin->getServer()->getOnlinePlayers());
        $maxPlayers = $this->plugin->getServer()->getMaxPlayers();

        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            if (!$player->isOnline()) continue;

            $name = $player->getName();
            $ping = $player->getNetworkSession()->getPing();

            $rank = "Guest";
            $azrank = $this->plugin->getServer()->getPluginManager()->getPlugin("AZRank");
            if ($azrank !== null) {
                $rank = $azrank->rank->getRank($name);
            }

            $money = 0;
            $coin = 0;
            $azeco = $this->plugin->getServer()->getPluginManager()->getPlugin("AZEconomy");
            if ($azeco !== null) {
                if (method_exists($azeco, "getMoney")) {
                    $money = $azeco->getMoney($name);
                }
                if (method_exists($azeco, "getCoin")) {
                    $coin = $azeco->getCoin($name);
                }
            }

            $islandData = "§cChưa có";
            $azskyblock = $this->plugin->getServer()->getPluginManager()->getPlugin("AZSkyBlock");
            if ($azskyblock !== null) {
                $islandId = $azskyblock->island->getIslandByPlayer($name);
                if ($islandId !== null) {
                    $data = $azskyblock->db->cache[$islandId] ?? null;
                    if ($data !== null) {
                        $islandData = "Lv." . ($data['level'] ?? 1) . " §f| §e" . ($data['points'] ?? 0) . " Điểm";
                    }
                }
            }

            $seasonData = "§cKhông rõ";
            $azseason = $this->plugin->getServer()->getPluginManager()->getPlugin("AZSeason");
            if ($azseason !== null) {
                $seasonData = $azseason->getSeasonManager()->getSeasonVietnamese();
            }

            $clanData = "§cChưa có";
            $azfaction = $this->plugin->getServer()->getPluginManager()->getPlugin("AZFaction");
            if ($azfaction !== null) {
                $factionName = $azfaction->getDatabase()->getPlayerFaction($name);
                if ($factionName !== null) {
                    $clanData = "§b" . $factionName;
                }
            }

            $realmName = "§7Phàm Nhân";
            $tuviValue = 0;
            $azcanhgioi = $this->plugin->getServer()->getPluginManager()->getPlugin("AZCanhGioi");
            if ($azcanhgioi !== null && $azcanhgioi->isEnabled()) {
                /** @var \BeeAZ\AZCanhGioi\Main $azcanhgioi */
                $realmName = $azcanhgioi->getPlayerRealmName($name);
                $tuviValue = $azcanhgioi->getTuvi($name);
            }

            $settings = $this->plugin->getPlayerSettings($name);
            if (!$settings["enabled"]) {
                ScoreboardAPI::remove($player);
                continue;
            }

            $lines = [];
            $lines[1] = " ";
            $index = 2;

            if ($settings["show_name"]) {
                $lines[$index++] = $color1 . "⚡ §fTên: §a" . $name;
            }
            if ($settings["show_rank"]) {
                $lines[$index++] = $color1 . "⚡ §fRank: §e" . $rank;
            }
            if ($settings["show_clan"]) {
                $lines[$index++] = $color1 . "⚡ §fClan: " . $clanData;
            }
            if ($settings["show_money"]) {
                $lines[$index++] = $color1 . "⚡ §fTiền: §e" . number_format((float)$money);
            }
            if ($settings["show_coin"]) {
                $lines[$index++] = $color1 . "⚡ §fCoin: §e" . number_format((float)$coin);
            }
            if ($settings["show_realm"]) {
                $lines[$index++] = $color1 . "⚡ §f" . $realmName;
            }
            if ($settings["show_tuvi"]) {
                $lines[$index++] = $color1 . "⚡ §fTu Vi: §a" . number_format($tuviValue);
            }
            if ($settings["show_island"]) {
                $lines[$index++] = $color1 . "⚡ §fĐảo: §a" . $islandData;
            }
            if ($settings["show_season"]) {
                $lines[$index++] = $color1 . "⚡ §fMùa: §e" . $seasonData;
            }
            if ($settings["show_ping"]) {
                $lines[$index++] = $color1 . "⚡ §fPing: §a" . $ping . "ms";
            }
            if ($settings["show_online"]) {
                $lines[$index++] = $color1 . "⚡ §fOnline: §a" . $onlineCount . "§7/§a" . $maxPlayers;
            }

            $lines[$index] = "§7-------------------- ";

            ScoreboardAPI::send($player, $title, $lines);
        }
    }
}