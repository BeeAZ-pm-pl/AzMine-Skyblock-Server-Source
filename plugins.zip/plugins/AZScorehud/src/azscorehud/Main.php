<?php

namespace azscorehud;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use azscorehud\task\ScoreboardTask;
use azscorehud\task\ScoreboardLoadTask;
use azscorehud\task\ScoreboardSaveTask;
use azscorehud\api\ScoreboardAPI;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Toggle;

class Main extends PluginBase implements Listener {

    public const DEFAULT_SETTINGS = [
        "enabled" => true,
        "show_name" => true,
        "show_rank" => true,
        "show_clan" => true,
        "show_money" => true,
        "show_coin" => true,
        "show_realm" => true,
        "show_tuvi" => true,
        "show_island" => true,
        "show_season" => true,
        "show_ping" => true,
        "show_online" => true
    ];

    private string $dbPath;
    private array $cache = [];

    protected function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->dbPath = $this->getDataFolder() . "scoreboard.db";

        $db = new \SQLite3($this->dbPath);
        $db->exec("CREATE TABLE IF NOT EXISTS scoreboard_settings (username TEXT PRIMARY KEY, settings TEXT)");
        $db->close();

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getScheduler()->scheduleRepeatingTask(new ScoreboardTask($this), 10);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $this->getServer()->getAsyncPool()->submitTask(new ScoreboardLoadTask($this->dbPath, $player->getName()));
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $username = strtolower($event->getPlayer()->getName());
        unset($this->cache[$username]);
        ScoreboardAPI::remove($event->getPlayer());
    }

    public function onSettingsLoaded(string $username, ?array $settings): void {
        $usernameLower = strtolower($username);
        if ($settings === null) {
            $this->cache[$usernameLower] = self::DEFAULT_SETTINGS;
        } else {
            $this->cache[$usernameLower] = array_merge(self::DEFAULT_SETTINGS, $settings);
        }
    }

    public function getPlayerSettings(string $username): array {
        return $this->cache[strtolower($username)] ?? self::DEFAULT_SETTINGS;
    }

    public function setPlayerSettings(string $username, array $settings): void {
        $this->cache[strtolower($username)] = $settings;
        $this->getServer()->getAsyncPool()->submitTask(new ScoreboardSaveTask($this->dbPath, $username, json_encode($settings)));
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "scoreboard" && $sender instanceof Player) {
            $this->openSettingsForm($sender);
            return true;
        }
        return false;
    }

    public function openSettingsForm(Player $player): void {
        $username = $player->getName();
        $settings = $this->getPlayerSettings($username);

        $form = new CustomForm(
            "§l§aCÀI ĐẶT SCOREBOARD",
            [
                new Toggle("enabled", "§l§eKích hoạt Scoreboard (Bật/Tắt)§r", $settings["enabled"]),
                new Toggle("show_name", "§fHiển thị Tên", $settings["show_name"]),
                new Toggle("show_rank", "§fHiển thị Rank", $settings["show_rank"]),
                new Toggle("show_clan", "§fHiển thị Clan", $settings["show_clan"]),
                new Toggle("show_money", "§fHiển thị Tiền", $settings["show_money"]),
                new Toggle("show_coin", "§fHiển thị Coin", $settings["show_coin"]),
                new Toggle("show_realm", "§fHiển thị Cảnh Giới", $settings["show_realm"]),
                new Toggle("show_tuvi", "§fHiển thị Tu Vi", $settings["show_tuvi"]),
                new Toggle("show_island", "§fHiển thị Đảo", $settings["show_island"]),
                new Toggle("show_season", "§fHiển thị Mùa", $settings["show_season"]),
                new Toggle("show_ping", "§fHiển thị Ping", $settings["show_ping"]),
                new Toggle("show_online", "§fHiển thị Online", $settings["show_online"])
            ],
            function(Player $submitter, CustomFormResponse $response) use ($username): void {
                $newSettings = [
                    "enabled" => $response->getBool("enabled"),
                    "show_name" => $response->getBool("show_name"),
                    "show_rank" => $response->getBool("show_rank"),
                    "show_clan" => $response->getBool("show_clan"),
                    "show_money" => $response->getBool("show_money"),
                    "show_coin" => $response->getBool("show_coin"),
                    "show_realm" => $response->getBool("show_realm"),
                    "show_tuvi" => $response->getBool("show_tuvi"),
                    "show_island" => $response->getBool("show_island"),
                    "show_season" => $response->getBool("show_season"),
                    "show_ping" => $response->getBool("show_ping"),
                    "show_online" => $response->getBool("show_online")
                ];
                
                $this->setPlayerSettings($username, $newSettings);
                $submitter->sendMessage("§aĐã cập nhật cài đặt Scoreboard thành công!");
                
                if (!$newSettings["enabled"]) {
                    ScoreboardAPI::remove($submitter);
                }
            },
            function(Player $submitter): void {}
        );

        $player->sendForm($form);
    }
}