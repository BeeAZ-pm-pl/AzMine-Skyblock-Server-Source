<?php

declare(strict_types=1);

namespace BeeAZ\AZRankBooster;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\entity\effect\EffectInstance;

class Main extends PluginBase implements Listener {

    private array $vanished = [];
    private array $spiderMode = [];

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Lệnh này chỉ dùng cho người chơi.");
            return true;
        }

        $cmdName = strtolower($command->getName());
        $prefix = $this->getConfig()->getNested("messages.prefix", "§l§7[§6AZRank§7] §r");

        switch ($cmdName) {
            case "fly":
                if (strpos($sender->getWorld()->getFolderName(), "dungeon_") === 0) {
                    $sender->sendMessage($prefix . "§cBạn không thể bay trong phó bản!");
                    return true;
                }
                if ($sender->getAllowFlight()) {
                    $sender->setAllowFlight(false);
                    $sender->setFlying(false);
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.fly-off", "§cFly OFF"));
                } else {
                    $sender->setAllowFlight(true);
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.fly-on", "§aFly ON"));
                }
                return true;

            case "spider":
                if (strpos($sender->getWorld()->getFolderName(), "dungeon_") === 0) {
                    $sender->sendMessage($prefix . "§cBạn không thể leo tường trong phó bản!");
                    return true;
                }
                $name = strtolower($sender->getName());
                if (isset($this->spiderMode[$name])) {
                    unset($this->spiderMode[$name]);
                    $sender->setCanClimbWalls(false);
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.spider-off", "§cSpider OFF"));
                } else {
                    $this->spiderMode[$name] = true;
                    $sender->setCanClimbWalls(true);
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.spider-on", "§aSpider ON"));
                }
                return true;

            case "invisible":
                $name = strtolower($sender->getName());
                if (isset($this->vanished[$name])) {
                    unset($this->vanished[$name]);
                    foreach ($this->getServer()->getOnlinePlayers() as $other) {
                        if ($other !== $sender) {
                            $other->showPlayer($sender);
                        }
                    }
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.vanish-off", "§cVanish OFF"));
                } else {
                    $this->vanished[$name] = true;
                    foreach ($this->getServer()->getOnlinePlayers() as $other) {
                        if ($other !== $sender) {
                            $other->hidePlayer($sender);
                        }
                    }
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.vanish-on", "§aVanish ON"));
                }
                return true;

            case "speed":
                if (!isset($args[0])) {
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.speed-invalid", "§cChọn 1-5"));
                    return true;
                }
                $level = (int)$args[0];
                if ($level === 0) {
                    $sender->setMovementSpeed(0.1);
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.speed-reset", "§cSpeed reset"));
                    return true;
                }
                if ($level < 1 || $level > 5) {
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.speed-invalid", "§cChọn 1-5"));
                    return true;
                }
                $speeds = [1 => 0.15, 2 => 0.20, 3 => 0.25, 4 => 0.30, 5 => 0.40];
                $sender->setMovementSpeed($speeds[$level]);
                $sender->sendMessage($prefix . str_replace("{level}", (string)$level, $this->getConfig()->getNested("messages.speed-set", "§aSpeed set")));
                return true;

            case "jump":
                if (!isset($args[0])) {
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.jump-invalid", "§cChọn 1-5"));
                    return true;
                }
                $level = (int)$args[0];
                if ($level === 0) {
                    $sender->getEffects()->remove(VanillaEffects::JUMP_BOOST());
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.jump-reset", "§cJump reset"));
                    return true;
                }
                if ($level < 1 || $level > 5) {
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.jump-invalid", "§cChọn 1-5"));
                    return true;
                }
                $sender->getEffects()->add(new EffectInstance(VanillaEffects::JUMP_BOOST(), 20 * 999999, $level - 1, false));
                $sender->sendMessage($prefix . str_replace("{level}", (string)$level, $this->getConfig()->getNested("messages.jump-set", "§aJump set")));
                return true;

            case "nv":
                if ($sender->getEffects()->has(VanillaEffects::NIGHT_VISION())) {
                    $sender->getEffects()->remove(VanillaEffects::NIGHT_VISION());
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.nv-off", "§cNight Vision OFF"));
                } else {
                    $sender->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 20 * 999999, 0, false));
                    $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.nv-on", "§aNight Vision ON"));
                }
                return true;

            case "feed":
                $sender->getHungerManager()->setFood($sender->getHungerManager()->getMaxFood());
                $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.feed-success", "§aFed"));
                return true;

            case "heal":
                $sender->setHealth($sender->getMaxHealth());
                $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.heal-success", "§aHealed"));
                return true;
        }

        return false;
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $joined = $event->getPlayer();
        // Hide vanished players from the newly joined player
        foreach ($this->vanished as $name => $val) {
            $vanishedPlayer = $this->getServer()->getPlayerExact($name);
            if ($vanishedPlayer !== null) {
                $joined->hidePlayer($vanishedPlayer);
            }
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $name = strtolower($event->getPlayer()->getName());
        unset($this->vanished[$name]);
        unset($this->spiderMode[$name]);
    }

    public function disableSpiderMode(Player $player): void {
        $name = strtolower($player->getName());
        if (isset($this->spiderMode[$name])) {
            unset($this->spiderMode[$name]);
            $player->setCanClimbWalls(false);
        }
    }
}
