<?php

declare(strict_types=1);

namespace BeeAZ\AZJackpot\listener;

use BeeAZ\AZJackpot\entity\SlotMachineEntity;
use BeeAZ\AZJackpot\ui\JackpotUI;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerEntityInteractEvent;
use pocketmine\event\entity\EntityDamageEvent;

class JackpotListener implements Listener {

    public function onPlayerEntityInteract(PlayerEntityInteractEvent $event): void {
        $entity = $event->getEntity();
        $player = $event->getPlayer();

        if ($entity instanceof SlotMachineEntity) {
            $event->cancel();

            $name = $player->getName();
            $main = \BeeAZ\AZJackpot\Main::getInstance();
            if (isset($main->removeMode[$name])) {
                unset($main->removeMode[$name]);
                $entity->close();
                $player->sendMessage("§a[Jackpot] Đã xóa thành công máy quay Jackpot!");
                return;
            }

            if ($entity->isSpinning()) {
                $player->sendActionBarMessage("§cMáy quay đang bận!");
                return;
            }

            $item = $player->getInventory()->getItemInHand();
            $tag = $item->getNamedTag()->getTag("jackpot_ticket");

            if ($tag !== null) {
                $value = $tag->getValue();
                
                $item->pop();
                $player->getInventory()->setItemInHand($item);

                $entity->startSpin($player, $value);
                $player->sendActionBarMessage("§aĐã sử dụng 1 Vé Quay (" . number_format($value) . " Xu)!");
            } else {
                JackpotUI::openMainMenu($player, $entity);
            }
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof SlotMachineEntity) {
            $event->cancel();
        }
    }
}
