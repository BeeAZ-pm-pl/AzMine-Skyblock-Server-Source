<?php

declare(strict_types=1);

namespace BeeAZ\AZJackpot;

use BeeAZ\AZJackpot\command\JackpotCommand;
use BeeAZ\AZJackpot\entity\SlotMachineEntity;
use BeeAZ\AZJackpot\listener\JackpotListener;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use function str_replace;

class Main extends PluginBase {
    use SingletonTrait;

    /** @var array<string, bool> */
    public array $removeMode = [];

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();

        // Register custom entity
        EntityFactory::getInstance()->register(SlotMachineEntity::class, function(World $world, CompoundTag $nbt): SlotMachineEntity {
            return new SlotMachineEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
        }, ["slot:slot_machine"]);

        // Register client identifier so players can see the model
        try {
            $instance = \pocketmine\network\mcpe\cache\StaticPacketCache::getInstance();
            $property = (new \ReflectionClass($instance))->getProperty("availableActorIdentifiers");
            $packet = $property->getValue($instance);
            $root = $packet->identifiers->getRoot();
            
            $idList = $root->getListTag("idlist");
            if ($idList !== null) {
                $registeredId = "slot:slot_machine";
                $existingIds = [];
                foreach ($idList as $tag) {
                    if ($tag instanceof CompoundTag) {
                        $existingIds[] = $tag->getString("id", "");
                    }
                }
                if (!in_array($registeredId, $existingIds, true)) {
                    $idList->push(CompoundTag::create()
                        ->setString("id", $registeredId)
                        ->setString("bid", "")
                    );
                }
                $packet->identifiers = new \pocketmine\network\mcpe\protocol\types\CacheableNbt($root);
            }
        } catch (\Exception $e) {
            $this->getLogger()->error("§cLỗi đăng ký client identifiers: " . $e->getMessage());
        }

        // Register command
        $this->getServer()->getCommandMap()->register("azjackpot", new JackpotCommand(
            "jackpot",
            "Mở hệ thống máy quay cược Jackpot",
            "/jackpot",
            ["slotmachine", "gamba", "cuoc"]
        ));

        // Register listener
        $this->getServer()->getPluginManager()->registerEvents(new JackpotListener(), $this);

        $this->getLogger()->info("§aAZJackpot đã khởi chạy thành công!");
    }

    /**
     * Helper to create a Jackpot Ticket Item
     */
    public function getTicketItem(int $value, int $amount = 1): \pocketmine\item\Item {
        $item = \pocketmine\item\VanillaItems::PAPER();
        $item->setCount($amount);
        $item->setCustomName("§r§l§e⚡ Vé Quay Jackpot: §a" . number_format($value) . " Xu ⚡");
        $item->setLore([
            "§r§7Dùng để quay máy Jackpot.",
            "§r§7Mức cược tương đương: §a" . number_format($value) . " Xu",
            "§r§7Sử dụng bằng cách nhấp vào máy Jackpot."
        ]);
        $nbt = $item->getNamedTag();
        $nbt->setInt("jackpot_ticket", $value);
        $item->setNamedTag($nbt);
        return $item;
    }

    /**
     * Get a formatted message from config
     */
    public function getMessage(string $key, array $replacements = []): string {
        $msg = $this->getConfig()->getNested("messages." . $key, $key);
        foreach ($replacements as $search => $replace) {
            $msg = str_replace("{" . $search . "}", (string)$replace, $msg);
        }
        return $msg;
    }
}
