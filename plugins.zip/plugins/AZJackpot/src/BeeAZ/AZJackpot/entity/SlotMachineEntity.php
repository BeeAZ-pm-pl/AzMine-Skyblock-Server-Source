<?php

declare(strict_types=1);

namespace BeeAZ\AZJackpot\entity;

use BeeAZ\AZJackpot\Main;
use BeeAZ\AZJackpot\utils\EconomyManager;
use pocketmine\entity\Living;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\PopSound;
use pocketmine\world\sound\ExplodeSound;
use pocketmine\Server;
use function array_sum;
use function mt_rand;
use function number_format;

class SlotMachineEntity extends Living {

    private bool $isSpinning = false;
    private ?Player $spinPlayer = null;
    private ?string $lastResult = null;

    public static function getNetworkTypeId(): string {
        return "slot:slot_machine";
    }

    public function getName(): string {
        return "Slot Machine";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.063, 0.5);
    }

    public function isSpinning(): bool {
        return $this->isSpinning;
    }

    public function getSpinPlayer(): ?Player {
        return $this->spinPlayer;
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setScale(2.0);
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTagVisible(true);
        $this->setCanSaveWithChunk(true);
        $this->setMaxHealth(100);
        $this->setHealth(100);
        $this->updateNameTag();
    }

    public function onUpdate(int $currentTick): bool {
        $this->setMotion($this->getMotion()->withComponents(0, 0, 0));
        $this->setGravity(0.0);
        if ($this->isOnFire()) {
            $this->extinguish();
        }
        return parent::onUpdate($currentTick);
    }

    public function attack(\pocketmine\event\entity\EntityDamageEvent $source): void {
        $source->cancel();
    }

    public function updateNameTag(): void {
        if ($this->isSpinning && $this->spinPlayer !== null) {
            $this->setNameTag("§l§c⚡ MÁY QUAY JACKPOT ⚡\n§6Đang quay bởi: §e" . $this->spinPlayer->getName() . "\n§7Chúc bạn may mắn!");
        } else {
            $tag = "§l§c⚡ MÁY QUAY JACKPOT ⚡\n§eNhấp chuột phải để chơi!";
            if ($this->lastResult !== null) {
                $tag .= "\n§7Kết quả gần nhất: §b" . $this->lastResult;
            }
            $this->setNameTag($tag);
        }
    }

    public function sendAnimation(string $animationName, string $controllerName = ""): void {
        $packet = AnimateEntityPacket::create($animationName, "", "", 0, $controllerName, 0.0, [$this->getId()]);
        $this->getWorld()->broadcastPacketToViewers($this->getLocation(), $packet);
    }

    public function sendStopAnimation(string $animationName, string $controllerName = ""): void {
        $packet = AnimateEntityPacket::create($animationName, "", "1", 0, $controllerName, 0.0, [$this->getId()]);
        $this->getWorld()->broadcastPacketToViewers($this->getLocation(), $packet);
    }

    public function playSound(string $soundName): void {
        $pos = $this->getLocation();
        $packet = PlaySoundPacket::create($soundName, $pos->getX(), $pos->getY(), $pos->getZ(), 1.0, 1.0, null);
        $this->getWorld()->broadcastPacketToViewers($pos, $packet);
    }

    private function rollReel(): int {
        $weights = [
            0 => 2,   // Emerald (Jackpot!)
            7 => 4,   // Netherite
            1 => 8,   // Diamond
            2 => 12,  // Gold
            3 => 15,  // Lapis
            4 => 18,  // Iron
            5 => 20,  // Copper
            6 => 25,  // Coal
        ];
        
        $totalWeight = array_sum($weights);
        $roll = mt_rand(1, $totalWeight);
        $currentWeight = 0;
        foreach ($weights as $value => $weight) {
            $currentWeight += $weight;
            if ($roll <= $currentWeight) {
                return $value;
            }
        }
        return 6; // Default to Coal
    }

    public function startSpin(Player $player, int $betAmount): void {
        $this->isSpinning = true;
        $this->spinPlayer = $player;
        $this->lastResult = null;
        $this->updateNameTag();

        // 1. Play handle animation & sound
        $this->sendAnimation("handle", "handle");
        $this->playSound("random.chestopen");

        // 2. Play reel loop animations & sound
        $this->sendAnimation("reel1loop", "reel1");
        $this->sendAnimation("reel2loop", "reel2");
        $this->sendAnimation("reel3loop", "reel3");
        $this->playSound("slot:loopreelsound");

        // 3. Roll the results
        $r1 = $this->rollReel();
        $r2 = $this->rollReel();
        $r3 = $this->rollReel();

        $itemNames = [
            0 => "emerald",
            1 => "diamond",
            2 => "gold",
            3 => "lapiz",
            4 => "iron",
            5 => "copper",
            6 => "coal",
            7 => "netherite"
        ];
        $displayNames = [
            0 => "EMERALD",
            1 => "DIAMOND",
            2 => "GOLD",
            3 => "LAPIS",
            4 => "IRON",
            5 => "COPPER",
            6 => "COAL",
            7 => "NETHERITE"
        ];

        $name1 = $itemNames[$r1];
        $name2 = $itemNames[$r2];
        $name3 = $itemNames[$r3];

        $disp1 = $displayNames[$r1];
        $disp2 = $displayNames[$r2];
        $disp3 = $displayNames[$r3];

        $scheduler = Main::getInstance()->getScheduler();

        // Stop reel 1 loop and play end animation at 1.5s (30 ticks)
        $scheduler->scheduleDelayedTask(new ClosureTask(function() use ($name1): void {
            if ($this->isClosed()) return;
            $this->sendStopAnimation("reel1loop", "reel1");
            $this->sendAnimation("reel1" . $name1, "reel1");
        }), 30);

        // Stop reel 2 loop and play end animation at 2.0s (40 ticks)
        $scheduler->scheduleDelayedTask(new ClosureTask(function() use ($name2): void {
            if ($this->isClosed()) return;
            $this->sendStopAnimation("reel2loop", "reel2");
            $this->sendAnimation("reel2" . $name2, "reel2");
        }), 40);

        // Stop reel 3 loop and play end animation at 2.5s (50 ticks)
        $scheduler->scheduleDelayedTask(new ClosureTask(function() use ($name3): void {
            if ($this->isClosed()) return;
            $this->sendStopAnimation("reel3loop", "reel3");
            $this->sendAnimation("reel3" . $name3, "reel3");
        }), 50);

        // Calculate payout and display results at 3.2s (64 ticks)
        $scheduler->scheduleDelayedTask(new ClosureTask(function() use ($player, $betAmount, $r1, $r2, $r3, $disp1, $disp2, $disp3): void {
            if ($this->isClosed()) return;
            $this->isSpinning = false;
            $this->spinPlayer = null;
            $this->lastResult = "$disp1 - $disp2 - $disp3";
            $this->updateNameTag();

            if (!$player->isOnline()) return;

            $plugin = Main::getInstance();
            $config = $plugin->getConfig();

            // Payout calculation
            $payoutMultiplier = 0.0;
            $isTriple = false;
            $isDouble = false;

            if ($r1 === $r2 && $r2 === $r3) {
                $isTriple = true;
                $payoutMultiplier = 3;
            } elseif ($r1 === $r2 || $r2 === $r3 || $r1 === $r3) {
                $isDouble = true;
                $payoutMultiplier = 1.0;
            }

            if ($payoutMultiplier > 0.0) {
                // Win
                $reward = (int)($betAmount * $payoutMultiplier);
                $profit = $reward - $betAmount;

                EconomyManager::addMoney($player, $reward, function(bool $addSuccess) use ($player, $r1, $disp1, $reward, $profit, $isTriple, $plugin): void {
                    if (!$player->isOnline()) return;

                    if ($isTriple) {
                        $msg = $plugin->getMessage("win_triple", [
                            "item" => $disp1,
                            "reward" => number_format($reward),
                            "profit" => number_format($profit)
                        ]);
                        $player->sendMessage($msg);

                        // Broadcast to server if it's a huge jackpot
                        if ($r1 === 0 || $r1 === 7 || $r1 === 1) {
                            $serverMsg = "§l§e[JACKPOT] §fChúc mừng người chơi §a" . $player->getName() . " §fđã nổ hũ §d3x " . $disp1 . " §fvà nhận §e" . number_format($reward) . " $§f!!!";
                            Server::getInstance()->broadcastMessage($serverMsg);
                        }
                    } else {
                        $msg = $plugin->getMessage("win_double", [
                            "reward" => number_format($reward),
                            "profit" => number_format($profit)
                        ]);
                        $player->sendMessage($msg);
                    }

                    $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(30));
                });
            } else {
                // Lose
                $msg = $plugin->getMessage("lose", [
                    "bet" => number_format($betAmount),
                    "r1" => $disp1,
                    "r2" => $disp2,
                    "r3" => $disp3
                ]);
                $player->sendMessage($msg);
                $player->getWorld()->addSound($player->getPosition(), new PopSound());

                // Jail chance check
                $jailChance = (int)$config->get("jail_chance_on_lose", 5);
                if (mt_rand(1, 100) <= $jailChance) {
                    $jailTimeConfig = $config->get("jail_time", ["min" => 2, "max" => 5]);
                    $minJail = (int)($jailTimeConfig["min"] ?? 2);
                    $maxJail = (int)($jailTimeConfig["max"] ?? 5);
                    $jailMinutes = mt_rand($minJail, $maxJail);

                    // Jail player using AZJail hook
                    $jailPlugin = Server::getInstance()->getPluginManager()->getPlugin("AZJail");
                    if ($jailPlugin !== null && class_exists(\BeeAZ\AZJail\Main::class)) {
                        /** @var \BeeAZ\AZJail\Main $jailPlugin */
                        $jailPlugin->jailPlayer($player->getName(), $jailMinutes, "Đánh bạc trái phép tại máy Jackpot", "Công An");
                    }

                    $broadcastMsg = $plugin->getMessage("jail_broadcast", [
                        "player" => $player->getName(),
                        "time" => (string)$jailMinutes
                    ]);
                    Server::getInstance()->broadcastMessage($broadcastMsg);

                    $privateMsg = $plugin->getMessage("jail_private", [
                        "time" => (string)$jailMinutes
                    ]);
                    $player->sendMessage($privateMsg);
                    $player->getWorld()->addSound($player->getPosition(), new ExplodeSound());
                }
            }
        }), 64);
    }
}
