<?php

declare(strict_types=1);

namespace BeeAZ\AZJackpot\command;

use BeeAZ\AZJackpot\entity\SlotMachineEntity;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class JackpotCommand extends Command {

    public function __construct(string $name, string $description = "", string $usageMessage = null, array $aliases = []) {
        parent::__construct($name, $description, $usageMessage, $aliases);
        $this->setPermission("azjackpot.command.use");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
            return true;
        }

        if (!isset($args[0])) {
            if ($sender->hasPermission("azjackpot.admin")) {
                $sender->sendMessage("§e=== HỆ THỐNG MÁY QUAY JACKPOT ===");
                $sender->sendMessage("§a/jackpot spawn §7- Đặt một máy quay Jackpot tại vị trí hiện tại");
                $sender->sendMessage("§a/jackpot remove §7- Xóa máy quay Jackpot gần nhất (bán kính 5m)");
                $sender->sendMessage("§a/jackpot list §7- Danh sách các máy Jackpot đang hoạt động");
            } else {
                $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này.");
            }
            return true;
        }

        switch (strtolower($args[0])) {
            case "spawn":
                if (!$sender->hasPermission("azjackpot.admin")) {
                    $sender->sendMessage("§cBạn không có quyền thực hiện lệnh này!");
                    return true;
                }
                
                $location = $sender->getLocation();
                $entity = new SlotMachineEntity($location);
                $entity->spawnToAll();
                $sender->sendMessage("§aĐã tạo một máy quay Jackpot thành công tại vị trí của bạn!");
                break;

            case "remove":
                if (!$sender->hasPermission("azjackpot.admin")) {
                    $sender->sendMessage("§cBạn không có quyền thực hiện lệnh này!");
                    return true;
                }

                $name = $sender->getName();
                $main = \BeeAZ\AZJackpot\Main::getInstance();
                if (isset($main->removeMode[$name])) {
                    unset($main->removeMode[$name]);
                    $sender->sendMessage("§c[Jackpot] Đã tắt chế độ xóa máy Jackpot.");
                } else {
                    $main->removeMode[$name] = true;
                    $sender->sendMessage("§a[Jackpot] Đã bật chế độ xóa máy Jackpot. Hãy nhấp chuột phải vào máy Jackpot bạn muốn xóa.");
                }
                break;

            case "list":
                if (!$sender->hasPermission("azjackpot.admin")) {
                    $sender->sendMessage("§cBạn không có quyền thực hiện lệnh này!");
                    return true;
                }

                $count = 0;
                foreach ($sender->getWorld()->getEntities() as $entity) {
                    if ($entity instanceof SlotMachineEntity) {
                        $pos = $entity->getLocation();
                        $sender->sendMessage("§7- §eMáy Jackpot ID " . $entity->getId() . "§f: X:" . round($pos->x) . " Y:" . round($pos->y) . " Z:" . round($pos->z));
                        $count++;
                    }
                }
                $sender->sendMessage("§aTổng cộng có §e" . $count . "§a máy Jackpot trong world hiện tại.");
                break;

            case "shop":
                \BeeAZ\AZJackpot\ui\JackpotUI::openTicketShop($sender);
                break;

            case "ticket":
                if (!$sender->hasPermission("azjackpot.admin")) {
                    $sender->sendMessage("§cBạn không có quyền thực hiện lệnh này!");
                    return true;
                }
                if (!isset($args[1]) || strtolower($args[1]) !== "give") {
                    $sender->sendMessage("§cHD: /jackpot ticket give <tên người chơi> <mức vé: 1000-20000> [số lượng]");
                    return true;
                }
                if (!isset($args[2]) || !isset($args[3])) {
                    $sender->sendMessage("§cHD: /jackpot ticket give <tên người chơi> <mức vé: 1000-20000> [số lượng]");
                    return true;
                }
                $targetPlayer = \pocketmine\Server::getInstance()->getPlayerByPrefix($args[2]);
                if ($targetPlayer === null) {
                    $sender->sendMessage("§cKhông tìm thấy người chơi: " . $args[2]);
                    return true;
                }
                $value = (int)$args[3];
                if ($value <= 0) {
                    $sender->sendMessage("§cMức vé không hợp lệ!");
                    return true;
                }
                $amount = isset($args[4]) ? (int)$args[4] : 1;
                if ($amount <= 0) $amount = 1;

                $ticketItem = \BeeAZ\AZJackpot\Main::getInstance()->getTicketItem($value, $amount);
                if ($targetPlayer->getInventory()->canAddItem($ticketItem)) {
                    $targetPlayer->getInventory()->addItem($ticketItem);
                } else {
                    $targetPlayer->getWorld()->dropItem($targetPlayer->getPosition(), $ticketItem);
                }
                $sender->sendMessage("§aĐã gửi §e" . $amount . " Vé Quay Jackpot (Mức cược " . number_format($value) . " Xu) §acho §e" . $targetPlayer->getName());
                $targetPlayer->sendMessage("§aBạn đã nhận được §e" . $amount . " Vé Quay Jackpot (Mức cược " . number_format($value) . " Xu) §atừ Admin!");
                break;

            default:
                $sender->sendMessage("§cHD: /jackpot [spawn|remove|list|shop|ticket]");
                break;
        }

        return true;
    }
}
