<?php

declare(strict_types=1);

namespace BeeAZ\AZJackpot\ui;

use BeeAZ\AZJackpot\Main;
use BeeAZ\AZJackpot\utils\EconomyManager;
use BeeAZ\AZJackpot\entity\SlotMachineEntity;
use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use function number_format;

class JackpotUI {

    /**
     * Opened when the player right-clicks the machine without holding a ticket
     */
    public static function openMainMenu(Player $player, SlotMachineEntity $entity): void {
        $title = "§l§c⚡ MÁY QUAY JACKPOT ⚡";
        
        $desc = "§c⚡ Bạn cần cầm Vé Quay Jackpot trên tay và chạm vào máy để bắt đầu quay!\n\n" .
                "§fNhấp vào nút bên dưới để mở cửa hàng mua Vé Quay bằng Xu.";

        $options = [
            new MenuOption("§l§a⚡ CỬA HÀNG MUA VÉ\n§r§8Nhấn để mua vé quay bằng Xu", new FormIcon("textures/ui/store_home_icon", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§c⚡ ĐÓNG GIAO DIỆN\n§r§8Thoát khỏi máy quay", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            $title,
            $desc,
            $options,
            function(Player $submitter, int $selected) use ($entity): void {
                if ($selected === 0) {
                    self::openTicketShop($submitter, $entity);
                }
            }
        );
        $player->sendForm($form);
    }

    /**
     * Ticket Shop UI
     */
    public static function openTicketShop(Player $player, ?SlotMachineEntity $entity = null): void {
        $title = "§l§e⚡ CỬA HÀNG VÉ JACKPOT ⚡";
        
        $ticketPrices = [1000, 2000, 5000, 10000, 20000];
        $options = [];
        foreach ($ticketPrices as $price) {
            $options[] = new MenuOption(
                "§l§a⚡ Mua Vé " . number_format($price) . " Xu\n§r§8Giá bán: " . number_format($price) . " Xu",
                new FormIcon("textures/ui/store_home_icon", FormIcon::IMAGE_TYPE_PATH)
            );
        }
        $options[] = new MenuOption("§l§c⚡ QUAY LẠI MENU CHÍNH", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));

        EconomyManager::getMoney($player, function(int $balance) use ($player, $title, $options, $ticketPrices, $entity): void {
            if (!$player->isOnline()) return;

            $desc = "§fSố dư hiện tại của bạn: §a" . number_format($balance) . " Xu\n\n§7Hãy chọn loại vé bạn muốn mua. Vé quay được sử dụng bằng cách cầm trên tay và chạm vào máy Jackpot.";

            $form = new MenuForm(
                $title,
                $desc,
                $options,
                function(Player $submitter, int $selected) use ($ticketPrices, $entity): void {
                    if ($selected === count($ticketPrices)) {
                        if ($entity !== null && !$entity->isClosed()) {
                            self::openMainMenu($submitter, $entity);
                        }
                        return;
                    }

                    if (!isset($ticketPrices[$selected])) return;
                    $price = $ticketPrices[$selected];

                    EconomyManager::getMoney($submitter, function(int $currentBal) use ($submitter, $price, $entity): void {
                        if (!$submitter->isOnline()) return;
                        if ($currentBal < $price) {
                            $submitter->sendMessage("§c[Jackpot] Bạn không có đủ tiền để mua vé này!");
                            return;
                        }

                        EconomyManager::reduceMoney($submitter, $price, function(bool $success) use ($submitter, $price, $entity): void {
                            if (!$submitter->isOnline()) return;
                            if (!$success) {
                                $submitter->sendMessage("§c[Jackpot] Giao dịch thất bại!");
                                return;
                            }

                            $ticketItem = Main::getInstance()->getTicketItem($price, 1);
                            if ($submitter->getInventory()->canAddItem($ticketItem)) {
                                $submitter->getInventory()->addItem($ticketItem);
                            } else {
                                $submitter->getWorld()->dropItem($submitter->getPosition(), $ticketItem);
                            }

                            $submitter->sendMessage("§a[Jackpot] Bạn đã mua thành công §e1 Vé Quay Jackpot (" . number_format($price) . " Xu)§a!");
                            
                            if ($entity !== null && !$entity->isClosed()) {
                                self::openMainMenu($submitter, $entity);
                            } else {
                                self::openTicketShop($submitter);
                            }
                        });
                    });
                }
            );
            $player->sendForm($form);
        });
    }
}
