<?php

namespace BeeAZ\AZHopper;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\block\Hopper as HopperBlock;
use pocketmine\block\Block;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\world\ChunkLoadEvent;
use pocketmine\event\world\ChunkUnloadEvent;
use pocketmine\block\tile\Hopper as HopperTile;

class Main extends PluginBase implements Listener {
    private array $lastClickFace = [];
    public static array $hoppers = [];

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getScheduler()->scheduleRepeatingTask(new HopperTask($this), 10);
        $this->getLogger()->info("§aAZHopper by BeeAZ enabled!");
        
        $ref = new \ReflectionClass(\pocketmine\block\Hopper::class);
        $methods = [];
        foreach($ref->getMethods() as $m) {
            if (strpos(strtolower($m->getName()), 'facing') !== false) {
                $methods[] = $m->getName();
            }
        }
        $this->getLogger()->info("Hopper facing methods: " . implode(", ", $methods));

        // Scan existing hoppers on load
        foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getLoadedChunks() as $chunk) {
                foreach ($chunk->getTiles() as $tile) {
                    if ($tile instanceof HopperTile) {
                        self::$hoppers[spl_object_id($tile)] = $tile;
                    }
                }
            }
        }
    }

    public function onChunkLoad(ChunkLoadEvent $event): void {
        foreach ($event->getChunk()->getTiles() as $tile) {
            if ($tile instanceof HopperTile) {
                self::$hoppers[spl_object_id($tile)] = $tile;
            }
        }
    }

    public function onChunkUnload(ChunkUnloadEvent $event): void {
        foreach ($event->getChunk()->getTiles() as $tile) {
            if ($tile instanceof HopperTile) {
                unset(self::$hoppers[spl_object_id($tile)]);
            }
        }
    }

    public function onInteract(\pocketmine\event\player\PlayerInteractEvent $event): void {
        if ($event->getAction() === \pocketmine\event\player\PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            $this->lastClickFace[$event->getPlayer()->getName()] = $event->getFace();
        }
    }

    public function onPlace(BlockPlaceEvent $event): void {
        foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            if ($block instanceof HopperBlock) {
                $player = $event->getPlayer();
                $faceClicked = $this->lastClickFace[$player->getName()] ?? \pocketmine\math\Facing::UP;
                $pos = clone $block->getPosition();
                $world = $pos->getWorld();
                
                $this->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(function() use ($pos, $world, $faceClicked): void {
                    if (!$world->isLoaded()) return;
                    $b = $world->getBlock($pos);
                    if ($b instanceof HopperBlock && method_exists($b, 'setFacing')) {
                        $targetFace = $faceClicked === \pocketmine\math\Facing::UP || $faceClicked === \pocketmine\math\Facing::DOWN ? \pocketmine\math\Facing::DOWN : \pocketmine\math\Facing::opposite($faceClicked);
                        
                        // Smart Auto-Connect: Scan for adjacent containers
                        $foundChest = false;
                        if ($targetFace === \pocketmine\math\Facing::DOWN) {
                            foreach ([\pocketmine\math\Facing::NORTH, \pocketmine\math\Facing::SOUTH, \pocketmine\math\Facing::EAST, \pocketmine\math\Facing::WEST] as $horizontalFace) {
                                $adjTile = $world->getTile($pos->getSide($horizontalFace));
                                if ($adjTile instanceof \pocketmine\block\tile\Container) {
                                    $targetFace = $horizontalFace;
                                    $foundChest = true;
                                    break;
                                }
                            }
                        }

                        $b->setFacing($targetFace);
                        $world->setBlock($pos, $b);

                        $tile = $world->getTile($pos);
                        if ($tile instanceof HopperTile) {
                            self::$hoppers[spl_object_id($tile)] = $tile;
                        }
                    }
                }), 1);
            }
        }
    }

    public function onCraft(CraftItemEvent $event): void {
        foreach ($event->getOutputs() as $output) {
            if ($output->getVanillaName() === "Hopper") {
                $event->cancel();
                $event->getPlayer()->sendMessage("§cBạn không thể chế tạo Phễu! Vui lòng mua tại /azshop.");
                return;
            }
        }
    }
}
