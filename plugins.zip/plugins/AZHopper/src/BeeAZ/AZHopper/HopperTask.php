<?php

namespace BeeAZ\AZHopper;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\block\tile\Hopper as HopperTile;
use pocketmine\block\tile\Container;
use pocketmine\block\Hopper as HopperBlock;
use pocketmine\math\AxisAlignedBB;
use pocketmine\entity\object\ItemEntity;
use pocketmine\math\Facing;

class HopperTask extends Task {

    public function __construct(private Main $plugin) {}

    public function onRun(): void {
        foreach (Main::$hoppers as $id => $tile) {
            if ($tile->isClosed()) {
                unset(Main::$hoppers[$id]);
                continue;
            }
            $this->tickHopper($tile);
        }
    }

    private function tickHopper(HopperTile $hopper): void {
        if ($hopper->isClosed() || !$hopper->getPosition()->isValid()) return;
        
        $world = $hopper->getPosition()->getWorld();
        $pos = $hopper->getPosition();
        $block = $world->getBlock($pos);
        if (!$block instanceof HopperBlock) return;
        if ($block->isPowered()) return;
        
        $hopperInventory = $hopper->getInventory();
        
        // Check if hopper inventory is full
        $isFull = true;
        if ($hopperInventory->firstEmpty() !== -1) {
            $isFull = false;
        } else {
            foreach ($hopperInventory->getContents() as $item) {
                if ($item->isNull() || $item->getCount() < $item->getMaxStackSize()) {
                    $isFull = false;
                    break;
                }
            }
        }
        
        if (!$isFull) {
            // 1. Suck items from above
            $bb = new AxisAlignedBB($pos->x, $pos->y, $pos->z, $pos->x + 1, $pos->y + 1.5, $pos->z + 1);
            foreach ($world->getNearbyEntities($bb) as $entity) {
                if ($entity instanceof ItemEntity && !$entity->isClosed() && !$entity->isFlaggedForDespawn()) {
                    $item = $entity->getItem();
                    if ($hopperInventory->canAddItem($item)) {
                        $remainder = $hopperInventory->addItem($item);
                        if (empty($remainder)) {
                            $entity->flagForDespawn();
                        } else {
                            $count = $remainder[0]->getCount();
                            if ($count <= 0) {
                                $entity->flagForDespawn();
                            } else {
                                $entity->setStackSize($count);
                            }
                        }
                    }
                }
            }
            
            // 2. Pull from Container above
            $tileAbove = $world->getTile($pos->getSide(Facing::UP));
            if ($tileAbove instanceof Container) {
                $invAbove = $tileAbove->getInventory();
                foreach ($invAbove->getContents() as $slot => $item) {
                    if ($item->isNull()) continue;
                    $clone = clone $item;
                    $clone->setCount(1);
                    if ($hopperInventory->canAddItem($clone)) {
                        $hopperInventory->addItem($clone);
                        $invAbove->removeItem($clone);
                        break; // Only pull 1 item per tick
                    }
                }
            }
        }
        
        // 3. Push to Container facing
        if (count($hopperInventory->getContents()) > 0) {
            $face = $block->getFacing();
            $targetPos = $pos->getSide($face);
            $tileFacing = $world->getTile($targetPos);
            
            if ($tileFacing instanceof Container) {
                $invFacing = $tileFacing->getInventory();
                foreach ($hopperInventory->getContents() as $slot => $item) {
                    if ($item->isNull()) continue;
                    $clone = clone $item;
                    $clone->setCount(1);
                    if ($invFacing->canAddItem($clone)) {
                        $invFacing->addItem($clone);
                        $hopperInventory->removeItem($clone);
                        break; // Only push 1 item per tick
                    }
                }
            }
        }
    }
}
