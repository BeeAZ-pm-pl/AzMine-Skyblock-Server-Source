<?php

namespace azauction\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\Server;
use azauction\Main;
use azauction\ui\AuctionUI;

class AuctionCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("ah", "Chợ đấu giá", "/ah [sell] [giá]", ["auction"]);
        $this->setPermission("azauction.use");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) return false;
        
        if (isset($args[0]) && strtolower($args[0]) === "sell") {
            if (!isset($args[1]) || !is_numeric($args[1]) || (int)$args[1] <= 0) {
                $sender->sendMessage("§c⚡ §lSử dụng: /ah sell <giá>");
                return false;
            }
            $price = (int)$args[1];
            $item = $sender->getInventory()->getItemInHand();
            
            if ($item->isNull()) {
                $sender->sendMessage("§c⚡ §lBạn phải cầm vật phẩm trên tay để bán!");
                return false;
            }

            if ($item->getNamedTag()->getTag("Owner") !== null) {
                $sender->sendMessage("§c⚡ §lKhông thể bán vật phẩm sở hữu (Owner) lên Chợ Đấu Giá!");
                return false;
            }
            
            $expireTime = time() + 86400;
            $this->plugin->db->addAuction($sender->getName(), clone $item, $price, $expireTime);
            $sender->getInventory()->setItemInHand(VanillaItems::AIR());
            
            $itemName = $item->getCustomName() !== "" ? $item->getCustomName() : $item->getName();
            
            $sender->sendMessage("§a⚡ §lĐã đăng bán vật phẩm lên Chợ Đấu Giá với giá §e" . number_format($price) . " xu§a!");
            Server::getInstance()->broadcastMessage("§l§e[CHỢ] §r§fNgười chơi §a" . $sender->getName() . " §fvừa rao bán §e" . $itemName . " §fx" . $item->getCount() . " §fvới giá §a" . number_format($price) . " xu§f! Gõ §c/ah §fđể mua ngay!");
            return true;
        }
        
        AuctionUI::sendMainMenu($sender, $this->plugin);
        return true;
    }
}