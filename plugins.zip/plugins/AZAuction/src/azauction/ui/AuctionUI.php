<?php

namespace azauction\ui;

use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\Durable;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\ModalForm;
use pocketmine\Server;
use azauction\Main;
use azeconomy\AZEconomy;

class AuctionUI {
    public static function formatTime(int $seconds): string {
        if ($seconds <= 0) return "00:00:00";
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        $s = $seconds % 60;
        return sprintf("%02d:%02d:%02d", $h, $m, $s);
    }

    public static function formatItemInfo(Item $item): string {
        $info = "";
        $lore = $item->getLore();
        if (!empty($lore)) {
            $info .= "§d✦ Lore:\n  " . implode("\n  ", $lore) . "\n";
        }
        $enchants = $item->getEnchantments();
        if (count($enchants) > 0) {
            $info .= "§e✦ Phù phép:\n";
            foreach ($enchants as $ench) {
                $info .= "  §7- " . $ench->getType()->getName() . " (Lv." . $ench->getLevel() . ")\n";
            }
        }
        if ($item instanceof Durable) {
            $max = $item->getMaxDurability();
            $damage = $item->getDamage();
            $info .= "§a✦ Độ bền: §f" . ($max - $damage) . " / " . $max . "\n";
        }
        return rtrim($info, "\n");
    }

    public static function sendMainMenu(Player $player, Main $plugin): void {
        $form = new MenuForm(
            "§l§eCHỢ ĐẤU GIÁ",
            "§fChọn khu vực bạn muốn truy cập:",
            [
                new MenuOption("§l§aMua Vật Phẩm\n§r§8Xem hàng hóa đang được bán"),
                new MenuOption("§l§dQuản Lý Đồ Đang Bán\n§r§8Gỡ đồ đang bán xuống"),
                new MenuOption("§l§cKho Đồ Cũ (Quá Hạn)\n§r§8Lấy lại đồ quá 24h"),
                new MenuOption("§l§6Nhận Tiền Bán Đồ\n§r§8Lấy tiền đồ đã bán")
            ],
            function(Player $submitter, int $selected) use ($plugin): void {
                if ($selected === 0) self::sendBrowseMenu($submitter, $plugin);
                if ($selected === 1) self::sendManageMenu($submitter, $plugin);
                if ($selected === 2) self::sendExpiredMenu($submitter, $plugin);
                if ($selected === 3) self::sendClaimMoneyMenu($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendBrowseMenu(Player $player, Main $plugin): void {
        $auctions = $plugin->db->getActiveAuctions();
        if (empty($auctions)) {
            $player->sendMessage("§c⚡ §lHiện tại chợ đang trống, chưa có ai bán gì cả!");
            return;
        }
        
        $options = [];
        foreach ($auctions as $auc) {
            $itemName = $auc['item']->getCustomName() !== "" ? $auc['item']->getCustomName() : $auc['item']->getName();
            $timeStr = self::formatTime($auc['expire_time'] - time());
            $options[] = new MenuOption("§l§e" . $itemName . " §r§8x" . $auc['item']->getCount() . "\n§fGiá: §a" . number_format($auc['price']) . " §f| Còn: §c" . $timeStr);
        }
        
        $form = new MenuForm(
            "§l§eMUA VẬT PHẨM",
            "§fDanh sách đồ trên chợ:",
            $options,
            function(Player $submitter, int $selected) use ($plugin, $auctions): void {
                self::sendConfirmBuy($submitter, $plugin, $auctions[$selected]);
            },
            function(Player $submitter) use ($plugin): void {
                self::sendMainMenu($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendConfirmBuy(Player $player, Main $plugin, array $auc): void {
        $itemName = $auc['item']->getCustomName() !== "" ? $auc['item']->getCustomName() : $auc['item']->getName();
        $timeStr = self::formatTime($auc['expire_time'] - time());
        $itemInfo = self::formatItemInfo($auc['item']);
        
        $content = "§l§bTHÔNG TIN VẬT PHẨM:\n\n" .
                   "§r§fTên: §a" . $itemName . " x" . $auc['item']->getCount() . "\n" .
                   "§fNgười bán: §b" . $auc['seller'] . "\n" .
                   "§fGiá bán: §e" . number_format($auc['price']) . " xu\n" .
                   "§fThời gian còn lại: §c" . $timeStr . "\n\n";
        
        if ($itemInfo !== "") {
            $content .= $itemInfo . "\n\n";
        }
        $content .= "§l§cCHÚ Ý: §r§fBạn có chắc chắn muốn xuất tiền để mua vật phẩm này không?";

        $form = new ModalForm(
            "§l§eXÁC NHẬN MUA",
            $content,
            function(Player $submitter, bool $choice) use ($plugin, $auc, $itemName): void {
                if ($choice) {
                    $check = $plugin->db->getAuction($auc['id']);
                    if ($check === null || $check['expire_time'] <= time()) {
                        $submitter->sendMessage("§c⚡ §lVật phẩm đã hết hạn, bị thu hồi hoặc đã có người khác mua!");
                        return;
                    }
                    if ($submitter->getName() === $auc['seller']) {
                        $submitter->sendMessage("§c⚡ §lBạn không thể tự mua đồ của chính mình!");
                        return;
                    }
                    if (AZEconomy::getInstance()->getMoney($submitter->getName()) < $auc['price']) {
                        $submitter->sendMessage("§c⚡ §lBạn không đủ xu để mua vật phẩm này!");
                        return;
                    }
                    if (!$submitter->getInventory()->canAddItem($auc['item'])) {
                        $submitter->sendMessage("§c⚡ §lTúi đồ của bạn đã đầy!");
                        return;
                    }
                    
                    AZEconomy::getInstance()->reduceMoney($submitter->getName(), $auc['price']);
                    $plugin->db->addUnclaimedMoney($auc['seller'], $auc['price'], $itemName);
                    $submitter->getInventory()->addItem($auc['item']);
                    $plugin->db->removeAuction($auc['id']);
                    
                    $submitter->sendMessage("§a⚡ §lMua thành công vật phẩm từ §e" . $auc['seller'] . "§a!");
                    
                    $sellerPlayer = Server::getInstance()->getPlayerExact($auc['seller']);
                    if ($sellerPlayer !== null) {
                        $sellerPlayer->sendMessage("§a⚡ §lVật phẩm §f" . $itemName . " §acủa bạn đã được bán! Gõ §e/ah §avà vào mục §eNhận Tiền §ađể lấy xu nhé.");
                    }
                } else {
                    self::sendBrowseMenu($submitter, $plugin);
                }
            }
        );
        $player->sendForm($form);
    }

    public static function sendManageMenu(Player $player, Main $plugin): void {
        $auctions = $plugin->db->getPlayerActiveAuctions($player->getName());
        if (empty($auctions)) {
            $player->sendMessage("§c⚡ §lBạn chưa đăng bán vật phẩm nào trên chợ!");
            return;
        }
        
        $options = [];
        foreach ($auctions as $auc) {
            $itemName = $auc['item']->getCustomName() !== "" ? $auc['item']->getCustomName() : $auc['item']->getName();
            $options[] = new MenuOption("§l§e" . $itemName . " §r§8x" . $auc['item']->getCount() . "\n§fGiá: §a" . number_format($auc['price']) . " §f| Nhấn để gỡ");
        }
        
        $form = new MenuForm(
            "§l§dQUẢN LÝ ĐỒ BÁN",
            "§fChọn vật phẩm bạn muốn gỡ xuống:",
            $options,
            function(Player $submitter, int $selected) use ($plugin, $auctions): void {
                self::sendConfirmRemove($submitter, $plugin, $auctions[$selected]);
            },
            function(Player $submitter) use ($plugin): void {
                self::sendMainMenu($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendConfirmRemove(Player $player, Main $plugin, array $auc): void {
        $itemName = $auc['item']->getCustomName() !== "" ? $auc['item']->getCustomName() : $auc['item']->getName();
        $itemInfo = self::formatItemInfo($auc['item']);
        $content = "§l§bTHÔNG TIN VẬT PHẨM:\n\n" . "§r§fTên: §a" . $itemName . " x" . $auc['item']->getCount() . "\n\n";
        if ($itemInfo !== "") $content .= $itemInfo . "\n\n";
        $content .= "§l§cCHÚ Ý: §r§fBạn có chắc chắn muốn gỡ món đồ này xuống và trả về túi không?";

        $form = new ModalForm(
            "§l§eXÁC NHẬN GỠ ĐỒ",
            $content,
            function(Player $submitter, bool $choice) use ($plugin, $auc): void {
                if ($choice) {
                    $check = $plugin->db->getAuction($auc['id']);
                    if ($check === null || $check['seller'] !== $submitter->getName()) {
                        $submitter->sendMessage("§c⚡ §lLỗi: Đồ này không tồn tại hoặc không phải của bạn!");
                        return;
                    }
                    if (!$submitter->getInventory()->canAddItem($auc['item'])) {
                        $submitter->sendMessage("§c⚡ §lTúi đồ của bạn đã đầy!");
                        return;
                    }
                    $plugin->db->removeAuction($auc['id']);
                    $submitter->getInventory()->addItem($auc['item']);
                    $submitter->sendMessage("§a⚡ §lĐã gỡ đồ và trả về túi thành công!");
                } else {
                    self::sendManageMenu($submitter, $plugin);
                }
            }
        );
        $player->sendForm($form);
    }

    public static function sendExpiredMenu(Player $player, Main $plugin): void {
        $auctions = $plugin->db->getPlayerExpiredAuctions($player->getName());
        if (empty($auctions)) {
            $player->sendMessage("§a⚡ §lBạn không có món đồ nào bị quá hạn trong kho!");
            return;
        }
        
        $options = [];
        foreach ($auctions as $auc) {
            $itemName = $auc['item']->getCustomName() !== "" ? $auc['item']->getCustomName() : $auc['item']->getName();
            $options[] = new MenuOption("§l§7" . $itemName . " §r§8x" . $auc['item']->getCount() . "\n§cĐã hết hạn §f| §aNhấn lấy lại");
        }
        
        $form = new MenuForm(
            "§l§cKHO ĐỒ CŨ",
            "§fĐồ quá 24h sẽ bị chuyển vào đây:",
            $options,
            function(Player $submitter, int $selected) use ($plugin, $auctions): void {
                $auc = $auctions[$selected];
                $check = $plugin->db->getAuction($auc['id']);
                if ($check === null || $check['seller'] !== $submitter->getName()) {
                    $submitter->sendMessage("§c⚡ §lLỗi: Đồ này không tồn tại hoặc không phải của bạn!");
                    return;
                }
                if (!$submitter->getInventory()->canAddItem($auc['item'])) {
                    $submitter->sendMessage("§c⚡ §lTúi đồ của bạn đã đầy!");
                    return;
                }
                $plugin->db->removeAuction($auc['id']);
                $submitter->getInventory()->addItem($auc['item']);
                $submitter->sendMessage("§a⚡ §lĐã lấy lại đồ cũ thành công!");
            },
            function(Player $submitter) use ($plugin): void {
                self::sendMainMenu($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }

    public static function sendClaimMoneyMenu(Player $player, Main $plugin): void {
        $moneys = $plugin->db->getPlayerUnclaimedMoney($player->getName());
        if (empty($moneys)) {
            $player->sendMessage("§c⚡ §lBạn không có khoản tiền nào đang chờ nhận!");
            return;
        }
        
        $options = [];
        foreach ($moneys as $m) {
            $options[] = new MenuOption("§l§a" . number_format($m['amount']) . " xu\n§r§8Bán: " . $m['item_name']);
        }
        
        $form = new MenuForm(
            "§l§6NHẬN TIỀN",
            "§fNhấn vào khoản tiền để nhận về ví:",
            $options,
            function(Player $submitter, int $selected) use ($plugin, $moneys): void {
                $m = $moneys[$selected];
                AZEconomy::getInstance()->addMoney($submitter->getName(), $m['amount']);
                $plugin->db->removeUnclaimedMoney($m['id']);
                $submitter->sendMessage("§a⚡ §lĐã nhận §e" . number_format($m['amount']) . " xu §atừ việc bán §f" . $m['item_name'] . "§a!");
            },
            function(Player $submitter) use ($plugin): void {
                self::sendMainMenu($submitter, $plugin);
            }
        );
        $player->sendForm($form);
    }
}