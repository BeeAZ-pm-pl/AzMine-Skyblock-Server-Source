<?php

declare(strict_types=1);

namespace azauction\database;

use pocketmine\scheduler\AsyncTask;

class AuctionSaveTask extends AsyncTask {
    private string $serializedData;

    public function __construct(
        private string $dbPath,
        private string $action,
        array $data
    ) {
        $this->serializedData = serialize($data);
    }

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $data = unserialize($this->serializedData);
        
        switch ($this->action) {
            case "add_auction":
                $stmt = $db->prepare("INSERT OR REPLACE INTO auctions (id, seller, item_data, price, expire_time) VALUES (:id, :seller, :data, :price, :expire_time)");
                $stmt->bindValue(":id", $data['id'], SQLITE3_INTEGER);
                $stmt->bindValue(":seller", $data['seller'], SQLITE3_TEXT);
                $stmt->bindValue(":data", $data['item_data'], SQLITE3_TEXT);
                $stmt->bindValue(":price", $data['price'], SQLITE3_INTEGER);
                $stmt->bindValue(":expire_time", $data['expire_time'], SQLITE3_INTEGER);
                $stmt->execute();
                break;
                
            case "remove_auction":
                $stmt = $db->prepare("DELETE FROM auctions WHERE id = :id");
                $stmt->bindValue(":id", $data['id'], SQLITE3_INTEGER);
                $stmt->execute();
                break;
                
            case "add_unclaimed":
                $stmt = $db->prepare("INSERT OR REPLACE INTO unclaimed_money (id, player, amount, item_name) VALUES (:id, :player, :amount, :item_name)");
                $stmt->bindValue(":id", $data['id'], SQLITE3_INTEGER);
                $stmt->bindValue(":player", $data['player'], SQLITE3_TEXT);
                $stmt->bindValue(":amount", $data['amount'], SQLITE3_INTEGER);
                $stmt->bindValue(":item_name", $data['item_name'], SQLITE3_TEXT);
                $stmt->execute();
                break;
                
            case "remove_unclaimed":
                $stmt = $db->prepare("DELETE FROM unclaimed_money WHERE id = :id");
                $stmt->bindValue(":id", $data['id'], SQLITE3_INTEGER);
                $stmt->execute();
                break;
        }
        
        $db->close();
    }
}
