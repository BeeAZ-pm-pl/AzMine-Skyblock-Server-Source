<?php

namespace azauction\database;

use pocketmine\item\Item;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

class Database {
    private \SQLite3 $db;
    private string $dbPath;
    private LittleEndianNbtSerializer $serializer;
    private array $auctions = [];
    private array $unclaimedMoney = [];
    private int $nextAuctionId = 1;
    private int $nextUnclaimedId = 1;

    public function __construct(string $path) {
        $this->dbPath = $path;
        $this->db = new \SQLite3($path);
        $this->db->exec("CREATE TABLE IF NOT EXISTS auctions (id INTEGER PRIMARY KEY AUTOINCREMENT, seller TEXT, item_data TEXT, price INTEGER, expire_time INTEGER)");
        $this->db->exec("CREATE TABLE IF NOT EXISTS unclaimed_money (id INTEGER PRIMARY KEY AUTOINCREMENT, player TEXT, amount INTEGER, item_name TEXT)");
        $this->serializer = new LittleEndianNbtSerializer();
        $this->loadAll();
    }

    private function loadAll(): void {
        $res = $this->db->query("SELECT * FROM auctions");
        if ($res !== false) {
            while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
                $row['item'] = Item::nbtDeserialize($this->serializer->read(base64_decode($row['item_data']))->mustGetCompoundTag());
                $this->auctions[$row['id']] = $row;
                if ($row['id'] >= $this->nextAuctionId) {
                    $this->nextAuctionId = $row['id'] + 1;
                }
            }
        }

        $res = $this->db->query("SELECT * FROM unclaimed_money");
        if ($res !== false) {
            while ($row = $res->fetchArray(SQLITE3_ASSOC)) {
                $this->unclaimedMoney[$row['id']] = $row;
                if ($row['id'] >= $this->nextUnclaimedId) {
                    $this->nextUnclaimedId = $row['id'] + 1;
                }
            }
        }
    }

    public function addAuction(string $seller, Item $item, int $price, int $expireTime): void {
        $id = $this->nextAuctionId++;
        $itemData = base64_encode($this->serializer->write(new TreeRoot($item->nbtSerialize())));
        $row = [
            'id' => $id,
            'seller' => $seller,
            'item_data' => $itemData,
            'price' => $price,
            'expire_time' => $expireTime,
            'item' => $item
        ];
        $this->auctions[$id] = $row;

        $taskData = $row;
        unset($taskData['item']);

        \pocketmine\Server::getInstance()->getAsyncPool()->submitTask(new AuctionSaveTask(
            $this->dbPath,
            "add_auction",
            $taskData
        ));
    }

    public function removeAuction(int $id): void {
        if (isset($this->auctions[$id])) {
            unset($this->auctions[$id]);
            \pocketmine\Server::getInstance()->getAsyncPool()->submitTask(new AuctionSaveTask(
                $this->dbPath,
                "remove_auction",
                ['id' => $id]
            ));
        }
    }

    public function getAuction(int $id): ?array {
        return $this->auctions[$id] ?? null;
    }

    public function getActiveAuctions(): array {
        $now = time();
        $active = [];
        foreach ($this->auctions as $row) {
            if ($row['expire_time'] > $now) {
                $active[] = $row;
            }
        }
        return $active;
    }

    public function getPlayerActiveAuctions(string $player): array {
        $now = time();
        $active = [];
        foreach ($this->auctions as $row) {
            if (strtolower($row['seller']) === strtolower($player) && $row['expire_time'] > $now) {
                $active[] = $row;
            }
        }
        return $active;
    }

    public function getPlayerExpiredAuctions(string $player): array {
        $now = time();
        $expired = [];
        foreach ($this->auctions as $row) {
            if (strtolower($row['seller']) === strtolower($player) && $row['expire_time'] <= $now) {
                $expired[] = $row;
            }
        }
        return $expired;
    }

    public function addUnclaimedMoney(string $player, int $amount, string $itemName): void {
        $id = $this->nextUnclaimedId++;
        $row = [
            'id' => $id,
            'player' => $player,
            'amount' => $amount,
            'item_name' => $itemName
        ];
        $this->unclaimedMoney[$id] = $row;

        \pocketmine\Server::getInstance()->getAsyncPool()->submitTask(new AuctionSaveTask(
            $this->dbPath,
            "add_unclaimed",
            $row
        ));
    }

    public function getPlayerUnclaimedMoney(string $player): array {
        $moneys = [];
        foreach ($this->unclaimedMoney as $row) {
            if (strtolower($row['player']) === strtolower($player)) {
                $moneys[] = $row;
            }
        }
        return $moneys;
    }

    public function removeUnclaimedMoney(int $id): void {
        if (isset($this->unclaimedMoney[$id])) {
            unset($this->unclaimedMoney[$id]);
            \pocketmine\Server::getInstance()->getAsyncPool()->submitTask(new AuctionSaveTask(
                $this->dbPath,
                "remove_unclaimed",
                ['id' => $id]
            ));
        }
    }

    public function close(): void {
        $this->db->close();
    }
}