<?php

namespace azauction;

use pocketmine\plugin\PluginBase;
use azauction\database\Database;
use azauction\command\AuctionCommand;

class Main extends PluginBase {
    public Database $db;

    protected function onEnable(): void {
        $this->db = new Database($this->getDataFolder() . "auctions.db");
        $this->getServer()->getCommandMap()->register("azauction", new AuctionCommand($this));
    }

    protected function onDisable(): void {
        $this->db->close();
    }
}