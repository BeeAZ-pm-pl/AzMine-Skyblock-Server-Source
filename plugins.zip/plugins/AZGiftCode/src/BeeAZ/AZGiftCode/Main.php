<?php

declare(strict_types=1);

namespace BeeAZ\AZGiftCode;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;
use pocketmine\item\Item;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;
use pocketmine\utils\Config;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Label;

class Main extends PluginBase {

    private \SQLite3 $db;
    private string $prefix = "§d§l[GiftCode] §r";

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->prefix = $this->getConfig()->getNested("messages.prefix", "§d§l[GiftCode] §r");

        // Set timezone
        $timezone = $this->getConfig()->get("timezone", "Asia/Ho_Chi_Minh");
        date_default_timezone_set($timezone);

        // Database Init
        @mkdir($this->getDataFolder());
        $this->db = new \SQLite3($this->getDataFolder() . "claims.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS claims (player TEXT, code TEXT, claim_time INTEGER, PRIMARY KEY (player, code))");

        $this->getLogger()->info("§aAZGiftCode đã khởi chạy thành công!");
    }

    protected function onDisable(): void {
        $this->db->close();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "giftcode") {
            if (isset($args[0]) && strtolower($args[0]) === "reload") {
                if (!$sender->hasPermission("azgiftcode.command.admin")) {
                    $sender->sendMessage($this->prefix . $this->getConfig()->getNested("messages.no_permission", "§cBạn không có quyền thực hiện hành động này."));
                    return true;
                }
                $this->reloadConfig();
                $this->prefix = $this->getConfig()->getNested("messages.prefix", "§d§l[GiftCode] §r");
                $sender->sendMessage($this->prefix . $this->getConfig()->getNested("messages.reloaded", "§aCấu hình AZGiftCode đã được tải lại thành công!"));
                return true;
            }

            if (!$sender instanceof Player) {
                $sender->sendMessage($this->getConfig()->getNested("messages.only_player", "Lệnh này chỉ có thể sử dụng trong trò chơi."));
                return true;
            }

            if (isset($args[0])) {
                $this->claimGiftCode($sender, trim($args[0]));
            } else {
                $this->openGiftCodeForm($sender);
            }
            return true;
        }
        return false;
    }

    /**
     * Opens PMForms UI to enter giftcode
     */
    private function openGiftCodeForm(Player $player): void {
        $form = new CustomForm(
            "§d§lNHẬP MÃ GIFTCODE",
            [
                new Label("lbl_desc", "§eNhập mã quà tặng của bạn bên dưới để nhận phần thưởng:"),
                new Input("code_input", "Mã GiftCode", "Ví dụ: TANTHU")
            ],
            function(Player $submitter, CustomFormResponse $response): void {
                $code = trim($response->getString("code_input"));
                if ($code === "") {
                    $submitter->sendMessage($this->prefix . $this->getConfig()->getNested("messages.not_found", "§cMã quà tặng này không tồn tại hoặc đã nhập sai!"));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    return;
                }
                $this->claimGiftCode($submitter, $code);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Handle giftcode claim logic
     */
    public function claimGiftCode(Player $player, string $code): void {
        $configCodes = $this->getConfig()->get("giftcodes", []);
        
        // Find matching code case-insensitively
        $matchedCodeKey = null;
        $codeLower = strtolower($code);
        foreach (array_keys($configCodes) as $key) {
            if (strtolower((string)$key) === $codeLower) {
                $matchedCodeKey = (string)$key;
                break;
            }
        }

        if ($matchedCodeKey === null) {
            $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.not_found", "§cMã quà tặng này không tồn tại hoặc đã nhập sai!"));
            $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
            return;
        }

        $codeData = $configCodes[$matchedCodeKey];
        $playerName = strtolower($player->getName());

        // 1. Check Expiry
        $expiryStr = $codeData["expiry"] ?? "";
        if ($expiryStr !== "") {
            $expiryTime = strtotime($expiryStr);
            if ($expiryTime !== false && time() > $expiryTime) {
                $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.expired", "§cMã quà tặng này đã hết hạn sử dụng!"));
                $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
                return;
            }
        }

        // 2. Check Player Already Claimed
        $stmt = $this->db->prepare("SELECT 1 FROM claims WHERE player = :player AND code = :code LIMIT 1");
        $stmt->bindValue(":player", $playerName, SQLITE3_TEXT);
        $stmt->bindValue(":code", $codeLower, SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($result !== false && $result->fetchArray(SQLITE3_ASSOC) !== false) {
            $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.already_claimed", "§cBạn đã nhận mã quà tặng này trước đó rồi!"));
            $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
            return;
        }

        // 3. Check Claim Limits
        $maxClaims = (int)($codeData["max_claims"] ?? -1);
        if ($maxClaims !== -1) {
            $countStmt = $this->db->prepare("SELECT COUNT(*) as count FROM claims WHERE code = :code");
            $countStmt->bindValue(":code", $codeLower, SQLITE3_TEXT);
            $countRes = $countStmt->execute();
            if ($countRes !== false) {
                $row = $countRes->fetchArray(SQLITE3_ASSOC);
                $currentClaims = (int)($row["count"] ?? 0);
                if ($currentClaims >= $maxClaims) {
                    $player->sendMessage($this->prefix . $this->getConfig()->getNested("messages.limit_reached", "§cMã quà tặng này đã đạt giới hạn lượt nhận tối đa!"));
                    $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
                    return;
                }
            }
        }

        // 4. Parse Items and Check Inventory Space
        $itemRewards = [];
        $itemsConfig = $codeData["items"] ?? [];
        foreach ($itemsConfig as $itemStr) {
            $parts = explode(":", $itemStr);
            if (count($parts) < 2) continue;

            if ($parts[0] === "myitems") {
                // Custom item from AZMyItems
                $itemKey = $parts[1];
                $count = isset($parts[2]) ? (int)$parts[2] : 1;

                if (class_exists(\BeeAZ\AZMyItems\Main::class)) {
                    $myItems = \BeeAZ\AZMyItems\Main::getInstance();
                    $customItem = $myItems->getItemFromConfig($itemKey);
                    if ($customItem !== null) {
                        $customItem->setCount($count);
                        $itemRewards[] = $customItem;
                    } else {
                        $this->getLogger()->warning("Vật phẩm custom '{$itemKey}' không tồn tại trong cấu hình AZMyItems!");
                    }
                } else {
                    $this->getLogger()->warning("AZMyItems chưa được cài đặt, không thể phát vật phẩm custom!");
                }
            } else {
                // Vanilla item
                $itemName = $parts[0];
                $count = (int)$parts[1];

                $item = StringToItemParser::getInstance()->parse($itemName);
                if ($item !== null) {
                    $item->setCount($count);
                    $itemRewards[] = $item;
                } else {
                    $this->getLogger()->warning("Vật phẩm vanilla '{$itemName}' không hợp lệ!");
                }
            }
        }

        // Check inventory space
        $inventory = $player->getInventory();
        $neededSlots = 0;
        foreach ($itemRewards as $item) {
            if (!$inventory->canAddItem($item)) {
                $neededSlots++;
            }
        }

        if ($neededSlots > 0) {
            $msg = str_replace("{slots}", (string)$neededSlots, $this->getConfig()->getNested("messages.inventory_full", "§cTúi đồ của bạn không đủ chỗ trống!"));
            $player->sendMessage($this->prefix . $msg);
            $player->getWorld()->addSound($player->getPosition(), new AnvilUseSound());
            return;
        }

        // 5. Save to database first to prevent double-claiming exploits
        $saveStmt = $this->db->prepare("INSERT OR REPLACE INTO claims (player, code, claim_time) VALUES (:player, :code, :time)");
        $saveStmt->bindValue(":player", $playerName, SQLITE3_TEXT);
        $saveStmt->bindValue(":code", $codeLower, SQLITE3_TEXT);
        $saveStmt->bindValue(":time", time(), SQLITE3_INTEGER);
        $saveStmt->execute();

        // 6. Give Rewards
        $rewardMessages = [];

        // Give Money (AZEconomy)
        $money = (int)($codeData["money"] ?? 0);
        if ($money > 0) {
            if (class_exists(\AZEconomy\AZEconomy::class)) {
                \AZEconomy\AZEconomy::getInstance()->addMoney($player->getName(), $money);
                $rewardMessages[] = "§e" . number_format($money) . " Xu";
            } else {
                $this->getLogger()->warning("AZEconomy không được tìm thấy, bỏ qua phần thưởng Xu.");
            }
        }

        // Give Coin (AZEconomy)
        $coin = (int)($codeData["coin"] ?? 0);
        if ($coin > 0) {
            if (class_exists(\AZEconomy\AZEconomy::class)) {
                \AZEconomy\AZEconomy::getInstance()->addCoin($player->getName(), $coin);
                $rewardMessages[] = "§e" . number_format($coin) . " Coin";
            } else {
                $this->getLogger()->warning("AZEconomy không được tìm thấy, bỏ qua phần thưởng Coin.");
            }
        }

        // Give Items
        $givenItemsText = [];
        foreach ($itemRewards as $item) {
            $inventory->addItem($item);
            $displayName = $item->hasCustomName() ? $item->getCustomName() : $item->getName();
            $givenItemsText[] = "§a{$displayName} §fx{$item->getCount()}";
        }

        if (count($givenItemsText) > 0) {
            $rewardMessages[] = implode(", ", $givenItemsText);
        }

        // Play level up sound
        $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(1));

        // Send confirmation message
        $rewardsSummary = count($rewardMessages) > 0 ? implode(" và ", $rewardMessages) : "không có gì";
        $successMsg = str_replace(
            ["{code}", "{rewards}"],
            [$matchedCodeKey, $rewardsSummary],
            $this->getConfig()->getNested("messages.success", "")
        );
        $player->sendMessage($this->prefix . $successMsg);
    }
}
