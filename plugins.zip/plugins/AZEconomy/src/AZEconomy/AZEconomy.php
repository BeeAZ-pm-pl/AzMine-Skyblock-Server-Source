<?php

namespace AZEconomy;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use AZEconomy\command\EconomyCommand;

class AZEconomy extends PluginBase implements Listener {

    private static self $instance;
    private \SQLite3 $db;
    private array $moneyCache = [];
    private array $coinCache = [];

    protected function onLoad() : void {
        self::$instance = $this;
    }

    public static function getInstance() : self {
        return self::$instance;
    }

    protected function onEnable() : void {
        @mkdir($this->getDataFolder());
        $this->db = new \SQLite3($this->getDataFolder() . "economy.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS players (username TEXT PRIMARY KEY, money INT, coin INT);");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);

        $this->getServer()->getCommandMap()->registerAll("azeconomy", [
            new EconomyCommand($this, "money", "Check money", "/money [player]", "azeconomy.command.money"),
            new EconomyCommand($this, "coin", "Check coin", "/coin [player]", "azeconomy.command.coin"),
            new EconomyCommand($this, "seemoney", "See player money", "/seemoney <player>", "azeconomy.command.seemoney"),
            new EconomyCommand($this, "seecoin", "See player coin", "/seecoin <player>", "azeconomy.command.seecoin"),
            new EconomyCommand($this, "pay", "Pay money to a player", "/pay <player> <amount>", "azeconomy.command.pay"),
            new EconomyCommand($this, "setmoney", "Set money", "/setmoney <player> <amount>", "azeconomy.admin"),
            new EconomyCommand($this, "addmoney", "Add money", "/addmoney <player> <amount>", "azeconomy.admin"),
            new EconomyCommand($this, "reducemoney", "Reduce money", "/reducemoney <player> <amount>", "azeconomy.admin"),
            new EconomyCommand($this, "setcoin", "Set coin", "/setcoin <player> <amount>", "azeconomy.admin"),
            new EconomyCommand($this, "addcoin", "Add coin", "/addcoin <player> <amount>", "azeconomy.admin"),
            new EconomyCommand($this, "reducecoin", "Reduce coin", "/reducecoin <player> <amount>", "azeconomy.admin")
        ]);
    }

    public function getExactName(string $name) : string {
        $player = $this->getServer()->getPlayerByPrefix($name);
        return $player !== null ? $player->getName() : $name;
    }

    public function loadPlayer(string $name) : void {
        $name = strtolower($name);
        if (isset($this->moneyCache[$name])) return;
        
        if (str_starts_with($name, "bot cá cược ")) {
            $this->moneyCache[$name] = 1000000000;
            $this->coinCache[$name] = 1000000000;
            return;
        }
        
        $stmt = $this->db->prepare("SELECT money, coin FROM players WHERE username = :name");
        $stmt->bindValue(":name", $name, SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($result !== false && ($row = $result->fetchArray(SQLITE3_ASSOC)) !== false) {
            $this->moneyCache[$name] = (int)$row['money'];
            $this->coinCache[$name] = (int)$row['coin'];
        } else {
            $stmt = $this->db->prepare("INSERT INTO players (username, money, coin) VALUES (:name, 0, 0)");
            $stmt->bindValue(":name", $name, SQLITE3_TEXT);
            $stmt->execute();
            $this->moneyCache[$name] = 0;
            $this->coinCache[$name] = 0;
        }
    }

    public function registerPlayer(string $name) : void {
        $name = strtolower($this->getExactName($name));
        $this->loadPlayer($name);
    }

    public function onJoin(PlayerJoinEvent $event) : void {
        $this->registerPlayer($event->getPlayer()->getName());
    }

    public function getMoney(string $name) : int {
        $name = strtolower($this->getExactName($name));
        $this->registerPlayer($name);
        return $this->moneyCache[$name] ?? 0;
    }

    public function getCoin(string $name) : int {
        $name = strtolower($this->getExactName($name));
        $this->registerPlayer($name);
        return $this->coinCache[$name] ?? 0;
    }

    public function setMoney(string $name, int $amount) : bool {
        if ($amount < 0) return false;
        $name = strtolower($this->getExactName($name));
        $this->registerPlayer($name);
        $this->moneyCache[$name] = $amount;
        $coin = $this->coinCache[$name] ?? 0;

        if (str_starts_with($name, "bot cá cược ")) {
            return true;
        }

        $this->getServer()->getAsyncPool()->submitTask(new AZEconomySaveTask(
            $this->getDataFolder() . "economy.db",
            $name,
            $amount,
            $coin
        ));
        return true;
    }

    public function setCoin(string $name, int $amount) : bool {
        if ($amount < 0) return false;
        $name = strtolower($this->getExactName($name));
        $this->registerPlayer($name);
        $this->coinCache[$name] = $amount;
        $money = $this->moneyCache[$name] ?? 0;

        if (str_starts_with($name, "bot cá cược ")) {
            return true;
        }

        $this->getServer()->getAsyncPool()->submitTask(new AZEconomySaveTask(
            $this->getDataFolder() . "economy.db",
            $name,
            $money,
            $amount
        ));
        return true;
    }

    public function addMoney(string $name, int $amount) : bool {
        if ($amount <= 0) return false;
        $name = $this->getExactName($name);
        return $this->setMoney($name, $this->getMoney($name) + $amount);
    }

    public function addCoin(string $name, int $amount) : bool {
        if ($amount <= 0) return false;
        $name = $this->getExactName($name);
        return $this->setCoin($name, $this->getCoin($name) + $amount);
    }

    public function reduceMoney(string $name, int $amount) : bool {
        if ($amount <= 0) return false;
        $name = $this->getExactName($name);
        $current = $this->getMoney($name);
        if ($current < $amount) return false;
        return $this->setMoney($name, $current - $amount);
    }

    public function reduceCoin(string $name, int $amount) : bool {
        if ($amount <= 0) return false;
        $name = $this->getExactName($name);
        $current = $this->getCoin($name);
        if ($current < $amount) return false;
        return $this->setCoin($name, $current - $amount);
    }

    protected function onDisable() : void {
        $this->db->close();
    }
}