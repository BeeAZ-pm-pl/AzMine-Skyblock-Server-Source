<?php

declare(strict_types=1);

namespace AZEconomy;

use pocketmine\scheduler\AsyncTask;

class AZEconomySaveTask extends AsyncTask {
    public function __construct(
        private string $dbPath,
        private string $username,
        private int $money,
        private int $coin
    ) {}

    public function onRun() : void {
        $db = new \SQLite3($this->dbPath);
        $db->busyTimeout(5000);
        
        $stmt = $db->prepare("INSERT OR REPLACE INTO players (username, money, coin) VALUES (:name, :money, :coin)");
        $stmt->bindValue(":name", $this->username, SQLITE3_TEXT);
        $stmt->bindValue(":money", $this->money, SQLITE3_INTEGER);
        $stmt->bindValue(":coin", $this->coin, SQLITE3_INTEGER);
        $stmt->execute();
        
        $db->close();
    }
}
