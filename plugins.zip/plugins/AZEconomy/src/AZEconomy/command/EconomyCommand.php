<?php

namespace AZEconomy\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use AZEconomy\AZEconomy;

class EconomyCommand extends Command {

    public function __construct(private AZEconomy $plugin, string $name, string $desc, string $usage, string $perm) {
        parent::__construct($name, $desc, $usage);
        $this->setPermission($perm);
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return false;

        $cmd = $this->getName();

        if ($cmd === "pay") {
            if (!$sender instanceof \pocketmine\player\Player) {
                $sender->sendMessage("Lệnh này chỉ có thể sử dụng trong trò chơi.");
                return false;
            }
            if (count($args) < 2) {
                $sender->sendMessage("Sử dụng: /pay <tên người chơi> <số tiền>");
                return false;
            }

            $targetName = $args[0];
            $amount = (int) $args[1];

            if ($amount <= 0) {
                $sender->sendMessage("Số tiền thanh toán phải lớn hơn 0.");
                return false;
            }

            $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
            if ($target === null) {
                $sender->sendMessage("Không tìm thấy người chơi '$targetName'. Người nhận phải online.");
                return false;
            }

            if ($target->getName() === $sender->getName()) {
                $sender->sendMessage("Bạn không thể tự thanh toán cho chính mình.");
                return false;
            }

            $senderMoney = $this->plugin->getMoney($sender->getName());
            if ($senderMoney < $amount) {
                $sender->sendMessage("Bạn không có đủ tiền. Số dư hiện tại: " . $senderMoney);
                return false;
            }

            $this->plugin->reduceMoney($sender->getName(), $amount);
            $this->plugin->addMoney($target->getName(), $amount);

            $sender->sendMessage("§aBạn đã chuyển thành công §e" . number_format($amount) . "$ §acho §7" . $target->getName());
            $target->sendMessage("§aBạn đã nhận được §e" . number_format($amount) . "$ §atừ §7" . $sender->getName());
            return true;
        }
        
        if ($cmd === "money" || $cmd === "coin" || $cmd === "seemoney" || $cmd === "seecoin") {
            if ($cmd === "seemoney" || $cmd === "seecoin") {
                if (count($args) < 1) {
                    $sender->sendMessage("Sử dụng: /$cmd <player>");
                    return false;
                }
                $target = $args[0];
            } else {
                if (!$sender instanceof \pocketmine\player\Player && !isset($args[0])) {
                    $sender->sendMessage("Sử dụng: /$cmd <player>");
                    return false;
                }
                $target = $sender->getName();
                if (isset($args[0])) {
                    if (!$sender->hasPermission("azeconomy.admin")) {
                        $sender->sendMessage("No permission.");
                        return false;
                    }
                    $target = $args[0];
                }
            }

            if ($cmd === "money" || $cmd === "seemoney") {
                if ($cmd === "seemoney") {
                    $sender->sendMessage("§aTiền của §e" . $target . "§a: §e" . number_format($this->plugin->getMoney($target)) . "$");
                } else {
                    $sender->sendMessage("Money ($target): " . $this->plugin->getMoney($target));
                }
            } else {
                if ($cmd === "seecoin") {
                    $sender->sendMessage("§aCoin của §e" . $target . "§a: §e" . number_format($this->plugin->getCoin($target)) . " coin");
                } else {
                    $sender->sendMessage("Coin ($target): " . $this->plugin->getCoin($target));
                }
            }
            return true;
        }

        if (count($args) < 2) {
            $sender->sendMessage("Usage: " . $this->getUsage());
            return false;
        }

        $target = $args[0];
        $amount = (int) $args[1];

        if ($amount < 0) {
            $sender->sendMessage("Amount >= 0");
            return false;
        }

        $res = false;
        switch ($cmd) {
            case "setmoney": $res = $this->plugin->setMoney($target, $amount); break;
            case "addmoney": $res = $this->plugin->addMoney($target, $amount); break;
            case "reducemoney": $res = $this->plugin->reduceMoney($target, $amount); break;
            case "setcoin": $res = $this->plugin->setCoin($target, $amount); break;
            case "addcoin": $res = $this->plugin->addCoin($target, $amount); break;
            case "reducecoin": $res = $this->plugin->reduceCoin($target, $amount); break;
        }

        if ($res) {
            $sender->sendMessage("Success: $cmd $target $amount");
        } else {
            $sender->sendMessage("Failed.");
        }

        return true;
    }
}