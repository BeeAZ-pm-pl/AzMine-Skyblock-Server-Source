<?php

namespace BeeAZ\AntiSpamChat;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\plugin\PluginBase;

class ASC extends PluginBase implements Listener {

    private $chatCooldowns = [];

    public function onEnable():void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onPlayerChat(PlayerChatEvent $event) {
        $player = $event->getPlayer();
        $playerName = $player->getName();
        if ($this->isSpamming($playerName)) {
            $event->cancel();
            $player->sendMessage("Vui lòng chat chậm lại !");
        }
        $this->updateChatTimestamp($playerName);
    }

    private function isSpamming($playerName) {
        $currentTime = time();

        if (isset($this->chatCooldowns[$playerName])) {
            $lastChatTimestamp = $this->chatCooldowns[$playerName];
            $cooldownTime = 2.1;
            if (($currentTime - $lastChatTimestamp) < $cooldownTime) {
                return true;
            }
        }

        return false;
    }

    private function updateChatTimestamp($playerName) {
        $this->chatCooldowns[$playerName] = time();
    }
}
