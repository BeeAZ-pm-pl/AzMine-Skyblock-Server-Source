<?php

declare(strict_types=1);

namespace BeeAZ\AZNapThe\task;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use BeeAZ\AZNapThe\Main;

class CardAPITask extends AsyncTask {

    private string $url;
    private string $partnerId;
    private string $secretKey;
    private string $requestId;
    private string $telco;
    private int $amount;
    private string $serial;
    private string $code;
    private string $command;
    private string $playerName;

    public function __construct(
        string $url,
        string $partnerId,
        string $secretKey,
        string $requestId,
        string $telco,
        int $amount,
        string $serial,
        string $code,
        string $command,
        string $playerName
    ) {
        $this->url = $url;
        $this->partnerId = $partnerId;
        $this->secretKey = $secretKey;
        $this->requestId = $requestId;
        $this->telco = $telco;
        $this->amount = $amount;
        $this->serial = $serial;
        $this->code = $code;
        $this->command = $command;
        $this->playerName = $playerName;
    }

    public function onRun(): void {
        $sign = md5($this->secretKey . $this->code . $this->serial);
        $queryParams = [
            'partner_id' => $this->partnerId,
            'request_id' => $this->requestId,
            'telco' => $this->telco,
            'amount' => $this->amount,
            'serial' => $this->serial,
            'code' => $this->code,
            'command' => $this->command,
            'sign' => $sign,
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($queryParams));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $this->setResult([
                'success' => false,
                'message' => "Lỗi cURL: " . $error
            ]);
            return;
        }

        if ($httpCode !== 200 || !$response) {
            $this->setResult([
                'success' => false,
                'message' => "Lỗi phản hồi API (HTTP " . $httpCode . ")"
            ]);
            return;
        }

        $data = json_decode($response, true);
        if ($data === null) {
            $this->setResult([
                'success' => false,
                'message' => "Phản hồi API không đúng định dạng JSON"
            ]);
            return;
        }

        $this->setResult([
            'success' => true,
            'status' => $data['status'] ?? 5,
            'value' => (int)($data['amount'] ?? $this->amount),
            'message' => $data['message'] ?? $data['msg'] ?? 'Lỗi không xác định.'
        ]);
    }

    public function onCompletion(): void {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("AZNapThe");
        if ($plugin instanceof Main && $plugin->isEnabled()) {
            $plugin->handleAPIResult(
                $this->playerName,
                $this->requestId,
                $this->telco,
                $this->amount,
                $this->serial,
                $this->code,
                $this->command,
                $this->getResult()
            );
        }
    }
}
