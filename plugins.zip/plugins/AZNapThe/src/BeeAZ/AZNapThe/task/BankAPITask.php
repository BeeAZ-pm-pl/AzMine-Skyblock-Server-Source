<?php

declare(strict_types=1);

namespace BeeAZ\AZNapThe\task;

use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use BeeAZ\AZNapThe\Main;

class BankAPITask extends AsyncTask {

    private string $apiUrl;
    private string $authToken;
    private string $content;
    private float $amount;
    private string $playerName;
    private int $transactionId;

    public function __construct(
        string $apiUrl,
        string $authToken,
        string $content,
        float $amount,
        string $playerName,
        int $transactionId
    ) {
        $this->apiUrl = $apiUrl;
        $this->authToken = $authToken;
        $this->content = $content;
        $this->amount = $amount;
        $this->playerName = $playerName;
        $this->transactionId = $transactionId;
    }

    public function onRun(): void {
        $url = $this->apiUrl . "?auth=" . urlencode($this->authToken) . "&content=" . urlencode($this->content) . "&amount=" . $this->amount;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            $this->setResult([
                'success' => false,
                'message' => "Lỗi cURL: " . $error
            ]);
            return;
        }

        if ($httpCode !== 200 || !$response) {
            $this->setResult([
                'success' => false,
                'message' => "Lỗi phản hồi API (HTTP " . $httpCode . ")"
            ]);
            return;
        }

        $data = json_decode($response, true);
        if ($data === null) {
            $this->setResult([
                'success' => false,
                'message' => "Phản hồi API không đúng định dạng JSON"
            ]);
            return;
        }

        if (isset($data['exists']) && $data['exists'] === true) {
            $this->setResult([
                'success' => true,
                'exists' => true,
                'message' => 'Thành công'
            ]);
        } else {
            $this->setResult([
                'success' => true,
                'exists' => false,
                'message' => 'Chưa tìm thấy chuyển khoản hoặc sai mệnh giá.'
            ]);
        }
    }

    public function onCompletion(): void {
        $plugin = Server::getInstance()->getPluginManager()->getPlugin("AZNapThe");
        if ($plugin instanceof Main && $plugin->isEnabled()) {
            $plugin->handleBankAPIResult(
                $this->transactionId,
                $this->playerName,
                $this->content,
                $this->amount,
                $this->getResult()
            );
        }
    }
}
