<?php

declare(strict_types=1);

namespace BeeAZ\AZNapThe\task;

use pocketmine\scheduler\Task;
use BeeAZ\AZNapThe\Main;

class AutoCheckTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $this->plugin->checkPendingCards();
    }
}
