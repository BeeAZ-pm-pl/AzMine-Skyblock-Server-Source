<?php

declare(strict_types=1);

namespace BeeAZ\AZNapThe;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\sound\XpLevelUpSound;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Dropdown;
use AZEconomy\AZEconomy;
use BeeAZ\AZNapThe\task\CardAPITask;
use BeeAZ\AZNapThe\task\BankAPITask;
use BeeAZ\AZNapThe\task\AutoCheckTask;

class Main extends PluginBase {

    private \SQLite3 $db;
    
    private string $apiUrl;
    private string $partnerId;
    private string $secretKey;
    private float $coinMultiplier;
    private float $discountMultiplier;
    private array $supportedTelcos;
    private array $supportedAmounts;

    private bool $bankEnabled;
    private string $bankName;
    private string $bankAccountNo;
    private string $bankAccountOwner;
    private string $bankMemoPrefix;
    private string $bankApiUrl;
    private string $bankAuthToken;
    private float $bankCoinMultiplier;

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        if ($this->getServer()->getPluginManager()->getPlugin("AZEconomy") === null) {
            $this->getLogger()->error("Khong tim thay plugin AZEconomy! Vo hieu hoa plugin.");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        $config = $this->getConfig();
        $this->apiUrl = $config->get("api-url", "https://pay1s.com/chargingws/v2");
        $this->partnerId = $config->get("partner-id", "80994979569");
        $this->secretKey = $config->get("secret-key", "ec5db2bb94f5041a636a8c4488ec2165");
        $this->coinMultiplier = (float) $config->get("coin-multiplier", 1.0);
        $this->discountMultiplier = (float) $config->get("discount-multiplier", 0.8);
        $this->supportedTelcos = $config->get("supported-telcos", ["VIETTEL", "MOBIFONE", "VINAPHONE", "ZING", "GATE", "GARENA", "VCOIN", "SCOIN"]);
        $this->supportedAmounts = $config->get("supported-amounts", [10000, 20000, 50000, 100000, 200000, 500000, 1000000]);

        $this->bankEnabled = (bool) $config->get("bank-enabled", true);
        $this->bankName = $config->get("bank-name", "TP Bank (Tien Phong Bank)");
        $this->bankAccountNo = $config->get("bank-account-no", "88621122005");
        $this->bankAccountOwner = $config->get("bank-account-owner", "NGUYEN CONG DAT");
        $this->bankMemoPrefix = $config->get("bank-memo-prefix", "AZ");
        $this->bankApiUrl = $config->get("bank-api-url", "https://playzonex.run.place/pages/deposit/api_check_payment.php");
        if(empty($this->bankApiUrl)) {
            $this->bankApiUrl = "https://playzonex.run.place/pages/deposit/api_check_payment.php";
        }
        $this->bankAuthToken = $config->get("bank-auth-token", "f81b1574a441113f8c8574164b300f89");
        if(empty($this->bankAuthToken)) {
            $this->bankAuthToken = "f81b1574a441113f8c8574164b300f89";
        }
        $this->bankCoinMultiplier = (float) $config->get("bank-coin-multiplier", 1.2);

        @mkdir($this->getDataFolder());
        $this->db = new \SQLite3($this->getDataFolder() . "napthe.db");
        
        $this->db->exec("CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player TEXT,
            request_id TEXT UNIQUE,
            telco TEXT,
            code TEXT,
            serial TEXT,
            declared_amount INTEGER,
            final_amount INTEGER DEFAULT 0,
            coins INTEGER DEFAULT 0,
            status TEXT,
            created_time INTEGER,
            message TEXT
        );");

        $this->db->exec("CREATE TABLE IF NOT EXISTS bank_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player TEXT,
            memo TEXT UNIQUE,
            amount REAL,
            coins INTEGER DEFAULT 0,
            status TEXT,
            created_time INTEGER,
            message TEXT
        );");

        $interval = (int) $config->get("auto-check-interval-seconds", 30);
        $this->getScheduler()->scheduleRepeatingTask(new AutoCheckTask($this), $interval * 20);
    }

    protected function onDisable(): void {
        if (isset($this->db)) {
            $this->db->close();
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "napthe") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("Lệnh này chỉ có thể sử dụng trong trò chơi.");
                return true;
            }
            $this->sendMainMenu($sender);
            return true;
        }
        return false;
    }

    public function sendMainMenu(Player $player): void {
        $eco = AZEconomy::getInstance();
        $coin = $eco->getCoin($player->getName());

        $text = "§l§eHỆ THỐNG NẠP TIỀN TỰ ĐỘNG §r§7- SkyBlock\n";
        $text .= "§fSố dư Coin hiện tại: §a" . number_format($coin) . " Coin\n\n";
        $text .= "§7Vui lòng chọn hình thức nạp tiền:";

        $options = [];
        $options[] = new MenuOption("§l§0⚡ §cNẠP THẺ CÀO §0⚡\n§r§7Viettel, Mobi, Vina... (Nhận " . ($this->discountMultiplier * 100) . "%)", new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH));
        
        if ($this->bankEnabled) {
            $options[] = new MenuOption("§l§0⚡ §aNẠP QUA NGÂN HÀNG §0⚡\n§r§7Chuyển khoản ATM (Nhận " . ($this->bankCoinMultiplier * 100) . "%)", new FormIcon("textures/items/gold_ingot", FormIcon::IMAGE_TYPE_PATH));
        }
        
        $options[] = new MenuOption("§l§0⚡ §6TOP NẠP THẺ §0⚡\n§r§7Xem bảng xếp hạng nạp thẻ", new FormIcon("textures/items/nether_star", FormIcon::IMAGE_TYPE_PATH));
        $options[] = new MenuOption("§l§0⚡ §eLỊCH SỬ GIAO DỊCH §0⚡\n§r§7Xem các giao dịch gần nhất", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH));
        $options[] = new MenuOption("§l§0⚡ §bKIỂM TRA GIAO DỊCH §0⚡\n§r§7Cập nhật trạng thái ngay", new FormIcon("textures/items/comparator", FormIcon::IMAGE_TYPE_PATH));
        $options[] = new MenuOption("§l§0⚡ §8ĐÓNG MENU §0⚡\n§r§7Thoát giao diện", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));

        $form = new MenuForm(
            "§l§0⚡ §9NẠP TIỀN §0⚡",
            $text,
            $options,
            function (Player $submitter, int $selected) : void {
                if (!$this->bankEnabled) {
                    switch ($selected) {
                        case 0:
                            $this->sendNapTheForm($submitter);
                            break;
                        case 1:
                            $this->sendTopNapTheMenu($submitter);
                            break;
                        case 2:
                            $this->sendHistoryMenu($submitter);
                            break;
                        case 3:
                            $submitter->sendMessage($this->getConfig()->getNested("messages.prefix", "") . "§eĐang kiểm tra lại các giao dịch đang chờ duyệt của bạn...");
                            $this->checkPendingCards($submitter->getName());
                            break;
                    }
                } else {
                    switch ($selected) {
                        case 0:
                            $this->sendNapTheForm($submitter);
                            break;
                        case 1:
                            $this->sendBankForm($submitter);
                            break;
                        case 2:
                            $this->sendTopNapTheMenu($submitter);
                            break;
                        case 3:
                            $this->sendHistoryMenu($submitter);
                            break;
                        case 4:
                            $submitter->sendMessage($this->getConfig()->getNested("messages.prefix", "") . "§eĐang kiểm tra lại các giao dịch đang chờ duyệt của bạn...");
                            $this->checkPendingCards($submitter->getName());
                            break;
                    }
                }
            }
        );
        $player->sendForm($form);
    }

    public function sendNapTheForm(Player $player): void {
        $telcoOptions = $this->supportedTelcos;
        
        $amountOptionsFormatted = [];
        foreach ($this->supportedAmounts as $val) {
            $amountOptionsFormatted[] = number_format($val) . " VND";
        }

        $form = new CustomForm(
            "§l§0⚡ §cNẠP THẺ CÀO §0⚡",
            [
                new Dropdown("telco", "§eChọn nhà mạng/loại thẻ cào:", $telcoOptions),
                new Dropdown("amount", "§eChọn đúng mệnh giá thẻ cào:\n§c(Chọn sai mệnh giá sẽ mất thẻ hoặc lỗi nhận coin!)", $amountOptionsFormatted),
                new Input("serial", "§eNhập số Seri in trên thẻ:", "Số seri thẻ cào"),
                new Input("code", "§eNhập mã thẻ cào (dưới lớp bạc):", "Mã PIN thẻ cào")
            ],
            function (Player $submitter, CustomFormResponse $response) use ($telcoOptions): void {
                $telcoIndex = $response->getInt("telco");
                $amountIndex = $response->getInt("amount");
                $serial = trim($response->getString("serial"));
                $code = trim($response->getString("code"));

                $prefix = $this->getConfig()->getNested("messages.prefix", "");

                if (empty($serial) || empty($code) || !preg_match('/^[a-zA-Z0-9]+$/', $serial) || !preg_match('/^[a-zA-Z0-9]+$/', $code)) {
                    $submitter->sendMessage($prefix . $this->getConfig()->getNested("messages.invalid-card", ""));
                    return;
                }

                $telco = $telcoOptions[$telcoIndex];
                $amount = $this->supportedAmounts[$amountIndex];

                $requestId = "AZ_" . uniqid() . "_" . mt_rand(100, 999);
                $time = time();

                $stmt = $this->db->prepare("INSERT INTO transactions (player, request_id, telco, code, serial, declared_amount, status, created_time, message) VALUES (:player, :request_id, :telco, :code, :serial, :amount, 'pending', :time, 'Đang gửi thẻ...')");
                $stmt->bindValue(":player", $submitter->getName(), SQLITE3_TEXT);
                $stmt->bindValue(":request_id", $requestId, SQLITE3_TEXT);
                $stmt->bindValue(":telco", $telco, SQLITE3_TEXT);
                $stmt->bindValue(":code", $code, SQLITE3_TEXT);
                $stmt->bindValue(":serial", $serial, SQLITE3_TEXT);
                $stmt->bindValue(":amount", $amount, SQLITE3_INTEGER);
                $stmt->bindValue(":time", $time, SQLITE3_INTEGER);
                $stmt->execute();

                $submitter->sendMessage($prefix . $this->getConfig()->getNested("messages.sending", ""));
                $this->getServer()->getAsyncPool()->submitTask(new CardAPITask(
                    $this->apiUrl,
                    $this->partnerId,
                    $this->secretKey,
                    $requestId,
                    $telco,
                    $amount,
                    $serial,
                    $code,
                    "charging",
                    $submitter->getName()
                ));
            },
            function (Player $submitter): void {
                $this->sendMainMenu($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function sendBankForm(Player $player): void {
        $previewCoins = number_format((10000 / 1000) * $this->bankCoinMultiplier);
        
        $form = new CustomForm(
            "§l§0⚡ §aNẠP QUA NGÂN HÀNG §0⚡",
            [
                new Label("label_info", "§eQuy đổi: §a10,000 VND = " . $previewCoins . " Coin\n§7Nhập số tiền chuyển khoản bên dưới. Sau khi gửi, bạn cần thực hiện chuyển khoản đúng số tiền và nội dung cung cấp."),
                new Input("amount", "§eNhập số tiền muốn nạp (VND):", "Tối thiểu 10,000", "50000")
            ],
            function (Player $submitter, CustomFormResponse $response) : void {
                $amountStr = trim($response->getString("amount"));
                $prefix = $this->getConfig()->getNested("messages.prefix", "");
                
                if (!is_numeric($amountStr) || (float)$amountStr < 10000) {
                    $submitter->sendMessage($prefix . "§cSố tiền nạp không hợp lệ! Số tiền tối thiểu là 10,000 VND.");
                    return;
                }

                $amount = (float)$amountStr;
                
                $cleanName = strtoupper(str_replace(" ", "", $submitter->getName()));
                $memo = strtoupper($this->bankMemoPrefix) . $cleanName . mt_rand(100, 999);
                $time = time();
                
                $coins = (int) (($amount / 1000) * $this->bankCoinMultiplier);

                $stmt = $this->db->prepare("INSERT INTO bank_transactions (player, memo, amount, coins, status, created_time, message) VALUES (:player, :memo, :amount, :coins, 'pending', :time, 'Chờ chuyển khoản...')");
                $stmt->bindValue(":player", $submitter->getName(), SQLITE3_TEXT);
                $stmt->bindValue(":memo", $memo, SQLITE3_TEXT);
                $stmt->bindValue(":amount", $amount, SQLITE3_FLOAT);
                $stmt->bindValue(":coins", $coins, SQLITE3_INTEGER);
                $stmt->bindValue(":time", $time, SQLITE3_INTEGER);
                $stmt->execute();

                $this->sendBankPaymentInfo($submitter, $memo, $amount);
            },
            function (Player $submitter): void {
                $this->sendMainMenu($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function sendBankPaymentInfo(Player $player, string $memo, float $amount): void {
        $prefix = $this->getConfig()->getNested("messages.prefix", "");
        
        $infoText = $this->getConfig()->getNested("messages.bank-info", "");
        $infoText = str_replace(
            ["{bank}", "{account}", "{owner}", "{amount}", "{memo}"],
            [$this->bankName, $this->bankAccountNo, $this->bankAccountOwner, number_format($amount), $memo],
            $infoText
        );

        $player->sendMessage("\n§7========================================\n" . $infoText . "\n§7========================================\n");
        $player->sendMessage($prefix . "§aThông tin chuyển khoản cũng đã được in ra khung chat của bạn để tiện copy!");

        $form = new MenuForm(
            "§l§0⚡ §aTHÔNG TIN THANH TOÁN §0⚡",
            $infoText,
            [
                new MenuOption("§l§0⚡ §8QUAY LẠI MENU CHÍNH §0⚡", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
            ],
            function (Player $submitter, int $selected): void {
                $this->sendMainMenu($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function sendHistoryMenu(Player $player): void {
        $sql = "
            SELECT 'Card' as type, telco as detail, declared_amount as amount, coins, status, created_time, message FROM transactions WHERE player = :player1
            UNION ALL
            SELECT 'Bank' as type, memo as detail, amount as amount, coins, status, created_time, message FROM bank_transactions WHERE player = :player2
            ORDER BY created_time DESC LIMIT 10
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->bindValue(":player1", $player->getName(), SQLITE3_TEXT);
        $stmt->bindValue(":player2", $player->getName(), SQLITE3_TEXT);
        $result = $stmt->execute();

        $text = "§l§eLỊCH SỬ GIAO DỊCH GẦN NHẤT:\n\n";
        $hasData = false;

        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $hasData = true;
            $date = date("d/m/Y H:i", $row['created_time']);
            $statusText = "§eĐang Chờ";
            if ($row['status'] === "completed") {
                $statusText = "§aThành Công";
            } elseif ($row['status'] === "failed" || $row['status'] === "expired") {
                $statusText = "§cThất Bại";
            }

            $typeText = $row['type'] === 'Card' ? "§cThẻ Cào" : "§aNgân Hàng";
            
            $text .= "§b• Ngày: §7" . $date . " §f[{$typeText}§f]\n";
            $text .= "  §fThông tin: §e" . $row['detail'] . " §f| Mệnh giá: §6" . number_format($row['amount']) . " VND\n";
            if ($row['status'] === "completed") {
                $text .= "  §fNhận thực tế: §d+" . number_format($row['coins']) . " Coin\n";
            }
            $text .= "  §fTrạng thái: " . $statusText . " §7(" . $row['message'] . ")\n\n";
        }

        if (!$hasData) {
            $text .= "§cBạn chưa có giao dịch nạp tiền nào gần đây.";
        }

        $form = new MenuForm(
            "§l§0⚡ §eLỊCH SỬ GIAO DỊCH §0⚡",
            $text,
            [new MenuOption("§l§0⚡ §8QUAY LẠI §0⚡", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))],
            function (Player $submitter, int $selected): void {
                $this->sendMainMenu($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function sendTopNapTheMenu(Player $player): void {
        $sql = "
            SELECT player, SUM(total_amount) AS total FROM (
                SELECT player, final_amount AS total_amount FROM transactions WHERE status = 'completed'
                UNION ALL
                SELECT player, amount AS total_amount FROM bank_transactions WHERE status = 'completed'
            ) GROUP BY player ORDER BY total DESC LIMIT 10
        ";

        $result = $this->db->query($sql);
        
        $text = "§l§eBẢNG XẾP HẠNG TOP NẠP THẺ:\n\n";
        $hasData = false;
        $rank = 1;

        if ($result) {
            while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
                $hasData = true;
                $color = "§f";
                if ($rank === 1) $color = "§6§l🏆 ";
                elseif ($rank === 2) $color = "§d🥈 ";
                elseif ($rank === 3) $color = "§e🥉 ";
                else $color = "§7#" . $rank . " ";

                $text .= $color . "§b" . $row['player'] . " §f- §a" . number_format($row['total']) . " VND\n";
                $rank++;
            }
        }

        if (!$hasData) {
            $text .= "§cChưa có dữ liệu bảng xếp hạng nạp thẻ.";
        }

        $form = new MenuForm(
            "§l§0⚡ §6TOP NẠP THẺ §0⚡",
            $text,
            [new MenuOption("§l§0⚡ §8QUAY LẠI §0⚡", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))],
            function (Player $submitter, int $selected): void {
                $this->sendMainMenu($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function handleAPIResult(
        string $playerName,
        string $requestId,
        string $telco,
        int $amount,
        string $serial,
        string $code,
        string $command,
        ?array $result
    ): void {
        $prefix = $this->getConfig()->getNested("messages.prefix", "");
        $player = $this->getServer()->getPlayerExact($playerName);

        if ($result === null || !$result['success']) {
            $errMessage = $result['message'] ?? "Lỗi kết nối API.";
            $stmt = $this->db->prepare("UPDATE transactions SET message = :msg WHERE request_id = :rid");
            $stmt->bindValue(":msg", $errMessage, SQLITE3_TEXT);
            $stmt->bindValue(":rid", $requestId, SQLITE3_TEXT);
            $stmt->execute();

            if ($player !== null) {
                $player->sendMessage($prefix . "§cKết nối tới cổng nạp thẻ tạm thời gián đoạn. Thẻ của bạn vẫn được lưu trên hệ thống và sẽ tự động duyệt lại sau.");
            }
            return;
        }

        $apiStatus = (int) $result['status'];
        $apiMessage = $result['message'];
        $finalAmount = (int) $result['value'];

        if ($apiStatus === 1 || $apiStatus === 2) {
            $baseCoin = $finalAmount / 1000;
            $coins = (int) ($baseCoin * $this->coinMultiplier * $this->discountMultiplier);
            
            if ($apiStatus === 2) {
                $coins = (int) ($coins * 0.8);
            }
            
            $stmtCheck = $this->db->prepare("SELECT status FROM transactions WHERE request_id = :rid");
            $stmtCheck->bindValue(":rid", $requestId, SQLITE3_TEXT);
            $checkRes = $stmtCheck->execute()->fetchArray(SQLITE3_ASSOC);

            if ($checkRes && $checkRes['status'] !== 'completed') {
                $msg = $apiStatus === 2 ? "Thành công (Sai mệnh giá, thực tế: " . number_format($finalAmount) . ", phạt -20% Coin)" : "Thành công";
                $stmt = $this->db->prepare("UPDATE transactions SET status = 'completed', final_amount = :fam, coins = :coins, message = :msg WHERE request_id = :rid");
                $stmt->bindValue(":fam", $finalAmount, SQLITE3_INTEGER);
                $stmt->bindValue(":coins", $coins, SQLITE3_INTEGER);
                $stmt->bindValue(":msg", $msg, SQLITE3_TEXT);
                $stmt->bindValue(":rid", $requestId, SQLITE3_TEXT);
                $stmt->execute();

                AZEconomy::getInstance()->addCoin($playerName, $coins);

                if ($player !== null) {
                    $player->sendMessage(str_replace("{coins}", number_format($coins), $prefix . $this->getConfig()->getNested("messages.success", "")));
                    $player->sendTitle("§a§lNẠP COIN THÀNH CÔNG", "§e+" . number_format($coins) . " Coin", 10, 50, 10);
                    $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(1));
                }

                $broadcast = str_replace(["{player}", "{amount}", "{coins}"], [$playerName, number_format($finalAmount), number_format($coins)], $prefix . $this->getConfig()->getNested("messages.broadcast-success", ""));
                $this->getServer()->broadcastMessage($broadcast);
            }
        } elseif (in_array($apiStatus, [3, 4, 100])) {
            $customMessage = $apiMessage;
            if ($apiStatus === 3) $customMessage = "Mã thẻ hoặc số seri không chính xác hoặc thẻ đã được sử dụng.";
            if ($apiStatus === 4) $customMessage = "Cổng nạp thẻ của nhà mạng này hiện đang bảo trì.";
            
            $stmt = $this->db->prepare("UPDATE transactions SET status = 'failed', message = :msg WHERE request_id = :rid");
            $stmt->bindValue(":msg", $customMessage, SQLITE3_TEXT);
            $stmt->bindValue(":rid", $requestId, SQLITE3_TEXT);
            $stmt->execute();

            if ($player !== null) {
                $player->sendMessage(str_replace("{reason}", $customMessage, $prefix . $this->getConfig()->getNested("messages.failed", "")));
                $player->sendTitle("§c§lNẠP THẺ THẤT BẠI", "§7" . $customMessage, 10, 50, 10);
            }
        } else {
            $stmt = $this->db->prepare("UPDATE transactions SET message = :msg WHERE request_id = :rid");
            $stmt->bindValue(":msg", $apiMessage, SQLITE3_TEXT);
            $stmt->bindValue(":rid", $requestId, SQLITE3_TEXT);
            $stmt->execute();

            if ($player !== null && $command === "charging") {
                $player->sendMessage($prefix . $this->getConfig()->getNested("messages.pending", ""));
            }
        }
    }

    public function handleBankAPIResult(
        int $transactionId,
        string $playerName,
        string $memo,
        float $amount,
        ?array $result
    ): void {
        $prefix = $this->getConfig()->getNested("messages.prefix", "");
        $player = $this->getServer()->getPlayerExact($playerName);

        if ($result === null || !$result['success']) {
            $errMessage = $result['message'] ?? "Lỗi kết nối API ngân hàng.";
            $stmt = $this->db->prepare("UPDATE bank_transactions SET message = :msg WHERE id = :id");
            $stmt->bindValue(":msg", $errMessage, SQLITE3_TEXT);
            $stmt->bindValue(":id", $transactionId, SQLITE3_INTEGER);
            $stmt->execute();
            return;
        }

        $exists = (bool)$result['exists'];
        $apiMessage = $result['message'];

        if ($exists) {
            $stmtCheck = $this->db->prepare("SELECT status, coins FROM bank_transactions WHERE id = :id");
            $stmtCheck->bindValue(":id", $transactionId, SQLITE3_INTEGER);
            $checkRes = $stmtCheck->execute()->fetchArray(SQLITE3_ASSOC);

            if ($checkRes && $checkRes['status'] !== 'completed') {
                $coins = (int)$checkRes['coins'];

                $stmt = $this->db->prepare("UPDATE bank_transactions SET status = 'completed', message = 'Thành công' WHERE id = :id");
                $stmt->bindValue(":id", $transactionId, SQLITE3_INTEGER);
                $stmt->execute();

                AZEconomy::getInstance()->addCoin($playerName, $coins);

                if ($player !== null) {
                    $player->sendMessage(str_replace("{coins}", number_format($coins), $prefix . $this->getConfig()->getNested("messages.bank-success", "")));
                    $player->sendTitle("§a§lNẠP BANK THÀNH CÔNG", "§e+" . number_format($coins) . " Coin", 10, 50, 10);
                    $player->getWorld()->addSound($player->getPosition(), new XpLevelUpSound(1));
                }

                $broadcast = str_replace(["{player}", "{amount}", "{coins}"], [$playerName, number_format($amount), number_format($coins)], $prefix . $this->getConfig()->getNested("messages.bank-broadcast-success", ""));
                $this->getServer()->broadcastMessage($broadcast);
            }
        } else {
            $stmt = $this->db->prepare("UPDATE bank_transactions SET message = :msg WHERE id = :id");
            $stmt->bindValue(":msg", $apiMessage, SQLITE3_TEXT);
            $stmt->bindValue(":id", $transactionId, SQLITE3_INTEGER);
            $stmt->execute();

            $stmtCheckTime = $this->db->prepare("SELECT created_time FROM bank_transactions WHERE id = :id");
            $stmtCheckTime->bindValue(":id", $transactionId, SQLITE3_INTEGER);
            $timeRes = $stmtCheckTime->execute()->fetchArray(SQLITE3_ASSOC);
            if ($timeRes && (time() - (int)$timeRes['created_time'] > 1800)) {
                $stmtExpire = $this->db->prepare("UPDATE bank_transactions SET status = 'failed', message = 'Giao dịch hết hạn (quá 30 phút)' WHERE id = :id");
                $stmtExpire->bindValue(":id", $transactionId, SQLITE3_INTEGER);
                $stmtExpire->execute();
            }
        }
    }

    public function checkPendingCards(?string $onlyPlayer = null): void {
        $queryCard = "SELECT request_id, telco, declared_amount, serial, code, player FROM transactions WHERE status = 'pending'";
        if ($onlyPlayer !== null) {
            $queryCard .= " AND player = :player";
        }
        $queryCard .= " LIMIT 15";

        $stmtCard = $this->db->prepare($queryCard);
        if ($onlyPlayer !== null) {
            $stmtCard->bindValue(":player", $onlyPlayer, SQLITE3_TEXT);
        }
        $resultCard = $stmtCard->execute();

        $count = 0;
        while ($row = $resultCard->fetchArray(SQLITE3_ASSOC)) {
            $count++;
            $this->getServer()->getAsyncPool()->submitTask(new CardAPITask(
                $this->apiUrl,
                $this->partnerId,
                $this->secretKey,
                $row['request_id'],
                $row['telco'],
                (int) $row['declared_amount'],
                $row['serial'],
                $row['code'],
                "check",
                $row['player']
            ));
        }

        if ($this->bankEnabled && !empty($this->bankApiUrl)) {
            $queryBank = "SELECT id, memo, amount, player FROM bank_transactions WHERE status = 'pending'";
            if ($onlyPlayer !== null) {
                $queryBank .= " AND player = :player";
            }
            $queryBank .= " LIMIT 15";

            $stmtBank = $this->db->prepare($queryBank);
            if ($onlyPlayer !== null) {
                $stmtBank->bindValue(":player", $onlyPlayer, SQLITE3_TEXT);
            }
            $resultBank = $stmtBank->execute();

            while ($row = $resultBank->fetchArray(SQLITE3_ASSOC)) {
                $count++;
                $this->getServer()->getAsyncPool()->submitTask(new BankAPITask(
                    $this->bankApiUrl,
                    $this->bankAuthToken,
                    $row['memo'],
                    (float)$row['amount'],
                    $row['player'],
                    (int)$row['id']
                ));
            }
        }

        if ($onlyPlayer !== null && $count === 0) {
            $player = $this->getServer()->getPlayerExact($onlyPlayer);
            if ($player !== null) {
                $player->sendMessage($this->getConfig()->getNested("messages.prefix", "") . "§aĐạo hữu không có giao dịch (Thẻ cào/ATM) nào đang chờ duyệt.");
            }
        }
    }
}