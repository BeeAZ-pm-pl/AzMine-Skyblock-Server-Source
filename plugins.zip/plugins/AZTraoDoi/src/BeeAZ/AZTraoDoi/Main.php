<?php

declare(strict_types=1);

namespace BeeAZ\AZTraoDoi;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerKickEvent;
use pocketmine\Server;
use muqsit\invmenu\InvMenuHandler;

class Main extends PluginBase implements Listener {

    private static self $instance;

    /** @var array<string, array{sender: string, time: int}> */
    private array $pendingRequests = [];

    /** @var array<string, TradeSession> */
    private array $activeSessions = [];

    protected function onEnable() : void {
        self::$instance = $this;

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public static function getInstance() : self {
        return self::$instance;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if ($command->getName() !== "traodoi") {
            return false;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi.");
            return true;
        }

        if (empty($args)) {
            $sender->sendMessage("§eSử dụng: §f/traodoi <tên người chơi> §ehoặc §f/traodoi accept/cancel");
            return true;
        }

        $sub = strtolower($args[0]);

        if ($sub === "accept") {
            $this->handleAccept($sender);
            return true;
        }

        if ($sub === "cancel") {
            $this->handleCancel($sender);
            return true;
        }

        // Send a request to another player
        $targetName = $args[0];
        $target = $this->getServer()->getPlayerByPrefix($targetName);

        if ($target === null) {
            $sender->sendMessage("§cNgười chơi §e" . $targetName . " §ckhông trực tuyến.");
            return true;
        }

        if ($target->getName() === $sender->getName()) {
            $sender->sendMessage("§cBạn không thể tự giao dịch với chính mình!");
            return true;
        }

        // Check if sender is in an active session
        if (isset($this->activeSessions[strtolower($sender->getName())])) {
            $sender->sendMessage("§cBạn đang trong một giao dịch khác!");
            return true;
        }

        // Check if target is in an active session
        if (isset($this->activeSessions[strtolower($target->getName())])) {
            $sender->sendMessage("§cNgười chơi §e" . $target->getName() . " §cđang bận giao dịch!");
            return true;
        }

        // Check if distance between players is close enough (optional, let's keep it simple or check if in same world)
        if ($sender->getWorld() !== $target->getWorld() || $sender->getPosition()->distance($target->getPosition()) > 15) {
            $sender->sendMessage("§cBạn cần phải đứng gần người chơi §e" . $target->getName() . " §ctrong phạm vi 15 block để giao dịch!");
            return true;
        }

        // Send request
        $this->pendingRequests[strtolower($target->getName())] = [
            "sender" => $sender->getName(),
            "time" => time()
        ];

        $sender->sendMessage("§aĐã gửi yêu cầu giao dịch tới §e" . $target->getName() . "§a. Yêu cầu tự hủy sau 30 giây.");
        $target->sendMessage("§e" . $sender->getName() . " §amuốn giao dịch với bạn. Gõ §e/traodoi accept §ađể đồng ý hoặc §e/traodoi cancel §ađể từ chối.");
        return true;
    }

    private function handleAccept(Player $player) : void {
        $nameLower = strtolower($player->getName());

        if (isset($this->activeSessions[$nameLower])) {
            $player->sendMessage("§cBạn đang trong một giao dịch khác!");
            return;
        }

        if (!isset($this->pendingRequests[$nameLower])) {
            $player->sendMessage("§cBạn không có yêu cầu giao dịch nào đang chờ!");
            return;
        }

        $request = $this->pendingRequests[$nameLower];
        unset($this->pendingRequests[$nameLower]);

        if (time() - $request["time"] > 30) {
            $player->sendMessage("§cYêu cầu giao dịch đã hết hạn!");
            return;
        }

        $sender = $this->getServer()->getPlayerExact($request["sender"]);
        if ($sender === null) {
            $player->sendMessage("§cNgười gửi yêu cầu giao dịch đã ngoại tuyến.");
            return;
        }

        if (isset($this->activeSessions[strtolower($sender->getName())])) {
            $player->sendMessage("§cĐối phương đang bận giao dịch khác!");
            return;
        }

        // Start session!
        $session = new TradeSession($sender, $player);
        $this->activeSessions[strtolower($sender->getName())] = $session;
        $this->activeSessions[$nameLower] = $session;

        $session->init();
    }

    private function handleCancel(Player $player) : void {
        $nameLower = strtolower($player->getName());

        // Cancel active trade
        if (isset($this->activeSessions[$nameLower])) {
            $session = $this->activeSessions[$nameLower];
            $session->cancel($player);
            return;
        }

        // Cancel pending incoming request
        if (isset($this->pendingRequests[$nameLower])) {
            $request = $this->pendingRequests[$nameLower];
            unset($this->pendingRequests[$nameLower]);

            $player->sendMessage("§aBạn đã từ chối yêu cầu giao dịch.");
            $sender = $this->getServer()->getPlayerExact($request["sender"]);
            if ($sender !== null) {
                $sender->sendMessage("§e" . $player->getName() . " §cđã từ chối yêu cầu giao dịch của bạn.");
            }
            return;
        }

        // Cancel pending outgoing request
        foreach ($this->pendingRequests as $targetName => $req) {
            if (strtolower($req["sender"]) === $nameLower) {
                unset($this->pendingRequests[$targetName]);
                $player->sendMessage("§aBạn đã hủy yêu cầu giao dịch của mình.");
                $target = $this->getServer()->getPlayerExact($targetName);
                if ($target !== null) {
                    $target->sendMessage("§e" . $player->getName() . " §cđã hủy yêu cầu giao dịch.");
                }
                return;
            }
        }

        $player->sendMessage("§cKhông có yêu cầu giao dịch nào để hủy.");
    }

    public function removeSession(TradeSession $session) : void {
        $p1 = strtolower($session->getPlayer1()->getName());
        $p2 = strtolower($session->getPlayer2()->getName());
        unset($this->activeSessions[$p1]);
        unset($this->activeSessions[$p2]);
    }

    /**
     * @priority NORMAL
     */
    public function onQuit(PlayerQuitEvent $event) : void {
        $player = $event->getPlayer();
        $nameLower = strtolower($player->getName());
        if (isset($this->activeSessions[$nameLower])) {
            $this->activeSessions[$nameLower]->cancel($player);
        }
        if (isset($this->pendingRequests[$nameLower])) {
            unset($this->pendingRequests[$nameLower]);
        }
        foreach ($this->pendingRequests as $targetName => $req) {
            if (strtolower($req["sender"]) === $nameLower) {
                unset($this->pendingRequests[$targetName]);
            }
        }
    }

    /**
     * @priority NORMAL
     */
    public function onKick(PlayerKickEvent $event) : void {
        $player = $event->getPlayer();
        $nameLower = strtolower($player->getName());
        if (isset($this->activeSessions[$nameLower])) {
            $this->activeSessions[$nameLower]->cancel($player);
        }
    }
}
