<?php

declare(strict_types=1);

namespace BeeAZ\AZTraoDoi;

use pocketmine\player\Player;
use pocketmine\inventory\Inventory;
use pocketmine\item\StringToItemParser;
use pocketmine\item\Item;
use pocketmine\Server;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;

class TradeSession {

    private Player $p1;
    private Player $p2;
    private bool $accepted1 = false;
    private bool $accepted2 = false;
    private InvMenu $menu;
    private bool $closed = false;

    // Define trade slots
    public const P1_SLOTS = [
        0, 1, 2,
        9, 10, 11,
        18, 19, 20,
        27, 28, 29,
        36, 37, 38,
        45, 46, 47
    ];

    public const P2_SLOTS = [
        6, 7, 8,
        15, 16, 17,
        24, 25, 26,
        33, 34, 35,
        42, 43, 44,
        51, 52, 53
    ];

    public function __construct(Player $p1, Player $p2) {
        $this->p1 = $p1;
        $this->p2 = $p2;
    }

    public function getPlayer1() : Player {
        return $this->p1;
    }

    public function getPlayer2() : Player {
        return $this->p2;
    }

    public function init() : void {
        $this->menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $this->menu->setName("§l§0GIAO DỊCH: " . $this->p1->getDisplayName() . " ⚖ " . $this->p2->getDisplayName());

        $inventory = $this->menu->getInventory();

        // 1. Fill Divider slots
        $divider = StringToItemParser::getInstance()->parse("black_stained_glass_pane");
        if ($divider !== null) {
            $divider->setCustomName("§0");
            foreach ([4, 13, 22, 31, 40, 49] as $slot) {
                $inventory->setItem($slot, clone $divider);
            }
        }

        // Fill side indicators
        $p1Filler = StringToItemParser::getInstance()->parse("gray_stained_glass_pane");
        if ($p1Filler !== null) {
            $p1Filler->setCustomName("§7Vùng kiểm soát của " . $this->p1->getDisplayName());
            foreach ([3, 21, 39, 48] as $slot) {
                $inventory->setItem($slot, clone $p1Filler);
            }
        }

        $p2Filler = StringToItemParser::getInstance()->parse("gray_stained_glass_pane");
        if ($p2Filler !== null) {
            $p2Filler->setCustomName("§7Vùng kiểm soát của " . $this->p2->getDisplayName());
            foreach ([5, 23, 41, 50] as $slot) {
                $inventory->setItem($slot, clone $p2Filler);
            }
        }

        // 2. Set Up Info and Buttons
        $this->updateUI();

        // 3. Set Up Listener
        $this->menu->setListener(function(InvMenuTransaction $transaction) : InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $slot = $transaction->getAction()->getSlot();

            $p1Name = strtolower($this->p1->getName());
            $p2Name = strtolower($this->p2->getName());
            $clickerName = strtolower($player->getName());

            if ($clickerName === $p1Name) {
                if (in_array($slot, self::P1_SLOTS, true)) {
                    // Reset acceptance status when trade contents are altered
                    $this->accepted1 = false;
                    $this->accepted2 = false;
                    Main::getInstance()->getScheduler()->scheduleDelayedTask(new class($this) extends \pocketmine\scheduler\Task {
                        private TradeSession $session;
                        public function __construct(TradeSession $session) { $this->session = $session; }
                        public function onRun() : void { $this->session->updateUI(); }
                    }, 1);
                    return $transaction->continue();
                }

                if ($slot === 30) {
                    $this->accepted1 = !$this->accepted1;
                    $this->updateUI();
                    $this->checkCompletion();
                    return $transaction->discard();
                }
            } elseif ($clickerName === $p2Name) {
                if (in_array($slot, self::P2_SLOTS, true)) {
                    // Reset acceptance status when trade contents are altered
                    $this->accepted1 = false;
                    $this->accepted2 = false;
                    Main::getInstance()->getScheduler()->scheduleDelayedTask(new class($this) extends \pocketmine\scheduler\Task {
                        private TradeSession $session;
                        public function __construct(TradeSession $session) { $this->session = $session; }
                        public function onRun() : void { $this->session->updateUI(); }
                    }, 1);
                    return $transaction->continue();
                }

                if ($slot === 32) {
                    $this->accepted2 = !$this->accepted2;
                    $this->updateUI();
                    $this->checkCompletion();
                    return $transaction->discard();
                }
            }

            return $transaction->discard();
        });

        // 4. Set Up Close Listener
        $this->menu->setInventoryCloseListener(function(Player $closer, Inventory $inv) : void {
            $this->cancel($closer);
        });

        // 5. Open for both players
        $this->menu->send($this->p1);
        $this->menu->send($this->p2);
    }

    public function updateUI() : void {
        $inventory = $this->menu->getInventory();

        // 1. Info Items
        $p1Info = StringToItemParser::getInstance()->parse("book");
        if ($p1Info !== null) {
            $statusStr = $this->accepted1 ? "§aĐÃ XÁC NHẬN" : "§cCHƯA XÁC NHẬN";
            $p1Info->setCustomName("§l§bNgười Giao Dịch 1: §e" . $this->p1->getDisplayName());
            $p1Info->setLore([
                "§r§fTrạng thái: " . $statusStr,
                "§r§7Vùng đặt vật phẩm: Cột 0, 1, 2"
            ]);
            $inventory->setItem(12, $p1Info);
        }

        $p2Info = StringToItemParser::getInstance()->parse("book");
        if ($p2Info !== null) {
            $statusStr = $this->accepted2 ? "§aĐÃ XÁC NHẬN" : "§cCHƯA XÁC NHẬN";
            $p2Info->setCustomName("§l§bNgười Giao Dịch 2: §e" . $this->p2->getDisplayName());
            $p2Info->setLore([
                "§r§fTrạng thái: " . $statusStr,
                "§r§7Vùng đặt vật phẩm: Cột 6, 7, 8"
            ]);
            $inventory->setItem(14, $p2Info);
        }

        // 2. Action Buttons
        if ($this->accepted1) {
            $btn1 = StringToItemParser::getInstance()->parse("lime_stained_glass_pane");
            if ($btn1 !== null) {
                $btn1->setCustomName("§l§a" . $this->p1->getDisplayName() . ": ĐÃ ĐỒNG Ý");
                $btn1->setLore([
                    "§r§7Trạng thái: ĐỒNG Ý GIAO DỊCH",
                    "§r§fNhấp để hủy đồng ý."
                ]);
                $inventory->setItem(30, $btn1);
            }
        } else {
            $btn1 = StringToItemParser::getInstance()->parse("red_stained_glass_pane");
            if ($btn1 !== null) {
                $btn1->setCustomName("§l§c" . $this->p1->getDisplayName() . ": CHƯA ĐỒNG Ý");
                $btn1->setLore([
                    "§r§7Trạng thái: CHƯA XÁC NHẬN",
                    "§r§fNhấp để đồng ý giao dịch."
                ]);
                $inventory->setItem(30, $btn1);
            }
        }

        if ($this->accepted2) {
            $btn2 = StringToItemParser::getInstance()->parse("lime_stained_glass_pane");
            if ($btn2 !== null) {
                $btn2->setCustomName("§l§a" . $this->p2->getDisplayName() . ": ĐÃ ĐỒNG Ý");
                $btn2->setLore([
                    "§r§7Trạng thái: ĐỒNG Ý GIAO DỊCH",
                    "§r§fNhấp để hủy đồng ý."
                ]);
                $inventory->setItem(32, $btn2);
            }
        } else {
            $btn2 = StringToItemParser::getInstance()->parse("red_stained_glass_pane");
            if ($btn2 !== null) {
                $btn2->setCustomName("§l§c" . $this->p2->getDisplayName() . ": CHƯA ĐỒNG Ý");
                $btn2->setLore([
                    "§r§7Trạng thái: CHƯA XÁC NHẬN",
                    "§r§fNhấp để đồng ý giao dịch."
                ]);
                $inventory->setItem(32, $btn2);
            }
        }
    }

    public function checkCompletion() : void {
        if ($this->accepted1 && $this->accepted2) {
            $this->complete();
        }
    }

    public function cancel(Player $initiator) : void {
        if ($this->closed) {
            return;
        }
        $this->closed = true;

        $inventory = $this->menu->getInventory();

        // Return items of Player 1
        foreach (self::P1_SLOTS as $slot) {
            $item = $inventory->getItem($slot);
            if (!$item->isNull()) {
                if ($this->p1->isOnline()) {
                    if ($this->p1->getInventory()->canAddItem($item)) {
                        $this->p1->getInventory()->addItem($item);
                    } else {
                        $this->p1->getWorld()->dropItem($this->p1->getPosition(), $item);
                    }
                } else {
                    $this->p1->getWorld()->dropItem($this->p1->getPosition(), $item);
                }
            }
        }

        // Return items of Player 2
        foreach (self::P2_SLOTS as $slot) {
            $item = $inventory->getItem($slot);
            if (!$item->isNull()) {
                if ($this->p2->isOnline()) {
                    if ($this->p2->getInventory()->canAddItem($item)) {
                        $this->p2->getInventory()->addItem($item);
                    } else {
                        $this->p2->getWorld()->dropItem($this->p2->getPosition(), $item);
                    }
                } else {
                    $this->p2->getWorld()->dropItem($this->p2->getPosition(), $item);
                }
            }
        }

        $inventory->clearAll();

        if ($this->p1->isOnline()) {
            $this->p1->removeCurrentWindow();
            $this->p1->sendMessage("§c⚠️ Giao dịch đã bị hủy bởi " . $initiator->getDisplayName() . ".");
        }
        if ($this->p2->isOnline()) {
            $this->p2->removeCurrentWindow();
            $this->p2->sendMessage("§c⚠️ Giao dịch đã bị hủy bởi " . $initiator->getDisplayName() . ".");
        }

        Main::getInstance()->removeSession($this);
    }

    private function complete() : void {
        if ($this->closed) {
            return;
        }
        $this->closed = true;

        $inventory = $this->menu->getInventory();

        /** @var Item[] $p1Items */
        $p1Items = [];
        foreach (self::P1_SLOTS as $slot) {
            $item = $inventory->getItem($slot);
            if (!$item->isNull()) {
                $p1Items[] = clone $item;
            }
        }

        /** @var Item[] $p2Items */
        $p2Items = [];
        foreach (self::P2_SLOTS as $slot) {
            $item = $inventory->getItem($slot);
            if (!$item->isNull()) {
                $p2Items[] = clone $item;
            }
        }

        $inventory->clearAll();

        if ($this->p1->isOnline()) {
            $this->p1->removeCurrentWindow();
        }
        if ($this->p2->isOnline()) {
            $this->p2->removeCurrentWindow();
        }

        // Give Player 2's items to Player 1
        foreach ($p2Items as $item) {
            if ($this->p1->isOnline()) {
                if ($this->p1->getInventory()->canAddItem($item)) {
                    $this->p1->getInventory()->addItem($item);
                } else {
                    $this->p1->getWorld()->dropItem($this->p1->getPosition(), $item);
                    $this->p1->sendMessage("§c⚠️ Túi đồ đầy, vật phẩm giao dịch rơi dưới chân.");
                }
            } else {
                $this->p1->getWorld()->dropItem($this->p1->getPosition(), $item);
            }
        }

        // Give Player 1's items to Player 2
        foreach ($p1Items as $item) {
            if ($this->p2->isOnline()) {
                if ($this->p2->getInventory()->canAddItem($item)) {
                    $this->p2->getInventory()->addItem($item);
                } else {
                    $this->p2->getWorld()->dropItem($this->p2->getPosition(), $item);
                    $this->p2->sendMessage("§c⚠️ Túi đồ đầy, vật phẩm giao dịch rơi dưới chân.");
                }
            } else {
                $this->p2->getWorld()->dropItem($this->p2->getPosition(), $item);
            }
        }

        if ($this->p1->isOnline()) {
            $this->p1->sendMessage("§a§l[AZ]§r§a Giao dịch thành công với §e" . $this->p2->getDisplayName() . "§a!");
        }
        if ($this->p2->isOnline()) {
            $this->p2->sendMessage("§a§l[AZ]§r§a Giao dịch thành công với §e" . $this->p1->getDisplayName() . "§a!");
        }

        Main::getInstance()->removeSession($this);
    }
}
