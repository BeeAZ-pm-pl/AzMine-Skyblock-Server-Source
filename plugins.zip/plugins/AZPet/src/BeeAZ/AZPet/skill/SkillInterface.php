<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill;

use pocketmine\entity\Living;
use BeeAZ\AZPet\entity\PetEntity;

interface SkillInterface {

    /**
     * Trigger the Pokemon's skill.
     *
     * @param PetEntity $pet
     * @param Living $target
     * @param int $skillTier (5 or 15)
     * @param float $damage (Reference variable to modify/apply multiplier to the damage)
     */
    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void;
}
