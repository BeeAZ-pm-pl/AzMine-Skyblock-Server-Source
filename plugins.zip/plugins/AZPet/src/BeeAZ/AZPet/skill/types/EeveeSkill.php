<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\math\Vector3;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class EeveeSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.3;

            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:normal_hit", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("damage.fallbig", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Knockback target
            $target->setMotion($target->getMotion()->add($pet->getDirectionVector()->multiply(0.8)->x, 0.4, $pet->getDirectionVector()->multiply(0.8)->z));

            if ($owner !== null) $owner->sendMessage("§6🐾 Eevee sử dụng [Húc Đố] đẩy lùi đối phương!");
        } else {
            $damage *= 1.8;

            $offsets = [
                new Vector3(0, 0, 0),
                new Vector3(-0.3, 0.2, 0.3),
                new Vector3(0.3, -0.2, -0.3)
            ];
            foreach ($offsets as $offset) {
                if ($steps > 0) {
                    for ($i = 0; $i <= $steps; $i++) {
                        $t = $i / $steps;
                        $pos = $start->add($dx * $t + $offset->x * (1 - $t), $dy * $t + $offset->y * (1 - $t), $dz * $t + $offset->z * (1 - $t));
                        $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:stars_tail", null);
                        $world->broadcastPacketToViewers($pos, $part);
                    }
                }
            }

            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:stars_360", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("random.orb", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            if ($owner !== null) $owner->sendMessage("§6🐾 Eevee sử dụng [Mưa Sao Băng] bắn sao liên hoàn!");
        }
    }
}
