<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class BulbasaurSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.4;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:short_seed_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partLeaf = SpawnParticleEffectPacket::create(0, -1, $end, "serp:leafage", null);
            $partSpore = SpawnParticleEffectPacket::create(0, -1, $end, "serp:yellow_spore_small", null);
            $world->broadcastPacketToViewers($end, $partLeaf);
            $world->broadcastPacketToViewers($end, $partSpore);

            $sound = PlaySoundPacket::create("step.grass", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Slowness I for 3 seconds
            $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 1));

            if ($owner !== null) $owner->sendMessage("§a🍃 Bulbasaur sử dụng [Roi Mây] quật ngã đối phương!");
        } else {
            $damage *= 2.0;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:leaf_storm", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partCut = SpawnParticleEffectPacket::create(0, -1, $end, "serp:leaf_cut", null);
            $part360 = SpawnParticleEffectPacket::create(0, -1, $end, "serp:leaf_360", null);
            $world->broadcastPacketToViewers($end, $partCut);
            $world->broadcastPacketToViewers($end, $part360);

            $sound = PlaySoundPacket::create("random.bow", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Apply poison II for 3 seconds to mimic toxic spores
            $target->getEffects()->add(new EffectInstance(VanillaEffects::POISON(), 60, 2));

            if ($owner !== null) $owner->sendMessage("§a🍃 Bulbasaur sử dụng [Lá Gió] chém lá và gieo bào tử độc tố lên đối thủ!");
        }
    }
}
