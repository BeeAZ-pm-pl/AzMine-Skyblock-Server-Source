<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;
use BeeAZ\AZPet\manager\StatusManager;

class UmbreonSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $targetLoc = $target->getLocation();

        if ($skillTier === 5) {
            $damage *= 1.4;
            $partHit = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:normal_hit", null);
            $world->broadcastPacketToViewers($targetLoc, $partHit);

            $sound = PlaySoundPacket::create("mob.wither.shoot", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.3, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            if ($owner !== null) $owner->sendMessage("§8🐈 Umbreon sử dụng [Cắn Xé] lao vào xé rách giáp đối thủ!");
        } else {
            $damage *= 1.8;
            $partHit = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:energy_psychic", null);
            $world->broadcastPacketToViewers($targetLoc, $partHit);

            $sound = PlaySoundPacket::create("mob.wither.shoot", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Slowness II for 3 seconds
            $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 2));

            // Stun for 1.0 second
            StatusManager::stun($target, 1.0);

            if ($owner !== null) $owner->sendMessage("§8🐈 Umbreon sử dụng [Dark Pulse] phóng luồng xung kích bóng tối làm chậm và choáng mục tiêu!");
        }
    }
}
