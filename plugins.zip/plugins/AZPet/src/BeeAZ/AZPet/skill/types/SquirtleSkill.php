<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class SquirtleSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.3;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:short_bubble_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:attack_bubble", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("random.splash", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.3, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Slowness I for 3 seconds
            $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 1));

            if ($owner !== null) $owner->sendMessage("§b💧 Squirtle sử dụng [Bong Bóng] làm chậm kẻ địch!");
        } else {
            $damage *= 2.0;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_water_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partWaterfall = SpawnParticleEffectPacket::create(0, -1, $end, "serp:waterfall", null);
            $partExplode = SpawnParticleEffectPacket::create(0, -1, $end, "serp:medium_water_explosion", null);
            $world->broadcastPacketToViewers($end, $partWaterfall);
            $world->broadcastPacketToViewers($end, $partExplode);

            $sound = PlaySoundPacket::create("random.splash", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.8, null);
            $soundThunder = PlaySoundPacket::create("ambient.weather.thunder", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
                $p->getNetworkSession()->sendDataPacket($soundThunder);
            }

            // Stronger knockback
            $target->setMotion($target->getMotion()->add($pet->getDirectionVector()->multiply(1.0)->x, 0.45, $pet->getDirectionVector()->multiply(1.0)->z));

            if ($owner !== null) $owner->sendMessage("§b💧 Squirtle sử dụng [Súng Phun Nước] bắn cột nước cực mạnh!");
        }
    }
}
