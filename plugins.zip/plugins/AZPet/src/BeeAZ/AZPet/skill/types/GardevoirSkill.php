<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class GardevoirSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.5;
            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:stars_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }
            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:stars_360", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("random.bow", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            if ($owner !== null) $owner->sendMessage("§a🌸 Gardevoir sử dụng [Tia Sáng] bắn loạt sao lấp lánh!");
        } else {
            $damage *= 2.0;
            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_psychic_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }
            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:psychic_center", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("mob.endermen.portal", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Apply Blindness II for 3 seconds
            $target->getEffects()->add(new EffectInstance(VanillaEffects::BLINDNESS(), 60, 2));

            if ($owner !== null) $owner->sendMessage("§a🌸 Gardevoir sử dụng [Moonblast] luồng ánh sáng mặt trăng làm mù mắt kẻ thù!");
        }
    }
}
