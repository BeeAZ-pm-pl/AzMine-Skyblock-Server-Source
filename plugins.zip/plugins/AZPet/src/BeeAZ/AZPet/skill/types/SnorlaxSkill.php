<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;
use BeeAZ\AZPet\manager\StatusManager;

class SnorlaxSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $targetLoc = $target->getLocation();

        if ($skillTier === 5) {
            $damage *= 1.5;
            $partHit = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:normal_hit", null);
            $world->broadcastPacketToViewers($targetLoc, $partHit);

            $sound = PlaySoundPacket::create("damage.fallbig", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.9, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            $target->setMotion($target->getMotion()->add($pet->getDirectionVector()->multiply(0.7)->x, 0.35, $pet->getDirectionVector()->multiply(0.7)->z));
            if ($owner !== null) $owner->sendMessage("§9🐻 Snorlax sử dụng [Đè Bẹp] dậm nhảy nghiền nát đối thủ!");
        } else {
            $damage *= 2.1;
            $partHit = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:big_electric_explosion", null);
            $world->broadcastPacketToViewers($targetLoc, $partHit);

            $sound = PlaySoundPacket::create("damage.fallbig", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.8, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            $target->setMotion($target->getMotion()->add($pet->getDirectionVector()->multiply(1.2)->x, 0.5, $pet->getDirectionVector()->multiply(1.2)->z));

            // Apply Stun for 1.5 seconds
            StatusManager::stun($target, 1.5);

            if ($owner !== null) $owner->sendMessage("§9🐻 Snorlax sử dụng [Body Slam] tung người đè bẹp chấn động làm choáng kẻ thù!");
        }
    }
}
