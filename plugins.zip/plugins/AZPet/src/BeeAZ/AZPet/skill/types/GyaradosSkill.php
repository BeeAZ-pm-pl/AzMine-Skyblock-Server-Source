<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class GyaradosSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.6;
            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_water_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }
            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:medium_water_explosion", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("random.splash", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 0.9, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            $target->setMotion($target->getMotion()->add($pet->getDirectionVector()->multiply(0.8)->x, 0.4, $pet->getDirectionVector()->multiply(0.8)->z));
            if ($owner !== null) $owner->sendMessage("§b🐉 Gyarados sử dụng [Bão Nước] quật đuôi thủy triều cực đại!");
        } else {
            $damage *= 2.3;
            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_water_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }
            $partWaterfall = SpawnParticleEffectPacket::create(0, -1, $end, "serp:waterfall", null);
            $partExplode = SpawnParticleEffectPacket::create(0, -1, $end, "serp:medium_water_explosion", null);
            $world->broadcastPacketToViewers($end, $partWaterfall);
            $world->broadcastPacketToViewers($end, $partExplode);

            $sound = PlaySoundPacket::create("ambient.weather.thunder", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.8, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            $target->setOnFire(4);
            if ($owner !== null) $owner->sendMessage("§b🐉 Gyarados sử dụng [Dragon Rage] cuồng nộ rồng lửa thiêu đốt đối thủ!");
        }
    }
}
