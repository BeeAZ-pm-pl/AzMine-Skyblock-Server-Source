<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class CharmanderSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.2;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:short_fire_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:will_o_wisp", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("random.fire", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            $target->setOnFire(3);

            if ($owner !== null) $owner->sendMessage("§c🔥 Charmander sử dụng [Tia Lửa] thiêu cháy mục tiêu!");
        } else {
            $damage *= 2.0;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:will_o_wisp", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partBlast = SpawnParticleEffectPacket::create(0, -1, $end, "serp:fire_blast", null);
            $partExplode = SpawnParticleEffectPacket::create(0, -1, $end, "serp:medium_fire_explosion", null);
            $world->broadcastPacketToViewers($end, $partBlast);
            $world->broadcastPacketToViewers($end, $partExplode);

            $sound = PlaySoundPacket::create("random.explode", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            $target->setOnFire(5);

            if ($owner !== null) $owner->sendMessage("§c🔥 Charmander sử dụng [Phun Lửa] phun bão lửa thiêu cháy!");
        }
    }
}
