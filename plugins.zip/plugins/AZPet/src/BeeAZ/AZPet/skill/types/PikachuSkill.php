<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;
use BeeAZ\AZPet\manager\StatusManager;

class PikachuSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.5;
            
            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:short_electric_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }
            
            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:medium_electric_explosion", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("random.explode", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.3, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Apply Stun for 1.0 second
            StatusManager::stun($target, 1.0);

            if ($owner !== null) $owner->sendMessage("§e⚡ Pikachu sử dụng [Tia Chớp] gây sát thương lớn và làm choáng đối thủ!");
        } else {
            $damage *= 2.0;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_electric_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partThunder = SpawnParticleEffectPacket::create(0, -1, $end, "serp:thunder", null);
            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:big_electric_explosion", null);
            $world->broadcastPacketToViewers($end, $partThunder);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("ambient.weather.lightning.impact", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Apply Stun for 2.0 seconds
            StatusManager::stun($target, 2.0);

            if ($owner !== null) $owner->sendMessage("§e⚡ Pikachu sử dụng [Sấm Sét] giáng sét nổ lớn làm tê liệt đối thủ!");
        }
    }
}
