<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\math\Vector3;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;
use BeeAZ\AZPet\manager\StatusManager;

class MewSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $myLoc = $pet->getLocation();
        $targetLoc = $target->getLocation();

        $start = $myLoc->add(0, 0.5, 0);
        $end = $targetLoc->add(0, 0.5, 0);
        $distance = $start->distance($end);
        $dx = $end->x - $start->x;
        $dy = $end->y - $start->y;
        $dz = $end->z - $start->z;
        $steps = (int)($distance * 1.5);

        if ($skillTier === 5) {
            $damage *= 1.5;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_psychic_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:energy_psychic", null);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("mob.endermen.portal", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Apply slowness II for 3 seconds
            $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 2));

            if ($owner !== null) $owner->sendMessage("§d✨ Mew sử dụng [Niệm Lực] làm chậm đối thủ!");
        } else {
            $damage *= 2.0;

            if ($steps > 0) {
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $pos = $start->add($dx * $t, $dy * $t, $dz * $t);
                    $part = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_psychic_tail", null);
                    $world->broadcastPacketToViewers($pos, $part);
                }
            }

            $partCenter = SpawnParticleEffectPacket::create(0, -1, $end, "serp:psychic_center", null);
            $partHit = SpawnParticleEffectPacket::create(0, -1, $end, "serp:medium_psychic_explosion", null);
            $world->broadcastPacketToViewers($end, $partCenter);
            $world->broadcastPacketToViewers($end, $partHit);

            $sound = PlaySoundPacket::create("mob.wither.shoot", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Spatial confusion - Stun for 1.5 seconds
            StatusManager::stun($target, 1.5);

            // Teleport target slightly to a random nearby location
            $randomOffset = new Vector3(mt_rand(-20, 20) / 10, 0, mt_rand(-20, 20) / 10);
            $newPos = $targetLoc->add($randomOffset->x, $randomOffset->y, $randomOffset->z);
            if ($world->getBlock($newPos)->isPassable()) {
                $target->teleport($newPos);
            }

            if ($owner !== null) $owner->sendMessage("§d✨ Mew sử dụng [Cầu Ngoại Cảm] bóp méo không gian làm choáng và dịch chuyển đối thủ!");
        }
    }
}
