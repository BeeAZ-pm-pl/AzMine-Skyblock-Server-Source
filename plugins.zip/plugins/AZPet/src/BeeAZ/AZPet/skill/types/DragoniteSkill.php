<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;

class DragoniteSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $targetLoc = $target->getLocation();

        if ($skillTier === 5) {
            $damage *= 1.7;
            $partThunder = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:thunder", null);
            $world->broadcastPacketToViewers($targetLoc, $partThunder);

            $sound = PlaySoundPacket::create("ambient.weather.lightning.impact", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.2, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            if ($owner !== null) $owner->sendMessage("§6🧡 Dragonite sử dụng [Tia Chớp Rồng] gọi sét giáng xuống đầu kẻ thù!");
        } else {
            $damage *= 2.5;
            $partThunder = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:thunder", null);
            $partBlast = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:fire_blast", null);
            $world->broadcastPacketToViewers($targetLoc, $partThunder);
            $world->broadcastPacketToViewers($targetLoc, $partBlast);

            $sound = PlaySoundPacket::create("ambient.weather.lightning.impact", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.3, 0.9, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }
            $target->setOnFire(4);
            if ($owner !== null) $owner->sendMessage("§6🧡 Dragonite sử dụng [Hyper Beam] giải phóng luồng sáng hủy diệt bốc cháy đối thủ!");
        }
    }
}
