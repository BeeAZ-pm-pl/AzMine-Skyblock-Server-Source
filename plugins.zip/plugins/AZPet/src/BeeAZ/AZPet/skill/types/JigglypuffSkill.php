<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill\types;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\skill\SkillInterface;
use BeeAZ\AZPet\manager\StatusManager;

class JigglypuffSkill implements SkillInterface {

    public function trigger(PetEntity $pet, Living $target, int $skillTier, float &$damage): void {
        $world = $pet->getWorld();
        $owner = $pet->getOwner();
        $targetLoc = $target->getLocation();

        if ($skillTier === 5) {
            $damage *= 1.3;
            $partHit = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:stars_tail", null);
            $world->broadcastPacketToViewers($targetLoc, $partHit);

            $sound = PlaySoundPacket::create("random.orb", $targetLoc->x, $targetLoc->y, $targetLoc->z, 0.8, 1.3, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Slowness II for 3 seconds
            $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 2));

            if ($owner !== null) $owner->sendMessage("§d🎤 Jigglypuff sử dụng [Hát Ru] gây buồn ngủ làm chậm đối phương!");
        } else {
            $damage *= 1.7;
            $partHit = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:stars_360", null);
            $world->broadcastPacketToViewers($targetLoc, $partHit);

            $sound = PlaySoundPacket::create("random.orb", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.0, null);
            foreach ($world->getPlayers() as $p) {
                $p->getNetworkSession()->sendDataPacket($sound);
            }

            // Apply Sleep for 3.0 seconds
            StatusManager::sleep($target, 3.0);

            if ($owner !== null) $owner->sendMessage("§d🎤 Jigglypuff sử dụng [Sing] ru ngủ sâu làm đối thủ bất động hoàn toàn!");
        }
    }
}
