<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\skill;

use pocketmine\entity\Living;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use BeeAZ\AZPet\entity\PetEntity;

class PetSkill {

    public static function trigger(PetEntity $pet, Living $target, float &$damage): void {
        $level = $pet->getPetLevel();
        if ($level < 5) return;

        // 30% chance to trigger skill
        if (mt_rand(1, 100) > 30) return;

        // Choose which skill to trigger
        $skillTier = 5;
        if ($level >= 15) {
            $skillTier = mt_rand(1, 2) === 1 ? 5 : 15;
        }

        $world = $pet->getWorld();

        // 1. Play entity attack animation defined in the resource pack
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$pet->getId()]);
        foreach ($world->getPlayers() as $p) {
            if ($p->isOnline()) {
                $p->getNetworkSession()->sendDataPacket($animPacket);
            }
        }

        // 2. Play custom Pokecry sound
        $pet->playPokeCry();

        // 3. Delegate to specific skill handler class
        $type = $pet->getPetType();
        $class = "BeeAZ\\AZPet\\skill\\types\\" . ucfirst($type) . "Skill";
        if (class_exists($class)) {
            /** @var SkillInterface $skill */
            $skill = new $class();
            $skill->trigger($pet, $target, $skillTier, $damage);
        }
    }
}
