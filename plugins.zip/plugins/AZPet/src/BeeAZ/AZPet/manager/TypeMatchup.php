<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\manager;

class TypeMatchup {

    // Define the type of each pet type
    public const PET_TYPES = [
        "pikachu" => "electric",
        "eevee" => "normal",
        "charmander" => "fire",
        "squirtle" => "water",
        "bulbasaur" => "grass",
        "mew" => "psychic",
        "lucario" => "fighting",
        "snorlax" => "normal",
        "gengar" => "ghost",
        "jigglypuff" => "fairy",
        "gyarados" => "water",
        "lapras" => "water",
        "gardevoir" => "psychic",
        "umbreon" => "dark",
        "dragonite" => "dragon",
        "mudkip" => "water"
    ];

    // Map types to their Vietnamese display names
    public const TYPE_NAMES = [
        "electric" => "§eLôi§r",
        "normal" => "§7Thường§r",
        "fire" => "§cHỏa§r",
        "water" => "§bThủy§r",
        "grass" => "§aThảo§r",
        "psychic" => "§dPsychic§r",
        "fighting" => "§cGiác Đấu§r",
        "ghost" => "§5Ma§r",
        "dark" => "§8Bóng Tối§r",
        "fairy" => "§dTiên§r",
        "dragon" => "§6Rồng§r"
    ];

    // Type Matchup Matrix: Attacker Type => [Defender Type => Multiplier]
    private const ADVANTAGES = [
        "fire" => [
            "grass" => 1.5,
            "water" => 0.5,
            "fire" => 0.8
        ],
        "water" => [
            "fire" => 1.5,
            "grass" => 0.5,
            "water" => 0.8
        ],
        "grass" => [
            "water" => 1.5,
            "fire" => 0.5,
            "grass" => 0.8
        ],
        "electric" => [
            "water" => 1.5,
            "grass" => 0.5,
            "electric" => 0.8
        ],
        "psychic" => [
            "fighting" => 1.5,
            "dark" => 0.0, // Dark immune to Psychic
            "psychic" => 0.8
        ],
        "fighting" => [
            "normal" => 1.5,
            "dark" => 1.5,
            "ghost" => 0.0, // Ghost immune to Fighting
            "fighting" => 0.8
        ],
        "ghost" => [
            "psychic" => 1.5,
            "normal" => 0.0, // Normal immune to Ghost
            "dark" => 0.5
        ],
        "dark" => [
            "psychic" => 1.5,
            "fighting" => 0.5,
            "dark" => 0.8
        ],
        "fairy" => [
            "dragon" => 1.5,
            "dark" => 1.5,
            "fire" => 0.5
        ],
        "dragon" => [
            "dragon" => 1.5,
            "fairy" => 0.0 // Fairy immune to Dragon
        ]
    ];

    public static function getPetType(string $petType): string {
        return self::PET_TYPES[strtolower($petType)] ?? "normal";
    }

    public static function getTypeName(string $type): string {
        return self::TYPE_NAMES[strtolower($type)] ?? "Thường";
    }

    public static function getMultiplier(string $attackerPetType, string $defenderPetType): float {
        $aType = self::getPetType($attackerPetType);
        $dType = self::getPetType($defenderPetType);

        return self::ADVANTAGES[$aType][$dType] ?? 1.0;
    }
}
