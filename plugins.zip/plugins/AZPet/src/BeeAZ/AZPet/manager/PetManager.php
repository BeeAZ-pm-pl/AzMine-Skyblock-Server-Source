<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\manager;

use BeeAZ\AZPet\Main;
use BeeAZ\AZPet\entity\PetEntity;
use pocketmine\player\Player;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;

use BeeAZ\AZPet\task\DatabaseSaveTask;

class PetManager {

    private \SQLite3 $db;
    private string $dbPath;
    private array $activePetEntities = []; // playername => PetEntity
    private array $respawnCooldowns = []; // ownerName => timestamp
    private array $feedCooldowns = []; // ownerName => timestamp

    public function setRespawnCooldown(string $owner, int $time): void {
        $this->respawnCooldowns[strtolower($owner)] = $time;
    }

    public function getRespawnCooldown(string $owner): int {
        return $this->respawnCooldowns[strtolower($owner)] ?? 0;
    }

    public function setFeedCooldown(string $owner, int $time): void {
        $this->feedCooldowns[strtolower($owner)] = $time;
    }

    public function getFeedCooldown(string $owner): int {
        return $this->feedCooldowns[strtolower($owner)] ?? 0;
    }

    public function __construct(private Main $plugin) {
        @mkdir($this->plugin->getDataFolder());
        $this->dbPath = $this->plugin->getDataFolder() . "pets.db";
        $this->db = new \SQLite3($this->dbPath);
        $this->db->exec("CREATE TABLE IF NOT EXISTS pets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner TEXT,
            pet_type TEXT,
            level INTEGER,
            exp INTEGER,
            hp INTEGER,
            max_hp INTEGER,
            damage INTEGER,
            active INTEGER DEFAULT 0,
            state TEXT DEFAULT 'follow'
        );");
    }

    public function getOwnedPets(string $owner): array {
        $owner = strtolower($owner);
        $stmt = $this->db->prepare("SELECT * FROM pets WHERE owner = :owner");
        $stmt->bindValue(":owner", $owner, SQLITE3_TEXT);
        $result = $stmt->execute();
        $pets = [];
        while ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            $pets[] = $row;
        }
        return $pets;
    }

    public function createPet(string $owner, string $type): bool {
        $owner = strtolower($owner);
        $this->plugin->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask(
            $this->dbPath,
            "INSERT INTO pets (owner, pet_type, level, exp, hp, max_hp, damage, active, state) 
             VALUES (:owner, :type, 1, 0, 100, 100, 1, 0, 'follow')",
            [":owner" => $owner, ":type" => $type]
        ));
        return true;
    }

    public function getActivePetData(string $owner): ?array {
        $owner = strtolower($owner);
        $stmt = $this->db->prepare("SELECT * FROM pets WHERE owner = :owner AND active = 1 LIMIT 1");
        $stmt->bindValue(":owner", $owner, SQLITE3_TEXT);
        $result = $stmt->execute();
        if ($row = $result->fetchArray(SQLITE3_ASSOC)) {
            return $row;
        }
        return null;
    }

    public function savePetData(array $data, bool $syncSave = false): void {
        $query = "UPDATE pets SET 
            level = :level, 
            exp = :exp, 
            hp = :hp, 
            max_hp = :max_hp, 
            damage = :damage, 
            active = :active, 
            state = :state 
            WHERE id = :id";
        $params = [
            ":level" => $data['level'],
            ":exp" => $data['exp'],
            ":hp" => $data['hp'],
            ":max_hp" => $data['max_hp'],
            ":damage" => $data['damage'],
            ":active" => $data['active'],
            ":state" => $data['state'],
            ":id" => $data['id']
        ];

        if ($syncSave) {
            $stmt = $this->db->prepare($query);
            if ($stmt !== false) {
                foreach ($params as $param => $val) {
                    $type = is_int($val) ? SQLITE3_INTEGER : SQLITE3_TEXT;
                    $stmt->bindValue($param, $val, $type);
                }
                $stmt->execute();
            }
        } else {
            $this->plugin->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask(
                $this->dbPath,
                $query,
                $params
            ));
        }
    }

    public function spawnPet(Player $player, array $petData): void {
        // Check respawn cooldown
        $cooldown = $this->getRespawnCooldown($player->getName());
        if ($cooldown > time()) {
            $player->sendMessage("§c💀 Pet của bạn đang hồi sức! Vui lòng chờ " . ($cooldown - time()) . " giây.");
            return;
        }

        // If the pet's HP is 0, auto-heal it since the cooldown has expired
        if ($petData['hp'] <= 0) {
            $petData['hp'] = $petData['max_hp'];
            $this->savePetData($petData);
        }

        $this->despawnPet($player);

        $ownerLower = strtolower($player->getName());
        // Mark active in database (Async)
        $this->plugin->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask(
            $this->dbPath,
            "UPDATE pets SET active = 0 WHERE owner = :owner",
            [":owner" => $ownerLower]
        ));
        $this->plugin->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask(
            $this->dbPath,
            "UPDATE pets SET active = 1 WHERE id = :id",
            [":id" => $petData['id']]
        ));
        $petData['active'] = 1;

        $location = $player->getLocation();
        $nbt = CompoundTag::create()
            ->setInt("PetID", $petData['id'])
            ->setString("Owner", $player->getName())
            ->setString("PetType", $petData['pet_type'])
            ->setInt("Level", $petData['level'])
            ->setInt("Exp", $petData['exp'])
            ->setInt("Hp", $petData['hp'])
            ->setInt("MaxHp", $petData['max_hp'])
            ->setInt("Damage", $petData['damage'])
            ->setString("State", $petData['state']);

        $entityClass = $this->getEntityClass($petData['pet_type']);
        if ($entityClass === null) return;

        /** @var PetEntity $entity */
        $entity = new $entityClass($location, null, $nbt);
        $entity->spawnToAll();

        $this->activePetEntities[$ownerLower] = $entity;
        $player->sendMessage("§a✨ Đã triệu hồi Pet " . $this->getPetDisplayName($petData['pet_type']) . "!");
    }

    public function despawnPet(Player|string $player, bool $saveToDb = true, bool $syncSave = false): void {
        $name = strtolower($player instanceof Player ? $player->getName() : $player);
        if (isset($this->activePetEntities[$name])) {
            $entity = $this->activePetEntities[$name];
            if (!$entity->isClosed() && $entity->isAlive()) {
                if ($saveToDb) {
                    $data = [
                        'id' => $entity->getPetDbId(),
                        'level' => $entity->getPetLevel(),
                        'exp' => $entity->getPetExp(),
                        'hp' => (int)$entity->getHealth(),
                        'max_hp' => (int)$entity->getMaxHealth(),
                        'damage' => (int)$entity->getPetDamage(),
                        'active' => 0,
                        'state' => $entity->getPetState()
                    ];
                    $this->savePetData($data, $syncSave);
                }
                $entity->close();
            }
            unset($this->activePetEntities[$name]);
            if ($saveToDb) {
                if ($syncSave) {
                    $this->db->exec("UPDATE pets SET active = 0 WHERE owner = '" . $name . "'");
                } else {
                    $this->plugin->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask(
                        $this->dbPath,
                        "UPDATE pets SET active = 0 WHERE owner = :owner",
                        [":owner" => $name]
                    ));
                }
            }
        }
    }

    public function getActivePetEntity(string $player): ?PetEntity {
        return $this->activePetEntities[strtolower($player)] ?? null;
    }

    public function getEntityClass(string $type): ?string {
        return match ($type) {
            "pikachu" => \BeeAZ\AZPet\entity\PikachuPet::class,
            "eevee" => \BeeAZ\AZPet\entity\EeveePet::class,
            "mew" => \BeeAZ\AZPet\entity\MewPet::class,
            "charmander" => \BeeAZ\AZPet\entity\CharmanderPet::class,
            "squirtle" => \BeeAZ\AZPet\entity\SquirtlePet::class,
            "bulbasaur" => \BeeAZ\AZPet\entity\BulbasaurPet::class,
            "lucario" => \BeeAZ\AZPet\entity\LucarioPet::class,
            "snorlax" => \BeeAZ\AZPet\entity\SnorlaxPet::class,
            "gengar" => \BeeAZ\AZPet\entity\GengarPet::class,
            "jigglypuff" => \BeeAZ\AZPet\entity\JigglypuffPet::class,
            "gyarados" => \BeeAZ\AZPet\entity\GyaradosPet::class,
            "lapras" => \BeeAZ\AZPet\entity\LaprasPet::class,
            "gardevoir" => \BeeAZ\AZPet\entity\GardevoirPet::class,
            "umbreon" => \BeeAZ\AZPet\entity\UmbreonPet::class,
            "dragonite" => \BeeAZ\AZPet\entity\DragonitePet::class,
            "mudkip" => \BeeAZ\AZPet\entity\MudkipPet::class,
            default => null
        };
    }

    public function getPetDisplayName(string $type): string {
        return match ($type) {
            "pikachu" => "§ePikachu",
            "eevee" => "§6Eevee",
            "mew" => "§dMew",
            "charmander" => "§cCharmander",
            "squirtle" => "§bSquirtle",
            "bulbasaur" => "§aBulbasaur",
            "lucario" => "§bLucario",
            "snorlax" => "§9Snorlax",
            "gengar" => "§5Gengar",
            "jigglypuff" => "§dJigglypuff",
            "gyarados" => "§bGyarados",
            "lapras" => "§3Lapras",
            "gardevoir" => "§aGardevoir",
            "umbreon" => "§8Umbreon",
            "dragonite" => "§6Dragonite",
            "mudkip" => "§bMudkip",
            default => "Pet"
        };
    }

    public function close(): void {
        $this->db->close();
    }
}
