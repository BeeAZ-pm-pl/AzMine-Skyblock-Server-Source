<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\manager;

use pocketmine\entity\Living;
use pocketmine\player\Player;

class StatusManager {

    /** @var array<int, float> Entity ID => expiration timestamp (microtime) */
    private static array $stunned = [];
    /** @var array<int, float> Entity ID => expiration timestamp (microtime) */
    private static array $frozen = [];
    /** @var array<int, float> Entity ID => expiration timestamp (microtime) */
    private static array $sleeping = [];

    public static function stun(Living $entity, float $seconds): void {
        $id = $entity->getId();
        self::$stunned[$id] = microtime(true) + $seconds;
        if ($entity instanceof Player) {
            $entity->sendTitle("§e⚡ BỊ CHOÁNG ⚡", "§7Không thể di chuyển hoặc tấn công!", 5, (int)($seconds * 20), 5);
        }
    }

    public static function freeze(Living $entity, float $seconds): void {
        $id = $entity->getId();
        self::$frozen[$id] = microtime(true) + $seconds;
        if ($entity instanceof Player) {
            $entity->sendTitle("§b❄️ BỊ ĐÓNG BĂNG ❄️", "§7Cơ thể bạn đã bị hóa đá!", 5, (int)($seconds * 20), 5);
        }
    }

    public static function sleep(Living $entity, float $seconds): void {
        $id = $entity->getId();
        self::$sleeping[$id] = microtime(true) + $seconds;
        if ($entity instanceof Player) {
            $entity->sendTitle("§d💤 BỊ RU NGỦ 💤", "§7Đang ngủ sâu... Sẽ tỉnh khi bị tấn công!", 5, (int)($seconds * 20), 5);
        }
    }

    public static function isStunned(Living $entity): bool {
        $id = $entity->getId();
        if (isset(self::$stunned[$id])) {
            if (microtime(true) < self::$stunned[$id]) {
                return true;
            }
            unset(self::$stunned[$id]);
        }
        return false;
    }

    public static function isFrozen(Living $entity): bool {
        $id = $entity->getId();
        if (isset(self::$frozen[$id])) {
            if (microtime(true) < self::$frozen[$id]) {
                return true;
            }
            unset(self::$frozen[$id]);
        }
        return false;
    }

    public static function isSleeping(Living $entity): bool {
        $id = $entity->getId();
        if (isset(self::$sleeping[$id])) {
            if (microtime(true) < self::$sleeping[$id]) {
                return true;
            }
            unset(self::$sleeping[$id]);
        }
        return false;
    }

    public static function wakeUp(Living $entity): void {
        $id = $entity->getId();
        if (isset(self::$sleeping[$id])) {
            unset(self::$sleeping[$id]);
            if ($entity instanceof Player) {
                $entity->sendTitle("§a✨ BỪNG TỈNH ✨", "§fBạn đã tỉnh giấc!", 5, 20, 5);
            }
        }
    }

    public static function isRestricted(Living $entity): bool {
        return self::isStunned($entity) || self::isFrozen($entity) || self::isSleeping($entity);
    }
}
