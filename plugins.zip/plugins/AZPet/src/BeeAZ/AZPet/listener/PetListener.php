<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\player\Player;
use pocketmine\entity\Living;
use BeeAZ\AZPet\manager\StatusManager;

use BeeAZ\AZPet\Main;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\ui\PetUI;

class PetListener implements Listener {

    public function __construct(private Main $plugin) {}

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        // Delay spawning slightly to ensure safe loading
        $this->plugin->getScheduler()->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(function() use ($player): void {
            if ($player->isOnline()) {
                $petData = $this->plugin->getPetManager()->getActivePetData($player->getName());
                if ($petData !== null) {
                    $this->plugin->getPetManager()->spawnPet($player, $petData);
                }
            }
        }), 20);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $this->plugin->getPetManager()->despawnPet($player, true);
    }

    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();

        // 0. If entity is sleeping and takes damage, wake them up
        if ($entity instanceof Living && StatusManager::isSleeping($entity)) {
            StatusManager::wakeUp($entity);
        }

        // 0.1 If attacker is restricted by status, cancel attack
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager = $event->getDamager();
            if ($damager instanceof Living && StatusManager::isRestricted($damager)) {
                $event->cancel();
                return;
            }
        }

        // 1. If a pet is taking damage
        if ($entity instanceof PetEntity) {
            $owner = $entity->getOwner();

            // Check if player is in a duel, and if the damage would K.O the pet
            if ($this->plugin->isInDuel($entity->getOwnerName())) {
                if ($entity->getHealth() - $event->getFinalDamage() <= 0) {
                    $event->cancel();
                    $entity->setHealth(1.0);
                    return;
                }
            }

            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();

                // If this damager is the pet's current attack target (pet is counter-attacking them), allow the damage!
                $target = $entity->getAttackTarget();
                if ($target !== null && $target->getId() === $damager->getId()) {
                    return;
                }

                // Otherwise, cancel damage and show menu/interaction if it's a player
                if ($damager instanceof Player) {
                    $event->cancel();

                    // Do not open menus if in a duel
                    if ($this->plugin->isInDuel($entity->getOwnerName())) {
                        return;
                    }

                    if ($owner !== null && strtolower($damager->getName()) === strtolower($owner->getName())) {
                        // Owner clicks: open quick menu
                        $petData = $this->plugin->getPetManager()->getActivePetData($damager->getName());
                        if ($petData !== null) {
                            PetUI::openPetQuickMenu($damager, $petData, $entity);
                        } else {
                            PetUI::openMainMenu($damager);
                        }
                    } else {
                        // Guest clicks: open info menu
                        PetUI::openPetInfoMenu($damager, $entity);
                    }
                } else {
                    // Block other entities from hurting the pet
                    $event->cancel();
                }
            } else {
                // Cancel environmental damage (void is handled in onUpdate, other environmental damage is ignored)
                $event->cancel();
            }
            return;
        }

        // 2. If a player (owner) is taking damage
        if ($entity instanceof Player) {
            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if ($damager instanceof Living && !$damager instanceof PetEntity) {
                    // Get active pet
                    $pet = $this->plugin->getPetManager()->getActivePetEntity($entity->getName());
                    if ($pet !== null && !$pet->isClosed() && $pet->isAlive()) {
                        // Do not attack if in a duel
                        if (!$this->plugin->isInDuel($entity->getName())) {
                            $pet->setAttackTarget($damager);
                        }
                    }
                }
            }
        }
    }

    public function onDeath(EntityDeathEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof PetEntity) {
            // Disable default drops/XP
            $event->setDrops([]);
            $event->setXpDropAmount(0);

            $ownerName = $entity->getOwnerName();
            $owner = $entity->getOwner();

            // Set 30 seconds respawn cooldown
            $this->plugin->getPetManager()->setRespawnCooldown($ownerName, time() + 30);

            // Save pet health as 0 to database
            $data = [
                'id' => $entity->getPetDbId(),
                'level' => $entity->getPetLevel(),
                'exp' => $entity->getPetExp(),
                'hp' => 0,
                'max_hp' => (int)$entity->getMaxHealth(),
                'damage' => (int)$entity->getPetDamage(),
                'active' => 0,
                'state' => $entity->getPetState()
            ];
            $this->plugin->getPetManager()->savePetData($data);

            // Clean up internal references
            $this->plugin->getPetManager()->despawnPet($owner ?? $ownerName, false);

            if ($owner !== null) {
                $owner->sendMessage("§c💀 Pet của bạn đã bị tiêu diệt! Cần 30 giây hồi sức để có thể triệu hồi lại.");
            }
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        if (StatusManager::isRestricted($player)) {
            $from = $event->getFrom();
            $to = $event->getTo();
            if ($from->x !== $to->x || $from->y !== $to->y || $from->z !== $to->z) {
                $newTo = clone $from;
                $newTo->x = $from->x;
                $newTo->y = $from->y;
                $newTo->z = $from->z;
                $event->setTo($newTo);
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        if (StatusManager::isRestricted($player)) {
            $event->cancel();
        }
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        if (StatusManager::isRestricted($player)) {
            $event->cancel();
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        if (StatusManager::isRestricted($player)) {
            $event->cancel();
        }
    }
}
