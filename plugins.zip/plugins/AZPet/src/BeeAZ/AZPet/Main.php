<?php

declare(strict_types=1);

namespace BeeAZ\AZPet;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\utils\SingletonTrait;
use pocketmine\scheduler\ClosureTask;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;

use BeeAZ\AZPet\manager\PetManager;
use BeeAZ\AZPet\listener\PetListener;
use BeeAZ\AZPet\entity\PetEntity;
use BeeAZ\AZPet\entity\PikachuPet;
use BeeAZ\AZPet\entity\EeveePet;
use BeeAZ\AZPet\entity\MewPet;
use BeeAZ\AZPet\entity\CharmanderPet;
use BeeAZ\AZPet\entity\SquirtlePet;
use BeeAZ\AZPet\entity\BulbasaurPet;
use BeeAZ\AZPet\entity\LucarioPet;
use BeeAZ\AZPet\entity\SnorlaxPet;
use BeeAZ\AZPet\entity\GengarPet;
use BeeAZ\AZPet\entity\JigglypuffPet;
use BeeAZ\AZPet\entity\GyaradosPet;
use BeeAZ\AZPet\entity\LaprasPet;
use BeeAZ\AZPet\entity\GardevoirPet;
use BeeAZ\AZPet\entity\UmbreonPet;
use BeeAZ\AZPet\entity\DragonitePet;
use BeeAZ\AZPet\entity\MudkipPet;
use BeeAZ\AZPet\ui\PetUI;

class Main extends PluginBase {
    use SingletonTrait;

    private PetManager $petManager;
    private array $activeDuels = []; // challengerName => [targetName, petA, petB, startTime]
    private array $duelRequests = []; // targetName => [challengerName => requestTime]

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        $this->petManager = new PetManager($this);
        
        $this->registerEntities();
        $this->getServer()->getPluginManager()->registerEvents(new PetListener($this), $this);

        // Keep duels ticked
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->tickDuels();
        }), 20);

        $this->getLogger()->info("§aAZPet v1.0.0 đã kích hoạt thành công!");
    }

    protected function onDisable(): void {
        // Despawn all pets on shutdown to save their data (using sync save to prevent loss on pool close)
        foreach ($this->getServer()->getOnlinePlayers() as $player) {
            $this->petManager->despawnPet($player, true, true);
        }
        $this->petManager->close();
    }

    public function getPetManager(): PetManager {
        return $this->petManager;
    }

    private function registerEntities(): void {
        $registerMap = [
            PikachuPet::class => ['azpet:pikachu', 'pokemon:p25_pet'],
            EeveePet::class => ['azpet:eevee', 'pokemon:p133_pet'],
            MewPet::class => ['azpet:mew', 'pokemon:p151_pet'],
            CharmanderPet::class => ['azpet:charmander', 'pokemon:p4_pet'],
            SquirtlePet::class => ['azpet:squirtle', 'pokemon:p7_pet'],
            BulbasaurPet::class => ['azpet:bulbasaur', 'pokemon:p1_pet'],
            LucarioPet::class => ['azpet:lucario', 'pokemon:p448_pet'],
            SnorlaxPet::class => ['azpet:snorlax', 'pokemon:p143_pet'],
            GengarPet::class => ['azpet:gengar', 'pokemon:p94_pet'],
            JigglypuffPet::class => ['azpet:jigglypuff', 'pokemon:p39_pet'],
            GyaradosPet::class => ['azpet:gyarados', 'pokemon:p130_pet'],
            LaprasPet::class => ['azpet:lapras', 'pokemon:p131_pet'],
            GardevoirPet::class => ['azpet:gardevoir', 'pokemon:p282_pet'],
            UmbreonPet::class => ['azpet:umbreon', 'pokemon:p197_pet'],
            DragonitePet::class => ['azpet:dragonite', 'pokemon:p149_pet'],
            MudkipPet::class => ['azpet:mudkip', 'pokemon:p258_pet']
        ];

        foreach ($registerMap as $class => $aliases) {
            EntityFactory::getInstance()->register($class, function(World $world, CompoundTag $nbt) use ($class): PetEntity {
                $location = clone $world->getSpawnLocation();
                try {
                    $location = EntityDataHelper::parseLocation($nbt, $world);
                } catch (\Exception $e) {}
                
                return new $class($location, null, $nbt);
            }, $aliases);
        }

        // Register client identifiers so player device displays the Pokemon skins properly
        try {
            $instance = \pocketmine\network\mcpe\cache\StaticPacketCache::getInstance();
            $property = (new \ReflectionClass($instance))->getProperty("availableActorIdentifiers");
            $packet = $property->getValue($instance);
            $root = $packet->identifiers->getRoot();
            
            $idList = $root->getListTag("idlist");
            if ($idList !== null) {
                $registeredIds = [
                    "pokemon:p25", "pokemon:p133", "pokemon:p151", "pokemon:p4", "pokemon:p7", "pokemon:p1",
                    "pokemon:p448", "pokemon:p143", "pokemon:p94", "pokemon:p39", "pokemon:p130", "pokemon:p131",
                    "pokemon:p282", "pokemon:p197", "pokemon:p149", "pokemon:p258"
                ];
                $existingIds = [];
                foreach ($idList as $tag) {
                    if ($tag instanceof CompoundTag) {
                        $existingIds[] = $tag->getString("id", "");
                    }
                }
                foreach ($registeredIds as $regId) {
                    if (!in_array($regId, $existingIds, true)) {
                        $idList->push(CompoundTag::create()
                            ->setString("id", $regId)
                            ->setString("bid", "")
                        );
                    }
                }
                $packet->identifiers = new \pocketmine\network\mcpe\protocol\types\CacheableNbt($root);
            }
        } catch (\Exception $e) {
            $this->getLogger()->error("§cLỗi đăng ký client identifiers: " . $e->getMessage());
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "pet") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cLệnh này chỉ sử dụng trong trò chơi!");
                return true;
            }

            if (isset($args[0])) {
                $sub = strtolower($args[0]);
                if ($sub === "duel") {
                    if (!isset($args[1])) {
                        $sender->sendMessage("§cHD: /pet duel <tên người chơi>");
                        return true;
                    }

                    $target = $this->getServer()->getPlayerByPrefix($args[1]);
                    if ($target === null) {
                        $sender->sendMessage("§cNgười chơi này không trực tuyến!");
                        return true;
                    }

                    $this->requestDuel($sender, $target);
                    return true;
                }

                if ($sub === "accept") {
                    if (!isset($args[1])) {
                        $sender->sendMessage("§cHD: /pet accept <tên người chơi>");
                        return true;
                    }

                    $challenger = $this->getServer()->getPlayerByPrefix($args[1]);
                    if ($challenger === null) {
                        $sender->sendMessage("§cNgười chơi này không trực tuyến!");
                        return true;
                    }

                    $this->acceptDuel($sender, $challenger);
                    return true;
                }

                if ($sub === "deny" || $sub === "reject") {
                    if (!isset($args[1])) {
                        $sender->sendMessage("§cHD: /pet deny <tên người chơi>");
                        return true;
                    }

                    $challenger = $this->getServer()->getPlayerByPrefix($args[1]);
                    if ($challenger === null) {
                        $sender->sendMessage("§cNgười chơi này không trực tuyến!");
                        return true;
                    }

                    $this->rejectDuel($sender, $challenger);
                    return true;
                }
            }

            PetUI::openMainMenu($sender);
            return true;
        }
        return false;
    }

    public function requestDuel(Player $challenger, Player $target): void {
        if ($challenger->getName() === $target->getName()) {
            $challenger->sendMessage("§cBạn không thể tự thách đấu chính mình!");
            return;
        }

        // Check if both have pets spawned
        $petA = $this->petManager->getActivePetEntity($challenger->getName());
        $petB = $this->petManager->getActivePetEntity($target->getName());

        if ($petA === null) {
            $challenger->sendMessage("§cBạn phải triệu hồi Pet mới có thể thách đấu!");
            return;
        }

        if ($petB === null) {
            $challenger->sendMessage("§cĐối phương chưa triệu hồi Pet!");
            return;
        }

        $challengerName = $challenger->getName();
        $targetName = $target->getName();

        // Check active duels
        if ($this->isInDuel($challengerName) || $this->isInDuel($targetName)) {
            $challenger->sendMessage("§cMột trong hai người đang trong trận chiến Pet!");
            return;
        }

        $this->duelRequests[strtolower($targetName)][strtolower($challengerName)] = time();
        $challenger->sendMessage("§aĐã gửi lời thách đấu tới §e" . $targetName . "§a. Chờ chấp nhận...");

        // Send chat notification prompts in case target has another UI open
        $target->sendMessage("§e⚔ Bạn nhận được lời thách đấu Pet từ §a" . $challenger->getName() . "§e!");
        $target->sendMessage("§eNhập lệnh: §a/pet accept " . $challenger->getName() . " §eđể chấp nhận hoặc §c/pet deny " . $challenger->getName() . " §eđể từ chối (Thời gian chờ: 30 giây).");

        // Send Form invitation to target
        PetUI::openDuelInviteForm($target, $challenger);
    }

    public function acceptDuel(Player $target, Player $challenger): void {
        $challengerName = $challenger->getName();
        $targetName = $target->getName();
        
        $reqs = $this->duelRequests[strtolower($targetName)] ?? [];
        if (!isset($reqs[strtolower($challengerName)]) || time() - $reqs[strtolower($challengerName)] > 30) {
            $target->sendMessage("§cLời thách đấu đã hết hạn hoặc không tồn tại!");
            return;
        }

        unset($this->duelRequests[strtolower($targetName)][strtolower($challengerName)]);

        $petA = $this->petManager->getActivePetEntity($challengerName);
        $petB = $this->petManager->getActivePetEntity($targetName);

        if ($petA === null || $petB === null) {
            $target->sendMessage("§cTrận chiến bị hủy do một trong hai Pet đã bị thu hồi!");
            $challenger->sendMessage("§cTrận chiến bị hủy do một trong hai Pet đã bị thu hồi!");
            return;
        }

        // Start Duel
        $this->activeDuels[strtolower($challengerName)] = [
            'target' => strtolower($targetName),
            'petA' => $petA,
            'petB' => $petB,
            'start_time' => time()
        ];

        // Teleport pets to fight
        $petA->teleport($challenger->getLocation());
        $petB->teleport($target->getLocation());

        $petA->setAttackTarget($petB);
        $petB->setAttackTarget($petA);

        $challenger->sendMessage("§a⚔ Trận chiến Pet bắt đầu! Pet của bạn đang PK với Pet của §e" . $targetName . "§a!");
        $target->sendMessage("§a⚔ Trận chiến Pet bắt đầu! Pet của bạn đang PK với Pet của §e" . $challengerName . "§a!");

        $challenger->getWorld()->addSound($challenger->getLocation(), new XpLevelUpSound(1));
        $target->getWorld()->addSound($target->getLocation(), new XpLevelUpSound(1));
    }

    public function rejectDuel(Player $target, Player $challenger): void {
        unset($this->duelRequests[strtolower($target->getName())][strtolower($challenger->getName())]);
        $challenger->sendMessage("§c" . $target->getName() . " đã từ chối lời thách đấu Pet của bạn.");
    }

    public function isInDuel(string $playerName): bool {
        $name = strtolower($playerName);
        if (isset($this->activeDuels[$name])) return true;
        foreach ($this->activeDuels as $challenger => $data) {
            if ($data['target'] === $name) return true;
        }
        return false;
    }

    private function tickDuels(): void {
        foreach ($this->activeDuels as $challenger => $data) {
            $target = $data['target'];
            /** @var PetEntity $petA */
            $petA = $data['petA'];
            /** @var PetEntity $petB */
            $petB = $data['petB'];

            $pA = $this->getServer()->getPlayerExact($challenger);
            $pB = $this->getServer()->getPlayerExact($target);

            // Check if player offline
            if ($pA === null || !$pA->isOnline()) {
                $this->endDuel($challenger, $target, $petB, $petA, "Chủ nhân offline");
                continue;
            }
            if ($pB === null || !$pB->isOnline()) {
                $this->endDuel($challenger, $target, $petA, $petB, "Chủ nhân offline");
                continue;
            }

            // Check if pets dead/despawned or K.O (health <= 1)
            if ($petA->isClosed() || !$petA->isAlive() || $petA->getHealth() <= 1.0) {
                $this->endDuel($challenger, $target, $petB, $petA, "K.O");
                continue;
            }
            if ($petB->isClosed() || !$petB->isAlive() || $petB->getHealth() <= 1.0) {
                $this->endDuel($challenger, $target, $petA, $petB, "K.O");
                continue;
            }

            // Force targets
            if ($petA->getAttackTarget() !== $petB) $petA->setAttackTarget($petB);
            if ($petB->getAttackTarget() !== $petA) $petB->setAttackTarget($petA);

            // Timeout check (60 seconds limit)
            if (time() - $data['start_time'] > 60) {
                $this->endDuel($challenger, $target, null, null, "Hết thời gian (Hòa)");
            }
        }
    }

    private function endDuel(string $challenger, string $target, ?PetEntity $winnerPet, ?PetEntity $loserPet, string $reason): void {
        unset($this->activeDuels[strtolower($challenger)]);

        $pA = $this->getServer()->getPlayerExact($challenger);
        $pB = $this->getServer()->getPlayerExact($target);

        if ($reason === "Hết thời gian (Hòa)" || $winnerPet === null || $loserPet === null) {
            if ($pA !== null) $pA->sendMessage("§e⚔ Trận đấu Pet kết thúc với kết quả Hòa!");
            if ($pB !== null) $pB->sendMessage("§e⚔ Trận đấu Pet kết thúc với kết quả Hòa!");
        } else {
            $winnerOwner = $winnerPet->getOwnerName();
            $loserOwner = $loserPet->getOwnerName();

            $pWinner = $this->getServer()->getPlayerExact($winnerOwner);
            $pLoser = $this->getServer()->getPlayerExact($loserOwner);

            // Calculate loser total exp
            $loserLevel = $loserPet->getPetLevel();
            $winnerLevel = $winnerPet->getPetLevel();
            $loserExp = $loserPet->getPetExp();
            $loserTotalExp = 500 * ($loserLevel - 1) * $loserLevel + $loserExp;

            if ($loserTotalExp <= 0) {
                // Friendly match (pk vui vẻ)
                if ($pWinner !== null) {
                    $pWinner->sendMessage("§a🎉 Trận đấu vui vẻ kết thúc! Do Pet đối phương chưa có kinh nghiệm nên không nhận được EXP.");
                    $pWinner->getWorld()->addSound($pWinner->getLocation(), new XpLevelUpSound(1));
                }
                if ($pLoser !== null) {
                    $pLoser->sendMessage("§e⚔ Trận đấu vui vẻ kết thúc! Pet của bạn chưa có kinh nghiệm nên không bị mất EXP.");
                    $pLoser->getWorld()->addSound($pLoser->getLocation(), new AnvilUseSound());
                }
            } else {
                // Calculate EXP transfer based on opponent's level with ratio scaling
                $baseExp = 500;
                $ratio = $loserLevel / max(1, $winnerLevel);
                $expTransfer = (int)($baseExp * $ratio);
                $expTransfer = max(10, $expTransfer);
                $expTransfer = min($expTransfer, $loserTotalExp);

                // Transfer EXP
                $winnerPet->addExp($expTransfer);
                $loserPet->reduceExp($expTransfer);

                if ($pWinner !== null) {
                    $pWinner->sendMessage("§a🎉 Pet của bạn đã giành chiến thắng! Nhận được §l" . $expTransfer . " EXP§r§a từ Pet đối thủ.");
                    $pWinner->getWorld()->addSound($pWinner->getLocation(), new XpLevelUpSound(1));
                }
                if ($pLoser !== null) {
                    $pLoser->sendMessage("§c💀 Pet của bạn đã thất bại và bị hao hụt §l" . $expTransfer . " EXP§r§c.");
                    $pLoser->getWorld()->addSound($pLoser->getLocation(), new AnvilUseSound());
                }
            }
        }

        // Fully heal both pets and reset their combat targets
        if ($winnerPet !== null && !$winnerPet->isClosed()) {
            $winnerPet->setAttackTarget(null);
            $winnerPet->healFull();
        }
        if ($loserPet !== null && !$loserPet->isClosed()) {
            $loserPet->setAttackTarget(null);
            $loserPet->healFull();
        }
    }
}
