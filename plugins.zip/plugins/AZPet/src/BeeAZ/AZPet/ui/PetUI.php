<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\ui;

use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;

use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\ModalForm;
use dktapps\pmforms\FormIcon;

use BeeAZ\AZPet\Main;
use BeeAZ\AZPet\entity\PetEntity;
use AZEconomy\AZEconomy;

class PetUI {

    public static function openMainMenu(Player $player): void {
        $plugin = Main::getInstance();
        $manager = $plugin->getPetManager();
        $ownedPets = $manager->getOwnedPets($player->getName());

        if (empty($ownedPets)) {
            // Main menu for players who do not own any pets
            $form = new MenuForm(
                "§l§dAZPET - THÚ CƯNG",
                "§fBạn chưa sở hữu Pet nào. Hãy ghé Cửa hàng để sở hữu chú Pet đầu tiên nhé!",
                [
                    new MenuOption("§l§0⚡ §eCỬA HÀNG PET §l§0⚡\n§r§7Mua Pet bằng Coin", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
                    new MenuOption("§l§0⚡ §dKỸ NĂNG & HƯỚNG DẪN §l§0⚡\n§r§7Thông tin kỹ năng mở khóa", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH))
                ],
                function(Player $player, int $selectedOption): void {
                    if ($selectedOption === 0) {
                        self::openShopMenu($player);
                    } elseif ($selectedOption === 1) {
                        self::openGuideMenu($player);
                    }
                }
            );
            $player->sendForm($form);
            return;
        }

        // Has pets: find the active one if any
        $activePetData = null;
        foreach ($ownedPets as $pet) {
            if ($pet['active'] === 1) {
                $activePetData = $pet;
                break;
            }
        }

        // If no pet is marked active in DB, but there is a spawned entity, sync it
        $activeEntity = $manager->getActivePetEntity($player->getName());
        if ($activeEntity !== null && $activePetData === null) {
            $activePetData = [
                'id' => $activeEntity->getPetDbId(),
                'pet_type' => $activeEntity->getPetState(),
                'level' => $activeEntity->getPetLevel(),
                'exp' => $activeEntity->getPetExp(),
                'hp' => (int)$activeEntity->getHealth(),
                'max_hp' => (int)$activeEntity->getMaxHealth(),
                'damage' => (int)$activeEntity->getPetDamage(),
                'active' => 1,
                'state' => $activeEntity->getPetState()
            ];
        }

        $content = "§fChào đạo hữu §e" . $player->getName() . "§f,\n\n";
        if ($activePetData !== null) {
            $displayName = $manager->getPetDisplayName($activePetData['pet_type']);
            $nextExp = $activePetData['level'] * 1000;
            $stateStr = $activePetData['state'] === "follow" ? "§aTheo Sau" : "§cĐứng Yên";
            $content .= "§fPet đang hoạt động: " . $displayName . "\n";
            $content .= "§fCấp độ: §e" . $activePetData['level'] . "\n";
            $content .= "§fEXP: §a" . $activePetData['exp'] . "§f/§a" . $nextExp . "\n";
            $content .= "§fHP: §c" . $activePetData['hp'] . "§f/§c" . $activePetData['max_hp'] . "\n";
            $content .= "§fSát thương: §e" . $activePetData['damage'] . "\n";
            $content .= "§fTrạng thái: " . $stateStr . "\n";
        } else {
            $content .= "§fBạn chưa triệu hồi Pet nào ra ngoài.";
        }

        $options = [];
        if ($activePetData !== null) {
            $options[] = new MenuOption("§l§0⚡ §cTHU HỒI PET §l§0⚡\n§r§7Đưa pet trở lại", new FormIcon("textures/blocks/barrier", FormIcon::IMAGE_TYPE_PATH));
            $stateText = $activePetData['state'] === "follow" ? "§l§0⚡ §6ĐỨNG YÊN (STAY) §l§0⚡\n§r§7Pet sẽ đứng tại chỗ" : "§l§0⚡ §aDI CHUYỂN (FOLLOW) §l§0⚡\n§r§7Pet sẽ đi theo bạn";
            $options[] = new MenuOption($stateText, new FormIcon("textures/items/compass_item", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ §eCHO PET ĂN §l§0⚡\n§r§7Hồi máu và nhận EXP", new FormIcon("textures/items/apple", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ §bHUẤN LUYỆN PET §l§0⚡\n§r§7Tăng nhanh cấp độ Pet", new FormIcon("textures/items/experience_bottle", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ §eCỬA HÀNG PET §l§0⚡\n§r§7Mua thêm Pet mới", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ §dKỸ NĂNG & HƯỚNG DẪN §l§0⚡\n§r§7Thông tin kỹ năng mở khóa", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH));
        } else {
            $options[] = new MenuOption("§l§0⚡ §aTRIỆU HỒI PET §l§0⚡\n§r§7Chọn Pet để ra trận", new FormIcon("textures/ui/color_plus", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ §eCỬA HÀNG PET §l§0⚡\n§r§7Mua thêm Pet mới", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH));
            $options[] = new MenuOption("§l§0⚡ §dKỸ NĂNG & HƯỚNG DẪN §l§0⚡\n§r§7Thông tin kỹ năng mở khóa", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH));
        }

        $form = new MenuForm(
            "§l§dAZPET - QUẢN LÝ",
            $content,
            $options,
            function(Player $player, int $selectedOption) use ($plugin, $manager, $ownedPets, $activePetData): void {
                if ($activePetData !== null) {
                    switch ($selectedOption) {
                        case 0: // Despawn
                            $manager->despawnPet($player, true);
                            $player->sendMessage("§aĐã thu hồi Pet vào túi!");
                            break;
                        case 1: // Toggle state
                            $newState = $activePetData['state'] === "follow" ? "stay" : "follow";
                            $activePetData['state'] = $newState;
                            $manager->savePetData($activePetData);
                            $entity = $manager->getActivePetEntity($player->getName());
                            if ($entity !== null) {
                                $entity->setPetState($newState);
                                $entity->updateNameTag();
                            }
                            $player->sendMessage("§aĐã chuyển trạng thái Pet sang: " . ($newState === "follow" ? "§aTheo Sau" : "§cĐứng Yên"));
                            break;
                        case 2: // Feed
                            self::openFeedMenu($player, $activePetData);
                            break;
                        case 3: // Train
                            self::openTrainMenu($player, $activePetData);
                            break;
                        case 4: // Shop
                            self::openShopMenu($player);
                            break;
                        case 5: // Guide
                            self::openGuideMenu($player);
                            break;
                    }
                } else {
                    switch ($selectedOption) {
                        case 0: // Spawn selection
                            self::openSpawnSelectionMenu($player, $ownedPets);
                            break;
                        case 1: // Shop
                            self::openShopMenu($player);
                            break;
                        case 2: // Guide
                            self::openGuideMenu($player);
                            break;
                    }
                }
            }
        );
        $player->sendForm($form);
    }

    public static function openGuideMenu(Player $player): void {
        $text = "§l§e1. CÁCH LUYỆN CẤP CHO PET:§r\n" .
            "§f- §dCho ăn:§f Vào Quản lý chọn Cho Pet Ăn. Mỗi vật phẩm (Raw Beef, Steak, Apple, Golden Apple) sẽ hồi HP và tăng EXP cho Pet.\n" .
            "§f- §dHuấn luyện:§f Tiêu tốn Coin để mua các khóa huấn luyện (Sơ, Trung, Cao cấp) tăng nhanh lượng lớn EXP.\n" .
            "§f- §dPK/Thách đấu Pet:§f Dùng lệnh §e/pet duel <tên người chơi>§f. Nhận EXP dựa trên chênh lệch cấp độ với đối thủ.\n" .
            "§f- §dĐánh quái/boss:§f Khi Pet đồng hành tấn công quái vật hoặc boss ngoài thiên giới sẽ nhận §a+5 EXP§f mỗi đòn đánh.\n\n" .
            "§l§e2. DANH SÁCH KỸ NĂNG MỞ KHÓA THEO CẤP:§r\n" .
            "§7(Tỉ lệ tự động kích hoạt 30% khi tấn công thường)\n\n" .
            "§e⚡ Pikachu:§r\n" .
            "§f- §aCấp 5 - [Tia Chớp]:§f Sát thương x1.5 và giật điện mục tiêu.\n" .
            "§f- §aCấp 15 - [Sấm Sét]:§f Sát thương x2.0 giáng sét hủy diệt.\n\n" .
            "§6🐾 Eevee:§r\n" .
            "§f- §aCấp 5 - [Húc Đố]:§f Sát thương x1.3, húc văng đẩy lùi mục tiêu.\n" .
            "§f- §aCấp 15 - [Mưa Sao Băng]:§f Sát thương x1.8 bắn sao liên hoàn.\n\n" .
            "§d✨ Mew:§r\n" .
            "§f- §aCấp 5 - [Niệm Lực]:§f Sát thương x1.5, áp chế làm chậm đối thủ.\n" .
            "§f- §aCấp 15 - [Cầu Ngoại Cảm]:§f Sát thương x2.0, bóp méo không gian dịch chuyển kẻ địch.\n\n" .
            "§c🔥 Charmander:§r\n" .
            "§f- §aCấp 5 - [Tia Lửa]:§f Sát thương x1.2, thiêu cháy mục tiêu trong 3 giây.\n" .
            "§f- §aCấp 15 - [Phun Lửa]:§f Sát thương x2.0, phun bão lửa thiêu cháy đối phương trong 5 giây.\n\n" .
            "§b💧 Squirtle:§r\n" .
            "§f- §aCấp 5 - [Bong Bóng]:§f Sát thương x1.3, làm chậm kẻ địch bằng bong bóng nước.\n" .
            "§f- §aCấp 15 - [Súng Phun Nước]:§f Sát thương x2.0, bắn cột nước cực mạnh đẩy lùi mục tiêu.\n\n" .
            "§a🍃 Bulbasaur:§r\n" .
            "§f- §aCấp 5 - [Roi Mây]:§f Sát thương x1.4, quật ngã giảm tốc độ chạy của đối phương.\n" .
            "§f- §aCấp 15 - [Lá Gió]:§f Sát thương x2.0, phóng hàng loạt lá sắc ngọt cắt xé mục tiêu.\n\n" .
            "§b🔵 Lucario:§r\n" .
            "§f- §aCấp 5 - [Aura Phá]:§f Sát thương x1.6, tụ khí cầu tâm linh.\n" .
            "§f- §aCấp 15 - [Aura Sphere]:§f Sát thương x2.2 giải phóng linh hồn cầu cực đại.\n\n" .
            "§9🐻 Snorlax:§r\n" .
            "§f- §aCấp 5 - [Đè Bẹp]:§f Sát thương x1.5, dậm nhảy nghiền nát đối thủ.\n" .
            "§f- §aCấp 15 - [Body Slam]:§f Sát thương x2.1 đè bẹp chấn động đẩy lùi cao.\n\n" .
            "§5👻 Gengar:§r\n" .
            "§f- §aCấp 5 - [Cầu Bóng Tối]:§f Sát thương x1.4, ám ảnh đối thủ làm chậm.\n" .
            "§f- §aCấp 15 - [Shadow Ball]:§f Sát thương x2.0 làm chậm sâu tê liệt cử động.\n\n" .
            "§d🎤 Jigglypuff:§r\n" .
            "§f- §aCấp 5 - [Hát Ru]:§f Sát thương x1.3, gây ru ngủ làm chậm đối phương.\n" .
            "§f- §aCấp 15 - [Sing]:§f Sát thương x1.7 ru ngủ cực sâu bất động hoàn toàn.\n\n" .
            "§b🐉 Gyarados:§r\n" .
            "§f- §aCấp 5 - [Bão Nước]:§f Sát thương x1.6 quật đuôi thủy triều cực mạnh.\n" .
            "§f- §aCấp 15 - [Dragon Rage]:§f Sát thương x2.3 thiêu đốt đối thủ cuồng nộ.\n\n" .
            "§3❄️ Lapras:§r\n" .
            "§f- §aCấp 5 - [Sóng Băng]:§f Sát thương x1.4, làm chậm tốc độ kẻ thù.\n" .
            "§f- §aCấp 15 - [Ice Beam]:§f Sát thương x1.9 phóng tia băng giá đông cứng đối thủ.\n\n" .
            "§a🌸 Gardevoir:§r\n" .
            "§f- §aCấp 5 - [Tia Sáng]:§f Sát thương x1.5, bắn loạt sao lấp lánh phép thuật.\n" .
            "§f- §aCấp 15 - [Moonblast]:§f Sát thương x2.0 luồng ánh sáng mặt trăng hủy diệt.\n\n" .
            "§8🐈 Umbreon:§r\n" .
            "§f- §aCấp 5 - [Cắn Xé]:§f Sát thương x1.4 xé rách giáp phòng ngự.\n" .
            "§f- §aCấp 15 - [Dark Pulse]:§f Sát thương x1.8 luồng xung kích bóng tối cực mạnh.\n\n" .
            "§6🧡 Dragonite:§r\n" .
            "§f- §aCấp 5 - [Tia Chớp Rồng]:§f Sát thương x1.7 gọi sét giáng đầu kẻ thù.\n" .
            "§f- §aCấp 15 - [Hyper Beam]:§f Sát thương x2.5 giải phóng chùm sáng thiêu đốt.\n\n" .
            "§b💧 Mudkip:§r\n" .
            "§f- §aCấp 5 - [Bong Bóng Nước]:§f Sát thương x1.3 làm chậm đối phương.\n" .
            "§f- §aCấp 15 - [Water Pulse]:§f Sát thương x1.8 tạo sóng xung kích bong bóng đẩy lùi.";

        $form = new MenuForm(
            "§l§dKỸ NĂNG & HƯỚNG DẪN",
            $text,
            [
                new MenuOption("§l§0⚡ §cQUAY LẠI MENU §l§0⚡")
            ],
            function(Player $player, int $selectedOption): void {
                self::openMainMenu($player);
            }
        );
        $player->sendForm($form);
    }

    private static function openSpawnSelectionMenu(Player $player, array $ownedPets): void {
        $manager = Main::getInstance()->getPetManager();
        $options = [];
        foreach ($ownedPets as $pet) {
            $displayName = $manager->getPetDisplayName($pet['pet_type']);
            $options[] = new MenuOption("§l§0⚡ " . $displayName . " §l§0⚡\n§r§7Cấp độ: " . $pet['level']);
        }

        $form = new MenuForm(
            "§l§dTRIỆU HỒI PET",
            "§fChọn chú Pet bạn muốn đồng hành:",
            $options,
            function(Player $player, int $selectedOption) use ($manager, $ownedPets): void {
                $petData = $ownedPets[$selectedOption] ?? null;
                if ($petData !== null) {
                    $manager->spawnPet($player, $petData);
                }
            }
        );
        $player->sendForm($form);
    }

    public static function openShopMenu(Player $player): void {
        $economy = AZEconomy::getInstance();
        $manager = Main::getInstance()->getPetManager();
        $coins = $economy->getCoin($player->getName());

        $shopPets = [
            ["type" => "pikachu", "price" => 500, "desc" => "§ePikachu - Hệ Lôi. Nhanh nhẹn, giật điện tê liệt đối thủ."],
            ["type" => "eevee", "price" => 200, "desc" => "§6Eevee - Hệ Thường. Tiềm năng tiến hóa vô hạn, húc ngã địch."],
            ["type" => "charmander", "price" => 350, "desc" => "§cCharmander - Hệ Hỏa. Khủng long lửa quật khởi thiêu cháy đối phương."],
            ["type" => "squirtle", "price" => 350, "desc" => "§bSquirtle - Hệ Thủy. Rùa nước phun súng nước đẩy lùi mạnh."],
            ["type" => "bulbasaur", "price" => 350, "desc" => "§aBulbasaur - Hệ Thảo. Gieo bào tử độc hại gây sát thương theo thời gian."],
            ["type" => "mew", "price" => 1000, "desc" => "§dMew - Hệ Siêu Linh. Pet tối thượng phá vỡ không gian, dịch chuyển & làm choáng."],
            ["type" => "lucario", "price" => 800, "desc" => "§bLucario - Hệ Giác Đấu. Sát thương cực lớn, nén aura làm choáng kẻ thù."],
            ["type" => "snorlax", "price" => 600, "desc" => "§9Snorlax - Hệ Thường. Đè bẹp mục tiêu gây choáng nặng."],
            ["type" => "gengar", "price" => 650, "desc" => "§5Gengar - Hệ Ma. Ám ảnh bóng tối làm chậm cực độ và mù lòa đối thủ."],
            ["type" => "jigglypuff", "price" => 200, "desc" => "§dJigglypuff - Hệ Tiên. Hát ru ngủ khiến đối thủ bất động hoàn toàn."],
            ["type" => "gyarados", "price" => 850, "desc" => "§bGyarados - Hệ Thủy. Sức mạnh cuồng nộ rồng lửa đại dương cực mạnh."],
            ["type" => "lapras", "price" => 700, "desc" => "§3Lapras - Hệ Thủy (Băng). Bắn tia băng giá đông cứng mục tiêu tại chỗ."],
            ["type" => "gardevoir", "price" => 750, "desc" => "§aGardevoir - Hệ Siêu Linh. Bắn pháo ánh trăng gây sát thương và mù lòa."],
            ["type" => "umbreon", "price" => 450, "desc" => "§8Umbreon - Hệ Bóng Tối. Lao vào cắn xé và phát xung kích bóng tối làm chậm."],
            ["type" => "dragonite", "price" => 900, "desc" => "§6Dragonite - Hệ Rồng. Sức mạnh rồng huyền thoại, phun tia hủy diệt thiêu cháy."],
            ["type" => "mudkip", "price" => 350, "desc" => "§bMudkip - Hệ Thủy. Bong bóng nước ngộ nghĩnh, đẩy lùi đối phương."]
        ];

        $options = [];
        foreach ($shopPets as $pet) {
            $options[] = new MenuOption("§l§0⚡ " . $manager->getPetDisplayName($pet['type']) . " §l§0⚡\n§r§7Giá: §e" . $pet['price'] . " Coin §8| §7" . $pet['desc']);
        }

        $form = new MenuForm(
            "§l§dCỬA HÀNG THÚ CƯNG",
            "§fSố Coin của bạn: §e" . number_format($coins) . " Coin\n\n§fChọn Pet muốn mua:",
            $options,
            function(Player $player, int $selectedOption) use ($economy, $manager, $shopPets): void {
                $selected = $shopPets[$selectedOption];
                $type = $selected['type'];
                $price = $selected['price'];

                // Check if already owned
                $owned = $manager->getOwnedPets($player->getName());
                foreach ($owned as $p) {
                    if ($p['pet_type'] === $type) {
                        $player->sendMessage("§cBạn đã sở hữu Pet này rồi!");
                        return;
                    }
                }

                // Try to deduct coins
                $currentCoins = $economy->getCoin($player->getName());
                if ($currentCoins < $price) {
                    $player->sendMessage("§cBạn không có đủ Coin! Cần §e" . $price . " Coin §cđể mua Pet này.");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                if ($economy->reduceCoin($player->getName(), $price)) {
                    $manager->createPet($player->getName(), $type);
                    $player->sendMessage("§a✨ Mua thành công Pet " . $manager->getPetDisplayName($type) . "§a! Gõ /pet để triệu hồi.");
                    $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                } else {
                    $player->sendMessage("§cCó lỗi xảy ra trong quá trình mua Pet!");
                }
            }
        );
        $player->sendForm($form);
    }

    public static function openFeedMenu(Player $player, array $petData): void {
        $foods = [
            ["name" => "Raw Beef (Thịt bò sống)", "item" => VanillaItems::RAW_BEEF(), "hp" => 20, "exp" => "15-30", "icon" => "textures/items/beef_raw"],
            ["name" => "Cooked Beef (Thịt bò chín)", "item" => VanillaItems::STEAK(), "hp" => 50, "exp" => "15-30", "icon" => "textures/items/beef_cooked"],
            ["name" => "Apple (Táo)", "item" => VanillaItems::APPLE(), "hp" => 10, "exp" => "15-30", "icon" => "textures/items/apple"],
            ["name" => "Golden Apple (Táo vàng)", "item" => VanillaItems::GOLDEN_APPLE(), "hp" => 100, "exp" => "15-30", "icon" => "textures/items/apple_golden"]
        ];

        $options = [];
        foreach ($foods as $food) {
            $options[] = new MenuOption(
                "§l§0⚡ " . $food['name'] . " §l§0⚡\n§r§7Hồi HP: +" . $food['hp'] . " | EXP: +" . $food['exp'],
                new FormIcon($food['icon'], FormIcon::IMAGE_TYPE_PATH)
            );
        }

        $form = new MenuForm(
            "§l§dCHO PET ĂN",
            "§fChọn loại thức ăn từ túi đồ của bạn:",
            $options,
            function(Player $player, int $selectedOption) use ($petData, $foods): void {
                $plugin = Main::getInstance();
                $manager = $plugin->getPetManager();

                // Enforce feeding cooldown (10 seconds)
                $cooldown = $manager->getFeedCooldown($player->getName());
                if ($cooldown > time()) {
                    $player->sendMessage("§cBạn đang trong thời gian chờ cho Pet ăn! Vui lòng chờ " . ($cooldown - time()) . " giây.");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $selected = $foods[$selectedOption];
                $targetItem = $selected['item'];
                $hpRestore = $selected['hp'];
                $expGain = mt_rand(15, 30); // Randomize EXP between 15 and 30

                $inv = $player->getInventory();
                if (!$inv->contains($targetItem)) {
                    $player->sendMessage("§cBạn không có " . $selected['name'] . " trong túi đồ!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                // Remove 1 food item
                $inv->removeItem($targetItem->setCount(1));

                // Set feeding cooldown
                $manager->setFeedCooldown($player->getName(), time() + 10);

                // Process feeding
                $entity = $manager->getActivePetEntity($player->getName());

                if ($entity !== null && !$entity->isClosed() && $entity->isAlive()) {
                    // Update entity state directly
                    $newHp = min($entity->getMaxHealth(), $entity->getHealth() + $hpRestore);
                    $entity->setHealth((float)$newHp);
                    $entity->addExp($expGain);
                    $player->sendMessage("§a✨ Đã cho Pet ăn " . $selected['name'] . "! Pet được hồi §c" . $hpRestore . " HP §avà nhận §e" . $expGain . " EXP§a.");
                } else {
                    // Pet is despawned, update database values directly
                    $petData['hp'] = min($petData['max_hp'], $petData['hp'] + $hpRestore);
                    
                    // Simulate level up in database
                    $petData['exp'] += $expGain;
                    $nextLevelExp = $petData['level'] * 1000;
                    while ($petData['exp'] >= $nextLevelExp) {
                        $petData['exp'] -= $nextLevelExp;
                        $petData['level']++;
                        $petData['damage'] = $petData['level'];
                        $petData['max_hp'] = 100 + ($petData['level'] - 1) * 20;
                        $petData['hp'] = $petData['max_hp'];
                        $nextLevelExp = $petData['level'] * 1000;
                        $player->sendMessage("§a✨ Pet của bạn đã thăng lên Cấp " . $petData['level'] . " trong túi!");
                    }

                    $manager->savePetData($petData);
                    $player->sendMessage("§a✨ Đã cho Pet ăn " . $selected['name'] . "! Pet trong túi nhận được §c" . $hpRestore . " HP §avà §e" . $expGain . " EXP§a.");
                }
                $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
            }
        );
        $player->sendForm($form);
    }

    public static function openTrainMenu(Player $player, array $petData): void {
        $economy = AZEconomy::getInstance();
        $coins = $economy->getCoin($player->getName());

        $courses = [
            ["name" => "§l§eHuấn Luyện Sơ Cấp", "cost" => 5, "exp" => 200],
            ["name" => "§l§6Huấn Luyện Trung Cấp", "cost" => 15, "exp" => 700],
            ["name" => "§l§cHuấn Luyện Cao Cấp", "cost" => 30, "exp" => 1500]
        ];

        $options = [];
        foreach ($courses as $c) {
            $options[] = new MenuOption("§l§0⚡ " . $c['name'] . " §l§0⚡\n§r§7Chi phí: §e" . $c['cost'] . " Coin §7| Nhận: §a+" . $c['exp'] . " EXP");
        }

        $form = new MenuForm(
            "§l§dHUẤN LUYỆN PET",
            "§fSố Coin của bạn: §e" . number_format($coins) . " Coin\n\n§fChọn khóa huấn luyện Pet:",
            $options,
            function(Player $player, int $selectedOption) use ($economy, $petData, $courses): void {
                $selected = $courses[$selectedOption];
                $cost = $selected['cost'];
                $expGain = $selected['exp'];

                $currentCoins = $economy->getCoin($player->getName());
                if ($currentCoins < $cost) {
                    $player->sendMessage("§cBạn không có đủ Coin! Cần §e" . $cost . " Coin §cđể tham gia.");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                if ($economy->reduceCoin($player->getName(), $cost)) {
                    $plugin = Main::getInstance();
                    $manager = $plugin->getPetManager();
                    $entity = $manager->getActivePetEntity($player->getName());

                    if ($entity !== null && !$entity->isClosed() && $entity->isAlive()) {
                        $entity->addExp($expGain);
                    } else {
                        // Despawned pet update database values
                        $petData['exp'] += $expGain;
                        $nextLevelExp = $petData['level'] * 1000;
                        while ($petData['exp'] >= $nextLevelExp) {
                            $petData['exp'] -= $nextLevelExp;
                            $petData['level']++;
                            $petData['damage'] = $petData['level'];
                            $petData['max_hp'] = 100 + ($petData['level'] - 1) * 20;
                            $petData['hp'] = $petData['max_hp'];
                            $nextLevelExp = $petData['level'] * 1000;
                            $player->sendMessage("§a✨ Pet của bạn đã thăng lên Cấp " . $petData['level'] . " trong túi!");
                        }
                        $manager->savePetData($petData);
                    }
                    $player->sendMessage("§a✨ Huấn luyện thành công! Pet nhận §e" . $expGain . " EXP§a.");
                    $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                } else {
                    $player->sendMessage("§cCó lỗi xảy ra trong quá trình giao dịch!");
                }
            }
        );
        $player->sendForm($form);
    }

    public static function openDuelInviteForm(Player $target, Player $challenger): void {
        $plugin = Main::getInstance();
        $manager = $plugin->getPetManager();
        $challengerPet = $manager->getActivePetEntity($challenger->getName());
        
        $petName = $challengerPet !== null ? $challengerPet->getName() : "Pet";

        $form = new ModalForm(
            "§l§6THÁCH ĐẤU PET",
            "§fĐạo hữu §e" . $challenger->getName() . " §fmuốn thách đấu Pet với bạn!\n\n§fPet của đối phương: " . $petName,
            function(Player $player, bool $choice) use ($plugin, $challenger): void {
                if ($choice) {
                    $plugin->acceptDuel($player, $challenger);
                } else {
                    $plugin->rejectDuel($player, $challenger);
                }
            },
            "§l§0⚡ §aĐồng Ý §l§0⚡",
            "§l§0⚡ §cTừ Chối §l§0⚡"
        );
        $target->sendForm($form);
    }

    public static function openPetQuickMenu(Player $player, array $petData, PetEntity $pet): void {
        $manager = Main::getInstance()->getPetManager();
        $displayName = $manager->getPetDisplayName($petData['pet_type']);
        $stateStr = $petData['state'] === "follow" ? "§aTheo Sau" : "§cĐứng Yên";
        $nextExp = $petData['level'] * 1000;

        $content = "§fPet: " . $displayName . "\n" .
            "§fCấp độ: §e" . $petData['level'] . "\n" .
            "§fEXP: §a" . $petData['exp'] . "§f/§a" . $nextExp . "\n" .
            "§fHP: §c" . $petData['hp'] . "§f/§c" . $petData['max_hp'] . "\n" .
            "§fSát thương: §e" . $petData['damage'] . "\n" .
            "§fTrạng thái: " . $stateStr;

        $stateButtonText = $petData['state'] === "follow" ? "§l§0⚡ §cĐỨNG YÊN (STAY) §l§0⚡\n§r§7Pet sẽ đứng tại chỗ" : "§l§0⚡ §aDI CHUYỂN (FOLLOW) §l§0⚡\n§r§7Pet sẽ đi theo bạn";

        $form = new MenuForm(
            "§l§dQUẢN LÝ NHANH PET",
            $content,
            [
                new MenuOption($stateButtonText, new FormIcon("textures/items/compass_item", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ §bQUẢN LÝ CHI TIẾT §l§0⚡\n§r§7Mở menu chính", new FormIcon("textures/items/comparator", FormIcon::IMAGE_TYPE_PATH)),
                new MenuOption("§l§0⚡ §cĐÓNG §l§0⚡\n§r§7Tắt giao diện", new FormIcon("textures/blocks/barrier", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $player, int $selectedOption) use ($manager, $petData, $pet): void {
                if ($selectedOption === 0) {
                    $newState = $petData['state'] === "follow" ? "stay" : "follow";
                    $petData['state'] = $newState;
                    $manager->savePetData($petData);
                    if (!$pet->isClosed() && $pet->isAlive()) {
                        $pet->setPetState($newState);
                        $pet->updateNameTag();
                    }
                    $player->sendMessage("§aĐã chuyển trạng thái Pet sang: " . ($newState === "follow" ? "§aTheo Sau" : "§cĐứng Yên"));
                } elseif ($selectedOption === 1) {
                    self::openMainMenu($player);
                }
            }
        );
        $player->sendForm($form);
    }

    public static function openPetInfoMenu(Player $player, PetEntity $pet): void {
        $ownerName = $pet->getOwnerName();
        $displayName = Main::getInstance()->getPetManager()->getPetDisplayName($pet->getPetType());

        $content = "§fPet: " . $displayName . "\n" .
            "§fChủ sở hữu: §b" . $ownerName . "\n" .
            "§fCấp độ: §e" . $pet->getPetLevel() . "\n" .
            "§fHP: §c" . (int)$pet->getHealth() . "§f/§c" . $pet->getMaxHealth() . "\n" .
            "§fSức tấn công: §e" . $pet->getPetDamage();

        $form = new MenuForm(
            "§l§dTHÔNG TIN PET",
            $content,
            [
                new MenuOption("§l§0⚡ §cĐÓNG §l§0⚡\n§r§7Tắt giao diện", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
            ],
            function(Player $player, int $selectedOption): void {}
        );
        $player->sendForm($form);
    }
}
