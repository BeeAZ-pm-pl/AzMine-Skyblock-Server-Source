<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class SnorlaxPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p143";
    }

    public function getPetScale(): float {
        return 0.85;
    }
}
