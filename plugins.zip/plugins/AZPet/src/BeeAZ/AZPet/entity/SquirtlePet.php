<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class SquirtlePet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p7";
    }

    public function getPetScale(): float {
        return 0.5;
    }
}
