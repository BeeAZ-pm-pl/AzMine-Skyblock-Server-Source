<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class LaprasPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p131";
    }

    public function getPetScale(): float {
        return 0.85;
    }
}
