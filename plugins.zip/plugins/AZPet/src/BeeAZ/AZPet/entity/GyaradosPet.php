<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class GyaradosPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p130";
    }

    public function getPetScale(): float {
        return 0.85;
    }
}
