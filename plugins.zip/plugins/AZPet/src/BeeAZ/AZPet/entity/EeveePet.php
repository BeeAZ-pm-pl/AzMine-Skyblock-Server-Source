<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class EeveePet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p133";
    }

    public function getPetScale(): float {
        return 0.5;
    }
}
