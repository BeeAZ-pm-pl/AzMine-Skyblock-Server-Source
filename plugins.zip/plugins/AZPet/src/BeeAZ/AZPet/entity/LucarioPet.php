<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class LucarioPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p448";
    }

    public function getPetScale(): float {
        return 0.75;
    }
}
