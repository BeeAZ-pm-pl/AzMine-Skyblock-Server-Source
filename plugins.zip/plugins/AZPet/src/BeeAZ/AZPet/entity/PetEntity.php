<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimatePacket;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\math\Vector3;
use pocketmine\world\particle\HeartParticle;
use pocketmine\world\particle\CriticalParticle;
use BeeAZ\AZPet\skill\PetSkill;
use BeeAZ\AZPet\manager\StatusManager;
use BeeAZ\AZPet\manager\TypeMatchup;

abstract class PetEntity extends Living {

    private int $petDbId;
    private string $ownerName;
    private string $petType;
    private int $level;
    private int $exp;
    private float $petDamage;
    private string $state;

    private ?Living $target = null;
    private int $attackCooldown = 0;
    private int $lastAiTick = 0;
    private int $nextSoundTick = 0;

    public function __construct(Location $location, $skin = null, ?CompoundTag $nbt = null) {
        if ($nbt !== null) {
            $this->petDbId = $nbt->getInt("PetID", 0);
            $this->ownerName = $nbt->getString("Owner", "");
            $this->petType = $nbt->getString("PetType", "default");
            $this->level = $nbt->getInt("Level", 1);
            $this->exp = $nbt->getInt("Exp", 0);
            $this->petDamage = (float)$nbt->getInt("Damage", 1);
            $this->state = $nbt->getString("State", "follow");
        }
        parent::__construct($location, $nbt);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        
        $baseSize = $this->getInitialSizeInfo();
        $this->size = new EntitySizeInfo(
            $baseSize->getHeight() * 0.45,
            $baseSize->getWidth(),
            $baseSize->getEyeHeight() !== null ? $baseSize->getEyeHeight() * 0.45 : null
        );
        
        $this->petDbId = $nbt->getInt("PetID", 0);
        $this->ownerName = $nbt->getString("Owner", "");
        $this->petType = $nbt->getString("PetType", "default");
        $this->level = $nbt->getInt("Level", 1);
        $this->exp = $nbt->getInt("Exp", 0);
        $this->petDamage = (float)$nbt->getInt("Damage", 1);
        $this->state = $nbt->getString("State", "follow");

        $maxHp = (int)$nbt->getInt("MaxHp", 100);
        $this->setMaxHealth($maxHp);
        
        if ($nbt->getTag("Health") === null) {
            $this->setHealth((float)$maxHp);
        } else {
            $this->setHealth((float)$nbt->getInt("Hp", $maxHp));
        }

        $this->setCanSaveWithChunk(false);
        $this->setNameTagAlwaysVisible(true);
        $this->setScale($this->getPetScale() * 2.4);
        $this->updateNameTag();
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setInt("PetID", $this->petDbId);
        $nbt->setString("Owner", $this->ownerName);
        $nbt->setString("PetType", $this->petType);
        $nbt->setInt("Level", $this->level);
        $nbt->setInt("Exp", $this->exp);
        $nbt->setInt("Hp", (int)$this->getHealth());
        $nbt->setInt("MaxHp", $this->getMaxHealth());
        $nbt->setInt("Damage", (int)$this->petDamage);
        $nbt->setString("State", $this->state);
        return $nbt;
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.8, 0.8, 1.62);
    }

    public function lookAt(Vector3 $target): void {
        parent::lookAt($target);
        $this->setRotation($this->location->yaw, 0.0);
    }

    /**
     * Trả về tỷ lệ scale phù hợp cho từng loại pet.
     * Mỗi class con sẽ override để định nghĩa scale riêng.
     */
    public function getPetScale(): float {
        return 0.5;
    }

    public function getName(): string {
        return $this->getNameTag();
    }

    public function getPetDbId(): int {
        return $this->petDbId;
    }

    public function getOwnerName(): string {
        return $this->ownerName;
    }

    public function getPetType(): string {
        return $this->petType;
    }

    public function getPetLevel(): int {
        return $this->level;
    }

    public function getPetExp(): int {
        return $this->exp;
    }

    public function getPetDamage(): float {
        return $this->petDamage;
    }

    public function getPetState(): string {
        return $this->state;
    }

    public function setPetState(string $state): void {
        $this->state = $state;
        $this->updateNameTag();
    }

    public function addExp(int $amount): void {
        $this->exp += $amount;
        $nextLevelExp = $this->level * 1000;
        
        $owner = $this->getOwner();
        
        while ($this->exp >= $nextLevelExp) {
            $this->exp -= $nextLevelExp;
            $this->level++;
            $this->petDamage = (float)$this->level; // damage = level
            $newMaxHp = 100 + ($this->level - 1) * 20;
            $this->setMaxHealth($newMaxHp);
            $this->setHealth((float)$newMaxHp);
            $nextLevelExp = $this->level * 1000;

            $this->getWorld()->addParticle($this->getLocation()->add(0, 1, 0), new HeartParticle());
            if ($owner !== null) {
                $owner->sendMessage("§a✨ Pet của bạn đã thăng cấp lên §lCấp " . $this->level . "§r§a! Tăng HP lên §c" . $newMaxHp . " §avà Dame lên §e" . $this->petDamage . "§a.");
            }
        }
        $this->updateNameTag();
    }

    public function reduceExp(int $amount): void {
        $totalExp = 500 * ($this->level - 1) * $this->level + $this->exp;
        $totalExp = max(0, $totalExp - $amount);
        
        $lvl = 1;
        $remainingExp = $totalExp;
        while (true) {
            $needed = $lvl * 1000;
            if ($remainingExp >= $needed) {
                $remainingExp -= $needed;
                $lvl++;
            } else {
                break;
            }
        }
        
        $this->level = $lvl;
        $this->exp = $remainingExp;
        $this->petDamage = (float)$this->level; // damage = level
        $newMaxHp = 100 + ($this->level - 1) * 20;
        $this->setMaxHealth($newMaxHp);
        $this->setHealth(min((float)$newMaxHp, $this->getHealth()));
        $this->updateNameTag();
    }

    public function healFull(): void {
        $this->setHealth((float)$this->getMaxHealth());
        $this->updateNameTag();
    }

    public function getOwner(): ?Player {
        return Server::getInstance()->getPlayerExact($this->ownerName);
    }

    public function setAttackTarget(?Living $target): void {
        if ($target === $this) return;
        $this->target = $target;
    }

    public function getAttackTarget(): ?Living {
        return $this->target;
    }

    public function updateNameTag(): void {
        $maxHp = $this->getMaxHealth();
        $hp = $this->getHealth();
        $percent = max(0, min(1, $hp / $maxHp));
        $percentValue = (int)round($percent * 100);
        
        $greenBars = (int)round($percent * 10);
        $redBars = 10 - $greenBars;
        $barStr = "§a" . str_repeat("|", $greenBars) . "§c" . str_repeat("|", $redBars) . " §e" . $percentValue . "%";

        $displayName = match ($this->petType) {
            "pikachu" => "§ePikachu",
            "eevee" => "§6Eevee",
            "mew" => "§dMew",
            "charmander" => "§cCharmander",
            "squirtle" => "§bSquirtle",
            "bulbasaur" => "§aBulbasaur",
            "lucario" => "§bLucario",
            "snorlax" => "§9Snorlax",
            "gengar" => "§5Gengar",
            "jigglypuff" => "§dJigglypuff",
            "gyarados" => "§bGyarados",
            "lapras" => "§3Lapras",
            "gardevoir" => "§aGardevoir",
            "umbreon" => "§8Umbreon",
            "dragonite" => "§6Dragonite",
            "mudkip" => "§bMudkip",
            default => "Pet"
        };

        $stateStr = $this->state === "follow" ? "§aTheo Sau" : "§cĐứng Yên";

        $this->setNameTag("§l" . $displayName . " §r§7[Lv." . $this->level . "]\n" . $barStr . "\n§7Chủ nhân: §f" . $this->ownerName . " §7(" . $stateStr . "§7)");
    }

    public function onUpdate(int $currentTick): bool {
        $hasUpdate = parent::onUpdate($currentTick);
        if (!$this->isAlive() || $this->isClosed()) return $hasUpdate;

        // 1. Teleport if falling into void
        if ($this->getPosition()->getY() < 0) {
            $owner = $this->getOwner();
            if ($owner !== null) {
                $this->teleport($owner->getLocation());
                $this->updateNameTag();
            }
        }

        // 2. Owner presence check
        $owner = $this->getOwner();
        if ($owner === null || !$owner->isOnline()) {
            $this->close();
            return false;
        }

        $this->tickPetAI();

        // 3. Play random PokeCry sound every 10-20 seconds (200-400 ticks)
        if ($this->nextSoundTick === 0) {
            $this->nextSoundTick = $currentTick + mt_rand(200, 400);
        } elseif ($currentTick >= $this->nextSoundTick) {
            $this->playPokeCry();
            $this->nextSoundTick = $currentTick + mt_rand(200, 400);
        }

        if ($currentTick % 10 === 0) {
            $this->updateNameTag();
        }

        return $hasUpdate;
    }

    private function tickPetAI(): void {
        if (StatusManager::isRestricted($this)) {
            $motion = $this->getMotion();
            $motion->x = 0;
            $motion->z = 0;
            $this->setMotion($motion);
            return;
        }

        $owner = $this->getOwner();
        if ($owner === null) return;

        $ownerLoc = $owner->getLocation();
        $myLoc = $this->getLocation();

        // Teleport to owner immediately if they are in another world
        if ($myLoc->getWorld() !== $ownerLoc->getWorld()) {
            $this->teleport($ownerLoc);
            return;
        }

        // Check target validity
        if ($this->target !== null) {
            if (!$this->target->isAlive() || $this->target->isClosed() || $this->target->getWorld() !== $this->getWorld() || $this->getLocation()->distance($this->target->getLocation()) > 15) {
                $this->target = null;
            } elseif ($this->target instanceof Player && ($this->target->isCreative() || $this->target->isSpectator())) {
                $this->target = null;
            }
        }

        if ($this->target !== null) {
            // Fight target
            $targetLoc = $this->target->getLocation();
            $distance = $myLoc->distance($targetLoc);

            if ($distance > 3.0) {
                // Move to target
                $dx = $targetLoc->x - $myLoc->x;
                $dz = $targetLoc->z - $myLoc->z;
                $distanceXZ = sqrt($dx * $dx + $dz * $dz);
                if ($distanceXZ > 0) {
                    $motion = $this->getMotion();
                    $motion->x = ($dx / $distanceXZ) * 0.4;
                    $motion->z = ($dz / $distanceXZ) * 0.4;
                    $this->setMotion($motion);
                }
                $this->lookAt($targetLoc);
            } else {
                // Stop horizontal movement
                $motion = $this->getMotion();
                $motion->x = 0;
                $motion->z = 0;
                $this->setMotion($motion);
                $this->lookAt($targetLoc);

                // Attack
                if (time() >= $this->attackCooldown) {
                    $this->attackCooldown = time() + 1; // 1s attack speed

                    $pk = new AnimatePacket();
                    $pk->action = AnimatePacket::ACTION_SWING_ARM;
                    $pk->actorRuntimeId = $this->getId();
                    $this->getWorld()->broadcastPacketToViewers($this->getLocation(), $pk);

                    // Add critical particle effect
                    $this->getWorld()->addParticle($targetLoc->add(0, 1, 0), new CriticalParticle());

                    $damage = $this->petDamage;

                    // If target is another PetEntity, calculate type matchup multiplier!
                    if ($this->target instanceof PetEntity) {
                        $multiplier = TypeMatchup::getMultiplier($this->getPetType(), $this->target->getPetType());
                        $damage *= $multiplier;
                        
                        // Send feedback message to owners
                        $ownerPlayer = $this->getOwner();
                        $targetOwner = $this->target->getOwner();
                        if ($multiplier > 1.2) {
                            if ($ownerPlayer !== null) $ownerPlayer->sendMessage("§a💥 Hiệu quả cực mạnh! Sát thương khắc hệ x" . $multiplier);
                            if ($targetOwner !== null) $targetOwner->sendMessage("§c💥 Pet đối phương đánh khắc hệ! Nhận sát thương x" . $multiplier);
                        } elseif ($multiplier < 0.8 && $multiplier > 0.0) {
                            if ($ownerPlayer !== null) $ownerPlayer->sendMessage("§c💥 Không hiệu quả lắm... Sát thương bị giảm x" . $multiplier);
                            if ($targetOwner !== null) $targetOwner->sendMessage("§a🛡️ Kháng đòn đánh đối thủ! Nhận sát thương x" . $multiplier);
                        } elseif ($multiplier === 0.0) {
                            if ($ownerPlayer !== null) $ownerPlayer->sendMessage("§e🛡️ Vô hiệu! Hệ của đối thủ miễn nhiễm đòn đánh.");
                            if ($targetOwner !== null) $targetOwner->sendMessage("§a🛡️ Miễn nhiễm đòn đánh đối thủ!");
                        }
                    }

                    $this->triggerSkill($this->target, $damage);

                    $ev = new EntityDamageByEntityEvent($this, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
                    $this->target->attack($ev);

                    // Train/feed gains exp when pet hits targets (non-pet, like monsters/bosses)
                    if (!$this->target instanceof PetEntity) {
                        $this->addExp(5);
                    }
                }
            }
        } else {
            // No target, follow state
            if ($this->state === "follow") {
                $distance = $myLoc->distance($ownerLoc);

                if ($distance > 12) {
                    $this->teleport($ownerLoc);
                } elseif ($distance > 2.5) {
                    // Move to owner
                    $dx = $ownerLoc->x - $myLoc->x;
                    $dz = $ownerLoc->z - $myLoc->z;
                    $distanceXZ = sqrt($dx * $dx + $dz * $dz);
                    if ($distanceXZ > 0) {
                        $motion = $this->getMotion();
                        $motion->x = ($dx / $distanceXZ) * 0.4;
                        $motion->z = ($dz / $distanceXZ) * 0.4;
                        $this->setMotion($motion);
                    }
                    $this->lookAt($ownerLoc);
                } else {
                    // Stop horizontal movement
                    $motion = $this->getMotion();
                    $motion->x = 0;
                    $motion->z = 0;
                    $this->setMotion($motion);
                }
            } else {
                // If standing still (not follow state), make sure it doesn't drift
                $motion = $this->getMotion();
                $motion->x = 0;
                $motion->z = 0;
                $this->setMotion($motion);
            }
        }

        // Jump over obstacles if colliding horizontally and on ground
        if ($this->isCollidedHorizontally && $this->onGround) {
            $direction = $this->getDirectionVector();
            $horizontalDir = new \pocketmine\math\Vector3($direction->x, 0, $direction->z);
            if ($horizontalDir->lengthSquared() > 0) {
                $horizontalDir = $horizontalDir->normalize();
            }
            $width = $this->size !== null ? $this->size->getWidth() : 0.6;
            $offsetDist = ($width / 2.0) + 0.35;
            $frontPos = new \pocketmine\math\Vector3($this->location->x + $horizontalDir->x * $offsetDist, $this->location->y + 0.5, $this->location->z + $horizontalDir->z * $offsetDist);
            $frontBlock = $this->getWorld()->getBlock($frontPos);
            $frontBlockUpper = $this->getWorld()->getBlock($frontPos->add(0, 1, 0));
            if ($frontBlock->isSolid() || $frontBlockUpper->isSolid()) {
                $motion = $this->getMotion();
                $motion->y = 0.52; // jump velocity
                $motion->x *= 1.8; // horizontal boost
                $motion->z *= 1.8;
                $this->setMotion($motion);
            }
        }
    }

    public function triggerSkill(Living $target, float &$damage): void {
        PetSkill::trigger($this, $target, $damage);
    }

    public function playPokeCry(): void {
        $cries = [
            "pikachu" => "mob.pokemon.25",
            "eevee" => "mob.pokemon.133",
            "mew" => "mob.pokemon.151",
            "charmander" => "mob.pokemon.4",
            "squirtle" => "mob.pokemon.7",
            "bulbasaur" => "mob.pokemon.1",
            "lucario" => "mob.pokemon.448",
            "snorlax" => "mob.pokemon.143",
            "gengar" => "mob.pokemon.94",
            "jigglypuff" => "mob.pokemon.39",
            "gyarados" => "mob.pokemon.130",
            "lapras" => "mob.pokemon.131",
            "gardevoir" => "mob.pokemon.282",
            "umbreon" => "mob.pokemon.197",
            "dragonite" => "mob.pokemon.149",
            "mudkip" => "mob.pokemon.258"
        ];
        $cry = $cries[$this->petType] ?? "mob.pokemon.25";
        $myLoc = $this->getLocation();
        $cryPacket = PlaySoundPacket::create($cry, $myLoc->x, $myLoc->y, $myLoc->z, 1.2, 1.0, null);
        foreach ($this->getWorld()->getPlayers() as $p) {
            if ($p->isOnline()) {
                $p->getNetworkSession()->sendDataPacket($cryPacket);
            }
        }
    }

    public function attack(EntityDamageEvent $source): void {
        parent::attack($source);
        $this->updateNameTag();
    }
}
