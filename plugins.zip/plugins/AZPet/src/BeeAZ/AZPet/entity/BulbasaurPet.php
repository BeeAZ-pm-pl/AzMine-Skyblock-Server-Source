<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class BulbasaurPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p1";
    }

    public function getPetScale(): float {
        return 0.5;
    }
}
