<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class PikachuPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p25";
    }

    public function getPetScale(): float {
        return 0.5;
    }
}
