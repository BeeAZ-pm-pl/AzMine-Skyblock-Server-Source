<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class GengarPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p94";
    }

    public function getPetScale(): float {
        return 0.75;
    }
}
