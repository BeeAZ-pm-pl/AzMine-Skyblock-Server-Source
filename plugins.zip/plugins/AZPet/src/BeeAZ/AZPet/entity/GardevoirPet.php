<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class GardevoirPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p282";
    }

    public function getPetScale(): float {
        return 0.75;
    }
}
