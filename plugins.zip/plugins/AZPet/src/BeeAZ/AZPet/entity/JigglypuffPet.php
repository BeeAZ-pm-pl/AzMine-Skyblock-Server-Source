<?php

declare(strict_types=1);

namespace BeeAZ\AZPet\entity;

class JigglypuffPet extends PetEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p39";
    }

    public function getPetScale(): float {
        return 0.55;
    }
}
