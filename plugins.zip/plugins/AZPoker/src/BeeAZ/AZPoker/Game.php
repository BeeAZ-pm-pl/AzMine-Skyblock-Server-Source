<?php

declare(strict_types=1);

namespace BeeAZ\AZPoker;

use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\utils\DyeColor;
use pocketmine\item\Item;
use pocketmine\Server;
use pocketmine\item\StringToItemParser;
use pocketmine\scheduler\ClosureTask;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use AZEconomy\AZEconomy;

class Game {

    public const ROUND_PREFLOP = 0;
    public const ROUND_FLOP = 1;
    public const ROUND_TURN = 2;
    public const ROUND_RIVER = 3;
    public const ROUND_SHOWDOWN = 4;

    private string $id;
    private int $buyIn;
    
    /** @var array */
    private array $players = []; // Array of ['name' => string, 'player' => ?Player, 'is_bot' => bool, 'hand' => array, 'bet' => int, 'acted' => bool, 'is_folded' => bool]
    
    /** @var InvMenu[] */
    private array $menus = []; // Mapping of playerName => InvMenu

    private bool $isBotGame;

    private array $deck = [];
    private array $communityCards = [];

    private int $pot = 0;
    private int $round = self::ROUND_PREFLOP;
    private int $turnIndex = 0;
    private int $turnId = 0;

    private bool $isFinished = false;
    private int $timeLeft = 30;
    private ?\pocketmine\scheduler\TaskHandler $timerTask = null;

    public function __construct(string $id, int $buyIn, array $humanPlayers, int $botCount) {
        $this->id = $id;
        $this->buyIn = $buyIn;
        $this->isBotGame = ($botCount > 0);

        // Initialize Players
        foreach ($humanPlayers as $p) {
            $this->players[] = [
                'name' => $p->getName(),
                'player' => $p,
                'is_bot' => false,
                'hand' => [],
                'bet' => 0,
                'acted' => false,
                'is_folded' => false,
                'last_action' => 'Chưa hành động',
                'raise_amount' => (int)($buyIn * 0.2)
            ];
        }

        if ($this->isBotGame) {
            for ($i = 1; $i <= $botCount; $i++) {
                $this->players[] = [
                    'name' => "Bot Cá Cược " . $i,
                    'player' => null,
                    'is_bot' => true,
                    'hand' => [],
                    'bet' => 0,
                    'acted' => false,
                    'is_folded' => false,
                    'last_action' => 'Chưa hành động'
                ];
            }
        }

        // Initialize Deck
        for ($value = 2; $value <= 14; $value++) {
            for ($suit = 0; $suit <= 3; $suit++) {
                $this->deck[] = ['value' => $value, 'suit' => $suit];
            }
        }
        shuffle($this->deck);

        // Deal Cards
        foreach ($this->players as &$pData) {
            $pData['hand'][] = array_pop($this->deck);
            $pData['hand'][] = array_pop($this->deck);
        }
        unset($pData);

        for ($i = 0; $i < 5; $i++) {
            $this->communityCards[] = array_pop($this->deck);
        }

        // Deduct blind / ante (10% of buy-in initially from all players)
        $blind = (int)($buyIn * 0.1);
        $eco = AZEconomy::getInstance();

        foreach ($this->players as &$pData) {
            if (!$pData['is_bot']) {
                $eco->reduceMoney($pData['name'], $blind);
            }
            $pData['bet'] = $blind;
            $this->pot += $blind;
        }
        unset($pData);

        // Select random starting turn
        $this->turnIndex = mt_rand(0, count($this->players) - 1);

        // Initialize InvMenus for humans
        foreach ($this->players as $pData) {
            if (!$pData['is_bot'] && $pData['player'] !== null) {
                $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
                $menu->setName("§6⚡ §e§lPOKER TABLE §r§6⚡");
                $menu->setListener(fn(InvMenuTransaction $tx) => $this->handleTransaction($tx, $pData['player']));
                $menu->setInventoryCloseListener(function(Player $player): void {
                    $this->handleInventoryClose($player);
                });
                
                $this->menus[$pData['name']] = $menu;
                $menu->send($pData['player']);
            }
        }

        $names = implode(", ", array_column($this->players, 'name'));
        $this->broadcastMessage("§aVán bài Poker đã bắt đầu! Tổng mức cược ban đầu (Ante): §e" . number_format($blind) . " Xu§a.\n§dDanh sách người chơi: §e" . $names);
        
        $this->startTurn();
    }

    public function handlePlayerQuit(Player $player): void {
        $this->foldByName($player->getName());
    }

    public function getPlayerA(): ?Player {
        foreach ($this->players as $pData) {
            if (!$pData['is_bot']) {
                return $pData['player'];
            }
        }
        return null;
    }

    public function getPlayerB(): ?Player {
        $foundFirst = false;
        foreach ($this->players as $pData) {
            if (!$pData['is_bot']) {
                if ($foundFirst) {
                    return $pData['player'];
                }
                $foundFirst = true;
            }
        }
        return null;
    }

    private function broadcastMessage(string $msg): void {
        foreach ($this->players as $pData) {
            if (!$pData['is_bot'] && $pData['player'] !== null && $pData['player']->isOnline()) {
                $pData['player']->sendMessage($msg);
            }
        }
    }

    private function stopTimer(): void {
        if ($this->timerTask !== null) {
            $this->timerTask->cancel();
            $this->timerTask = null;
        }
    }

    private function getCurrentPlayerName(): string {
        return $this->players[$this->turnIndex]['name'];
    }

    private function startTurn(): void {
        if ($this->isFinished) {
            return;
        }

        // Check if only 1 active player remains
        $activePlayers = [];
        foreach ($this->players as $idx => $pData) {
            if (!$pData['is_folded']) {
                $activePlayers[] = $idx;
            }
        }

        if (count($activePlayers) === 1) {
            $winnerIdx = $activePlayers[0];
            $winnerData = $this->players[$winnerIdx];
            $this->endGameWithWinner($winnerData['name'], "Mọi đối thủ khác đã bỏ bài (Fold)");
            return;
        }

        // Check if betting round is completed
        if ($this->isBettingRoundComplete()) {
            $this->advanceBettingRound();
            return;
        }

        // Check if current player is folded, if so advance
        $currentPlayer = &$this->players[$this->turnIndex];
        if ($currentPlayer['is_folded']) {
            $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
            $this->startTurn();
            return;
        }

        // Increment turn ID for scheduling validation
        $this->turnId++;

        // Stop any running timer task
        $this->stopTimer();

        // Render UI
        $this->render();

        // If bot, schedule AI action
        if ($currentPlayer['is_bot']) {
            $this->scheduleBotAction();
        } else {
            // Human player: Start 30 seconds repeating timer
            $this->timeLeft = 30;
            $currentTurnId = $this->turnId;
            $activePlayerName = $currentPlayer['name'];

            $this->timerTask = Main::getInstance()->getScheduler()->scheduleRepeatingTask(new ClosureTask(function() use ($currentTurnId, $activePlayerName): void {
                if ($this->isFinished || $this->turnId !== $currentTurnId || $this->getCurrentPlayerName() !== $activePlayerName) {
                    $this->stopTimer();
                    return;
                }

                $this->timeLeft--;

                if ($this->timeLeft <= 0) {
                    $this->stopTimer();

                    $player = Server::getInstance()->getPlayerExact($activePlayerName);
                    $pIdx = array_search($activePlayerName, array_column($this->players, 'name'));
                    
                    if ($pIdx !== false) {
                        $maxBet = 0;
                        foreach ($this->players as $pData) {
                            if (!$pData['is_folded'] && $pData['bet'] > $maxBet) {
                                $maxBet = $pData['bet'];
                            }
                        }
                        $myBet = $this->players[$pIdx]['bet'];
                        $callAmount = $maxBet - $myBet;

                        if ($callAmount > 0) {
                            // Auto fold
                            if ($player !== null) {
                                $player->sendMessage("§cĐã hết thời gian suy nghĩ! Vì đối thủ đã Tố/Cược nên bạn tự động Bỏ bài (Fold).");
                            }
                            $this->broadcastMessage("§c[POKER] §e" . $activePlayerName . " §cđã tự động Bỏ bài (Fold) do hết thời gian suy nghĩ.");
                            $this->foldByName($activePlayerName);
                        } else {
                            // Auto check
                            if ($player !== null) {
                                $player->sendMessage("§eĐã hết thời gian suy nghĩ! Vì đối thủ không Tố thêm nên bạn tự động Xem bài (Check).");
                            }
                            $this->broadcastMessage("§a[POKER] §e" . $activePlayerName . " §ađã tự động Xem bài (Check) do hết thời gian suy nghĩ.");
                            
                            $this->players[$pIdx]['acted'] = true;
                            $this->players[$pIdx]['last_action'] = '§eXem bài (Check)§r';
                            
                            $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
                            $this->startTurn();
                        }
                    }
                } else {
                    $this->render();
                }
            }), 20);
        }
    }

    private function isBettingRoundComplete(): bool {
        $maxBet = 0;
        foreach ($this->players as $pData) {
            if (!$pData['is_folded'] && $pData['bet'] > $maxBet) {
                $maxBet = $pData['bet'];
            }
        }

        foreach ($this->players as $pData) {
            if (!$pData['is_folded']) {
                if (!$pData['acted'] || $pData['bet'] !== $maxBet) {
                    return false;
                }
            }
        }
        return true;
    }

    private function advanceBettingRound(): void {
        if ($this->checkPoliceRaid()) {
            return;
        }

        // Reset bets and acted status
        foreach ($this->players as &$pData) {
            $pData['bet'] = 0;
            $pData['acted'] = false;
        }
        unset($pData);

        if ($this->round === self::ROUND_RIVER) {
            $this->round = self::ROUND_SHOWDOWN;
            $this->showdown();
            return;
        }

        $this->round++;
        $this->turnIndex = 0; // Turn index resets to first active player

        $roundsName = [
            self::ROUND_FLOP => "Flop (Chia 3 lá chung)",
            self::ROUND_TURN => "Turn (Chia lá chung thứ 4)",
            self::ROUND_RIVER => "River (Chia lá chung thứ 5)"
        ];

        $this->broadcastMessage("§b§lChuyển sang vòng: §e" . $roundsName[$this->round]);
        $this->startTurn();
    }

    private function handleTransaction(InvMenuTransaction $tx, Player $player): InvMenuTransactionResult {
        if ($this->isFinished) {
            return $tx->discard();
        }

        if ($player->getName() !== $this->getCurrentPlayerName()) {
            $player->sendMessage("§cChưa đến lượt đi của bạn!");
            return $tx->discard();
        }

        $slot = $tx->getAction()->getSlot();

        switch ($slot) {
            case 30: // Fold
                $this->fold($player);
                break;
            case 31: // Check/Call
                $this->checkCall($player);
                break;
            case 32: // Raise
                $this->raise($player);
                break;
            case 33: // Increase Raise
                $pIdx = array_search($player->getName(), array_column($this->players, 'name'));
                if ($pIdx !== false) {
                    $this->players[$pIdx]['raise_amount'] = ($this->players[$pIdx]['raise_amount'] ?? (int)($this->buyIn * 0.2)) + (int)($this->buyIn * 0.1);
                    $this->render();
                }
                break;
            case 34: // Decrease Raise
                $pIdx = array_search($player->getName(), array_column($this->players, 'name'));
                if ($pIdx !== false) {
                    $currentRaise = $this->players[$pIdx]['raise_amount'] ?? (int)($this->buyIn * 0.2);
                    $step = (int)($this->buyIn * 0.1);
                    $newRaise = max($step, $currentRaise - $step);
                    $this->players[$pIdx]['raise_amount'] = $newRaise;
                    $this->render();
                }
                break;
        }

        return $tx->discard();
    }

    private function handleInventoryClose(Player $player): void {
        if ($this->isFinished) {
            return;
        }
        
        Main::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player): void {
            if (!$this->isFinished) {
                // If they are still in the game array as active/not-folded, auto-fold them
                foreach ($this->players as $pData) {
                    if ($pData['name'] === $player->getName() && !$pData['is_folded']) {
                        $player->sendMessage("§cBạn đã bỏ cuộc vì đóng bảng điều khiển Poker!");
                        $this->fold($player);
                        break;
                    }
                }
            }
        }), 5);
    }

    private function fold(Player $player): void {
        $this->foldByName($player->getName());
    }

    private function foldByName(string $name): void {
        foreach ($this->players as &$pData) {
            if ($pData['name'] === $name) {
                $pData['is_folded'] = true;
                $pData['acted'] = true;
                $pData['last_action'] = '§cBỏ bài (Fold)§r';
                break;
            }
        }
        unset($pData);

        $this->broadcastMessage("§c[POKER] §e" . $name . " §cđã Bỏ bài (Fold).");
        
        $pIdx = array_search($name, array_column($this->players, 'name'));
        if ($pIdx !== false) {
            $p = $this->players[$pIdx]['player'];
            if ($p !== null) {
                $p->removeCurrentWindow();
            }
        }

        $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
        $this->startTurn();
    }

    private function checkCall(Player $player): void {
        $eco = AZEconomy::getInstance();
        $pIdx = array_search($player->getName(), array_column($this->players, 'name'));
        $myBet = $this->players[$pIdx]['bet'];

        $maxBet = 0;
        foreach ($this->players as $pData) {
            if (!$pData['is_folded'] && $pData['bet'] > $maxBet) {
                $maxBet = $pData['bet'];
            }
        }

        if ($myBet < $maxBet) {
            // Call
            $callAmount = $maxBet - $myBet;
            if ($eco->getMoney($player->getName()) < $callAmount) {
                $player->sendMessage("§cBạn không đủ tiền để Theo (Call)!");
                return;
            }
            $eco->reduceMoney($player->getName(), $callAmount);
            $this->pot += $callAmount;

            $this->players[$pIdx]['bet'] = $maxBet;
            $this->players[$pIdx]['acted'] = true;
            $this->players[$pIdx]['last_action'] = '§eTheo bài (Call) §a' . number_format($callAmount) . ' Xu§r';

            $this->broadcastMessage("§a[POKER] §e" . $player->getName() . " §ađã Theo bài (Call) §e" . number_format($callAmount) . " Xu§a.");
        } else {
            // Check
            $this->players[$pIdx]['acted'] = true;
            $this->players[$pIdx]['last_action'] = '§eXem bài (Check)§r';
            $this->broadcastMessage("§a[POKER] §e" . $player->getName() . " §ađã Xem bài (Check).");
        }

        $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
        $this->startTurn();
    }

    private function raise(Player $player): void {
        $eco = AZEconomy::getInstance();
        $pIdx = array_search($player->getName(), array_column($this->players, 'name'));
        $myBet = $this->players[$pIdx]['bet'];

        $maxBet = 0;
        foreach ($this->players as $pData) {
            if (!$pData['is_folded'] && $pData['bet'] > $maxBet) {
                $maxBet = $pData['bet'];
            }
        }

        $raiseAmount = $this->players[$pIdx]['raise_amount'] ?? (int)($this->buyIn * 0.2);
        $targetBet = $maxBet + $raiseAmount;
        $totalCost = $targetBet - $myBet;

        if ($eco->getMoney($player->getName()) < $totalCost) {
            $player->sendMessage("§cBạn không đủ tiền để Tố thêm (Raise)!");
            return;
        }

        $eco->reduceMoney($player->getName(), $totalCost);
        $this->pot += $totalCost;

        // Apply Raise to player
        $this->players[$pIdx]['bet'] = $targetBet;
        $this->players[$pIdx]['acted'] = true;
        $this->players[$pIdx]['last_action'] = '§eTố thêm (Raise) §a' . number_format($raiseAmount) . ' Xu§r';

        // Reset acted status for other active players since they must respond to the raise
        foreach ($this->players as $idx => &$pData) {
            if ($idx !== $pIdx && !$pData['is_folded']) {
                $pData['acted'] = false;
            }
        }
        unset($pData);

        $this->broadcastMessage("§a[POKER] §e" . $player->getName() . " §ađã Tố thêm (Raise) §e" . number_format($raiseAmount) . " Xu§a.");

        $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
        $this->startTurn();
    }

    private function checkPoliceRaid(): bool {
        $plugin = Main::getInstance();
        $jailChance = (int)$plugin->getConfig()->get("jail_chance", 10);
        
        if (mt_rand(1, 100) <= $jailChance) {
            $this->isFinished = true;
            $this->stopTimer();
            
            // Programmatically close all open menus
            foreach ($this->players as $pData) {
                if (!$pData['is_bot'] && $pData['player'] !== null) {
                    $pData['player']->removeCurrentWindow();
                }
            }

            // Fetch AZJail API
            $jailPlugin = Server::getInstance()->getPluginManager()->getPlugin("AZJail");
            $duration = (int)$plugin->getConfig()->get("jail_duration", 5);
            $reason = (string)$plugin->getConfig()->get("jail_reason", "Đánh bạc trái phép (Poker)");

            $jailedNames = [];
            if ($jailPlugin instanceof \BeeAZ\AZJail\Main) {
                foreach ($this->players as $pData) {
                    if (!$pData['is_bot']) {
                        $jailPlugin->jailPlayer($pData['name'], $duration, $reason, "Hệ Thống");
                        $jailedNames[] = $pData['name'];
                    }
                }
            }

            // Server-wide warning broadcast
            $jailedListStr = implode(", ", $jailedNames);
            if ($this->isBotGame) {
                Server::getInstance()->broadcastMessage(
                    "§c§l[CẢNH SÁT HÌNH SỰ] §ePhát hiện sòng bạc Poker đánh bạc lậu! §f" . 
                    $jailedListStr . " §eđã bị cảnh sát hốt về đồn biệt giam §c" . $duration . 
                    " phút§e! Số tiền gà §6" . number_format($this->pot) . " Xu §eđã bị tịch thu! §7(Các Bot đối thủ đã nhanh chân chạy thoát!)"
                );
            } else {
                Server::getInstance()->broadcastMessage(
                    "§c§l[CẢNH SÁT HÌNH SỰ] §ePhát hiện sòng bạc Poker đánh bạc lậu! §f" . 
                    $jailedListStr . 
                    " §eđã bị cảnh sát hốt về đồn biệt giam §c" . $duration . " phút§e! Số tiền gà §6" . 
                    number_format($this->pot) . " Xu §eđã bị tịch thu!"
                );
            }

            // Cleanup game
            $plugin->removeGame($this->id);
            return true;
        }
        return false;
    }

    private function scheduleBotAction(): void {
        $scheduledTurnId = $this->turnId;
        Main::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($scheduledTurnId): void {
            if (!$this->isFinished && $this->turnId === $scheduledTurnId) {
                $this->executeBotAction();
            }
        }), 30); // 1.5 seconds delay
    }

    private function executeBotAction(): void {
        if ($this->isFinished) {
            return;
        }

        $botIdx = $this->turnIndex;
        $botData = &$this->players[$botIdx];

        if ($botData['is_folded']) {
            $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
            $this->startTurn();
            return;
        }

        $maxBet = 0;
        foreach ($this->players as $pData) {
            if (!$pData['is_folded'] && $pData['bet'] > $maxBet) {
                $maxBet = $pData['bet'];
            }
        }
        $myBet = $botData['bet'];
        $callAmount = $maxBet - $myBet;

        // Bot AI decision making
        $cards = array_merge($botData['hand'], array_slice($this->communityCards, 0, $this->getCommunityCardCount()));
        
        $action = "check";
        if (count($cards) >= 5) {
            $eval = self::evaluateBestHand($cards);
            $rank = $eval[0];

            if ($rank >= 4) { // Straight or better
                $action = "raise";
            } elseif ($rank >= 1) { // One Pair or better
                $action = $callAmount > 0 ? "call" : "check";
            } else {
                $action = $callAmount > 0 ? "fold" : "check";
            }
        } else {
            // Preflop evaluation
            $v0 = $botData['hand'][0]['value'];
            $v1 = $botData['hand'][1]['value'];
            
            if ($v0 === $v1 || $v0 >= 10 || $v1 >= 10) {
                $action = $callAmount > 0 ? "call" : "check";
            } else {
                $action = $callAmount > 0 ? "fold" : "check";
            }
        }

        if ($action === "fold") {
            $botData['is_folded'] = true;
            $botData['acted'] = true;
            $botData['last_action'] = '§cBỏ bài (Fold)§r';
            $this->broadcastMessage("§6[" . $botData['name'] . "] §cđã Bỏ bài (Fold).");
        } elseif ($action === "raise") {
            $raiseAmount = (int)($this->buyIn * 0.2);
            $targetBet = $maxBet + $raiseAmount;
            
            $botData['bet'] = $targetBet;
            $botData['acted'] = true;
            $botData['last_action'] = '§eTố thêm (Raise) §a' . number_format($raiseAmount) . ' Xu§r';
            $this->pot += ($targetBet - $myBet);

            foreach ($this->players as $idx => &$p) {
                if ($idx !== $botIdx && !$p['is_folded']) {
                    $p['acted'] = false;
                }
            }
            unset($p);
            $this->broadcastMessage("§6[" . $botData['name'] . "] §eđã Tố thêm (Raise) §a" . number_format($raiseAmount) . " Xu§e.");
        } else {
            if ($callAmount > 0) {
                $botData['bet'] = $maxBet;
                $botData['acted'] = true;
                $botData['last_action'] = '§eTheo bài (Call) §a' . number_format($callAmount) . ' Xu§r';
                $this->pot += $callAmount;
                $this->broadcastMessage("§6[" . $botData['name'] . "] §eđã Theo bài (Call) §a" . number_format($callAmount) . " Xu§e.");
            } else {
                $botData['acted'] = true;
                $botData['last_action'] = '§eXem bài (Check)§r';
                $this->broadcastMessage("§6[" . $botData['name'] . "] §eđã Xem bài (Check).");
            }
        }

        $this->turnIndex = ($this->turnIndex + 1) % count($this->players);
        $this->startTurn();
    }

    private function getCommunityCardCount(): int {
        switch ($this->round) {
            case self::ROUND_FLOP: return 3;
            case self::ROUND_TURN: return 4;
            case self::ROUND_RIVER: return 5;
            default: return 0;
        }
    }

    private function render(): void {
        $border = $this->getBorderPane(DyeColor::GRAY);
        $felt = $this->getBorderPane(DyeColor::GREEN);

        // Action buttons
        $btnFold = $this->createItem(VanillaBlocks::WOOL()->setColor(DyeColor::RED)->asItem(), "§l§c[ BỎ BÀI - FOLD ]", [
            "§7Chấp nhận thua cuộc,",
            "§7Mất toàn bộ số tiền đã cược."
        ]);

        $maxBet = 0;
        foreach ($this->players as $pData) {
            if (!$pData['is_folded'] && $pData['bet'] > $maxBet) {
                $maxBet = $pData['bet'];
            }
        }

        // Render each human player menu
        foreach ($this->players as $pIdx => $pData) {
            if ($pData['is_bot'] || $pData['player'] === null) {
                continue;
            }

            $menu = $this->menus[$pData['name']];
            $inv = $menu->getInventory();

            // Set backgrounds
            for ($i = 0; $i < 54; $i++) {
                $inv->setItem($i, $border);
            }
            for ($i = 45; $i <= 53; $i++) {
                $inv->setItem($i, $felt);
            }

            // Render opponents info cards on slot 0, 1, 2, 3
            $slotIdx = 0;
            foreach ($this->players as $otherIdx => $otherData) {
                if ($otherIdx === $pIdx) {
                    continue; // Skip self
                }
                
                $statusColor = "§a";
                $statusStr = "Đang chơi";
                if ($otherData['is_folded']) {
                    $statusColor = "§c";
                    $statusStr = "Đã bỏ bài (Fold)";
                } elseif ($this->turnIndex === $otherIdx) {
                    $statusColor = "§e";
                    $statusStr = "Đang suy nghĩ...";
                }

                $oppCard = $this->createItem(
                    VanillaBlocks::STAINED_GLASS_PANE()->setColor($otherData['is_folded'] ? DyeColor::RED : DyeColor::LIGHT_BLUE)->asItem(),
                    "§l§b" . $statusColor . $otherData['name'],
                    [
                        "§fTrạng thái: " . $statusColor . $statusStr,
                        "§fĐã cược vòng này: §a" . number_format($otherData['bet']) . " Xu",
                        "§fHành động gần nhất: " . ($otherData['last_action'] ?? "Chưa hành động"),
                        "§fBài tẩy: §c[ Úp ]"
                    ]
                );
                $inv->setItem($slotIdx++, $oppCard);
            }

            // Render Player own Hand
            $inv->setItem(43, $this->getCardItem($pData['hand'][0]));
            $inv->setItem(44, $this->getCardItem($pData['hand'][1]));

            // Render Community Cards
            for ($i = 0; $i < 5; $i++) {
                $visible = false;
                if ($this->round === self::ROUND_FLOP && $i < 3) $visible = true;
                if ($this->round === self::ROUND_TURN && $i < 4) $visible = true;
                if ($this->round === self::ROUND_RIVER && $i < 5) $visible = true;

                if ($visible) {
                    $inv->setItem(20 + $i, $this->getCardItem($this->communityCards[$i]));
                } else {
                    $hiddenCard = $this->createItem(VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::YELLOW)->asItem(), "§l§eChưa chia [ ? ]", ["§7Đợi đến vòng tiếp theo."]);
                    $inv->setItem(20 + $i, $hiddenCard);
                }
            }

            // Render Turn Indicator
            $activePlayerName = $this->getCurrentPlayerName();
            $isBot = $this->players[$this->turnIndex]['is_bot'] ?? false;
            $timeStr = $isBot ? "Đang suy nghĩ..." : $this->timeLeft . " giây";

            $turnActive = $this->createItem(VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::GREEN)->asItem(), "§l§aĐẾN LƯỢT BẠN!", [
                "§7Thời gian còn lại: §e" . $timeStr,
                "§7Nhấp chuột vào hành động bên dưới."
            ]);
            $turnInactive = $this->createItem(VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::RED)->asItem(), "§l§cĐỢI ĐỐI THỦ...", [
                "§7Lượt đi của: §b" . $activePlayerName,
                "§7Thời gian còn lại: §e" . $timeStr
            ]);

            if ($this->turnIndex === $pIdx) {
                $inv->setItem(12, $turnActive);
            } else {
                $inv->setItem(12, $turnInactive);
            }

            // Render Info Book
            $infoBookLore = [
                "§fMã bàn: §e" . $this->id,
                "§fTiền cược gốc (Buy-in): §a" . number_format($this->buyIn) . " Xu",
                "§fTổng gà hiện tại (Pot): §e" . number_format($this->pot) . " Xu",
                "§fLượt chơi của: §b" . $this->getCurrentPlayerName() . " (§e" . $timeStr . "§f)",
                "",
                "§e§lLỊCH SỬ HÀNH ĐỘNG VÒNG NÀY:"
            ];
            foreach ($this->players as $p) {
                $infoBookLore[] = "§7- §f" . $p['name'] . ": " . ($p['last_action'] ?? "Chưa hành động");
            }

            $infoBook = $this->createItem(VanillaItems::BOOK(), "§l§eℹ THÔNG TIN VÁN BÀI", $infoBookLore);
            $inv->setItem(9, $infoBook);

            // Render Player own Bet
            $betItem = $this->createItem(VanillaItems::GOLD_INGOT(), "§l§aTiền Cược Của Bạn", [
                "§fĐã tố vòng này: §a" . number_format($pData['bet']) . " Xu"
            ]);
            $inv->setItem(10, $betItem);

            // Action Buttons
            $callAmount = $maxBet - $pData['bet'];
            $btnCall = $callAmount > 0 ? 
                $this->createItem(VanillaBlocks::WOOL()->setColor(DyeColor::YELLOW)->asItem(), "§l§e[ THEO BÀI - CALL ]", ["§7Tố thêm §e" . number_format($callAmount) . " Xu §7để bằng đối thủ."]) :
                $this->createItem(VanillaBlocks::WOOL()->setColor(DyeColor::YELLOW)->asItem(), "§l§e[ XEM BÀI - CHECK ]", ["§7Không cần tố thêm.", "§7Nhường lượt cho đối thủ."]);

            $raiseSize = $pData['raise_amount'] ?? (int)($this->buyIn * 0.2);
            $btnRaise = $this->createItem(VanillaBlocks::WOOL()->setColor(DyeColor::GREEN)->asItem(), "§l§a[ TỐ THÊM - RAISE ]", [
                "§7Tố thêm §a" . number_format($raiseSize) . " Xu§7.",
                "§7Gia tăng áp lực lên đối thủ!"
            ]);

            $btnIncreaseRaise = $this->createItem(VanillaItems::EMERALD(), "§l§2[ + ] TĂNG LƯỢNG TỐ", [
                "§7Tăng thêm §a" . number_format((int)($this->buyIn * 0.1)) . " Xu §7vào mức tố.",
                "§7Mức tố hiện tại: §e" . number_format($raiseSize) . " Xu"
            ]);

            $redstoneItem = StringToItemParser::getInstance()->parse("redstone") ?? VanillaBlocks::REDSTONE()->asItem();
            $btnDecreaseRaise = $this->createItem($redstoneItem, "§l§c[ - ] GIẢM LƯỢNG TỐ", [
                "§7Giảm bớt §c" . number_format((int)($this->buyIn * 0.1)) . " Xu §7khỏi mức tố.",
                "§7Mức tố hiện tại: §e" . number_format($raiseSize) . " Xu"
            ]);

            $inv->setItem(30, $btnFold);
            $inv->setItem(31, $btnCall);
            $inv->setItem(32, $btnRaise);
            $inv->setItem(33, $btnIncreaseRaise);
            $inv->setItem(34, $btnDecreaseRaise);
        }
    }

    private function createItem(Item $item, string $name, array $lore = []): Item {
        $item->setCustomName($name);
        $item->setLore($lore);
        return $item;
    }

    private function getBorderPane(DyeColor $color): Item {
        return $this->createItem(VanillaBlocks::STAINED_GLASS_PANE()->setColor($color)->asItem(), " ");
    }

    private function getCardItem(array $card): Item {
        $paper = StringToItemParser::getInstance()->parse("paper");
        if ($paper === null) {
            $paper = VanillaItems::PAPER();
        }
        return $this->createItem($paper, self::formatCard($card), ["§7Quân bài của bạn trong ván Poker."]);
    }

    public static function formatCard(array $card): string {
        $suits = ["§7♠", "§7♣", "§c♦", "§c♥"];
        $values = [
            2 => "2", 3 => "3", 4 => "4", 5 => "5", 6 => "6", 7 => "7", 
            8 => "8", 9 => "9", 10 => "10", 11 => "J", 12 => "Q", 13 => "K", 14 => "A"
        ];
        return "§l§f[ §6" . $values[$card['value']] . " " . $suits[$card['suit']] . " §f]";
    }

    public static function getRankName(int $rank): string {
        switch ($rank) {
            case 9: return "Thùng Phá Sảnh Lớn (Royal Flush)";
            case 8: return "Thùng Phá Sảnh (Straight Flush)";
            case 7: return "Tứ Quý (Four of a Kind)";
            case 6: return "Cù Lũ (Full House)";
            case 5: return "Thùng (Flush)";
            case 4: return "Sảnh (Straight)";
            case 3: return "Sám Cô (Three of a Kind)";
            case 2: return "Thú (Two Pair)";
            case 1: return "Đôi (One Pair)";
            default: return "Mậu Thầu (High Card)";
        }
    }

    private function showdown(): void {
        $results = [];
        foreach ($this->players as $pData) {
            if ($pData['is_folded']) {
                continue;
            }
            $allCards = array_merge($pData['hand'], $this->communityCards);
            $eval = self::evaluateBestHand($allCards);
            $results[] = [
                'name' => $pData['name'],
                'rank' => $eval[0],
                'tie' => $eval[1],
                'player' => $pData['player']
            ];
        }

        // Sort winners using rank and tiebreakers
        usort($results, function($a, $b) {
            if ($a['rank'] !== $b['rank']) {
                return $b['rank'] <=> $a['rank'];
            }
            for ($i = 0; $i < count($a['tie']); $i++) {
                if ($a['tie'][$i] !== $b['tie'][$i]) {
                    return $b['tie'][$i] <=> $a['tie'][$i];
                }
            }
            return 0;
        });

        // Find all players tying with the first element
        $winners = [];
        $first = $results[0];
        $winners[] = $first;

        for ($i = 1; $i < count($results); $i++) {
            $curr = $results[$i];
            if ($curr['rank'] === $first['rank'] && $curr['tie'] === $first['tie']) {
                $winners[] = $curr;
            } else {
                break;
            }
        }

        if (count($winners) === 1) {
            $w = $winners[0];
            $this->endGameWithWinner($w['name'], "Thắng Showdown với bộ bài " . self::getRankName($w['rank']));
        } else {
            // Split pot
            $share = (int)($this->pot / count($winners));
            $winnerNames = array_column($winners, 'name');
            $this->endGameWithSplit($winnerNames, $share, "Hòa bài với bộ bài " . self::getRankName($first['rank']));
        }
    }

    private function endGameWithWinner(string $winnerName, string $reason): void {
        $this->isFinished = true;
        $this->stopTimer();

        $eco = AZEconomy::getInstance();
        if (!str_starts_with(strtolower($winnerName), "bot cá cược ")) {
            $eco->addMoney($winnerName, $this->pot);
        }

        $this->broadcastMessage("§a§l[POKER] §eNgười chơi §6" . $winnerName . " §eđã chiến thắng! Nhận §6" . number_format($this->pot) . " Xu§e. Lý do: §f" . $reason);

        // Close all inventories
        foreach ($this->players as $pData) {
            if (!$pData['is_bot'] && $pData['player'] !== null) {
                $pData['player']->removeCurrentWindow();
            }
        }

        Main::getInstance()->removeGame($this->id);
    }

    private function endGameWithSplit(array $winnerNames, int $share, string $reason): void {
        $this->isFinished = true;
        $this->stopTimer();

        $eco = AZEconomy::getInstance();
        foreach ($winnerNames as $wName) {
            if (!str_starts_with(strtolower($wName), "bot cá cược ")) {
                $eco->addMoney($wName, $share);
            }
        }

        $listNames = implode(", ", $winnerNames);
        $this->broadcastMessage("§e§l[POKER] §eVán đấu hòa bài! Các người chơi thắng cuộc: §6" . $listNames . " §eđược chia §6" . number_format($share) . " Xu§e mỗi người. Lý do: §f" . $reason);

        // Close all inventories
        foreach ($this->players as $pData) {
            if (!$pData['is_bot'] && $pData['player'] !== null) {
                $pData['player']->removeCurrentWindow();
            }
        }

        Main::getInstance()->removeGame($this->id);
    }

    public static function evaluate5CardHand(array $cards): array {
        usort($cards, fn($a, $b) => $b['value'] <=> $a['value']);
        
        $values = array_column($cards, 'value');
        $suits = array_column($cards, 'suit');
        
        $isFlush = count(array_unique($suits)) === 1;
        
        $isStraight = false;
        if (count(array_unique($values)) === 5) {
            if ($values[0] - $values[4] === 4) {
                $isStraight = true;
            } elseif ($values === [14, 5, 4, 3, 2]) {
                $isStraight = true;
                $values = [5, 4, 3, 2, 1];
            }
        }
        
        $valueCounts = array_count_values($values);
        arsort($valueCounts);
        $counts = array_values($valueCounts);
        $uniqueValues = array_keys($valueCounts);
        
        if ($isFlush && $isStraight) {
            if ($values[0] === 14) {
                return [9, $values];
            }
            return [8, $values];
        }
        
        if ($counts[0] === 4) {
            return [7, [$uniqueValues[0], $uniqueValues[1]]];
        }
        
        if ($counts[0] === 3 && $counts[1] === 2) {
            return [6, [$uniqueValues[0], $uniqueValues[1]]];
        }
        
        if ($isFlush) {
            return [5, $values];
        }
        
        if ($isStraight) {
            return [4, $values];
        }
        
        if ($counts[0] === 3) {
            return [3, [$uniqueValues[0], $uniqueValues[1], $uniqueValues[2]]];
        }
        
        if ($counts[0] === 2 && $counts[1] === 2) {
            return [2, [$uniqueValues[0], $uniqueValues[1], $uniqueValues[2]]];
        }
        
        if ($counts[0] === 2) {
            return [1, [$uniqueValues[0], $uniqueValues[1], $uniqueValues[2], $uniqueValues[3]]];
        }
        
        return [0, $values];
    }

    public static function compareHands(int $rankA, array $tieA, int $rankB, array $tieB): int {
        if ($rankA !== $rankB) {
            return $rankA <=> $rankB;
        }
        for ($i = 0; $i < min(count($tieA), count($tieB)); $i++) {
            if ($tieA[$i] !== $tieB[$i]) {
                return $tieA[$i] <=> $tieB[$i];
            }
        }
        return 0;
    }

    public static function evaluateBestHand(array $cards): array {
        $n = count($cards);
        if ($n < 5) {
            return [0, array_column($cards, 'value'), $cards];
        }
        if ($n === 5) {
            $res = self::evaluate5CardHand($cards);
            return [$res[0], $res[1], $cards];
        }
        
        $bestRank = -1;
        $bestTie = [];
        $bestCombo = [];
        
        if ($n === 6) {
            for ($i = 0; $i < 6; $i++) {
                $combo = [];
                for ($k = 0; $k < 6; $k++) {
                    if ($k !== $i) {
                        $combo[] = $cards[$k];
                    }
                }
                $res = self::evaluate5CardHand($combo);
                if (self::compareHands($res[0], $res[1], $bestRank, $bestTie) > 0) {
                    $bestRank = $res[0];
                    $bestTie = $res[1];
                    $bestCombo = $combo;
                }
            }
        } elseif ($n === 7) {
            for ($i = 0; $i < 7; $i++) {
                for ($j = $i + 1; $j < 7; $j++) {
                    $combo = [];
                    for ($k = 0; $k < 7; $k++) {
                        if ($k !== $i && $k !== $j) {
                            $combo[] = $cards[$k];
                        }
                    }
                    $res = self::evaluate5CardHand($combo);
                    if (self::compareHands($res[0], $res[1], $bestRank, $bestTie) > 0) {
                        $bestRank = $res[0];
                        $bestTie = $res[1];
                        $bestCombo = $combo;
                    }
                }
            }
        }
        return [$bestRank, $bestTie, $bestCombo];
    }
}
