<?php

declare(strict_types=1);

namespace BeeAZ\AZPoker;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\utils\Config;
use pocketmine\Server;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Label;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Dropdown;
use muqsit\invmenu\InvMenuHandler;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\scheduler\ClosureTask;
use pocketmine\item\StringToItemParser;
use AZEconomy\AZEconomy;

class Main extends PluginBase implements Listener {

    private static self $instance;

    // Queue of hosting tables: [buyin => [playerName => Player]]
    private array $queue = [];
    
    // Active games: [playerName => Game]
    private array $games = [];

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onLoad(): void {
        self::$instance = $this;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        // Register InvMenu if not registered
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "poker") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cLệnh này chỉ sử dụng được trong trò chơi!");
                return true;
            }
            $this->openMainMenu($sender);
            return true;
        }
        return false;
    }

    public function openMainMenu(Player $player): void {
        $options = [
            new MenuOption("§0⚡ §lMỞ SÒNG BẠC (HOST) §r§0⚡\n§8Tạo sòng Poker mới", new FormIcon("textures/ui/anvil_icon", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lTHAM GIA SÒNG (JOIN) §r§0⚡\n§8Xem các sòng đang chờ", new FormIcon("textures/ui/multiplayer_glyph_color", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lĐẤU VỚI BOT (VS BOT) §r§0⚡\n§8Chơi Poker với máy tính", new FormIcon("textures/items/spawn_egg", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lHƯỚNG DẪN CHƠI §r§0⚡\n§8Xem luật chơi Poker", new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§0⚡ §lCASINO POKER §r§0⚡",
            "§aChào mừng bạn đến với Sòng bạc Poker Hoàng Gia!\n\n§eChọn một hành động bên dưới để bắt đầu:",
            $options,
            function(Player $submitter, int $selected): void {
                switch ($selected) {
                    case 0:
                        $this->openHostForm($submitter);
                        break;
                    case 1:
                        $this->openJoinMenu($submitter);
                        break;
                    case 2:
                        $this->openHostBotForm($submitter);
                        break;
                    case 3:
                        $this->openHelpMenu($submitter);
                        break;
                }
            }
        );

        $player->sendForm($form);
    }

    private function openHostBotForm(Player $player): void {
        if ($this->isInGame($player)) {
            $player->sendMessage("§cBạn đang trong một ván đấu Poker khác!");
            return;
        }

        $min = (int)$this->getConfig()->get("min_buyin", 1000);
        $max = (int)$this->getConfig()->get("max_buyin", 1000000);

        $form = new CustomForm(
            "§0⚡ §lĐẤU VỚI BOT §r§0⚡",
            [
                new Label("info", "§eĐặt số tiền cược (Buy-in) cho ván Poker với Bot.\n\n§fGiới hạn: §a" . number_format($min) . " Xu §f- §c" . number_format($max) . " Xu\n"),
                new Input("buyin", "§bNhập số tiền cược (Xu):", "Ví dụ: 1000", "1000"),
                new Dropdown("bot_count", "§eChọn số lượng Bot đối thủ:", ["1 Bot (2 Người)", "2 Bots (3 Người)", "3 Bots (4 Người)"])
            ],
            function(Player $submitter, CustomFormResponse $response) use ($min, $max): void {
                $buyinStr = $response->getString("buyin");
                if (!is_numeric($buyinStr)) {
                    $submitter->sendMessage("§cSố tiền cược phải là một con số hợp lệ!");
                    return;
                }

                $buyin = (int)$buyinStr;
                if ($buyin < $min || $buyin > $max) {
                    $submitter->sendMessage("§cTiền cược phải nằm trong giới hạn cho phép!");
                    return;
                }

                $eco = AZEconomy::getInstance();
                if ($eco->getMoney($submitter->getName()) < $buyin) {
                    $submitter->sendMessage("§cBạn không có đủ " . number_format($buyin) . " Xu để đặt cược!");
                    return;
                }

                $botCount = $response->getInt("bot_count") + 1;
                $gameId = uniqid("poker_bot_");
                $game = new Game($gameId, $buyin, [$submitter], $botCount);
                
                $this->games[$submitter->getName()] = $game;
            },
            function(Player $submitter): void {
                $this->openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    private function openHostForm(Player $player): void {
        if ($this->isInGame($player)) {
            $player->sendMessage("§cBạn đang trong một ván đấu Poker khác!");
            return;
        }

        $min = (int)$this->getConfig()->get("min_buyin", 1000);
        $max = (int)$this->getConfig()->get("max_buyin", 1000000);

        $form = new CustomForm(
            "§0⚡ §lMỞ SÒNG POKER §r§0⚡",
            [
                new Label("info", "§eĐặt số tiền cược (Buy-in) cho sòng Poker của bạn.\n§eNgười tham gia sẽ phải cược số tiền tương tự.\n\n§fGiới hạn: §a" . number_format($min) . " Xu §f- §c" . number_format($max) . " Xu\n"),
                new Input("buyin", "§bNhập số tiền cược (Xu):", "Ví dụ: 50000", "1000"),
                new Dropdown("max_players", "§eChọn số lượng người chơi tối đa:", ["2 Người", "3 Người", "4 Người"])
            ],
            function(Player $submitter, CustomFormResponse $response) use ($min, $max): void {
                $buyinStr = $response->getString("buyin");
                if (!is_numeric($buyinStr)) {
                    $submitter->sendMessage("§cSố tiền cược phải là một con số hợp lệ!");
                    return;
                }

                $buyin = (int)$buyinStr;
                if ($buyin < $min || $buyin > $max) {
                    $submitter->sendMessage("§cTiền cược phải nằm trong giới hạn cho phép!");
                    return;
                }

                $eco = AZEconomy::getInstance();
                if ($eco->getMoney($submitter->getName()) < $buyin) {
                    $submitter->sendMessage("§cBạn không có đủ " . number_format($buyin) . " Xu để mở sòng!");
                    return;
                }

                // Check if already hosting
                foreach ($this->queue as $bi => $players) {
                    if (isset($players[$submitter->getName()])) {
                        unset($this->queue[$bi][$submitter->getName()]);
                    }
                }

                $maxPlayers = $response->getInt("max_players") + 2;

                $menu = InvMenu::create(InvMenu::TYPE_CHEST);
                $menu->setName("§6⚡ §e§lPOKER LOBBY §r§6⚡");

                $this->queue[$buyin][$submitter->getName()] = [
                    'host' => $submitter,
                    'players' => [$submitter->getName() => $submitter],
                    'max_players' => $maxPlayers,
                    'menu' => $menu,
                    'starting' => false
                ];

                $menu->setListener(function(InvMenuTransaction $transaction) use ($submitter, $buyin): InvMenuTransactionResult {
                    $player = $transaction->getPlayer();
                    $slot = $transaction->getAction()->getSlot();
                    $hostName = $submitter->getName();

                    if ($slot === 22) { // Start Game
                        if ($player->getName() !== $hostName) {
                            $player->sendMessage("§cChỉ chủ sòng mới có quyền bắt đầu ván đấu!");
                        } else {
                            $this->startLobbyGame($hostName, $buyin);
                        }
                    } elseif ($slot === 26) { // Leave Room
                        $player->removeCurrentWindow();
                    }
                    return $transaction->discard();
                });

                $menu->setInventoryCloseListener(function(Player $player) use ($submitter, $buyin): void {
                    $this->leaveRoom($player, $buyin, $submitter->getName());
                });

                $this->updateWaitingLobbyItems($submitter->getName(), $buyin);
                $menu->send($submitter);

                $submitter->sendMessage("§aĐã tạo sòng cược §e" . number_format($buyin) . " Xu§a thành công! Đang chờ đối thủ...");
                $this->getServer()->broadcastMessage(
                    "§l§d[CASINO] §f" . $submitter->getName() . 
                    " §eđã mở sòng Poker §a" . $maxPlayers . " người §emức cược §a" . number_format($buyin) . " Xu§e! Gõ §f/poker §eđể vào so tài!"
                );
            },
            function(Player $submitter): void {
                $this->openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    private function openJoinMenu(Player $player): void {
        if ($this->isInGame($player)) {
            $player->sendMessage("§cBạn đang trong một ván đấu Poker khác!");
            return;
        }

        $options = [];
        $tempList = [];

        foreach ($this->queue as $buyin => $hosts) {
            foreach ($hosts as $name => $data) {
                $host = $data['host'];
                if (!$host->isOnline()) {
                    unset($this->queue[$buyin][$name]);
                    continue;
                }
                if (isset($data['players'][$player->getName()])) {
                    continue; // Already in it
                }
                $currentCount = count($data['players']);
                $maxCount = $data['max_players'];
                $options[] = new MenuOption("§0⚡ §lChủ sòng: §a{$name} §r§0⚡\n§eMức cược: §b" . number_format($buyin) . " Xu §f| §eSòng: §a" . $currentCount . "/" . $maxCount, new FormIcon("textures/ui/icon_map", FormIcon::IMAGE_TYPE_PATH));
                $tempList[] = ['host_name' => $name, 'buyin' => $buyin];
            }
        }

        if (count($options) === 0) {
            $options[] = new MenuOption("§0⚡ §lQUAY LẠI LOBBY §r§0⚡\n§8Về menu chính", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));
            $form = new MenuForm(
                "§0⚡ §lTHAM GIA SÒNG POKER §r§0⚡",
                "§cKhông tìm thấy bàn chơi Poker nào đang chờ người chơi khác.",
                $options,
                function(Player $submitter, int $selected): void {
                    $this->openMainMenu($submitter);
                }
            );
            $player->sendForm($form);
            return;
        }

        $form = new MenuForm(
            "§0⚡ §lTHAM GIA SÒNG POKER §r§0⚡",
            "§eChọn một sòng bạc bên dưới để tham gia:",
            $options,
            function(Player $submitter, int $selected) use ($tempList): void {
                if (!isset($tempList[$selected])) {
                    $this->openMainMenu($submitter);
                    return;
                }

                $room = $tempList[$selected];
                $hostName = $room['host_name'];
                $buyin = $room['buyin'];

                if (!isset($this->queue[$buyin][$hostName])) {
                    $submitter->sendMessage("§cSòng bạc này không còn tồn tại!");
                    return;
                }

                $data = &$this->queue[$buyin][$hostName];
                $host = $data['host'];

                if (!$host->isOnline()) {
                    $submitter->sendMessage("§cChủ sòng đã thoát game!");
                    unset($this->queue[$buyin][$hostName]);
                    return;
                }

                if (count($data['players']) >= $data['max_players']) {
                    $submitter->sendMessage("§cSòng bạc này đã đầy!");
                    return;
                }

                $eco = AZEconomy::getInstance();
                if ($eco->getMoney($submitter->getName()) < $buyin) {
                    $submitter->sendMessage("§cBạn không có đủ " . number_format($buyin) . " Xu để tham gia!");
                    return;
                }

                // Add player to the room
                $data['players'][$submitter->getName()] = $submitter;

                // Notify all members
                foreach ($data['players'] as $roomPlayer) {
                    $roomPlayer->sendMessage("§a[POKER] Người chơi §e" . $submitter->getName() . " §ađã tham gia sòng cược (" . count($data['players']) . "/" . $data['max_players'] . ")");
                }

                // If room is full, start the game!
                if (count($data['players']) >= $data['max_players']) {
                    $playersList = array_values($data['players']);
                    $data['starting'] = true;
                    unset($this->queue[$buyin][$hostName]);

                    foreach ($playersList as $p) {
                        $p->removeCurrentWindow();
                    }

                    $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($playersList, $buyin): void {
                        $gameId = uniqid("poker_");
                        $game = new Game($gameId, $buyin, $playersList, 0);

                        foreach ($playersList as $p) {
                            $this->games[$p->getName()] = $game;
                        }
                    }), 10);
                } else {
                    $this->openWaitingLobby($submitter, $hostName, $buyin);
                }
            }
        );

        $player->sendForm($form);
    }

    private function openHelpMenu(Player $player): void {
        $options = [new MenuOption("§0⚡ §lQUAY LẠI LOBBY §r§0⚡\n§8Về menu chính", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))];
        $form = new MenuForm(
            "§0⚡ §lHƯỚNG DẪN POKER §r§0⚡",
            "§eLuật chơi Heads-up Texas Hold'em rút gọn:\n\n" .
            "§f1. Mỗi bên được chia §e2 lá bài tẩy§f riêng tư.\n" .
            "§f2. Sẽ có tất cả §e5 lá bài chung§f được chia giữa bàn qua các vòng Flop, Turn, River.\n" .
            "§f3. Mỗi vòng, bạn có 3 lựa chọn:\n" .
            "   - §cFold§f: Bỏ cuộc, chấp nhận thua cược hiện tại.\n" .
            "   - §eCheck/Call§f: Nhường lượt hoặc cược thêm để bằng đối thủ.\n" .
            "   - §aRaise§f: Tố thêm 20% Buy-in ban đầu để gây áp lực.\n" .
            "§f4. Khi kết thúc River, hệ thống sẽ kết hợp 2 bài tẩy của bạn và 5 bài chung để tìm ra §e5 lá mạnh nhất§f so bài.\n\n" .
            "§c⚠️ LƯU Ý: Đánh bạc có tỉ lệ 10% bị cảnh sát bắt giam 5 phút!",
            $options,
            function(Player $submitter, int $selected): void {
                $this->openMainMenu($submitter);
            }
        );
        $player->sendForm($form);
    }

    public function isInGame(Player $player): bool {
        return isset($this->games[$player->getName()]);
    }

    public function removeGame(string $gameId): void {
        foreach ($this->games as $name => $game) {
            // Find and remove the association
            unset($this->games[$name]);
        }
    }

    private function openWaitingLobby(Player $player, string $hostName, int $buyin): void {
        if (!isset($this->queue[$buyin][$hostName])) return;
        $data = $this->queue[$buyin][$hostName];
        $data['menu']->send($player);
        $this->updateWaitingLobbyItems($hostName, $buyin);
    }

    private function updateWaitingLobbyItems(string $hostName, int $buyin): void {
        if (!isset($this->queue[$buyin][$hostName])) return;
        $data = $this->queue[$buyin][$hostName];
        $menu = $data['menu'];
        $inv = $menu->getInventory();

        $border = $this->createItem(VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::GRAY)->asItem(), " ");
        for ($i = 0; $i < 27; $i++) {
            $inv->setItem($i, $border);
        }

        // Slot 4: Info
        $infoItem = $this->createItem(VanillaBlocks::GOLD()->asItem(), "§l§6SÒNG POKER ĐANG CHỜ", [
            "§fChủ sòng: §e" . $hostName,
            "§fMức cược (Buy-in): §a" . number_format($buyin) . " Xu",
            "§fSố người chơi hiện tại: §e" . count($data['players']) . " / " . $data['max_players']
        ]);
        $inv->setItem(4, $infoItem);

        // Slots 10, 11, 12, 13: Players
        $playerSlots = [10, 11, 12, 13];
        $playersList = array_values($data['players']);
        for ($i = 0; $i < 4; $i++) {
            $slot = $playerSlots[$i];
            if ($i < $data['max_players']) {
                if (isset($playersList[$i])) {
                    $p = $playersList[$i];
                    $pCard = $this->createItem(
                        VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::GREEN)->asItem(),
                        "§l§a" . $p->getName(),
                        [
                            $i === 0 ? "§eChủ sòng" : "§7Người chơi",
                            "§aĐã sẵn sàng"
                        ]
                    );
                    $inv->setItem($slot, $pCard);
                } else {
                    $pCard = $this->createItem(
                        VanillaBlocks::STAINED_GLASS_PANE()->setColor(DyeColor::LIGHT_GRAY)->asItem(),
                        "§l§8Trống",
                        [
                            "§7Đang đợi người chơi khác..."
                        ]
                    );
                    $inv->setItem($slot, $pCard);
                }
            }
        }

        // Slot 22: Start Button (Green Wool for Host, Gray pane for Guests)
        // Slot 26: Leave Button (Red Wool)
        $btnLeave = $this->createItem(VanillaBlocks::WOOL()->setColor(DyeColor::RED)->asItem(), "§l§c[ RỜI SÒNG ]", [
            "§7Thoát khỏi phòng chờ và quay lại menu chính."
        ]);
        $inv->setItem(26, $btnLeave);

        $canStart = count($data['players']) >= 2;
        $btnStart = $this->createItem(
            VanillaBlocks::WOOL()->setColor($canStart ? DyeColor::GREEN : DyeColor::LIGHT_GRAY)->asItem(),
            "§l§a[ BẮT ĐẦU NGAY ]",
            [
                $canStart ? "§7Nhấp để bắt đầu ván đấu ngay." : "§cCần ít nhất 2 người chơi để bắt đầu."
            ]
        );
        $inv->setItem(22, $btnStart);
    }

    private function leaveRoom(Player $player, int $buyin, string $hostName): void {
        if (!isset($this->queue[$buyin][$hostName])) return;
        $data = &$this->queue[$buyin][$hostName];
        
        if ($data['starting']) return;

        $name = $player->getName();
        if (isset($data['players'][$name])) {
            unset($data['players'][$name]);

            foreach ($data['players'] as $p) {
                $p->sendMessage("§c[POKER] Người chơi §e" . $name . " §cđã rời phòng.");
            }

            if ($name === $hostName) {
                foreach ($data['players'] as $p) {
                    $p->sendMessage("§c[POKER] Chủ sòng đã hủy phòng.");
                    $p->removeCurrentWindow();
                }
                unset($this->queue[$buyin][$hostName]);
            } else {
                $this->updateWaitingLobbyItems($hostName, $buyin);
            }
        }
    }

    private function startLobbyGame(string $hostName, int $buyin): void {
        if (!isset($this->queue[$buyin][$hostName])) return;
        $data = &$this->queue[$buyin][$hostName];
        
        if (count($data['players']) < 2) {
            $data['host']->sendMessage("§cCần ít nhất 2 người chơi để bắt đầu!");
            return;
        }

        $data['starting'] = true;

        $playersList = array_values($data['players']);
        unset($this->queue[$buyin][$hostName]);

        foreach ($playersList as $p) {
            $p->removeCurrentWindow();
        }

        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($playersList, $buyin): void {
            $gameId = uniqid("poker_");
            $game = new Game($gameId, $buyin, $playersList, 0);

            foreach ($playersList as $p) {
                $this->games[$p->getName()] = $game;
            }
        }), 10);
    }

    private function createItem(Item $item, string $name, array $lore = []): Item {
        $item->setCustomName($name);
        $item->setLore($lore);
        return $item;
    }

    /**
     * @priority MONITOR
     */
    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        if (isset($this->games[$player->getName()])) {
            $game = $this->games[$player->getName()];
            $game->handlePlayerQuit($player);
        }

        // Clean up from matchmaking queue
        foreach ($this->queue as $bi => $hosts) {
            foreach ($hosts as $hostName => $data) {
                if (isset($data['players'][$player->getName()])) {
                    unset($this->queue[$bi][$hostName]['players'][$player->getName()]);
                    if (count($this->queue[$bi][$hostName]['players']) === 0) {
                        unset($this->queue[$bi][$hostName]);
                    }
                }
            }
        }
    }

    /**
     * @priority NORMAL
     */
    public function onCommandExecute(CommandEvent $event): void {
        $sender = $event->getSender();
        if ($sender instanceof Player && $this->isInGame($sender)) {
            $sender->sendMessage("§cBạn không thể sử dụng lệnh khi đang chơi Poker! Vui lòng bỏ bài (Fold) trước.");
            $event->cancel();
        }
    }
}
