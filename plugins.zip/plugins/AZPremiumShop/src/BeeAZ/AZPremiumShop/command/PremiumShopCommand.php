<?php

declare(strict_types=1);

namespace BeeAZ\AZPremiumShop\command;

use BeeAZ\AZPremiumShop\ui\PremiumShopUI;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class PremiumShopCommand extends Command {

    public function __construct(string $name, string $description = "", string $usageMessage = null, array $aliases = []) {
        parent::__construct($name, $description, $usageMessage, $aliases);
        $this->setPermission("azpremiumshop.command.use");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) {
            return true;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
            return true;
        }

        PremiumShopUI::openShopMenu($sender);
        return true;
    }
}
