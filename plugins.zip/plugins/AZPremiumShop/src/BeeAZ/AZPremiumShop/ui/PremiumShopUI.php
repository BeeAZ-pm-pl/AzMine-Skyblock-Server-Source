<?php

declare(strict_types=1);

namespace BeeAZ\AZPremiumShop\ui;

use BeeAZ\AZPremiumShop\Main;
use BeeAZ\AZPremiumShop\utils\EconomyManager;
use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\enchantment\EnchantmentInstance;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use function class_exists;
use function is_array;
use function number_format;

class PremiumShopUI {

    /**
     * Build item from configuration array
     */
    public static function buildItem(array $data): ?Item {
        $itemStr = $data["item"] ?? "";
        if ($itemStr === "") return null;

        $item = StringToItemParser::getInstance()->parse($itemStr);
        if ($item === null) return null;

        $item->setCount((int)($data["amount"] ?? 1));

        if (isset($data["name"])) {
            $item->setCustomName($data["name"]);
        }

        if (isset($data["lore"]) && is_array($data["lore"])) {
            $lore = [];
            foreach ($data["lore"] as $line) {
                $lore[] = (string)$line;
            }
            $item->setLore($lore);
        }

        if (isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach ($data["enchants"] as $enchantName => $level) {
                $enchantment = StringToEnchantmentParser::getInstance()->parse((string)$enchantName);
                if ($enchantment === null) {
                    $normalized = str_replace(" ", "_", (string)$enchantName);
                    $enchantment = StringToEnchantmentParser::getInstance()->parse($normalized);
                }
                if ($enchantment === null) {
                    $enchantment = StringToEnchantmentParser::getInstance()->parse(strtolower((string)$enchantName));
                }
                if ($enchantment === null) {
                    $enchantment = StringToEnchantmentParser::getInstance()->parse(strtolower(str_replace(" ", "_", (string)$enchantName)));
                }
                if ($enchantment === null && class_exists(\DaPigGuy\PiggyCustomEnchants\CustomEnchantManager::class)) {
                    $enchantment = \DaPigGuy\PiggyCustomEnchants\CustomEnchantManager::getEnchantmentByName((string)$enchantName);
                }
                if ($enchantment === null && is_numeric($enchantName)) {
                    try {
                        $enchantment = \pocketmine\data\bedrock\EnchantmentIdMap::getInstance()->fromId((int)$enchantName);
                    } catch (\InvalidArgumentException $e) {}
                }
                if ($enchantment !== null) {
                    $item->addEnchantment(new EnchantmentInstance($enchantment, (int)$level));
                }
            }
        }

        // Apply AZCustomEnchants stats formatting dynamically if available
        if (class_exists(\BeeAZ\AZCustomEnchants\manager\StatsManager::class)) {
            \BeeAZ\AZCustomEnchants\manager\StatsManager::checkAndRebuildLore($item);
        }

        return $item;
    }

    /**
     * Opens the main Premium Shop GUI using InvMenu Double Chest
     */
    public static function openShopMenu(Player $player, int $page = 1): void {
        $plugin = Main::getInstance();
        $shopItems = $plugin->getConfig()->get("items", []);
        $title = $plugin->getConfig()->get("gui_title", "§l§6CỬA HÀNG PREMIUM VIP");

        // Calculate pages
        $itemsPerPage = 28;
        $totalItems = count($shopItems);
        $totalPages = (int)max(1, ceil($totalItems / $itemsPerPage));
        if ($page < 1) $page = 1;
        if ($page > $totalPages) $page = $totalPages;

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName($title . " §r§7- Trang $page/$totalPages");
        $inventory = $menu->getInventory();

        // Fill borders with black stained glass panes
        $borderSlots = [
            0, 1, 2, 3, 4, 5, 6, 7, 8,
            9, 17, 18, 26, 27, 35, 36, 44,
            45, 46, 47, 48, 49, 50, 51, 52, 53
        ];
        $pane = StringToItemParser::getInstance()->parse("black_stained_glass_pane");
        if ($pane !== null) {
            $pane->setCustomName(" ");
            foreach ($borderSlots as $slot) {
                $inventory->setItem($slot, clone $pane);
            }
        }

        // Previous Page Button
        if ($page > 1) {
            $prevButton = StringToItemParser::getInstance()->parse("paper");
            if ($prevButton !== null) {
                $prevButton->setCustomName("§l§e<- TRANG TRƯỚC");
                $prevButton->setLore(["§r§7Nhấp vào đây để quay lại trang trước"]);
                $prevButton->getNamedTag()->setInt("AZPremiumShopPrevPage", $page - 1);
                $inventory->setItem(45, $prevButton);
            }
        }

        // Next Page Button
        if ($page < $totalPages) {
            $nextButton = StringToItemParser::getInstance()->parse("paper");
            if ($nextButton !== null) {
                $nextButton->setCustomName("§l§eTRANG TIẾP ->");
                $nextButton->setLore(["§r§7Nhấp vào đây để đi tới trang tiếp theo"]);
                $nextButton->getNamedTag()->setInt("AZPremiumShopNextPage", $page + 1);
                $inventory->setItem(53, $nextButton);
            }
        }

        // Available slots in the center of double chest
        $shopSlots = [
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
        ];

        // Slice items for current page
        $offset = ($page - 1) * $itemsPerPage;
        $pageItemsKeys = array_slice(array_keys($shopItems), $offset, $itemsPerPage);

        $idx = 0;
        foreach ($pageItemsKeys as $shopKey) {
            if (!isset($shopSlots[$idx])) {
                break;
            }
            $data = $shopItems[$shopKey];
            $price = (int)($data["price"] ?? 0);
            $currency = strtolower($data["currency"] ?? "coin");
            $currencyName = $currency === "money" ? "Xu" : "Coin";

            $customItem = self::buildItem($data);
            if ($customItem === null) {
                continue;
            }

            $slot = $shopSlots[$idx];
            $displayItem = clone $customItem;
            
            $lore = $displayItem->getLore();
            $lore[] = "";
            $lore[] = "§r§8--------------------------";
            $lore[] = "§r§eGiá Bán: §d" . number_format($price) . " " . $currencyName;
            $lore[] = "§r§aNhấp chuột để chọn mua vật phẩm!";
            $lore[] = "§r§8--------------------------";
            $displayItem->setLore($lore);

            // Save configuration key inside NamedTag to retrieve later
            $displayItem->getNamedTag()->setString("AZPremiumShopKey", (string)$shopKey);

            $inventory->setItem($slot, $displayItem);
            $idx++;
        }

        $menu->setListener(function(InvMenuTransaction $transaction) use ($shopItems, $page): InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $item = $transaction->getItemClicked();
            $tag = $item->getNamedTag();

            if ($tag->getTag("AZPremiumShopPrevPage") !== null) {
                $prev = $tag->getInt("AZPremiumShopPrevPage");
                $player->removeCurrentWindow();
                Main::getInstance()->getScheduler()->scheduleDelayedTask(
                    new \pocketmine\scheduler\ClosureTask(function() use ($player, $prev): void {
                        if ($player->isOnline()) {
                            self::openShopMenu($player, $prev);
                        }
                    }),
                    2
                );
                return $transaction->discard();
            }

            if ($tag->getTag("AZPremiumShopNextPage") !== null) {
                $next = $tag->getInt("AZPremiumShopNextPage");
                $player->removeCurrentWindow();
                Main::getInstance()->getScheduler()->scheduleDelayedTask(
                    new \pocketmine\scheduler\ClosureTask(function() use ($player, $next): void {
                        if ($player->isOnline()) {
                            self::openShopMenu($player, $next);
                        }
                    }),
                    2
                );
                return $transaction->discard();
            }

            if ($tag->getTag("AZPremiumShopKey") !== null) {
                $shopKey = $tag->getString("AZPremiumShopKey");

                if (isset($shopItems[$shopKey])) {
                    $data = $shopItems[$shopKey];
                    $price = (int)($data["price"] ?? 0);

                    $player->removeCurrentWindow();

                    // Open confirmation form with delay to prevent client GUI glitch
                    Main::getInstance()->getScheduler()->scheduleDelayedTask(
                        new \pocketmine\scheduler\ClosureTask(function() use ($player, $shopKey, $data, $price): void {
                            if ($player->isOnline()) {
                                $displayName = $data["name"] ?? $shopKey;
                                self::openConfirmPurchaseForm($player, $shopKey, $data, $price, $displayName);
                            }
                        }),
                        5
                    );
                }
            }

            return $transaction->discard();
        });

        $menu->send($player);
    }

    /**
     * Confirmation form for buying an item (SimpleForm/MenuForm)
     */
    public static function openConfirmPurchaseForm(Player $player, string $shopKey, array $data, int $price, string $displayName): void {
        $currency = strtolower($data["currency"] ?? "coin");
        $currencyName = $currency === "money" ? "Xu" : "Coin";

        $options = [
            new MenuOption("§l§aXÁC NHẬN MUA", new FormIcon("textures/ui/confirm", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§l§cHUỶ GIAO DỊCH", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§l§5XÁC NHẬN MUA ĐỒ",
            "§eBạn có chắc chắn muốn mua:\n" .
            "§f- Vật phẩm: §r" . $displayName . "\n" .
            "§f- Giá mua: §d" . number_format($price) . " " . $currencyName . "\n\n" .
            "§7Số dư của bạn sẽ bị trừ sau khi xác nhận.",
            $options,
            function(Player $submitter, int $selected) use ($shopKey, $data, $price, $displayName, $currency, $currencyName): void {
                if ($selected === 0) {
                    if ($currency === "money") {
                        $currentBal = EconomyManager::getMoney($submitter);
                    } else {
                        $currentBal = EconomyManager::getCoin($submitter);
                    }

                    if ($currentBal < $price) {
                        $submitter->sendMessage("§c[Cửa Hàng] Giao dịch thất bại: Bạn không có đủ " . $currencyName . "! (Thiếu " . number_format($price - $currentBal) . " " . $currencyName . ")");
                        return;
                    }

                    // Build the actual item
                    $item = self::buildItem($data);
                    if ($item === null) {
                        $submitter->sendMessage("§c[Cửa Hàng] Giao dịch thất bại: Lỗi hệ thống khi tạo vật phẩm!");
                        return;
                    }

                    if (!$submitter->getInventory()->canAddItem($item)) {
                        $submitter->sendMessage("§c[Cửa Hàng] Giao dịch thất bại: Túi đồ của bạn đã đầy!");
                        return;
                    }

                    // Deduct balance
                    $deducted = false;
                    if ($currency === "money") {
                        $deducted = EconomyManager::reduceMoney($submitter, $price);
                    } else {
                        $deducted = EconomyManager::reduceCoin($submitter, $price);
                    }

                    if ($deducted) {
                        $submitter->getInventory()->addItem($item);
                        $submitter->sendMessage("§a[Cửa Hàng] Mua thành công §r" . $displayName . " §avới giá §e" . number_format($price) . " " . $currencyName . "§a!");
                    } else {
                        $submitter->sendMessage("§c[Cửa Hàng] Giao dịch thất bại: Lỗi hệ thống khi trừ " . $currencyName . "!");
                    }
                } else {
                    self::openShopMenu($submitter);
                }
            },
            function(Player $submitter): void {
                self::openShopMenu($submitter);
            }
        );

        $player->sendForm($form);
    }
}
