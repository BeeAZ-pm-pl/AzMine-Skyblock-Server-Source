<?php

declare(strict_types=1);

namespace BeeAZ\AZPremiumShop\utils;

use pocketmine\player\Player;
use AZEconomy\AZEconomy;

class EconomyManager {

    /**
     * Get player's Coin balance from AZEconomy
     */
    public static function getCoin(Player $player): int {
        if (class_exists(AZEconomy::class)) {
            return AZEconomy::getInstance()->getCoin($player->getName());
        }
        return 0;
    }

    /**
     * Deduct Coin from player using AZEconomy
     */
    public static function reduceCoin(Player $player, int $amount): bool {
        if ($amount <= 0) {
            return false;
        }
        if (class_exists(AZEconomy::class)) {
            return AZEconomy::getInstance()->reduceCoin($player->getName(), $amount);
        }
        return false;
    }

    /**
     * Get player's Money balance from AZEconomy
     */
    public static function getMoney(Player $player): int {
        if (class_exists(AZEconomy::class)) {
            return AZEconomy::getInstance()->getMoney($player->getName());
        }
        return 0;
    }

    /**
     * Deduct Money from player using AZEconomy
     */
    public static function reduceMoney(Player $player, int $amount): bool {
        if ($amount <= 0) {
            return false;
        }
        if (class_exists(AZEconomy::class)) {
            return AZEconomy::getInstance()->reduceMoney($player->getName(), $amount);
        }
        return false;
    }
}
