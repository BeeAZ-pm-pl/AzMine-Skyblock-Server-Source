<?php

declare(strict_types=1);

namespace BeeAZ\AZPremiumShop;

use BeeAZ\AZPremiumShop\command\PremiumShopCommand;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

class Main extends PluginBase {
    use SingletonTrait;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();

        if (!\muqsit\invmenu\InvMenuHandler::isRegistered()) {
            \muqsit\invmenu\InvMenuHandler::register($this);
        }

        // Register the shop command
        $this->getServer()->getCommandMap()->register("azpremiumshop", new PremiumShopCommand(
            "premiumshop",
            "Mở cửa hàng vật phẩm cao cấp",
            "/premiumshop",
            ["pshop", "mi-shop"]
        ));

        $this->getLogger()->info("§aAZPremiumShop đã khởi chạy thành công!");
    }
}
