<?php

declare(strict_types=1);

namespace BeeAZ\AZSpawn;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\math\Vector3;

class Main extends PluginBase implements Listener {

    /** @var array<string, SpawnTask> */
    private array $pendingTeleports = [];

    private Config $cfg;

    protected function onEnable(): void {
        $this->saveResource("config.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        $cmdName = strtolower($command->getName());

        if (!in_array($cmdName, ["hub", "lobby", "spawn"], true)) {
            return false;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("Lệnh này chỉ dùng cho người chơi.");
            return true;
        }

        $prefix = $this->cfg->getNested("messages.prefix", "§l§7[§6AZSpawn§7] §r");

        // Check if already waiting
        if (isset($this->pendingTeleports[$sender->getName()])) {
            $sender->sendMessage($prefix . $this->cfg->getNested("messages.already_waiting", "§cBạn đang chờ dịch chuyển rồi!"));
            return true;
        }

        // Get spawn position
        $world = $this->getServer()->getWorldManager()->getDefaultWorld();
        if ($world === null) {
            $sender->sendMessage($prefix . $this->cfg->getNested("messages.no_spawn", "§cKhông tìm thấy điểm Spawn!"));
            return true;
        }

        $spawnPos = $world->getSpawnLocation();
        $delay = (int)$this->cfg->get("delay", 5);

        if ($delay <= 0) {
            // Instant teleport
            $sender->teleport($spawnPos);
            $sender->sendMessage($prefix . $this->cfg->getNested("messages.success", "§aBạn đã được dịch chuyển về Spawn!"));
            return true;
        }

        // Start delayed teleport
        $msgTeleporting = $this->cfg->getNested("messages.teleporting", "§eDịch chuyển về Spawn sau §c{seconds} §egiây...");
        $sender->sendMessage($prefix . str_replace("{seconds}", (string)$delay, $msgTeleporting));

        $task = new SpawnTask($this, $sender, $spawnPos, $delay);
        $this->pendingTeleports[$sender->getName()] = $task;
        $this->getScheduler()->scheduleRepeatingTask($task, 20); // 20 ticks = 1 giây

        return true;
    }

    /**
     * Cancel teleport if player moves too far
     */
    public function onMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        $name = $player->getName();

        if (!isset($this->pendingTeleports[$name])) {
            return;
        }

        $task = $this->pendingTeleports[$name];
        $maxDist = (float)$this->cfg->get("max_move_distance", 0.5);
        $startPos = $task->getStartPosition();
        $currentPos = $player->getPosition();

        $dist = $startPos->distance($currentPos);
        if ($dist > $maxDist) {
            $this->cancelTeleport($player, true);
        }
    }

    /**
     * Clean up on quit
     */
    public function onQuit(PlayerQuitEvent $event): void {
        $this->cancelTeleport($event->getPlayer(), false);
    }

    /**
     * Cancel a pending teleport
     */
    public function cancelTeleport(Player $player, bool $sendMessage): void {
        $name = $player->getName();
        if (isset($this->pendingTeleports[$name])) {
            $task = $this->pendingTeleports[$name];
            $task->getHandler()->cancel();
            unset($this->pendingTeleports[$name]);

            if ($sendMessage && $player->isOnline()) {
                $prefix = $this->cfg->getNested("messages.prefix", "§l§7[§6AZSpawn§7] §r");
                $player->sendMessage($prefix . $this->cfg->getNested("messages.cancelled", "§cĐã hủy dịch chuyển vì bạn di chuyển!"));
            }
        }
    }

    /**
     * Called by SpawnTask when countdown finishes
     */
    public function completeTeleport(Player $player, Vector3 $target): void {
        $name = $player->getName();
        unset($this->pendingTeleports[$name]);

        if (!$player->isOnline()) {
            return;
        }

        $world = $this->getServer()->getWorldManager()->getDefaultWorld();
        if ($world === null) {
            return;
        }

        $player->teleport($world->getSpawnLocation());
        $prefix = $this->cfg->getNested("messages.prefix", "§l§7[§6AZSpawn§7] §r");
        $player->sendMessage($prefix . $this->cfg->getNested("messages.success", "§aBạn đã được dịch chuyển về Spawn!"));
    }
}
