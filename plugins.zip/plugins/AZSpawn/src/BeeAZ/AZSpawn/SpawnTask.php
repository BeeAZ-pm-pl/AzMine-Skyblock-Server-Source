<?php

declare(strict_types=1);

namespace BeeAZ\AZSpawn;

use pocketmine\scheduler\Task;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class SpawnTask extends Task {

    private Main $plugin;
    private Player $player;
    private Vector3 $target;
    private Vector3 $startPosition;
    private int $countdown;

    public function __construct(Main $plugin, Player $player, Vector3 $target, int $delay) {
        $this->plugin = $plugin;
        $this->player = $player;
        $this->target = $target;
        $this->startPosition = $player->getPosition()->asVector3();
        $this->countdown = $delay;
    }

    public function getStartPosition(): Vector3 {
        return $this->startPosition;
    }

    public function onRun(): void {
        if (!$this->player->isOnline()) {
            $this->plugin->cancelTeleport($this->player, false);
            return;
        }

        $this->countdown--;

        if ($this->countdown > 0) {
            // Show countdown in action bar
            $bar = "";
            for ($i = 0; $i < $this->countdown; $i++) {
                $bar .= "§a▮";
            }
            $this->player->sendActionBarMessage("§e⏳ Dịch chuyển sau §c" . $this->countdown . " §egiây " . $bar);
            return;
        }

        // Countdown finished - teleport
        $this->getHandler()->cancel();
        $this->plugin->completeTeleport($this->player, $this->target);
    }
}
