<?php

namespace az\season;

use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;
use pocketmine\player\Player;
use pocketmine\item\StringToItemParser;
use AZEconomy\AZEconomy;

class ShopForm {
    public static function sendShop(Player $player, Main $plugin): void {
        $season = $plugin->getSeasonManager()->getCurrentSeason();
        $seasonVN = $plugin->getSeasonManager()->getSeasonVietnamese();
        
        $crops = $plugin->getConfig()->get("crops", []);
        $options = [];
        $cropKeys = [];

        $content = "§l§eTHÔNG TIN THỊ TRƯỜNG\n";
        $content .= "§fMùa hiện tại: §a" . $seasonVN . "\n";
        $content .= "§fGiá nông sản sẽ thay đổi linh hoạt tùy theo mùa vụ.\n";
        $content .= "§7Hãy chọn loại nông sản bạn muốn bán:\n";

        foreach ($crops as $key => $data) {
            $basePrice = $data['base-price'];
            $multiplier = $data['season-multiplier'][$season] ?? 1.0;
            $currentPrice = $basePrice * $multiplier;
            
            $trend = "§a=";
            if ($multiplier > 1.0) $trend = "§a▲(+" . (($multiplier - 1) * 100) . "%%%)";
            if ($multiplier < 1.0) $trend = "§c▼(-" . ((1 - $multiplier) * 100) . "%%%)";

            $icon = isset($data['icon']) ? new FormIcon($data['icon'], FormIcon::IMAGE_TYPE_PATH) : null;
            $options[] = new MenuOption($data['name'] . "\nGiá: §e" . $currentPrice . " xu §r" . $trend, $icon);
            $cropKeys[] = $key;
        }

        $form = new MenuForm(
            "§l§2NÔNG SẢN THEO MÙA",
            $content,
            $options,
            function (Player $submitter, int $selected) use ($plugin, $cropKeys, $season): void {
                self::sellCrop($submitter, $plugin, $cropKeys[$selected], $season);
            }
        );
        $player->sendForm($form);
    }

    private static function sellCrop(Player $player, Main $plugin, string $cropKey, string $season): void {
        $config = $plugin->getConfig()->get("crops")[$cropKey];
        $parsed = StringToItemParser::getInstance()->parse($config['id']);
        
        if ($parsed === null) {
            $player->sendMessage("§cLỗi hệ thống: Vật phẩm không tồn tại!");
            return;
        }

        $inv = $player->getInventory();
        $totalEarned = 0;
        $itemsToRemove = [];

        $basePrice = $config['base-price'];
        $multiplier = $config['season-multiplier'][$season] ?? 1.0;
        $itemPrice = $basePrice * $multiplier;

        foreach ($inv->getContents() as $slot => $item) {
            if ($item->getTypeId() === $parsed->getTypeId()) {
                $totalEarned += ($itemPrice * $item->getCount());
                $itemsToRemove[] = $item;
            }
        }

        if (count($itemsToRemove) === 0) {
            $player->sendMessage("§cBạn không có " . $config['name'] . " để bán!");
            return;
        }

        $inv->removeItem(...$itemsToRemove);
        
        AZEconomy::getInstance()->addMoney($player->getName(), (int)$totalEarned);
        
        $player->sendMessage("§aBạn đã bán thành công §e" . $config['name'] . " §avà nhận được §e" . number_format($totalEarned) . "$!");
    }
}