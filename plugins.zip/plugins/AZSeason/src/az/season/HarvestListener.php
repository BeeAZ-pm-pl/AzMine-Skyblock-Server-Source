<?php

namespace az\season;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\block\Crops;
use pocketmine\item\StringToItemParser;

class HarvestListener implements Listener {
    public function __construct(private Main $plugin) {}

    /**
     * @priority HIGH
     */
    public function onBreak(BlockBreakEvent $event): void {
        if ($event->isCancelled()) return;
        
        $block = $event->getBlock();
        
        if ($block instanceof Crops) {
            if ($block->getAge() >= $block::MAX_AGE) {
                $drops = $event->getDrops();
                $newDrops = [];
                
                foreach ($drops as $item) {
                    $cropConfig = $this->getCropConfigById($item->getTypeId());
                    if ($cropConfig !== null) {
                        $freshness = mt_rand(1, 100);
                        $nbt = $item->getNamedTag();
                        $nbt->setInt("AZFreshness", $freshness);
                        $item->setNamedTag($nbt);
                        
                        $color = "§a";
                        if ($freshness < 50) $color = "§e";
                        if ($freshness < 20) $color = "§c";
                        
                        $item->setCustomName("§r" . $cropConfig['name'] . "\n§r" . $color . "Độ tươi: " . $freshness . "%");
                    }
                    $newDrops[] = $item;
                }
                $event->setDrops($newDrops);
            }
        }
    }

    private function getCropConfigById(int $typeId): ?array {
        $crops = $this->plugin->getConfig()->get("crops", []);
        foreach ($crops as $key => $data) {
            $parsed = StringToItemParser::getInstance()->parse($data['id']);
            if ($parsed !== null && $parsed->getTypeId() === $typeId) {
                return $data;
            }
        }
        return null;
    }
}