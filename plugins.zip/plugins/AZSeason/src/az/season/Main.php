<?php

namespace az\season;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class Main extends PluginBase {
    private SeasonManager $seasonManager;

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->seasonManager = new SeasonManager($this);
    }

    public function getSeasonManager(): SeasonManager {
        return $this->seasonManager;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "seasonshop" && $sender instanceof Player) {
            ShopForm::sendShop($sender, $this);
            return true;
        }
        return false;
    }
}