<?php

namespace az\season;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class SeasonManager implements Listener {
    private const SEASONS = ["Spring", "Summer", "Autumn", "Winter"];
    private const VIETNAMESE = ["Xuân", "Hạ", "Thu", "Đông"];

    public function __construct(private Main $plugin) {
        $this->plugin->getServer()->getPluginManager()->registerEvents($this, $this->plugin);
    }

    public function getCurrentSeasonIndex(): int {
        $day = (int)date("j");
        if ($day >= 1 && $day <= 7) return 0;
        if ($day >= 8 && $day <= 14) return 1;
        if ($day >= 15 && $day <= 21) return 2;
        return 3;
    }

    public function getCurrentSeason(): string {
        return self::SEASONS[$this->getCurrentSeasonIndex()];
    }

    public function getSeasonVietnamese(): string {
        return self::VIETNAMESE[$this->getCurrentSeasonIndex()];
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $player->sendMessage("§a[Season] §fHiện tại đang là mùa §e" . $this->getSeasonVietnamese());
    }
}