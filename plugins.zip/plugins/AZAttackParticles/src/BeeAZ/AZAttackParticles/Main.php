<?php

declare(strict_types=1);

namespace BeeAZ\AZAttackParticles;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\ModalForm;
use dktapps\pmforms\FormIcon;
use AZEconomy\AZEconomy;
use BeeAZ\AZAttackParticles\task\DatabaseSaveTask;

class Main extends PluginBase implements Listener {

    private \SQLite3 $db;
    private string $prefix = "§d§l[Hiệu Ứng] §r";
    private array $activeEffectsCache = [];
    private array $expiryCache = [];

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->prefix = $this->getConfig()->getNested("messages.prefix", "§d§l[Hiệu Ứng] §r");

        // Verify AZEconomy dependency
        if (!class_exists(AZEconomy::class)) {
            $this->getLogger()->emergency("AZEconomy không được tìm thấy! Plugin này yêu cầu AZEconomy.");
            $this->getServer()->getPluginManager()->disablePlugin($this);
            return;
        }

        // Database Init
        @mkdir($this->getDataFolder());
        $this->db = new \SQLite3($this->getDataFolder() . "particles.db");
        $this->db->busyTimeout(5000);
        $this->db->exec("PRAGMA journal_mode=WAL;");
        $this->db->exec("PRAGMA synchronous=NORMAL;");
        $this->db->exec("CREATE TABLE IF NOT EXISTS unlocked_effects (player TEXT, effect TEXT, expiry INTEGER, PRIMARY KEY (player, effect))");
        $this->db->exec("CREATE TABLE IF NOT EXISTS active_effects (player TEXT PRIMARY KEY, effect TEXT)");

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    protected function onDisable(): void {
        if (isset($this->db)) {
            // Save active effects cache synchronously to prevent data loss on reload/restart
            if (!empty($this->activeEffectsCache)) {
                $this->db->exec("BEGIN TRANSACTION;");
                $stmt = $this->db->prepare("INSERT OR REPLACE INTO active_effects (player, effect) VALUES (:player, :effect)");
                $delStmt = $this->db->prepare("DELETE FROM active_effects WHERE player = :player");
                foreach ($this->activeEffectsCache as $player => $effect) {
                    if ($effect === null) {
                        $delStmt->bindValue(":player", $player);
                        $delStmt->execute();
                    } else {
                        $stmt->bindValue(":player", $player);
                        $stmt->bindValue(":effect", $effect);
                        $stmt->execute();
                    }
                }
                $this->db->exec("COMMIT;");
            }

            // Save expiry cache synchronously to prevent data loss on reload/restart
            if (!empty($this->expiryCache)) {
                $this->db->exec("BEGIN TRANSACTION;");
                $stmt = $this->db->prepare("INSERT OR REPLACE INTO unlocked_effects (player, effect, expiry) VALUES (:player, :effect, :expiry)");
                foreach ($this->expiryCache as $player => $effects) {
                    foreach ($effects as $effect => $expiry) {
                        $stmt->bindValue(":player", $player);
                        $stmt->bindValue(":effect", $effect);
                        $stmt->bindValue(":expiry", $expiry);
                        $stmt->execute();
                    }
                }
                $this->db->exec("COMMIT;");
            }

            $this->db->close();
        }
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "hieuung") {
            if (!$sender instanceof Player) {
                $sender->sendMessage($this->getConfig()->getNested("messages.only_player", "Lệnh này chỉ có thể sử dụng trong trò chơi."));
                return true;
            }
            $this->openMainMenu($sender);
            return true;
        }
        return false;
    }

    /**
     * Helper to format remaining time
     */
    private function formatRemainingTime(int $expiry): string {
        $diff = $expiry - time();
        if ($diff <= 0) return "Hết hạn";
        $days = (int)($diff / 86400);
        $diff %= 86400;
        $hours = (int)($diff / 3600);
        $diff %= 3600;
        $mins = (int)($diff / 60);

        $parts = [];
        if ($days > 0) $parts[] = $days . " ngày";
        if ($hours > 0) $parts[] = $hours . " giờ";
        if ($days === 0 && $mins > 0) $parts[] = $mins . " phút";

        return count($parts) > 0 ? implode(" ", $parts) : "Vài giây";
    }

    /**
     * Database Helpers
     */
    public function getExpiry(string $playerName, string $effect): int {
        $playerNameLower = strtolower($playerName);
        if (isset($this->expiryCache[$playerNameLower][$effect])) {
            return $this->expiryCache[$playerNameLower][$effect];
        }

        $stmt = $this->db->prepare("SELECT expiry FROM unlocked_effects WHERE player = :player AND effect = :effect");
        $stmt->bindValue(":player", $playerNameLower);
        $stmt->bindValue(":effect", $effect);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);
        $expiry = $row !== false ? (int)$row["expiry"] : 0;

        $this->expiryCache[$playerNameLower][$effect] = $expiry;
        return $expiry;
    }

    public function isUnlocked(string $playerName, string $effect): bool {
        $expiry = $this->getExpiry($playerName, $effect);
        return $expiry > time();
    }

    public function unlockEffect(string $playerName, string $effect, int $durationDays): void {
        $playerNameLower = strtolower($playerName);
        $seconds = $durationDays * 86400;
        $currentExpiry = $this->getExpiry($playerName, $effect);

        $now = time();
        $base = max($now, $currentExpiry);
        $newExpiry = $base + $seconds;

        // Update local memory cache immediately to prevent race conditions
        $this->expiryCache[$playerNameLower][$effect] = $newExpiry;

        // Submit write query asynchronously to avoid main thread block
        $dbPath = $this->getDataFolder() . "particles.db";
        $query = "INSERT OR REPLACE INTO unlocked_effects (player, effect, expiry) VALUES (:player, :effect, :expiry)";
        $params = [
            ":player" => $playerNameLower,
            ":effect" => $effect,
            ":expiry" => $newExpiry
        ];
        $this->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask($dbPath, $query, $params));
    }

    public function getActiveEffect(string $playerName): ?string {
        $playerNameLower = strtolower($playerName);
        if (array_key_exists($playerNameLower, $this->activeEffectsCache)) {
            $effect = $this->activeEffectsCache[$playerNameLower];
            if ($effect !== null && !$this->isUnlocked($playerName, $effect)) {
                $this->setActiveEffect($playerName, null);
                return null;
            }
            return $effect;
        }

        $stmt = $this->db->prepare("SELECT effect FROM active_effects WHERE player = :player");
        $stmt->bindValue(":player", $playerNameLower);
        $res = $stmt->execute();
        $row = $res->fetchArray(SQLITE3_ASSOC);
        $effect = null;
        if ($row !== false) {
            $effect = $row["effect"];
            if (!$this->isUnlocked($playerName, $effect)) {
                $this->setActiveEffect($playerName, null);
                $effect = null;
            }
        }

        $this->activeEffectsCache[$playerNameLower] = $effect;
        return $effect;
    }

    public function setActiveEffect(string $playerName, ?string $effect): void {
        $playerNameLower = strtolower($playerName);
        
        // Update local memory cache immediately
        $this->activeEffectsCache[$playerNameLower] = $effect;

        // Submit write query asynchronously to avoid main thread block
        $dbPath = $this->getDataFolder() . "particles.db";
        if ($effect === null) {
            $query = "DELETE FROM active_effects WHERE player = :player";
            $params = [
                ":player" => $playerNameLower
            ];
        } else {
            $query = "INSERT OR REPLACE INTO active_effects (player, effect) VALUES (:player, :effect)";
            $params = [
                ":player" => $playerNameLower,
                ":effect" => $effect
            ];
        }
        $this->getServer()->getAsyncPool()->submitTask(new DatabaseSaveTask($dbPath, $query, $params));
    }

    /**
     * opens main menu form
     */
    private function openMainMenu(Player $player): void {
        $money = AZEconomy::getInstance()->getMoney($player->getName());
        $coin = AZEconomy::getInstance()->getCoin($player->getName());
        $active = $this->getActiveEffect($player->getName());

        $options = [];
        $actions = [];

        // Option to turn off
        if ($active !== null) {
            $options[] = new MenuOption("§0⚡ §lTắt hiệu ứng đang dùng §r§0⚡\n§8Hủy kích hoạt hiệu ứng chém hiện tại", new FormIcon("textures/blocks/barrier", FormIcon::IMAGE_TYPE_PATH));
            $actions[] = ["type" => "deactivate"];
        }

        $effects = $this->getConfig()->get("effects", []);
        foreach ($effects as $key => $data) {
            $name = $data["name"];
            $desc = $data["desc"];

            $isUnlocked = $this->isUnlocked($player->getName(), $key);
            $expiry = $this->getExpiry($player->getName(), $key);

            if ($active === $key) {
                $btnText = "§0⚡ §l" . $name . " §r§d(Đang dùng - Còn " . $this->formatRemainingTime($expiry) . ") §r§0⚡\n§8" . $desc;
                $iconPath = "textures/items/magma_cream";
            } elseif ($isUnlocked) {
                $btnText = "§0⚡ §l" . $name . " §r§a(Đã sở hữu - Còn " . $this->formatRemainingTime($expiry) . ") §r§0⚡\n§8" . $desc;
                $iconPath = "textures/items/glowstone_dust";
            } else {
                $btnText = "§0⚡ §l" . $name . " §r§e(Bấm để xem các gói thời hạn) §r§0⚡\n§8" . $desc;
                $iconPath = "textures/items/redstone_dust";
            }

            $options[] = new MenuOption($btnText, new FormIcon($iconPath, FormIcon::IMAGE_TYPE_PATH));
            $actions[] = [
                "type" => "effect",
                "key" => $key,
                "data" => $data,
                "unlocked" => $isUnlocked
            ];
        }

        $form = new MenuForm(
            "§d§lKHO HIỆU ỨNG TẤN CÔNG",
            "§eSố dư: §a" . number_format($money) . " Xu §f| §d" . number_format($coin) . " Coin\n§fChọn hiệu ứng để mua hoặc kích hoạt:",
            $options,
            function(Player $submitter, int $selected) use ($actions): void {
                $action = $actions[$selected];
                if ($action["type"] === "deactivate") {
                    $this->setActiveEffect($submitter->getName(), null);
                    $submitter->sendMessage($this->prefix . $this->getConfig()->getNested("messages.deactivate_success"));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                    $this->openMainMenu($submitter);
                } elseif ($action["type"] === "effect") {
                    $key = $action["key"];
                    $data = $action["data"];
                    if ($action["unlocked"]) {
                        // Owned: Open selection to activate or extend
                        $this->openOwnedEffectOptions($submitter, $key, $data);
                    } else {
                        // Not owned: Open duration packages menu
                        $this->openDurationsForm($submitter, $key, $data);
                    }
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * opens choices for owned effects (Activate / Extend)
     */
    private function openOwnedEffectOptions(Player $player, string $key, array $data): void {
        $expiry = $this->getExpiry($player->getName(), $key);
        $remaining = $this->formatRemainingTime($expiry);

        $options = [
            new MenuOption("§0⚡ §lKích Hoạt Hiệu Ứng §r§0⚡\n§8Sử dụng hiệu ứng này khi chém", new FormIcon("textures/ui/check", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lGia Hạn Sử Dụng §r§0⚡\n§8Mua thêm thời gian sử dụng", new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)),
            new MenuOption("§0⚡ §lQuay Lại §r§0⚡\n§8Trở về trang chính", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH))
        ];

        $form = new MenuForm(
            "§d§lHIỆU ỨNG: " . $data["name"],
            "Trạng thái: §aĐã sở hữu (Còn $remaining)\n§fVui lòng chọn thao tác:",
            $options,
            function(Player $submitter, int $selected) use ($key, $data): void {
                if ($selected === 0) {
                    $this->setActiveEffect($submitter->getName(), $key);
                    $submitter->sendMessage($this->prefix . str_replace("{effect}", $data["name"], $this->getConfig()->getNested("messages.activate_success")));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new XpLevelUpSound(1));
                    $this->openMainMenu($submitter);
                } elseif ($selected === 1) {
                    $this->openDurationsForm($submitter, $key, $data);
                } else {
                    $this->openMainMenu($submitter);
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * opens durations packages selection form
     */
    private function openDurationsForm(Player $player, string $key, array $data): void {
        $money = AZEconomy::getInstance()->getMoney($player->getName());
        $coin = AZEconomy::getInstance()->getCoin($player->getName());
        
        $currency = strtolower($data["currency"]);
        $currencyName = $currency === "coin" ? "Coin" : "Xu";

        $options = [];
        $packages = [];

        $prices = $data["prices"] ?? [];
        foreach ($prices as $days => $price) {
            $packageName = $days . " Ngày";
            $packagePrice = (int)$price;

            $options[] = new MenuOption("§0⚡ §lGói " . $packageName . " §r§0⚡\n§r§fGiá: §e" . number_format($packagePrice) . " " . $currencyName, new FormIcon("textures/items/gold_nugget", FormIcon::IMAGE_TYPE_PATH));
            $packages[] = [
                "days" => (int)$days,
                "name" => $packageName,
                "price" => $packagePrice
            ];
        }
        
        $options[] = new MenuOption("§0⚡ §lQuay Lại §r§0⚡\n§8Trở về trang trước", new FormIcon("textures/ui/cancel", FormIcon::IMAGE_TYPE_PATH));

        $form = new MenuForm(
            "§d§lMUA: " . $data["name"],
            "§eSố dư: §a" . number_format($money) . " Xu §f| §d" . number_format($coin) . " Coin\n§fVui lòng chọn gói thời hạn bạn muốn mua:",
            $options,
            function(Player $submitter, int $selected) use ($key, $data, $packages, $currency, $currencyName): void {
                if ($selected >= count($packages)) {
                    $this->openMainMenu($submitter);
                    return;
                }

                $package = $packages[$selected];
                $this->openConfirmBuyForm($submitter, $key, $data, $package, $currency, $currencyName);
            }
        );

        $player->sendForm($form);
    }

    /**
     * opens buy confirmation form
     */
    private function openConfirmBuyForm(Player $player, string $key, array $data, array $package, string $currency, string $currencyName): void {
        $price = $package["price"];
        $days = $package["days"];
        $packageName = $package["name"];

        $form = new ModalForm(
            "§d§lXÁC NHẬN MUA",
            "Bạn có chắc chắn muốn mua hiệu ứng " . $data["name"] . " §r§fcho gói §e" . $packageName . " §fvới giá §e" . number_format($price) . " " . $currencyName . " §fkhông?",
            function(Player $submitter, bool $choice) use ($key, $data, $price, $days, $packageName, $currency, $currencyName): void {
                if ($choice) {
                    $playerName = $submitter->getName();
                    if ($currency === "coin") {
                        $balance = AZEconomy::getInstance()->getCoin($playerName);
                        if ($balance < $price) {
                            $submitter->sendMessage($this->prefix . str_replace(
                                ["{needed}", "{currency}", "{current}"],
                                [number_format($price), "Coin", number_format($balance)],
                                $this->getConfig()->getNested("messages.no_money")
                            ));
                            $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                            $this->openDurationsForm($submitter, $key, $data);
                            return;
                        }
                        $success = AZEconomy::getInstance()->reduceCoin($playerName, $price);
                    } else {
                        $balance = AZEconomy::getInstance()->getMoney($playerName);
                        if ($balance < $price) {
                            $submitter->sendMessage($this->prefix . str_replace(
                                ["{needed}", "{currency}", "{current}"],
                                [number_format($price), "Xu", number_format($balance)],
                                $this->getConfig()->getNested("messages.no_money")
                            ));
                            $submitter->getWorld()->addSound($submitter->getPosition(), new AnvilUseSound());
                            $this->openDurationsForm($submitter, $key, $data);
                            return;
                        }
                        $success = AZEconomy::getInstance()->reduceMoney($playerName, $price);
                    }

                    if (!$success) {
                        $submitter->sendMessage($this->prefix . "§cĐã xảy ra lỗi trong quá trình giao dịch. Vui lòng thử lại!");
                        return;
                    }

                    $this->unlockEffect($playerName, $key, $days);
                    $this->setActiveEffect($playerName, $key);

                    $submitter->sendMessage($this->prefix . str_replace(
                        ["{effect}", "{duration}", "{price}", "{currency}"],
                        [$data["name"], $packageName, number_format($price), $currencyName],
                        $this->getConfig()->getNested("messages.buy_success")
                    ));
                    $submitter->getWorld()->addSound($submitter->getPosition(), new XpLevelUpSound(1));
                }
                $this->openMainMenu($submitter);
            }
        );

        $player->sendForm($form);
    }

    /**
     * listens to damage and triggers particle effects
     */
    public function onDamage(EntityDamageByEntityEvent $event): void {
        $attacker = $event->getDamager();
        $victim = $event->getEntity();

        if ($attacker instanceof Player) {
            $effect = $this->getActiveEffect($attacker->getName());
            if ($effect !== null) {
                $this->spawnAttackParticle($victim, $effect);
            }
        }
    }

    /**
     * spawns attack particles at the victim's location
     */
    private function spawnAttackParticle(Entity $victim, string $effect): void {
        $center = $victim->getPosition();
        $world = $victim->getWorld();

        switch ($effect) {
            case "water_circle":
                // 3 concentric dense circles of splash and bubble particles
                $radii = [0.5, 1.0, 1.5];
                $counts = [12, 18, 24];
                for ($j = 0; $j < 3; $j++) {
                    $r = $radii[$j];
                    $points = $counts[$j];
                    for ($i = 0; $i < $points; $i++) {
                        $angle = $i * (2 * M_PI / $points);
                        $x = cos($angle) * $r;
                        $z = sin($angle) * $r;
                        $world->addParticle($center->add($x, 0.3, $z), new \pocketmine\world\particle\BubbleParticle());
                        if ($i % 2 === 0) {
                            $world->addParticle($center->add($x, 0.4, $z), new \pocketmine\world\particle\SplashParticle());
                        }
                    }
                }
                break;

            case "magic_dust":
                // Spawn 65 vibrant dust particles in a sphere around victim
                for ($i = 0; $i < 65; $i++) {
                    $x = (mt_rand(-15, 15) / 10) * 0.9;
                    $y = (mt_rand(0, 25) / 10);
                    $z = (mt_rand(-15, 15) / 10) * 0.9;
                    $color = new \pocketmine\color\Color(mt_rand(0, 255), mt_rand(128, 255), mt_rand(128, 255));
                    $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\DustParticle($color));
                }
                break;

            case "heart_blast":
                // Spawn 35 heart particles floating upwards
                for ($i = 0; $i < 35; $i++) {
                    $x = (mt_rand(-12, 12) / 10) * 0.8;
                    $y = 0.2 + (mt_rand(0, 22) / 10);
                    $z = (mt_rand(-12, 12) / 10) * 0.8;
                    $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\HeartParticle());
                }
                break;

            case "dark_portal":
                // Dense portal swirl with heavy smoke
                for ($i = 0; $i < 40; $i++) {
                    $angle = $i * (2 * M_PI / 20);
                    $x = cos($angle) * 0.8;
                    $z = sin($angle) * 0.8;
                    $y = 0.1 + ($i / 20) * 2.0;
                    $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\PortalParticle());
                    $world->addParticle($center->add($x * 0.7, $y, $z * 0.7), new \pocketmine\world\particle\SmokeParticle());
                }
                for ($i = 0; $i < 25; $i++) {
                    $x = (mt_rand(-10, 10) / 10);
                    $y = (mt_rand(0, 20) / 10);
                    $z = (mt_rand(-10, 10) / 10);
                    $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\PortalParticle());
                }
                break;

            case "dragon_fire":
                // 3 helix strands with double density and sparks (CriticalParticle)
                for ($y = 0.0; $y <= 3.2; $y += 0.08) {
                    $angle = $y * 3.5 * M_PI;
                    
                    // Strand 1
                    $x1 = cos($angle) * 0.85;
                    $z1 = sin($angle) * 0.85;
                    $world->addParticle($center->add($x1, $y, $z1), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add($x1, $y, $z1), new \pocketmine\world\particle\LavaParticle());

                    // Strand 2
                    $x2 = cos($angle + (2 * M_PI / 3)) * 0.85;
                    $z2 = sin($angle + (2 * M_PI / 3)) * 0.85;
                    $world->addParticle($center->add($x2, $y, $z2), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add($x2, $y, $z2), new \pocketmine\world\particle\CriticalParticle());

                    // Strand 3
                    $x3 = cos($angle + (4 * M_PI / 3)) * 0.85;
                    $z3 = sin($angle + (4 * M_PI / 3)) * 0.85;
                    $world->addParticle($center->add($x3, $y, $z3), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add($x3, $y, $z3), new \pocketmine\world\particle\LavaParticle());
                }
                break;

            case "fire_burst":
                // Massive fire burst dome
                $world->addSound($center, new \pocketmine\world\sound\BlazeShootSound());
                for ($r = 0.4; $r <= 2.8; $r += 0.4) {
                    $points = (int)($r * 12);
                    for ($i = 0; $i < $points; $i++) {
                        $angle = $i * (2 * M_PI / $points);
                        $x = cos($angle) * $r;
                        $z = sin($angle) * $r;
                        $y = 0.3 + (mt_rand(-4, 4) / 10);
                        $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\FlameParticle());
                        $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\LavaParticle());
                        if (mt_rand(1, 2) === 1) {
                            $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\ExplodeParticle());
                        }
                    }
                }
                break;

            case "lightning_strike":
                // Strike 3 lightning bolts and heavy smoke/explosion particles
                $world->addSound($center, new \pocketmine\world\sound\ExplodeSound());
                
                $offsets = [
                    new \pocketmine\math\Vector3(0, 0, 0),
                    new \pocketmine\math\Vector3(0.5, 0, 0.5),
                    new \pocketmine\math\Vector3(-0.5, 0, -0.5)
                ];

                foreach ($offsets as $offset) {
                    $strikePos = $center->add($offset->x, $offset->y, $offset->z);
                    $lightningId = mt_rand(1000000, 9000000);
                    $packet = \pocketmine\network\mcpe\protocol\AddActorPacket::create(
                        $lightningId,
                        $lightningId,
                        "minecraft:lightning_bolt",
                        $strikePos,
                        null,
                        0.0, 0.0, 0.0, 0.0, [], [],
                        new \pocketmine\network\mcpe\protocol\types\entity\PropertySyncData([], []),
                        []
                    );
                    foreach ($world->getPlayers() as $p) {
                        if ($p->getLocation()->distanceSquared($strikePos) <= 1024) {
                            $p->getNetworkSession()->sendDataPacket($packet);
                        }
                    }
                }

                for ($i = 0; $i < 35; $i++) {
                    $x = mt_rand(-20, 20) / 10;
                    $y = mt_rand(0, 25) / 10;
                    $z = mt_rand(-20, 20) / 10;
                    $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\ExplodeParticle());
                    $world->addParticle($center->add($x, $y, $z), new \pocketmine\world\particle\SmokeParticle());
                }
                break;

            case "giant_x":
                // Thick double-layered giant X
                $world->addSound($center, new \pocketmine\world\sound\BlazeShootSound());
                for ($t = -1.6; $t <= 1.6; $t += 0.12) {
                    // Line 1: backslash
                    $world->addParticle($center->add($t, $t + 1.25, 0), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add($t, $t + 1.25, 0.1), new \pocketmine\world\particle\LavaParticle());
                    // Line 2: slash
                    $world->addParticle($center->add($t, -$t + 1.25, 0), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add($t, -$t + 1.25, -0.1), new \pocketmine\world\particle\LavaParticle());
                    
                    // Z axis cross
                    $world->addParticle($center->add(0, $t + 1.25, $t), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add(0.1, $t + 1.25, $t), new \pocketmine\world\particle\LavaParticle());
                    $world->addParticle($center->add(0, -$t + 1.25, $t), new \pocketmine\world\particle\FlameParticle());
                    $world->addParticle($center->add(-0.1, -$t + 1.25, $t), new \pocketmine\world\particle\LavaParticle());
                }
                break;
        }
    }
}
