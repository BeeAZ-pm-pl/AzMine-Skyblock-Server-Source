<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC\entity;

use pocketmine\entity\Human;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\inventory\SimpleInventory;
use BeeAZ\AZTradeNPC\manager\TradeManager;

class TradeNPC extends Human {

    private string $tradeId = "";
    private ?SimpleInventory $tradeInventory = null;

    public static function getNetworkTypeId(): string {
        return "minecraft:npc";
    }

    protected function syncNetworkData(\pocketmine\network\mcpe\protocol\types\entity\EntityMetadataCollection $properties): void {
        parent::syncNetworkData($properties);
        $properties->setGenericFlag(\pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags::ALWAYS_SHOW_NAMETAG, $this->isNameTagAlwaysVisible());
    }

    public function initEntity(CompoundTag $nbt): void {
        $this->setNameTagAlwaysVisible($nbt->getByte("NameTagAlwaysVisible", 1) === 1);
        $this->setNameTagVisible();

        parent::initEntity($nbt);
        
        if ($nbt->getTag("TradeId") !== null) {
            $this->tradeId = $nbt->getString("TradeId");
        } else {
            $this->tradeId = \ramsey\uuid\Uuid::uuid4()->toString();
        }
        
        $this->setMaxHealth(1000);
        $this->setHealth(1000);
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString("TradeId", $this->tradeId);
        $nbt->setByte("NameTagAlwaysVisible", $this->isNameTagAlwaysVisible() ? 1 : 0);
        return $nbt;
    }

    public function attack(\pocketmine\event\entity\EntityDamageEvent $source): void {
        $source->cancel();
    }

    public function getTradeId(): string {
        return $this->tradeId;
    }

    public function onUpdate(int $currentTick): bool {
        $this->setMotion($this->getMotion()->withComponents(0, 0, 0));
        $this->setGravity(0.0);
        if ($this->isOnFire()) {
            $this->extinguish();
        }
        
        $hasUpdate = parent::onUpdate($currentTick);
        
        if ($currentTick % 2 === 0) {
            $nearest = null;
            $nearestDist = 100; // 10 blocks radius
            foreach ($this->getWorld()->getPlayers() as $player) {
                $dist = $this->getLocation()->distanceSquared($player->getLocation());
                if ($dist < $nearestDist) {
                    $nearest = $player;
                    $nearestDist = $dist;
                }
            }
            
            if ($nearest !== null) {
                $angle = $nearest->getLocation()->subtractVector($this->getLocation());
                $yaw = rad2deg(atan2(-$angle->x, $angle->z));
                $pitch = rad2deg(-atan2($angle->y, sqrt($angle->x * $angle->x + $angle->z * $angle->z)));
                $this->setRotation($yaw, $pitch);
                $hasUpdate = true;
            }
        }
        
        return $hasUpdate;
    }
    
    public function getTradeRecipes(): array {
        return TradeManager::getRecipes($this->tradeId);
    }
    
    public function getTradeInventory(): ?SimpleInventory {
        return $this->tradeInventory;
    }
    
    public function getOrCreateTradeInventory(): SimpleInventory {
        if ($this->tradeInventory === null) {
            $this->tradeInventory = new SimpleInventory(5);
        }
        return $this->tradeInventory;
    }

    public function getLevel(): int {
        return 1;
    }

    public function toggleNameTagVisibility(\pocketmine\player\Player $sender): void {
        $this->setNameTagAlwaysVisible(!$this->isNameTagAlwaysVisible());
        $this->despawnFromAll();
        $scheduler = \BeeAZ\AZTradeNPC\Main::getInstance()->getScheduler();
        $scheduler->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(function() use ($sender): void {
            if (!$this->isClosed()) {
                $this->spawnToAll();
                $sender->sendMessage(\pocketmine\utils\TextFormat::GREEN . "TradeNPC nametag visibility toggled to: " . ($this->isNameTagAlwaysVisible() ? 'Always' : 'Hover/Focus'));
            }
        }), 5);
    }
}
