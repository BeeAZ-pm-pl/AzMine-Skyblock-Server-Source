<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC\task;

use pocketmine\scheduler\AsyncTask;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\entity\Skin;
use BeeAZ\AZTradeNPC\entity\TradeNPC;
use pocketmine\utils\TextFormat;
use Ramsey\Uuid\Uuid;

class FetchSkinTask extends AsyncTask {

    private string $url;
    private int $entityId;
    private string $playerName;

    public function __construct(string $url, int $entityId, string $playerName) {
        $this->url = $url;
        $this->entityId = $entityId;
        $this->playerName = $playerName;
    }

    public function onRun(): void {
        $ch = curl_init($this->url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Accept: image/png, image/jpeg',
            'Cache-Control: no-cache'
        ]);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        
        $data = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($data === false || $httpCode !== 200) {
            $this->setResult(["success" => false]);
            return;
        }

        $src = @imagecreatefromstring($data);
        if ($src === false) {
            $this->setResult(["success" => false]);
            return;
        }

        $width = imagesx($src);
        $height = imagesy($src);

        if (!in_array($width, [64, 128]) || !in_array($height, [32, 64, 128])) {
            imagedestroy($src);
            $this->setResult(["success" => false]);
            return;
        }

        $is128 = ($width === 128 || $height === 128);
        $targetW = $is128 ? 128 : 64;
        $targetH = $is128 ? 128 : 64;

        $dst = imagecreatetruecolor($targetW, $targetH);
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefill($dst, 0, 0, $transparent);
        
        imagecopy($dst, $src, 0, 0, 0, 0, $width, $height);
        imagedestroy($src);

        $bytes = "";
        for ($y = 0; $y < $targetH; $y++) {
            for ($x = 0; $x < $targetW; $x++) {
                $color = imagecolorat($dst, $x, $y);
                $a = ((~((int)($color >> 24))) << 1) & 0xff;
                $r = ($color >> 16) & 0xff;
                $g = ($color >> 8) & 0xff;
                $b = $color & 0xff;
                $bytes .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        imagedestroy($dst);
        $this->setResult(["success" => true, "data" => $bytes]);
    }

    public function onCompletion(): void {
        $server = Server::getInstance();
        $player = $server->getPlayerExact($this->playerName);
        $entity = $server->getWorldManager()->findEntity($this->entityId);
        $result = $this->getResult();

        if ($player !== null) {
            if ($result === null || $result["success"] === false) {
                $player->sendMessage(TextFormat::colorize("&c[Lỗi] Không thể tải Skin từ URL, vui lòng kiểm tra lại."));
                return;
            }

            if ($entity instanceof TradeNPC && !$entity->isClosed()) {
                try {
                    $newSkinId = Uuid::uuid4()->toString();
                    
                    $newSkin = new Skin(
                        $newSkinId,
                        $result["data"],
                        "",
                        "geometry.humanoid.custom",
                        self::getSteveGeometry()
                    );
                    
                    $entity->setSkin($newSkin);
                    $entity->sendSkin($entity->getViewers());
                    $entity->getWorld()->save(true);
                    
                    $entity->despawnFromAll();
                    
                    $validPlugin = null;
                    foreach($server->getPluginManager()->getPlugins() as $p){
                        if($p->isEnabled()){
                            $validPlugin = $p;
                            break;
                        }
                    }
                    
                    if($validPlugin !== null){
                        $validPlugin->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($entity): void {
                            if(!$entity->isClosed()){
                                $entity->spawnToAll();
                            }
                        }), 5);
                    } else {
                        $entity->spawnToAll();
                    }
                    
                    $player->sendMessage(TextFormat::colorize("&a[Thành công] Đã cập nhật Skin mới cho NPC!"));
                } catch (\Exception $e) {
                    $player->sendMessage(TextFormat::colorize("&c[Lỗi] Không thể áp dụng Skin: &f" . $e->getMessage()));
                }
            } else {
                $player->sendMessage(TextFormat::colorize("&c[Lỗi] Không tìm thấy NPC (có thể đã bị xóa)."));
            }
        }
    }

    public static function getSteveGeometry(): string {
        return json_encode([
            "format_version" => "1.12.0",
            "minecraft:geometry" => [
                [
                    "description" => [
                        "identifier" => "geometry.humanoid.custom",
                        "visible_bounds_width" => 1.0,
                        "visible_bounds_height" => 2.0,
                        "visible_bounds_offset" => [0.0, 1.0, 0.0],
                        "texture_width" => 64,
                        "texture_height" => 64
                    ],
                    "bones" => [
                        ["name" => "root", "pivot" => [0.0, 0.0, 0.0]],
                        [
                            "name" => "body",
                            "parent" => "waist",
                            "pivot" => [0.0, 24.0, 0.0],
                            "cubes" => [
                                ["origin" => [-4.0, 12.0, -2.0], "size" => [8, 12, 4], "uv" => [16, 16]]
                            ]
                        ],
                        ["name" => "waist", "parent" => "root", "pivot" => [0.0, 12.0, 0.0]],
                        [
                            "name" => "head",
                            "parent" => "body",
                            "pivot" => [0.0, 24.0, 0.0],
                            "cubes" => [
                                ["origin" => [-4.0, 24.0, -4.0], "size" => [8, 8, 8], "uv" => [0, 0]]
                            ]
                        ],
                        ["name" => "cape", "pivot" => [0.0, 24.0, 3.0], "parent" => "body"],
                        [
                            "name" => "hat",
                            "parent" => "head",
                            "pivot" => [0.0, 24.0, 0.0],
                            "cubes" => [
                                ["origin" => [-4.0, 24.0, -4.0], "size" => [8, 8, 8], "uv" => [32, 0], "inflate" => 0.5]
                            ]
                        ],
                        [
                            "name" => "leftArm",
                            "parent" => "body",
                            "pivot" => [5.0, 22.0, 0.0],
                            "cubes" => [
                                ["origin" => [4.0, 12.0, -2.0], "size" => [4, 12, 4], "uv" => [32, 48]]
                            ]
                        ],
                        [
                            "name" => "leftSleeve",
                            "parent" => "leftArm",
                            "pivot" => [5.0, 22.0, 0.0],
                            "cubes" => [
                                ["origin" => [4.0, 12.0, -2.0], "size" => [4, 12, 4], "uv" => [48, 48], "inflate" => 0.25]
                            ]
                        ],
                        ["name" => "leftItem", "pivot" => [6.0, 15.0, 1.0], "parent" => "leftArm"],
                        [
                            "name" => "rightArm",
                            "parent" => "body",
                            "pivot" => [-5.0, 22.0, 0.0],
                            "cubes" => [
                                ["origin" => [-8.0, 12.0, -2.0], "size" => [4, 12, 4], "uv" => [40, 16]]
                            ]
                        ],
                        [
                            "name" => "rightSleeve",
                            "parent" => "rightArm",
                            "pivot" => [-5.0, 22.0, 0.0],
                            "cubes" => [
                                ["origin" => [-8.0, 12.0, -2.0], "size" => [4, 12, 4], "uv" => [40, 32], "inflate" => 0.25]
                            ]
                        ],
                        [
                            "name" => "rightItem",
                            "pivot" => [-6.0, 15.0, 1.0],
                            "locators" => ["lead_hold" => [-6.0, 15.0, 1.0]],
                            "parent" => "rightArm"
                        ],
                        [
                            "name" => "leftLeg",
                            "parent" => "root",
                            "pivot" => [1.9, 12.0, 0.0],
                            "cubes" => [
                                ["origin" => [-0.1, 0.0, -2.0], "size" => [4, 12, 4], "uv" => [16, 48]]
                            ]
                        ],
                        [
                            "name" => "leftPants",
                            "parent" => "leftLeg",
                            "pivot" => [1.9, 12.0, 0.0],
                            "cubes" => [
                                ["origin" => [-0.1, 0.0, -2.0], "size" => [4, 12, 4], "uv" => [0, 48], "inflate" => 0.25]
                            ]
                        ],
                        [
                            "name" => "rightLeg",
                            "parent" => "root",
                            "pivot" => [-1.9, 12.0, 0.0],
                            "cubes" => [
                                ["origin" => [-3.9, 0.0, -2.0], "size" => [4, 12, 4], "uv" => [0, 16]]
                            ]
                        ],
                        [
                            "name" => "rightPants",
                            "parent" => "rightLeg",
                            "pivot" => [-1.9, 12.0, 0.0],
                            "cubes" => [
                                ["origin" => [-3.9, 0.0, -2.0], "size" => [4, 12, 4], "uv" => [0, 32], "inflate" => 0.25]
                            ]
                        ],
                        [
                            "name" => "jacket",
                            "parent" => "body",
                            "pivot" => [0.0, 24.0, 0.0],
                            "cubes" => [
                                ["origin" => [-4.0, 12.0, -2.0], "size" => [8, 12, 4], "uv" => [16, 32], "inflate" => 0.25]
                            ]
                        ]
                    ]
                ]
            ]
        ], JSON_UNESCAPED_SLASHES);
    }
}
