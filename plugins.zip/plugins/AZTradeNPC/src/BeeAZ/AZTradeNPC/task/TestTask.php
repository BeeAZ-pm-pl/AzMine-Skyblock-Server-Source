<?php
use pocketmine\item\StringToItemParser;

$items = ['ender_pearl', 'phantom_membrane', 'elytra', 'blaze_rod', 'ghast_tear', 'arrow'];

$str = "TESTING ITEMS:\n";
foreach($items as $i) {
    try {
        $item = StringToItemParser::getInstance()->parse($i);
        if ($item !== null) {
            $str .= "$i => OK (" . $item->getName() . ")\n";
        } else {
            $item2 = \pocketmine\item\LegacyStringToItemParser::getInstance()->parse($i);
            $str .= "$i => LEGACY OK (" . $item2->getName() . ")\n";
        }
    } catch (\Throwable $e) {
        $str .= "$i => FAILED\n";
    }
}
file_put_contents("test_out.txt", $str);
