<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC\ui;

use pocketmine\player\Player;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Toggle;
use BeeAZ\AZTradeNPC\entity\TradeNPC;
use BeeAZ\AZTradeNPC\manager\TradeManager;
use BeeAZ\AZTradeNPC\task\FetchSkinTask;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;

class UI {

    public static function sendEditNPCMenu(Player $player, TradeNPC $npc): void {
        $form = new MenuForm(
            "§l§eCHỈNH SỬA TRADENPC",
            "Chọn hành động:",
            [
                new MenuOption("§l§aChỉnh sửa Đồ\n§r§8Chỉnh sửa đồ bằng InvMenu"),
                new MenuOption("§l§eĐổi Tên\n§r§8Đổi tên hiển thị của NPC"),
                new MenuOption("§l§bBật/Tắt Nametag\n§r§8" . ($npc->isNameTagAlwaysVisible() ? "Đang: Luôn hiện" : "Đang: Chỉ hiện khi nhìn")),
                new MenuOption("§l§dĐổi Skin (URL)\n§r§8Dùng link ảnh đuôi .png")
            ],
            function(Player $submitter, int $selected) use ($npc): void {
                if ($npc->isClosed()) return;
                
                if ($selected === 0) {
                    self::sendEditTrades($submitter, $npc);
                } elseif ($selected === 1) {
                    self::sendEditName($submitter, $npc);
                } elseif ($selected === 2) {
                    $npc->setNameTagAlwaysVisible(!$npc->isNameTagAlwaysVisible());
                    $npc->sendData($npc->getViewers());
                    $status = $npc->isNameTagAlwaysVisible() ? "Luôn hiện" : "Chỉ hiện khi nhìn";
                    $submitter->sendMessage("§aĐã đổi trạng thái Nametag: §f{$status}");
                } elseif ($selected === 3) {
                    self::sendEditSkin($submitter, $npc);
                }
            }
        );
        $player->sendForm($form);
    }

    public static function sendEditSkin(Player $player, TradeNPC $npc): void {
        $form = new CustomForm(
            "§l§dĐỔI SKIN NPC",
            [
                new Input("url", "Nhập URL ảnh Skin (phải là đuôi .png và kích thước chuẩn 64x64 hoặc 128x128):", "https://example.com/skin.png")
            ],
            function(Player $submitter, CustomFormResponse $response) use ($npc): void {
                if ($npc->isClosed()) return;
                $url = $response->getString("url");
                if (trim($url) === "") {
                    $submitter->sendMessage("§cURL không được để trống!");
                    return;
                }
                $submitter->sendMessage("§eĐang tiến hành tải Skin từ URL, vui lòng đợi...");
                \pocketmine\Server::getInstance()->getAsyncPool()->submitTask(new FetchSkinTask($url, $npc->getId(), $submitter->getName()));
            }
        );
        $player->sendForm($form);
    }

    public static function sendEditName(Player $player, TradeNPC $npc): void {
        $form = new CustomForm(
            "§l§eĐỔI TÊN NPC",
            [
                new Input("name", "Tên NPC (dùng & để tô màu, {line} để xuống dòng)", "", str_replace(["\n", "§"], ["{line}", "&"], $npc->getNameTag()))
            ],
            function(Player $submitter, CustomFormResponse $response) use ($npc): void {
                if ($npc->isClosed()) return;
                $name = $response->getString("name");
                $npc->setNameTag(str_replace("{line}", "\n", \pocketmine\utils\TextFormat::colorize($name)));
                $submitter->sendMessage("§aCập nhật tên thành công!");
            }
        );
        $player->sendForm($form);
    }

    public static function sendEditTrades(Player $player, TradeNPC $npc): void {
        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§l§eChỉnh sửa Đồ (A | B | Thành Phẩm)");
        
        $recipes = $npc->getTradeRecipes();
        $inv = $menu->getInventory();
        
        $slot = 0;
        foreach ($recipes as $r) {
            if ($slot + 2 >= 54) break; 
            $inv->setItem($slot, $r['buyA']);
            $inv->setItem($slot + 1, $r['buyB']);
            $inv->setItem($slot + 2, $r['sell']);
            $slot += 3;
        }

        $menu->setListener(function(InvMenuTransaction $transaction) : InvMenuTransactionResult {
            return $transaction->continue();
        });
        
        $menu->setInventoryCloseListener(function(Player $closer, \pocketmine\inventory\Inventory $inventory) use ($npc): void {
            if ($npc->isClosed()) return;
            
            $newRecipes = [];
            for ($i = 0; $i < 54; $i += 3) {
                $buyA = $inventory->getItem($i);
                $buyB = $inventory->getItem($i + 1);
                $sell = $inventory->getItem($i + 2);
                
                if (!$buyA->isNull() && !$sell->isNull()) {
                    $newRecipes[] = [
                        'buyA' => clone $buyA,
                        'buyB' => clone $buyB,
                        'sell' => clone $sell,
                        'tier' => 1,
                        'uses' => 0,
                        'maxUses' => 9999,
                        'rewardExp' => 0,
                        'traderExp' => 0,
                        'priceMultiplierA' => 0.0,
                        'priceMultiplierB' => 0.0,
                        'demand' => 0
                    ];
                }
            }
            
            TradeManager::saveRecipes($npc->getTradeId(), $newRecipes);
            $closer->sendMessage("§aĐã lưu thành công dữ liệu vào cấu hình! Có thể dùng AI để config nhanh.");
        });

        $menu->send($player);
    }
}
