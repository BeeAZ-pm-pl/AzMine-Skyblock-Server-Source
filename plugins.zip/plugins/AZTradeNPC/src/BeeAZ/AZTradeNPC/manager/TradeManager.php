<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC\manager;

use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\item\StringToItemParser;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\utils\Config;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ByteTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\protocol\types\CacheableNbt;
use pocketmine\network\mcpe\convert\TypeConverter;
use pocketmine\world\format\io\GlobalItemDataHandlers;
use BeeAZ\AZTradeNPC\Main;

class TradeManager {
    private static ?array $customLoreMap = null;

    public static function loadCustomLoreMap(): void {
        if (self::$customLoreMap !== null) return;
        self::$customLoreMap = [];
        
        $tradesFolder = Main::getInstance()->getDataFolder() . "trades/";
        if (!is_dir($tradesFolder)) return;
        
        foreach (glob($tradesFolder . "*.yml") as $file) {
            try {
                $config = new Config($file, Config::YAML);
                $tradesData = $config->get("trades", []);
                foreach ($tradesData as $t) {
                    if (isset($t['sell']) && isset($t['sell']['name']) && isset($t['sell']['lore'])) {
                        $name = str_replace("&", "§", $t['sell']['name']);
                        $lore = array_map(fn($l) => str_replace("&", "§", $l), (array)$t['sell']['lore']);
                        self::$customLoreMap[$name] = $lore;
                    }
                }
            } catch (\Throwable $e) {}
        }
    }
    
    
    public static function createDefaultConfig(string $tradeId): void {
        $path = Main::getInstance()->getDataFolder() . "trades/" . $tradeId . ".yml";
        if (!file_exists($path)) {
            $config = new Config($path, Config::YAML);
            $config->set("trades", []);
            $config->save();
        }
    }

    public static function getRecipes(string $tradeId): array {
        $path = Main::getInstance()->getDataFolder() . "trades/" . $tradeId . ".yml";
        if (!file_exists($path)) return [];
        $config = new Config($path, Config::YAML);
        $tradesData = $config->get("trades", []);
        
        $recipes = [];
        foreach ($tradesData as $t) {
            if (!isset($t['sell']) || !isset($t['buyA'])) continue;
            $recipes[] = [
                'buyA' => self::deserializeItem($t['buyA']),
                'buyB' => isset($t['buyB']) ? self::deserializeItem($t['buyB']) : VanillaItems::AIR(),
                'sell' => self::deserializeItem($t['sell']),
                'tier' => 1,
                'uses' => 0,
                'maxUses' => $t['maxUses'] ?? 9999,
                'rewardExp' => $t['rewardExp'] ?? 0,
                'traderExp' => $t['traderExp'] ?? 0,
                'priceMultiplierA' => $t['priceMultiplierA'] ?? 0.0,
                'priceMultiplierB' => $t['priceMultiplierB'] ?? 0.0,
                'demand' => $t['demand'] ?? 0
            ];
        }
        return $recipes;
    }

    public static function saveRecipes(string $tradeId, array $recipes): void {
        $path = Main::getInstance()->getDataFolder() . "trades/" . $tradeId . ".yml";
        $config = new Config($path, Config::YAML);
        
        $tradesData = [];
        foreach ($recipes as $r) {
            $data = [
                'buyA' => self::serializeItem($r['buyA']),
                'sell' => self::serializeItem($r['sell']),
            ];
            if (isset($r['buyB']) && !$r['buyB']->isNull()) {
                $data['buyB'] = self::serializeItem($r['buyB']);
            }
            $tradesData[] = $data;
        }
        $config->set("trades", $tradesData);
        $config->save();
    }

    public static function getEnchantmentName(\pocketmine\item\enchantment\Enchantment $enchantment): string {
        static $cachedMap = null;
        if ($cachedMap === null) {
            $parser = StringToEnchantmentParser::getInstance();
            $ref = new \ReflectionClass($parser);
            $parent = $ref->getParentClass();
            $prop = $parent->getProperty('callbackMap');
            $prop->setAccessible(true);
            $map = $prop->getValue($parser);
            
            $cachedMap = [];
            foreach ($map as $key => $callback) {
                try {
                    $item = $callback();
                    if ($item instanceof \pocketmine\item\enchantment\Enchantment) {
                        $cachedMap[spl_object_id($item)] = $key;
                    }
                } catch (\Throwable $e) {}
            }
        }
        return $cachedMap[spl_object_id($enchantment)] ?? "unknown";
    }

    public static function serializeItem(Item $item): array {
        if ($item->isNull()) return ["id" => "minecraft:air", "count" => 0];
        
        $id = StringToItemParser::getInstance()->lookupAliases($item)[0] ?? "unknown";
        if($id === "unknown") {
            try {
                $id = \pocketmine\world\format\io\GlobalItemDataHandlers::getSerializer()->serializeType($item)->getName();
            } catch (\Throwable $e) {
                $id = "minecraft:air";
            }
        }
        
        $data = [
            "id" => $id,
            "count" => $item->getCount()
        ];
        
        if ($item->hasCustomName()) {
            $data["name"] = str_replace("§", "&", $item->getCustomName());
        }
        if (count($item->getLore()) > 0) {
            $data["lore"] = array_map(fn($l) => str_replace("§", "&", $l), $item->getLore());
        }
        
        if ($item->hasEnchantments()) {
            $data["enchants"] = [];
            foreach ($item->getEnchantments() as $ench) {
                $name = self::getEnchantmentName($ench->getType());
                if($name !== "unknown") {
                    $data["enchants"][$name] = $ench->getLevel();
                }
            }
        }
        return $data;
    }

    public static function deserializeItem(array $data): Item {
        if (!isset($data["id"]) || $data["id"] === "minecraft:air" || $data["id"] === "air") {
            return VanillaItems::AIR();
        }
        
        $item = StringToItemParser::getInstance()->parse($data["id"]);
        if ($item === null) {
            try {
                $item = \pocketmine\item\LegacyStringToItemParser::getInstance()->parse($data["id"]);
            } catch (\Exception $e) {
                $item = VanillaItems::AIR();
            }
        }
        
        if (($item === null || $item->isNull()) && !in_array(strtolower($data["id"]), ["air", "minecraft:air"])) {
            Main::getInstance()->getLogger()->warning("Failed to parse item ID: " . $data["id"] . " in trade configuration!");
        }

        if ($item->isNull()) return $item;
        
        $item->setCount($data["count"] ?? 1);
        
        if (isset($data["name"])) {
            $item->setCustomName(str_replace("&", "§", $data["name"]));
        }
        if (isset($data["lore"]) && is_array($data["lore"])) {
            $item->setLore(array_map(fn($l) => str_replace("&", "§", $l), $data["lore"]));
        }
        if (isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach ($data["enchants"] as $enchName => $level) {
                $enchantment = StringToEnchantmentParser::getInstance()->parse($enchName);
                if ($enchantment !== null) {
                    $item->addEnchantment(new EnchantmentInstance($enchantment, (int)$level));
                }
            }
        }
        
        if ($item->hasCustomName() && empty($item->getLore())) {
            self::loadCustomLoreMap();
            $customName = $item->getCustomName();
            if (isset(self::$customLoreMap[$customName])) {
                $item->setLore(self::$customLoreMap[$customName]);
            }
        }

        // Soft-dependency: rebuild lore cho AZCustomEnchants nếu plugin đang load
        if (class_exists(\BeeAZ\AZCustomEnchants\manager\StatsManager::class)) {
            \BeeAZ\AZCustomEnchants\manager\StatsManager::checkAndRebuildLore($item);
        }
        return $item;
    }

    public static function getItemNbt(Item $item): CompoundTag {
        if ($item->isNull()) {
            return CompoundTag::create()
                ->setByte("Count", 0)
                ->setShort("Damage", 0)
                ->setString("Name", "minecraft:air");
        }
        
        try {
            $netItem = TypeConverter::getInstance()->coreItemStackToNet($item);
            $itemName = GlobalItemDataHandlers::getSerializer()->serializeType($item)->getName();
        } catch (\Throwable $e) {
            return CompoundTag::create()
                ->setByte("Count", 0)
                ->setShort("Damage", 0)
                ->setString("Name", "minecraft:air");
        }

        $tag = CompoundTag::create()
            ->setByte("Count", $item->getCount())
            ->setShort("Damage", $netItem->getMeta())
            ->setString("Name", $itemName);

        if ($item->hasNamedTag()) {
            $tag->setTag("tag", clone $item->getNamedTag());
        }

        return $tag;
    }

    public static function buildOffersNbt(array $recipes): CacheableNbt {
        $recipesList = new ListTag();
        foreach ($recipes as $idx => $recipe) {
            $buyA = $recipe['buyA'];
            $buyB = $recipe['buyB'] ?? null;
            $sell = $recipe['sell'];

            $nbt = CompoundTag::create()
                ->setTag("buyA", self::getItemNbt($buyA))
                ->setInt("buyCountA", $buyA->getCount())
                ->setTag("sell", self::getItemNbt($sell))
                ->setInt("tier", ($recipe['tier'] ?? 1) - 1)
                ->setInt("uses", 0)
                ->setInt("maxUses", $recipe['maxUses'] ?? 9999)
                ->setByte("rewardExp", (int)($recipe['rewardExp'] ?? 0))
                ->setInt("traderExp", $recipe['traderExp'] ?? 0)
                ->setFloat("priceMultiplierA", $recipe['priceMultiplierA'] ?? 0.0)
                ->setFloat("priceMultiplierB", $recipe['priceMultiplierB'] ?? 0.0)
                ->setInt("demand", $recipe['demand'] ?? 0)
                ->setInt("recipeNetworkId", 32000 + $idx);

            if ($buyB !== null && !$buyB->isNull()) {
                $nbt->setTag("buyB", self::getItemNbt($buyB));
                $nbt->setInt("buyCountB", $buyB->getCount());
            }

            $recipesList->push($nbt);
        }

        $offers = CompoundTag::create()
            ->setTag("Recipes", $recipesList);

        return new CacheableNbt($offers);
    }
}
