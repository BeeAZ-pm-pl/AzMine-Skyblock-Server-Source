<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC\listener;

use BeeAZ\AZTradeNPC\Main;
use BeeAZ\AZTradeNPC\entity\TradeNPC;
use BeeAZ\AZTradeNPC\command\TradeCommand;
use BeeAZ\AZTradeNPC\manager\TradeManager;
use BeeAZ\AZTradeNPC\ui\UI;
use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\player\PlayerEntityInteractEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\ContainerClosePacket;
use pocketmine\network\mcpe\protocol\UpdateTradePacket;
use pocketmine\network\mcpe\protocol\ContainerOpenPacket;
use pocketmine\network\mcpe\protocol\PlayerAuthInputPacket;
use pocketmine\network\mcpe\protocol\ItemStackRequestPacket;
use pocketmine\network\mcpe\protocol\types\inventory\ContainerUIIds;
use pocketmine\network\mcpe\protocol\types\inventory\WindowTypes;
use pocketmine\network\mcpe\protocol\types\inventory\stackrequest\ItemStackRequestSlotInfo;
use pocketmine\network\mcpe\protocol\types\inventory\stackrequest\CraftRecipeStackRequestAction;
use pocketmine\network\mcpe\protocol\types\inventory\stackrequest\CraftRecipeAutoStackRequestAction;
use pocketmine\scheduler\ClosureTask;
use pocketmine\entity\object\ExperienceOrb;
use pocketmine\entity\Location;

class TradeListener implements Listener {

    private Main $plugin;
    public static array $trading = [];
    public static array $tradeOffset = [];
    public static array $clientRecipeCount = [];
    public static array $fakeIds = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $playerName = $event->getPlayer()->getName();
        self::closeTrade($event->getPlayer());
        unset(self::$trading[$playerName]);
        unset(self::$tradeOffset[$playerName]);
    }

    public function onPlayerInteractEntity(PlayerEntityInteractEvent $event): void {
        $player = $event->getPlayer();
        $entity = $event->getEntity();

        if ($entity instanceof TradeNPC) {
            $event->cancel();

            if (isset(TradeCommand::$editMode[$player->getName()])) {
                UI::sendEditNPCMenu($player, $entity);
                return;
            }

            if (isset(TradeCommand::$removeMode[$player->getName()])) {
                $entity->close();
                $player->sendMessage("§aĐã xóa TradeNPC.");
                return;
            }

            $recipes = $entity->getTradeRecipes();
            if (empty($recipes)) {
                $player->sendMessage("§cNPC này chưa có đồ gì để trao đổi.");
                return;
            }

            self::openTrade($player, $entity);
        }
    }

    public static function openTrade(Player $player, TradeNPC $npc): void {
        if (isset(self::$trading[$player->getName()])) {
            self::closeTrade($player);
        }

        self::$trading[$player->getName()] = $npc;

        $inv = $npc->getOrCreateTradeInventory();
        $inv->clearAll();

        $playerName = $player->getName();
        $recipes = $npc->getTradeRecipes();

        $craftingManager = $player->getServer()->getCraftingManager();
        $craftingCount = count($craftingManager->getCraftingRecipeIndex());
        $furnaceCount = 0;
        foreach (\pocketmine\crafting\FurnaceType::cases() as $furnaceType) {
            $furnaceCount += count($craftingManager->getFurnaceRecipeManager($furnaceType)->getAll());
        }
        $initialOffset = $craftingCount + $furnaceCount + 1;

        self::$tradeOffset[$playerName] = $initialOffset;

        $invManager = $player->getNetworkSession()->getInvManager();
        if ($invManager !== null) {
            try {
                $reflection = new \ReflectionClass($invManager);

                $addComplexMethod = $reflection->getMethod("addComplex");
                $addComplexMethod->setAccessible(true);
                
                $addComplexMethod->invoke($invManager, [4 => 0, 5 => 1, 6 => 2, 7 => 3, 8 => 4], $inv);

                $associateMethod = $reflection->getMethod("associateIdWithInventory");
                $associateMethod->setAccessible(true);
                $associateMethod->invoke($invManager, 99, $inv);

                $invManager->syncContents($inv);
            } catch (\Throwable $t) {
            }
        }

        $fakeEntityId = \pocketmine\entity\Entity::nextRuntimeId();
        self::$fakeIds[$playerName] = $fakeEntityId;
        
        $addActor = new \pocketmine\network\mcpe\protocol\AddActorPacket();
        $addActor->actorUniqueId = $fakeEntityId;
        $addActor->actorRuntimeId = $fakeEntityId;
        $addActor->type = "minecraft:villager_v2";
        $addActor->position = $player->getPosition()->add(0, 5, 0);
        $addActor->motion = new \pocketmine\math\Vector3(0, 0, 0);
        $addActor->yaw = 0.0;
        $addActor->pitch = 0.0;
        $addActor->headYaw = 0.0;
        $addActor->bodyYaw = 0.0;
        $addActor->attributes = [];
        $addActor->links = [];
        $addActor->syncedProperties = new \pocketmine\network\mcpe\protocol\types\entity\PropertySyncData([], []);
        $addActor->senderSubId = 0;
        $addActor->recipientSubId = 0;
        $addActor->metadata = [
            \pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties::FLAGS => new \pocketmine\network\mcpe\protocol\types\entity\LongMetadataProperty(
                1 << \pocketmine\network\mcpe\protocol\types\entity\EntityMetadataFlags::INVISIBLE
            ),
            \pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties::HAS_NPC_COMPONENT => new \pocketmine\network\mcpe\protocol\types\entity\ByteMetadataProperty(1)
        ];
        $player->getNetworkSession()->sendDataPacket($addActor);

        $openPk = ContainerOpenPacket::entityInv(99, WindowTypes::TRADING, $fakeEntityId);
        $player->getNetworkSession()->sendDataPacket($openPk);

        $offersNbt = TradeManager::buildOffersNbt($recipes);
        $pk = UpdateTradePacket::create(
            99, WindowTypes::TRADING, 0, $npc->getLevel() - 1, $fakeEntityId, $player->getId(), $npc->getNameTag() !== "" ? $npc->getNameTag() : "Thương Nhân", true, false, $offersNbt
        );
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    public static function refreshTrade(Player $player, TradeNPC $npc): void {
        $playerName = $player->getName();
        $recipes = $npc->getTradeRecipes();

        $craftingManager = $player->getServer()->getCraftingManager();
        $craftingCount = count($craftingManager->getCraftingRecipeIndex());
        $furnaceCount = 0;
        foreach (\pocketmine\crafting\FurnaceType::cases() as $furnaceType) {
            $furnaceCount += count($craftingManager->getFurnaceRecipeManager($furnaceType)->getAll());
        }
        $initialOffset = $craftingCount + $furnaceCount + 1;

        self::$tradeOffset[$playerName] = $initialOffset;
        
        $fakeEntityId = self::$fakeIds[$playerName] ?? $npc->getId();

        $offersNbt = TradeManager::buildOffersNbt($recipes);
        $pk = UpdateTradePacket::create(
            99, WindowTypes::TRADING, 0, $npc->getLevel() - 1, $fakeEntityId, $player->getId(), $npc->getNameTag() !== "" ? $npc->getNameTag() : "Thương Nhân", true, false, $offersNbt
        );
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    public static function closeTrade(Player $player): void {
        $name = $player->getName();
        unset(self::$tradeOffset[$name]);
        if (isset(self::$trading[$name])) {
            $npc = self::$trading[$name];
            unset(self::$trading[$name]);

            $inv = $npc->getTradeInventory();
            if ($inv !== null) {
                for ($slot = 0; $slot <= 1; $slot++) {
                    $item = $inv->getItem($slot);
                    if (!$item->isNull()) {
                        $leftovers = $player->getInventory()->addItem($item);
                        foreach ($leftovers as $l) {
                            $player->getWorld()->dropItem($player->getLocation(), $l);
                        }
                        $inv->clear($slot);
                    }
                }
                $inv->clear(2);
                $inv->clear(3);
                $inv->clear(4);
            }

            $player->getNetworkSession()->sendDataPacket(ContainerClosePacket::create(99, WindowTypes::TRADING, true));

            $invManager = $player->getNetworkSession()->getInvManager();
            if ($invManager !== null) {
                try {
                    $reflection = new \ReflectionClass($invManager);
                    $removeMethod = $reflection->getMethod("remove");
                    $removeMethod->setAccessible(true);
                    $removeMethod->invoke($invManager, 99);
                } catch (\Throwable $t) {
                }
                $invManager->syncAll();
            }
            
            if (isset(self::$fakeIds[$name])) {
                $fakeId = self::$fakeIds[$name];
                $rmPk = \pocketmine\network\mcpe\protocol\RemoveActorPacket::create($fakeId);
                $player->getNetworkSession()->sendDataPacket($rmPk);
                unset(self::$fakeIds[$name]);
            }
        }
    }

    public function onDataPacketReceive(DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();

        if ($packet instanceof PlayerAuthInputPacket) {
            $player = $event->getOrigin()->getPlayer();
            if ($player !== null && isset(self::$trading[$player->getName()])) {
                $npc = self::$trading[$player->getName()];
                if (!$npc->isAlive() || $player->getWorld() !== $npc->getWorld() || $player->getLocation()->distanceSquared($npc->getLocation()) > 64) {
                    self::closeTrade($player);
                }
            }
        } elseif ($packet instanceof ContainerClosePacket) {
            $player = $event->getOrigin()->getPlayer();
            if ($player !== null && isset(self::$trading[$player->getName()])) {
                if ($packet->windowId === 99) {
                    self::closeTrade($player);
                }
            }
        } elseif ($packet instanceof ItemStackRequestPacket) {
            $player = $event->getOrigin()->getPlayer();
            if ($player === null || !isset(self::$trading[$player->getName()])) return;

            $npc = self::$trading[$player->getName()];
            $tradeInv = $npc->getTradeInventory();
            if ($tradeInv === null) return;

            try {
                $reflectionPacket = new \ReflectionClass($packet);
                $requestsProp = $reflectionPacket->getProperty("requests");
                $requestsProp->setAccessible(true);
                $requests = $requestsProp->getValue($packet);

                $spoofedStackIds = [];

                foreach ($requests as $request) {
                    $reflectionRequest = new \ReflectionClass($request);
                    $actionsProp = $reflectionRequest->getProperty("actions");
                    $actionsProp->setAccessible(true);
                    $actions = $actionsProp->getValue($request);

                    foreach ($actions as $action) {
                        $actionRefl = new \ReflectionClass($action);
                        foreach (["source", "destination"] as $propName) {
                            if ($actionRefl->hasProperty($propName)) {
                                $prop = $actionRefl->getProperty($propName);
                                $prop->setAccessible(true);
                                $slotInfo = $prop->getValue($action);
                                if ($slotInfo instanceof ItemStackRequestSlotInfo) {
                                    $cid = $slotInfo->getContainerName()->getContainerId();
                                    $sid = $slotInfo->getSlotId();
                                    $stackId = $slotInfo->getStackId();

                                    $targetSlot = null;
                                    if ($cid === ContainerUIIds::TRADE_INGREDIENT1 || $cid === ContainerUIIds::TRADE2_INGREDIENT1) {
                                        if ($sid === 4) $targetSlot = 0;
                                        elseif ($sid === 5) $targetSlot = 1;
                                        elseif ($sid === 6) $targetSlot = 2;
                                        elseif ($sid === 7) $targetSlot = 3;
                                        elseif ($sid === 8) $targetSlot = 4;
                                        elseif ($sid !== 50) $targetSlot = 0; 
                                    } elseif ($cid === ContainerUIIds::TRADE_INGREDIENT2 || $cid === ContainerUIIds::TRADE2_INGREDIENT2) {
                                        $targetSlot = 1;
                                    } elseif ($cid === ContainerUIIds::CREATED_OUTPUT) {
                                        $targetSlot = 2;
                                    }

                                    if ($targetSlot !== null) {
                                        $spoofedStackIds[$targetSlot] = $stackId;
                                        self::setItemStackId($player, $tradeInv, $targetSlot, $stackId);
                                    }
                                }
                            }
                        }
                    }
                }

                $hasTrade = false;
                $rawRecipeId = null;
                $totalCount = 0;
                $multiplier = 1;

                foreach ($requests as $request) {
                    $reflectionRequest = new \ReflectionClass($request);
                    $actionsProp = $reflectionRequest->getProperty("actions");
                    $actionsProp->setAccessible(true);
                    $actions = $actionsProp->getValue($request);

                    $newActions = [];
                    $consumeIndex = 0;

                    foreach ($actions as $action) {
                        $className = get_class($action);
                        
                        if ($action instanceof \pocketmine\network\mcpe\protocol\types\inventory\stackrequest\CraftingConsumeInputStackRequestAction) {
                            $actionRefl = new \ReflectionClass($action);
                            $sourceProp = $actionRefl->getProperty("source");
                            $sourceProp->setAccessible(true);
                            $source = $sourceProp->getValue($action);
                            
                            $count = 1;
                            if (method_exists($action, "getCount")) {
                                $count = $action->getCount();
                            } elseif ($actionRefl->hasProperty("count")) {
                                $countProp = $actionRefl->getProperty("count");
                                $countProp->setAccessible(true);
                                $count = $countProp->getValue($action);
                            }
                            
                            $fnClass = "pocketmine\\network\\mcpe\\protocol\\types\\inventory\\FullContainerName";
                            $cName = new $fnClass(ContainerUIIds::TRADE2_INGREDIENT1);
                            $infoClass = "pocketmine\\network\\mcpe\\protocol\\types\\inventory\\stackrequest\\ItemStackRequestSlotInfo";
                            $destSlotInfo = new $infoClass($cName, 7 + $consumeIndex, 0);
                            $consumeIndex++;

                            $placeActionClass = "pocketmine\\network\\mcpe\\protocol\\types\\inventory\\stackrequest\\PlaceStackRequestAction";
                            $newActions[] = new $placeActionClass($count, $source, $destSlotInfo);
                            continue;
                        }

                        if (str_contains($className, "Craft") || str_contains($className, "Crafting")) {
                            if ($action instanceof CraftRecipeStackRequestAction || $action instanceof CraftRecipeAutoStackRequestAction) {
                                $hasTrade = true;
                                $rawRecipeId = $action->getRecipeId();
                                if ($action instanceof CraftRecipeAutoStackRequestAction) {
                                    $multiplier = $action->getRepetitions();
                                }
                            }
                            continue;
                        }
                        if ($action instanceof \pocketmine\network\mcpe\protocol\types\inventory\stackrequest\CreativeCreateStackRequestAction) {
                            return; 
                        }

                        $actionRefl = new \ReflectionClass($action);
                        foreach (["source", "destination"] as $propName) {
                            if ($actionRefl->hasProperty($propName)) {
                                $prop = $actionRefl->getProperty($propName);
                                $prop->setAccessible(true);
                                $slotInfo = $prop->getValue($action);
                                if ($slotInfo instanceof ItemStackRequestSlotInfo) {
                                    $cName = $slotInfo->getContainerName();
                                    $cid = $cName->getContainerId();
                                    if ($cid === ContainerUIIds::CREATED_OUTPUT) {
                                        $cRefl = new \ReflectionClass($cName);
                                        $idProp = $cRefl->getProperty("containerId");
                                        $idProp->setAccessible(true);
                                        $idProp->setValue($cName, ContainerUIIds::TRADE2_INGREDIENT1);

                                        $slotInfoRefl = new \ReflectionClass($slotInfo);
                                        $slotIdProp = $slotInfoRefl->getProperty("slotId");
                                        $slotIdProp->setAccessible(true);
                                        $slotIdProp->setValue($slotInfo, 6);
                                        
                                        if ($propName === "source") {
                                            if (method_exists($action, "getCount")) {
                                                $totalCount += $action->getCount();
                                            } elseif ($actionRefl->hasProperty("count")) {
                                                $countProp = $actionRefl->getProperty("count");
                                                $countProp->setAccessible(true);
                                                $totalCount += $countProp->getValue($action);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        $newActions[] = $action;
                    }
                    $actionsProp->setValue($request, $newActions);
                }

                if (!$hasTrade || $rawRecipeId === null) return;

                $recipes = $npc->getTradeRecipes();

                if (count($recipes) > 0) {
                    $inputA = $tradeInv->getItem(0);
                    $inputB = $tradeInv->getItem(1);
                    $recipeIndex = null;

                    $storedOffset = self::$tradeOffset[$player->getName()] ?? null;
                    if ($storedOffset !== null) {
                        $testIdx = $rawRecipeId - $storedOffset;
                        if (isset($recipes[$testIdx]) && self::recipeMatchesIngredients($recipes[$testIdx], $inputA, $inputB)) {
                            $recipeIndex = $testIdx;
                        }
                    }

                    if ($recipeIndex === null) {
                        $matchingIndices = [];
                        foreach ($recipes as $idx => $recipe) {
                            if (self::recipeMatchesIngredients($recipe, $inputA, $inputB)) {
                                $matchingIndices[] = $idx;
                            }
                        }

                        if (count($matchingIndices) === 1) {
                            $recipeIndex = $matchingIndices[0];
                        } elseif (count($matchingIndices) > 1) {
                            $cachedClientCount = self::$clientRecipeCount[$player->getName()] ?? null;
                            if ($cachedClientCount !== null) {
                                $testIdx = $rawRecipeId - $cachedClientCount;
                                if (in_array($testIdx, $matchingIndices, true)) {
                                    $recipeIndex = $testIdx;
                                }
                            }
                            if ($recipeIndex === null) {
                                $recipeIndex = $matchingIndices[0];
                            }
                        }
                    }

                    if ($recipeIndex !== null && isset($recipes[$recipeIndex])) {
                        self::$clientRecipeCount[$player->getName()] = $rawRecipeId - $recipeIndex;

                        $recipe = $recipes[$recipeIndex];
                        if ($recipe['tier'] <= $npc->getLevel() && $recipe['uses'] < $recipe['maxUses']) {
                            
                            $sellCount = $recipe['sell']->getCount();
                            if ($totalCount === 0) {
                                $totalCount = $sellCount * $multiplier;
                            }
                            
                            $sellItem = clone $recipe['sell'];
                            $sellItem->setCount($totalCount);
                            $tradeInv->setItem(2, $sellItem);
                            
                            foreach ($spoofedStackIds as $slot => $stackId) {
                                self::setItemStackId($player, $tradeInv, $slot, $stackId);
                            }

                            $this->plugin->getScheduler()->scheduleDelayedTask(
                                new ClosureTask(function () use ($player, $npc, $recipeIndex, $multiplier, $tradeInv): void {
                                    if (!$player->isOnline()) return;
                                    
                                    $tradeInv->clear(3);
                                    $tradeInv->clear(4);
                                    
                                    $invManager = $player->getNetworkSession()->getInvManager();
                                    if ($invManager !== null) {
                                        $invManager->syncAll();
                                    }
                                }), 1
                            );
                        }
                    }
                }
            } catch (\Throwable $t) {
            }
        }
    }

    private static function setItemStackId(Player $player, \pocketmine\inventory\Inventory $inventory, int $slotId, int $stackId): void {
        $invManager = $player->getNetworkSession()->getInvManager();
        if ($invManager === null) return;
        
        try {
            $reflection = new \ReflectionClass($invManager);
            $inventoriesProp = $reflection->getProperty("inventories");
            $inventoriesProp->setAccessible(true);
            $inventories = $inventoriesProp->getValue($invManager);
            
            $objId = spl_object_id($inventory);
            if (isset($inventories[$objId])) {
                $entry = $inventories[$objId];
                
                $entryRefl = new \ReflectionClass($entry);
                $infosProp = $entryRefl->getProperty("itemStackInfos");
                $infosProp->setAccessible(true);
                $itemStackInfos = $infosProp->getValue($entry);
                
                $itemStackInfoClass = "pocketmine\\network\\mcpe\\ItemStackInfo";
                if (class_exists($itemStackInfoClass)) {
                    $newInfo = new $itemStackInfoClass(null, $stackId);
                    $itemStackInfos[$slotId] = $newInfo;
                    $infosProp->setValue($entry, $itemStackInfos);
                }
            }
        } catch (\Throwable $t) {
        }
    }

    private static function recipeMatchesIngredients(array $recipe, \pocketmine\item\Item $inputA, \pocketmine\item\Item $inputB): bool {
        $buyA = $recipe['buyA'];
        $buyB = $recipe['buyB'] ?? null;

        if (!$inputA->equals($buyA, true, true) || $inputA->getCount() < $buyA->getCount()) {
            return false;
        }

        if ($buyB === null || $buyB->isNull()) {
            if (!$inputB->isNull()) {
                return false;
            }
        } else {
            if (!$inputB->equals($buyB, true, true) || $inputB->getCount() < $buyB->getCount()) {
                return false;
            }
        }

        return true;
    }

    public function onEntityDamage(EntityDamageEvent $event): void {
        if ($event->getEntity() instanceof TradeNPC) {
            $event->cancel();
        }
    }

    public function onEntityEffectAdd(EntityEffectAddEvent $event): void {
        if ($event->getEntity() instanceof TradeNPC) {
            $event->cancel();
        }
    }
}
