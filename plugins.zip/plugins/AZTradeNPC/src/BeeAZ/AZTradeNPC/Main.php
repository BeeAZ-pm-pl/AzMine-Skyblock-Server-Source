<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC;

use pocketmine\plugin\PluginBase;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use BeeAZ\AZTradeNPC\entity\TradeNPC;
use BeeAZ\AZTradeNPC\listener\TradeListener;
use BeeAZ\AZTradeNPC\command\TradeCommand;
use muqsit\invmenu\InvMenuHandler;

class Main extends PluginBase {
    private static self $instance;

    protected function onEnable(): void {
        self::$instance = $this;

        @mkdir($this->getDataFolder() . "trades/");

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        EntityFactory::getInstance()->register(TradeNPC::class, function (World $world, CompoundTag $nbt): TradeNPC {
            return new TradeNPC(EntityDataHelper::parseLocation($nbt, $world), \pocketmine\entity\Human::parseSkinNBT($nbt), $nbt);
        }, ['TradeNPC', 'tradenpc']);

        $this->getServer()->getPluginManager()->registerEvents(new TradeListener($this), $this);
        
        $this->getServer()->getCommandMap()->register("aztradenpc", new TradeCommand($this));

        $this->getLogger()->info("AZTradeNPC has been enabled!");
    }

    public static function getInstance(): self {
        return self::$instance;
    }
}
