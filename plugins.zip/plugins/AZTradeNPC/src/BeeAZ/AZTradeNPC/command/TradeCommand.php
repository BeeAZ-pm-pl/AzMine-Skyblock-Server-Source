<?php

declare(strict_types=1);

namespace BeeAZ\AZTradeNPC\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use BeeAZ\AZTradeNPC\Main;
use BeeAZ\AZTradeNPC\entity\TradeNPC;
use BeeAZ\AZTradeNPC\manager\TradeManager;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\ListTag;

class TradeCommand extends Command {
    private Main $plugin;
    
    public static array $editMode = [];
    public static array $removeMode = [];

    public function __construct(Main $plugin) {
        parent::__construct("trade", "Quản lý Trade NPCs", "/trade <spawn|edit|remove>", ["aztrade"]);
        $this->setPermission("trade.command");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return false;
        if (!$sender instanceof Player) {
            $sender->sendMessage("Sử dụng trong game");
            return true;
        }

        if (!isset($args[0])) {
            $sender->sendMessage("§e=== HƯỚNG DẪN AZTRADENPC ===");
            $sender->sendMessage("§a/trade spawn <tên_file> [tên_NPC] §7- Tạo NPC giao dịch từ file cấu hình (ví dụ: test_trade)");
            $sender->sendMessage("§a/trade edit §7- Bật/tắt chế độ chỉnh sửa NPC (chạm vào NPC để sửa)");
            $sender->sendMessage("§a/trade remove §7- Bật/tắt chế độ xóa NPC (chạm vào NPC để xóa)");
            return true;
        }

        switch (strtolower($args[0])) {
            case "spawn":
                $tradeId = \ramsey\uuid\Uuid::uuid4()->toString();
                $name = "Thương Nhân";

                if (isset($args[1])) {
                    $joinedArgs = implode(" ", array_slice($args, 1));
                    if (file_exists($this->plugin->getDataFolder() . "trades/" . $joinedArgs . ".yml")) {
                        $tradeId = $joinedArgs;
                        $name = $joinedArgs;
                    } else {
                        if (file_exists($this->plugin->getDataFolder() . "trades/" . $args[1] . ".yml")) {
                            $tradeId = $args[1];
                            $name = implode(" ", array_slice($args, 2));
                            if ($name === "") $name = "Thương Nhân";
                        } else {
                            $name = $joinedArgs;
                        }
                    }
                }
                
                $nbt = CompoundTag::create()
                    ->setString("Name", $sender->getSkin()->getSkinId())
                    ->setByteArray("Data", $sender->getSkin()->getSkinData())
                    ->setByteArray("CapeData", $sender->getSkin()->getCapeData())
                    ->setString("GeometryName", $sender->getSkin()->getGeometryName())
                    ->setByteArray("GeometryData", $sender->getSkin()->getGeometryData());
                
                $nbt->setString("TradeId", $tradeId);

                $npc = new TradeNPC(Location::fromObject($sender->getPosition(), $sender->getWorld()), $sender->getSkin(), $nbt);
                $npc->setNameTag(str_replace("{line}", "\n", TextFormat::colorize($name)));
                $npc->setNameTagAlwaysVisible(true);
                $npc->spawnToAll();
                $npc->getWorld()->save(true);
                
                TradeManager::createDefaultConfig($tradeId);

                $sender->sendMessage("§aĐã tạo TradeNPC với ID: $tradeId");
                break;
                
            case "edit":
                if (isset(self::$editMode[$sender->getName()])) {
                    unset(self::$editMode[$sender->getName()]);
                    $sender->sendMessage("§eĐã thoát chế độ chỉnh sửa.");
                } else {
                    unset(self::$removeMode[$sender->getName()]);
                    self::$editMode[$sender->getName()] = true;
                    $sender->sendMessage("§aHãy chạm vào một TradeNPC để chỉnh sửa.");
                }
                break;

            case "remove":
                if (isset(self::$removeMode[$sender->getName()])) {
                    unset(self::$removeMode[$sender->getName()]);
                    $sender->sendMessage("§eĐã thoát chế độ xóa.");
                } else {
                    unset(self::$editMode[$sender->getName()]);
                    self::$removeMode[$sender->getName()] = true;
                    $sender->sendMessage("§cHãy chạm vào một TradeNPC để xóa.");
                }
                break;

            default:
                $sender->sendMessage("§e=== HƯỚNG DẪN AZTRADENPC ===");
                $sender->sendMessage("§a/trade spawn <tên_file> [tên_NPC]");
                $sender->sendMessage("§a/trade edit");
                $sender->sendMessage("§a/trade remove");
                break;
        }

        return true;
    }
}
