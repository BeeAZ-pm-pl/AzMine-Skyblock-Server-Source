<?php

declare(strict_types=1);

namespace azboss\ui;

use pocketmine\form\Form;
use pocketmine\player\Player;

class ConfirmUI implements Form {

    /** @var callable */
    private $onConfirm;
    private string $title;
    private string $content;

    public function __construct(string $title, string $content, callable $onConfirm) {
        $this->title = $title;
        $this->content = $content;
        $this->onConfirm = $onConfirm;
    }

    public function jsonSerialize(): array {
        return [
            "type" => "modal",
            "title" => $this->title,
            "content" => $this->content,
            "button1" => "§l§2ĐỒNG Ý",
            "button2" => "§l§cHỦY BỎ"
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === true) {
            ($this->onConfirm)($player);
        }
    }
}