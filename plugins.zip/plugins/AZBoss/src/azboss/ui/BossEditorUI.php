<?php

declare(strict_types=1);

namespace azboss\ui;

use azboss\Main;
use pocketmine\form\Form;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class BossEditorUI implements Form {

    public function jsonSerialize(): array {
        return [
            "type" => "custom_form",
            "title" => "§l§5TẠO BOSS MỚI",
            "content" => [
                ["type" => "input", "text" => "§lID Boss:", "placeholder" => "skeleton_king"],
                ["type" => "input", "text" => "§lTên hiển thị:", "placeholder" => "§l§cVua Xương"],
                ["type" => "input", "text" => "§lMáu tối đa:", "default" => "1000"],
                ["type" => "input", "text" => "§lSát thương cơ bản:", "default" => "10"],
                ["type" => "input", "text" => "§lKích thước (Scale):", "default" => "1.0"],
                ["type" => "input", "text" => "§lID Skin:", "default" => "default"],
                ["type" => "toggle", "text" => "§c🔥 Skill: Vòng Tròn Lửa", "default" => false],
                ["type" => "toggle", "text" => "§5👿 Skill: Triệu Hồi", "default" => true],
                ["type" => "toggle", "text" => "§4😡 Skill: Cuồng Nộ", "default" => true],
                ["type" => "toggle", "text" => "§e⚡ Skill: Sét Đánh", "default" => false],
                ["type" => "toggle", "text" => "§f💨 Skill: Lướt", "default" => false],
                ["type" => "toggle", "text" => "§2☠ Skill: Vùng Độc", "default" => false],
                ["type" => "toggle", "text" => "§6☄ Skill: Cầu Lửa", "default" => false]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;

        $id = strtolower(str_replace(" ", "_", trim($data[0])));
        $name = trim($data[1]);
        $health = (int)$data[2];
        $damage = (float)$data[3];
        $scale = (float)$data[4];
        $skinId = trim($data[5]) === "" ? $id : trim($data[5]);

        if ($id === "" || $name === "") {
            $player->sendMessage("§c[AZBoss] ID và Tên không được để trống!");
            return;
        }

        $skills = [];
        if ($data[6]) $skills[] = ["type" => "fire_aura", "chance" => 20, "cooldown" => 10];
        if ($data[7]) $skills[] = ["type" => "summon", "chance" => 15, "cooldown" => 20, "minion_count" => 3];
        if ($data[8]) $skills[] = ["type" => "rage", "trigger_hp_percent" => 30];
        if ($data[9]) $skills[] = ["type" => "lightning", "chance" => 25, "cooldown" => 8, "damage" => 15];
        if ($data[10]) $skills[] = ["type" => "dash", "chance" => 30, "cooldown" => 5, "power" => 1.5];
        if ($data[11]) $skills[] = ["type" => "poison", "chance" => 20, "cooldown" => 15];
        if ($data[12]) $skills[] = ["type" => "fireball", "chance" => 25, "cooldown" => 8, "damage" => 15];

        $bossConfig = [
            "name" => $name,
            "max_health" => $health > 0 ? $health : 1000,
            "damage" => $damage > 0 ? $damage : 10,
            "speed" => 0.25,
            "scale" => $scale > 0 ? $scale : 1.0,
            "skin_id" => $skinId,
            "skills" => $skills,
            "rewards" => [
                "say §l§e{player} §fvừa tiêu diệt được §c" . $name . "§f!"
            ]
        ];

        $config = new Config(Main::getInstance()->getDataFolder() . "bosses.yml", Config::YAML);
        $config->set($id, $bossConfig);
        $config->save();

        Main::getInstance()->getBossManager()->loadBosses();
        $player->sendMessage("§a[AZBoss] Tạo thành công Boss: §e$name §a(ID: $id).");
    }
}