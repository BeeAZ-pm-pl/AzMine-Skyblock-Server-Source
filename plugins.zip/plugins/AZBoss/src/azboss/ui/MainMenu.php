<?php

declare(strict_types=1);

namespace azboss\ui;

use azboss\Main;
use pocketmine\form\Form;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;

class MainMenu implements Form {

    public function jsonSerialize(): array {
        return [
            "type" => "form",
            "title" => "§l§cAZBOSS MANAGER",
            "content" => "§eVui lòng chọn chức năng quản lý:",
            "buttons" => [
                ["text" => "§l§2[+] §r§0Triệu Hồi Boss"],
                ["text" => "§l§5[+] §r§0Tạo Boss Mới"],
                ["text" => "§l§4[-] §r§0Xóa Boss Đang Sống"],
                ["text" => "§l§e[+] §r§0Tải Lại Cấu Hình"]
            ]
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null) return;

        Main::getInstance()->getScheduler()->scheduleDelayedTask(new class($player, $data) extends Task {
            public function __construct(private Player $player, private int $data) {}

            public function onRun(): void {
                if (!$this->player->isOnline()) return;

                switch ($this->data) {
                    case 0:
                        $this->player->sendForm(new BossListUI("spawn"));
                        break;
                    case 1:
                        $this->player->sendForm(new BossEditorUI());
                        break;
                    case 2:
                        $this->player->sendForm(new DeleteBossUI());
                        break;
                    case 3:
                        Main::getInstance()->getBossManager()->loadBosses();
                        $this->player->sendMessage("§a[AZBoss] Tải lại cấu hình thành công!");
                        break;
                }
            }
        }, 2);
    }
}