<?php

declare(strict_types=1);

namespace azboss\ui;

use azboss\Main;
use pocketmine\form\Form;
use pocketmine\player\Player;
use pocketmine\nbt\tag\CompoundTag;
use azboss\entity\BossEntity;
use azboss\utils\SkinLoader;

class BossListUI implements Form {

    private string $action;
    private array $bossIds = [];

    public function __construct(string $action) {
        $this->action = $action;
    }

    public function jsonSerialize(): array {
        $bosses = Main::getInstance()->getBossManager()->getAllBosses();
        $buttons = [];

        foreach ($bosses as $id => $data) {
            $name = $data['name'] ?? $id;
            $this->bossIds[] = $id;
            $buttons[] = ["text" => $name . "\n§8ID: " . $id];
        }

        if (empty($buttons)) {
            $buttons[] = ["text" => "§cChưa có Boss nào\n§8Bấm để thoát"];
        }

        return [
            "type" => "form",
            "title" => "§l§9DANH SÁCH BOSS",
            "content" => "§eChọn một boss để thực hiện hành động:",
            "buttons" => $buttons
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null || !isset($this->bossIds[$data])) return;

        $selectedId = $this->bossIds[$data];
        $bossData = Main::getInstance()->getBossManager()->getBossData($selectedId);

        if ($this->action === "spawn") {
            $player->sendForm(new ConfirmUI(
                "§l§cXÁC NHẬN TRIỆU HỒI", 
                "§fBạn có chắc muốn triệu hồi Boss §e" . $bossData['name'] . " §ftại vị trí hiện tại không?",
                function(Player $p) use ($selectedId, $bossData) {
                    
                    // KHÔNG DÙNG COMMAND - GỌI THẲNG ENTITY BẰNG CODE
                    $nbt = CompoundTag::create()->setString("BossID", $selectedId);
                    $loc = clone $p->getLocation(); 
                    
                    // Khởi tạo Boss
                    $boss = BossEntity::create($loc, $nbt);
                    $boss->spawnToAll();
                    
                    $p->sendMessage("§a[AZBoss] Đã triệu hồi Boss §e" . $bossData['name'] . " §atại vị trí của bạn!");
                }
            ));
        }
    }
}