<?php

declare(strict_types=1);

namespace azboss\ui;

use azboss\entity\BossEntity;
use pocketmine\form\Form;
use pocketmine\player\Player;

class DeleteBossUI implements Form {

    private array $liveBosses = [];

    public function jsonSerialize(): array {
        $buttons = [];
        
        foreach (\pocketmine\Server::getInstance()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof BossEntity && $entity->isAlive()) {
                    $this->liveBosses[] = $entity;
                    $pos = $entity->getLocation();
                    $locStr = "X: " . round($pos->x) . " Y: " . round($pos->y) . " Z: " . round($pos->z);
                    $buttons[] = ["text" => $entity->getNameTag() . "\n§8" . $locStr];
                }
            }
        }

        if (empty($buttons)) {
            $buttons[] = ["text" => "§cKhông có Boss nào đang sống\n§8Bấm để thoát"];
        }

        return [
            "type" => "form",
            "title" => "§l§4XÓA BOSS ĐANG SỐNG",
            "content" => "§eChọn Boss đang tồn tại trong World để xóa:",
            "buttons" => $buttons
        ];
    }

    public function handleResponse(Player $player, $data): void {
        if ($data === null || !isset($this->liveBosses[$data])) return;

        $entity = $this->liveBosses[$data];
        if (!$entity->isClosed() && $entity->isAlive()) {
            $entity->flagForDespawn();
            $player->sendMessage("§a[AZBoss] Đã xóa Boss thành công!");
        } else {
            $player->sendMessage("§c[AZBoss] Boss này đã bị tiêu diệt hoặc không còn tồn tại!");
        }
    }
}