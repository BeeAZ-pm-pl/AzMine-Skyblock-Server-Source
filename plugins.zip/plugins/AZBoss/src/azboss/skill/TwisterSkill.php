<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class TwisterSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossPos = $boss->getLocation();

        // 1. Play animation (attack) on Boss & cry sound of Rayquaza
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$boss->getId()]);
        $cryPacket = PlaySoundPacket::create("mob.pokemon.384", $bossPos->x, $bossPos->y, $bossPos->z, 1.5, 1.0, null);

        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($animPacket);
            $p->getNetworkSession()->sendDataPacket($cryPacket);
        }

        // 2. Trajectory from boss to target with wind/gust particles
        $start = $bossPos->add(0, 1.5, 0);
        $end = $target->getLocation()->add(0, 1.0, 0);
        $distance = $start->distance($end);
        $direction = $end->subtractVector($start)->normalize();

        for ($i = 0.5; $i <= $distance; $i += 0.5) {
            $pos = $start->addVector($direction->multiply($i));
            $partPacket1 = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:gust", null);
            $partPacket2 = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:short_flying_tail", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($partPacket1);
                    $p->getNetworkSession()->sendDataPacket($partPacket2);
                }
            }
        }

        // 3. Tornado effect at target location
        $targetLoc = $target->getLocation();
        for ($h = 0; $h < 5; $h++) {
            $pos = $targetLoc->add(0, $h * 0.8, 0);
            $partPacket = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:air_cutter", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($partPacket);
                }
            }
        }

        $twisterSound = PlaySoundPacket::create("ambient.weather.thunder", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.0, 1.5, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($twisterSound);
        }

        // 4. Knock the target up in the air
        $target->setMotion(new Vector3(0, 0.45, 0));

        // 5. Damage target
        $damage = (float)($skillData['damage'] ?? 20.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
