<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class DragonClawSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossPos = $boss->getLocation();

        // 1. Play animation (attack) on Boss
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$boss->getId()]);
        
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($animPacket);
        }

        // 2. Spawn dragon claw slash particle at target
        $targetPos = $target->getLocation()->add(0, 1.0, 0);
        $partPacket = SpawnParticleEffectPacket::create(0, -1, $targetPos, "serp:dragon_claw", null);
        $slashSound = PlaySoundPacket::create("random.slash", $targetPos->x, $targetPos->y, $targetPos->z, 1.2, 0.9, null);

        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetPos) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($partPacket);
                $p->getNetworkSession()->sendDataPacket($slashSound);
            }
        }

        // 3. Deal physical damage
        $damage = (float)($skillData['damage'] ?? 25.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($ev);
    }
}
