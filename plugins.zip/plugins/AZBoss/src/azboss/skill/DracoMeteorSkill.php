<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class DracoMeteorSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossPos = $boss->getLocation();

        // 1. Play animation (attack) on Boss & cry sound
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$boss->getId()]);
        $crySound = ($boss instanceof \azboss\entity\RayquazaBossEntity) ? "mob.pokemon.384" : "mob.pokemon.6";
        $cryPacket = PlaySoundPacket::create($crySound, $bossPos->x, $bossPos->y, $bossPos->z, 1.5, 0.85, null);

        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($animPacket);
            $p->getNetworkSession()->sendDataPacket($cryPacket);
        }

        // 2. Summon 5 meteors around the target
        $targetPos = $target->getLocation();
        
        for ($m = 0; $m < 5; $m++) {
            // Random offset in X and Z
            $ox = mt_rand(-4, 4);
            $oz = mt_rand(-4, 4);
            
            $landPos = $targetPos->add($ox, 0, $oz);
            // Sky position (start)
            $skyPos = $landPos->add(mt_rand(-2, 2), 15, mt_rand(-2, 2));

            $distance = $skyPos->distance($landPos);
            $direction = $landPos->subtractVector($skyPos)->normalize();

            // Trace path downwards spawning Draco Meteor / Will-o-wisp trail
            for ($i = 0.0; $i <= $distance; $i += 0.5) {
                $pos = $skyPos->addVector($direction->multiply($i));
                $partPacket = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:draco_meteor", null);
                $wispPacket = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:will_o_wisp", null);
                
                foreach ($world->getPlayers() as $p) {
                    if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                        $p->getNetworkSession()->sendDataPacket($partPacket);
                        $p->getNetworkSession()->sendDataPacket($wispPacket);
                    }
                }
            }

            // Explosion on land
            $explodePacket = SpawnParticleEffectPacket::create(0, -1, $landPos, "serp:medium_fire_explosion", null);
            $blastPacket = SpawnParticleEffectPacket::create(0, -1, $landPos, "serp:fire_blast", null);
            $explodeSound = PlaySoundPacket::create("random.explode", $landPos->x, $landPos->y, $landPos->z, 1.0, 1.2, null);

            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($landPos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($explodePacket);
                    $p->getNetworkSession()->sendDataPacket($blastPacket);
                    $p->getNetworkSession()->sendDataPacket($explodeSound);
                }
            }

            // Deal area damage to players near landing site
            foreach ($world->getPlayers() as $p) {
                if ($p->isCreative() || $p->isSpectator()) continue;
                if ($p->getLocation()->distance($landPos) <= 3.0) {
                    $ev = new EntityDamageByEntityEvent($boss, $p, EntityDamageEvent::CAUSE_MAGIC, (float)($skillData['damage'] ?? 15.0));
                    $p->attack($ev);
                    $p->setOnFire(3);
                }
            }
        }
    }
}
