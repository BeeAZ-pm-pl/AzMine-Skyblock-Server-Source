<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class RageFistSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn ghostly dark clouds particles
        $particle = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "serp:dark_clouds", null);
        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetLoc) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($particle);
            }
        }

        // Play wither sound representing rage fist strike
        $sound = PlaySoundPacket::create("mob.wither.shoot", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.9, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Calculate dynamic damage based on boss missing health percentage
        $baseDamage = (float)($skillData['damage'] ?? 20.0);
        $missingHpPercent = 1.0 - ($boss->getHealth() / $boss->getMaxHealth());
        // Up to +100% damage when near death
        $finalDamage = $baseDamage * (1.0 + $missingHpPercent);

        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $finalDamage);
        $target->attack($ev);
    }
}
