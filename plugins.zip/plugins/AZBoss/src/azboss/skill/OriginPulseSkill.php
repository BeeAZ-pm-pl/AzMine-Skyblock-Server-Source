<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class OriginPulseSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $config): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();
        $targetLoc = $target->getLocation();

        // 1. Play Kyogre's Cry
        $pkSound = PlaySoundPacket::create(
            "mob.pokemon.382",
            $bossLoc->x, $bossLoc->y, $bossLoc->z,
            2.5,
            1.0,
            null
        );
        $world->broadcastPacketToViewers($bossLoc, $pkSound);

        // 2. Spawn water center particles around Kyogre
        $pkWaterCharge = SpawnParticleEffectPacket::create(0, -1, $bossLoc->add(0, 1.0, 0), "serp:water_center", null);
        $world->broadcastPacketToViewers($bossLoc, $pkWaterCharge);

        // 3. Shoot water pulses/projectiles to target
        $dx = $targetLoc->x - $bossLoc->x;
        $dy = $targetLoc->y - $bossLoc->y;
        $dz = $targetLoc->z - $bossLoc->z;
        $distance = sqrt($dx * $dx + $dy * $dy + $dz * $dz);

        $steps = (int)($distance * 1.5);
        if ($steps > 0) {
            for ($i = 0; $i <= $steps; ++$i) {
                $t = $i / $steps;
                $p = $bossLoc->add($dx * $t, 1.0 + $dy * $t, $dz * $t);
                $pkPath = SpawnParticleEffectPacket::create(0, -1, $p, "serp:short_water_tail", null);
                $world->broadcastPacketToViewers($p, $pkPath);
            }
        }

        // 4. Geyser waterfall eruption on target
        $pkWaterfall = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "serp:waterfall", null);
        $world->broadcastPacketToViewers($targetLoc, $pkWaterfall);

        $pkExplosion = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 1, 0), "serp:big_water_explosion", null);
        $world->broadcastPacketToViewers($targetLoc, $pkExplosion);

        // Apply Slowness (60 ticks = 3 seconds)
        $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 2));

        // Deal damage
        $damage = (float)($config['damage'] ?? 10.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);

        $target->sendMessage("§1§l» Bạn bị trúng chiêu Căn Nguyên Làn Sóng (Origin Pulse) của Kyogre và bị làm chậm!");
    }
}
