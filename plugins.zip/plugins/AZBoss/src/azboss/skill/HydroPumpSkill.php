<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class HydroPumpSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn waterfall/water splash particles
        for ($y = 0.0; $y <= 5.0; $y += 0.5) {
            $pos = $targetLoc->add(0, $y, 0);
            $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:waterfall", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($particle);
                }
            }
        }

        $bigWater = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "serp:big_water_explosion", null);
        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetLoc) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($bigWater);
            }
        }

        // Play thunder blast / splash sound
        $sound = PlaySoundPacket::create("ambient.weather.thunder", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.3, 1.1, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Knocks player up and back
        $target->setMotion(new Vector3(0, 0.5, 0));

        $damage = (float)($skillData['damage'] ?? 36.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
