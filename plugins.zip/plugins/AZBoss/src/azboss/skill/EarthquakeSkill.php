<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;

class EarthquakeSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn ground dust/explosion particles
        for ($i = 0; $i < 8; $i++) {
            $pos = $targetLoc->add(mt_rand(-20, 20) / 10.0, 0.2, mt_rand(-20, 20) / 10.0);
            $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "minecraft:lava_particle", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($particle);
                }
            }
        }
        
        $bigExplosion = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "minecraft:huge_explosion_emitter", null);
        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetLoc) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($bigExplosion);
            }
        }

        // Play thunderous rumble sound
        $sound = PlaySoundPacket::create("random.explode", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.6, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Apply damage and Slowness
        $damage = (float)($skillData['damage'] ?? 35.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);

        $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 80, 2));
    }
}
