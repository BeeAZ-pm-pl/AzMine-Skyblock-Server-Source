<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;

class IronTailSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn grey smoke/crit circle representing iron tail slam
        for ($r = 0.5; $r <= 2.5; $r += 0.5) {
            $count = (int)($r * 8);
            for ($i = 0; $i < $count; $i++) {
                $angle = ($i / $count) * M_PI * 2;
                $pos = $targetLoc->add(cos($angle) * $r, 0.1, sin($angle) * $r);
                $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "minecraft:crit_particle", null);
                foreach ($world->getPlayers() as $p) {
                    if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                        $p->getNetworkSession()->sendDataPacket($particle);
                    }
                }
            }
        }

        // Play metal clang sound
        $sound = PlaySoundPacket::create("random.anvil_land", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.8, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Apply negative status effects
        $target->getEffects()->add(new EffectInstance(VanillaEffects::BLINDNESS(), 80, 0));
        $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 80, 3));
        $target->getEffects()->add(new EffectInstance(VanillaEffects::WITHER(), 60, 1));

        $damage = (float)($skillData['damage'] ?? 30.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
