<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\player\Player;

abstract class BaseSkill {
    /**
     * @param BossEntity $boss Entity đang dùng skill
     * @param Player|null $target Mục tiêu hiện tại (có thể null nếu skill diện rộng)
     * @param array $skillData Cấu hình riêng của skill từ YAML
     */
    abstract public function execute(BossEntity $boss, ?Player $target, array $skillData): void;
}