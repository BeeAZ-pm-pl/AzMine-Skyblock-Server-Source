<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use azboss\utils\ParticleHelper;
use pocketmine\player\Player;
use pocketmine\world\particle\LavaParticle;

class RageSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        ParticleHelper::spawnCircle($boss->getWorld(), $boss->getLocation(), 2.0, 50, new LavaParticle());
    }
}