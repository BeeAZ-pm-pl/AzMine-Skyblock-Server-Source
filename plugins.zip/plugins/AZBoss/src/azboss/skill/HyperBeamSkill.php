<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class HyperBeamSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossPos = $boss->getLocation();

        // 1. Play animation & cry sound
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$boss->getId()]);
        $cryPacket = PlaySoundPacket::create("mob.pokemon.384", $bossPos->x, $bossPos->y, $bossPos->z, 1.5, 0.9, null);

        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($animPacket);
            $p->getNetworkSession()->sendDataPacket($cryPacket);
        }

        // 2. Beam trajectory from Rayquaza's mouth to player
        $start = $bossPos->add(0, 1.8, 0);
        $end = $target->getLocation()->add(0, 1.0, 0);
        $distance = $start->distance($end);
        $direction = $end->subtractVector($start)->normalize();

        // Spawn a dense path of hyper beam particles
        for ($i = 0.5; $i <= $distance + 1.0; $i += 0.35) {
            $pos = $start->addVector($direction->multiply($i));
            $beamPacket = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:hyper_beam", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($beamPacket);
                }
            }
        }

        // 3. Explosion at target
        $explodePos = $target->getLocation()->add(0, 0.5, 0);
        $explodeSound = PlaySoundPacket::create("random.explode", $explodePos->x, $explodePos->y, $explodePos->z, 1.3, 0.8, null);
        $blastPacket = SpawnParticleEffectPacket::create(0, -1, $explodePos, "serp:big_dragon_explosion", null);

        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($explodePos) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($explodeSound);
                $p->getNetworkSession()->sendDataPacket($blastPacket);
            }
        }

        // 4. Deal damage
        $damage = (float)($skillData['damage'] ?? 35.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
