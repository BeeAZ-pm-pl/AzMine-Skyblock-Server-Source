<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;

class MeteorMashSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn explosive meteor mash particles
        $particle = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "serp:big_electric_explosion", null);
        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetLoc) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($particle);
            }
        }

        // Play explosive sound
        $sound = PlaySoundPacket::create("random.explode", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.8, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Metagross gains Strength briefly
        $boss->getEffects()->add(new EffectInstance(VanillaEffects::STRENGTH(), 60, 1));

        $damage = (float)($skillData['damage'] ?? 40.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);

        // Slow player down
        $target->getEffects()->add(new EffectInstance(VanillaEffects::SLOWNESS(), 60, 2));
    }
}
