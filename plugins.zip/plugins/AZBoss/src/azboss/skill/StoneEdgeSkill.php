<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class StoneEdgeSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Summon stone dust/explosion path
        for ($i = 0; $i < 5; $i++) {
            $pos = $targetLoc->add(mt_rand(-15, 15)/10.0, 0.1, mt_rand(-15, 15)/10.0);
            $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:normal_hit", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($particle);
                }
            }
        }

        // Earth cracking sound
        $sound = PlaySoundPacket::create("block.stone.break", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.4, 0.8, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Throw player upwards slightly (simulate stone spike launch)
        $target->setMotion(new Vector3(0, 0.4, 0));

        $damage = (float)($skillData['damage'] ?? 36.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($ev);
    }
}
