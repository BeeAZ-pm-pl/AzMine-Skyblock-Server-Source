<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class PrecipiceBladesSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $config): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();
        $targetLoc = $target->getLocation();

        // 1. Play Groudon Cry
        $pkSound = PlaySoundPacket::create(
            "mob.pokemon.383",
            $bossLoc->x, $bossLoc->y, $bossLoc->z,
            2.5,
            0.8,
            null
        );
        $world->broadcastPacketToViewers($bossLoc, $pkSound);

        // 2. Play explosion sound at target
        $pkExplode = PlaySoundPacket::create(
            "random.explode",
            $targetLoc->x, $targetLoc->y, $targetLoc->z,
            1.5,
            0.7,
            null
        );
        $world->broadcastPacketToViewers($targetLoc, $pkExplode);

        // 3. Spawn volcano eruption particles at target
        for ($i = 0; $i < 8; $i++) {
            $offset = $targetLoc->add(
                (mt_rand(-15, 15) / 10),
                0.2,
                (mt_rand(-15, 15) / 10)
            );
            $pkLava = SpawnParticleEffectPacket::create(0, -1, $offset, "minecraft:lava_particle", null);
            $world->broadcastPacketToViewers($offset, $pkLava);
        }

        $pkExplosion = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "minecraft:huge_explosion_emitter", null);
        $world->broadcastPacketToViewers($targetLoc, $pkExplosion);

        // 4. Apply damage and Slowness
        $damage = (float) ($config['damage'] ?? 25);
        $event = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($event);

        $target->getEffects()->add(new EffectInstance(
            VanillaEffects::SLOWNESS(),
            80, // 4 seconds
            2,  // Slowness III
            true
        ));
    }
}
