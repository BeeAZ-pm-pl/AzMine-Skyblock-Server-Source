<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class DragonRushSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn draconic energy particles
        $particle = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "serp:big_dragon_explosion", null);
        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetLoc) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($particle);
            }
        }

        // Play dragon growl/charge sound
        $sound = PlaySoundPacket::create("mob.enderdragon.growl", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 0.9, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Teleport boss to target and attack with heavy knockback
        $boss->teleport($targetLoc->add(cos(mt_rand(0, 360)) * 0.8, 0, sin(mt_rand(0, 360)) * 0.8));

        // Knock player back
        $direction = $targetLoc->subtractVector($boss->getLocation())->normalize();
        $target->setMotion(new Vector3($direction->x * 1.2, 0.4, $direction->z * 1.2));

        $damage = (float)($skillData['damage'] ?? 45.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
