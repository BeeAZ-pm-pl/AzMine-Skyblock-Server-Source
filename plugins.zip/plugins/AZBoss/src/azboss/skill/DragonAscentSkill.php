<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class DragonAscentSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossPos = $boss->getLocation();

        // 1. Play animation & cry sound
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$boss->getId()]);
        $cryPacket = PlaySoundPacket::create("mob.pokemon.384", $bossPos->x, $bossPos->y, $bossPos->z, 1.5, 0.85, null);

        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($animPacket);
            $p->getNetworkSession()->sendDataPacket($cryPacket);
        }

        // 2. Summon dragon energy storm around target
        $targetLoc = $target->getLocation();
        
        // Aura energy charging particles
        for ($i = 0; $i < 12; $i++) {
            $angle = ($i / 12) * 2 * M_PI;
            $ox = cos($angle) * 1.5;
            $oz = sin($angle) * 1.5;
            $pos = $targetLoc->add($ox, mt_rand(0, 20) / 10, $oz);
            
            $energyPacket = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:energy_d_in", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($energyPacket);
                }
            }
        }

        // 3. Huge dragon explosions
        $explodeSound = PlaySoundPacket::create("random.explode", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.5, 0.7, null);
        $explosion1 = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 0.5, 0), "serp:big_dragon_explosion", null);
        $explosion2 = SpawnParticleEffectPacket::create(0, -1, $targetLoc->add(0, 1.5, 0), "serp:medium_dragon_explosion", null);

        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($targetLoc) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($explodeSound);
                $p->getNetworkSession()->sendDataPacket($explosion1);
                $p->getNetworkSession()->sendDataPacket($explosion2);
            }
        }

        // 4. Knock player back / away
        $diff = $targetLoc->subtractVector($bossPos);
        $diff->y = 0;
        if ($diff->lengthSquared() > 0) {
            $dir = $diff->normalize()->multiply(1.2);
            $target->setMotion(new Vector3($dir->x, 0.4, $dir->z));
        }

        // 5. Deal huge damage
        $damage = (float)($skillData['damage'] ?? 40.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
