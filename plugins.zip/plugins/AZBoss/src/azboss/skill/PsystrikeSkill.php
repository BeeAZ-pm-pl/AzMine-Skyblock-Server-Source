<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class PsystrikeSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $targetLoc = $target->getLocation();

        // Spawn spherical pattern of psychic energy particles
        for ($i = 0; $i < 15; $i++) {
            $theta = mt_rand(0, 360) * M_PI / 180;
            $phi = mt_rand(0, 180) * M_PI / 180;
            $pos = $targetLoc->add(
                sin($phi) * cos($theta) * 1.5,
                cos($phi) * 1.5 + 1.0,
                sin($phi) * sin($theta) * 1.5
            );
            $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:long_psychic_tail", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($particle);
                }
            }
        }

        // Play high-pitch psychic blast sound
        $sound = PlaySoundPacket::create("respawn_anchor.deplete", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.4, 1.5, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Deal psychic magic damage
        $damage = (float)($skillData['damage'] ?? 42.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
    }
}
