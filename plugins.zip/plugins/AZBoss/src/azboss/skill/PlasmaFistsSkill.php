<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class PlasmaFistsSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $config): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();
        $targetLoc = $target->getLocation();

        // 1. Play Zeraora Cry
        $pkSound = PlaySoundPacket::create(
            "mob.pokemon.807",
            $bossLoc->x, $bossLoc->y, $bossLoc->z,
            2.5,
            1.1,
            null
        );
        $world->broadcastPacketToViewers($bossLoc, $pkSound);

        // 2. Play Lightning sound at target
        $pkLightningSound = PlaySoundPacket::create(
            "ambient.weather.lightning.strike",
            $targetLoc->x, $targetLoc->y, $targetLoc->z,
            1.8,
            1.0,
            null
        );
        $world->broadcastPacketToViewers($targetLoc, $pkLightningSound);

        // 3. Spawn Electric/Lightning particles
        // Spawn lightning bolt particle
        $pkBolt = SpawnParticleEffectPacket::create(0, -1, $targetLoc, "minecraft:lightning_bolt", null);
        $world->broadcastPacketToViewers($targetLoc, $pkBolt);

        // Spawn blue energy sparks
        for ($i = 0; $i < 15; $i++) {
            $offset = $targetLoc->add(
                (mt_rand(-10, 10) / 10),
                (mt_rand(0, 20) / 10),
                (mt_rand(-10, 10) / 10)
            );
            $pkSpark = SpawnParticleEffectPacket::create(0, -1, $offset, "minecraft:conduit_particle", null);
            $world->broadcastPacketToViewers($offset, $pkSpark);
        }

        // 4. Damage and Paralysis (Slowness IV & Blindness)
        $damage = (float) ($config['damage'] ?? 30);
        $event = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($event);

        $target->getEffects()->add(new EffectInstance(
            VanillaEffects::SLOWNESS(),
            60, // 3 seconds
            3,  // Slowness IV
            true
        ));
        $target->getEffects()->add(new EffectInstance(
            VanillaEffects::BLINDNESS(),
            60, // 3 seconds
            0,
            true
        ));
    }
}
