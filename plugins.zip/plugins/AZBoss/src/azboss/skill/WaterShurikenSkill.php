<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class WaterShurikenSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $config): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();
        $targetLoc = $target->getLocation();

        // 1. Play Greninja Cry
        $pkSound = PlaySoundPacket::create(
            "mob.pokemon.658",
            $bossLoc->x, $bossLoc->y, $bossLoc->z,
            2.5,
            1.2,
            null
        );
        $world->broadcastPacketToViewers($bossLoc, $pkSound);

        // 2. Launch 3 water shurikens (offset paths)
        $dx = $targetLoc->x - $bossLoc->x;
        $dy = $targetLoc->y - $bossLoc->y;
        $dz = $targetLoc->z - $bossLoc->z;
        $distance = sqrt($dx * $dx + $dy * $dy + $dz * $dz);

        if ($distance > 0) {
            $steps = (int) ($distance * 2);
            $offsets = [
                new Vector3(0, 0, 0),        // Center Shuriken
                new Vector3(-0.4, 0.2, 0.4),  // Left Shuriken
                new Vector3(0.4, -0.2, -0.4)  // Right Shuriken
            ];

            foreach ($offsets as $idx => $offsetVec) {
                // Play throw sound
                $throwSound = PlaySoundPacket::create(
                    "item.trident.throw",
                    $bossLoc->x, $bossLoc->y, $bossLoc->z,
                    1.2,
                    1.4 + ($idx * 0.1),
                    null
                );
                $world->broadcastPacketToViewers($bossLoc, $throwSound);

                // Spawn projectile path particles
                for ($i = 0; $i <= $steps; $i++) {
                    $t = $i / $steps;
                    $p = $bossLoc->add(
                        $dx * $t + $offsetVec->x * (1 - $t),
                        1.0 + $dy * $t + $offsetVec->y * (1 - $t),
                        $dz * $t + $offsetVec->z * (1 - $t)
                    );
                    
                    $pkDrip = SpawnParticleEffectPacket::create(0, -1, $p, "minecraft:water_drip_particle", null);
                    $pkBubble = SpawnParticleEffectPacket::create(0, -1, $p, "minecraft:bubble_particle", null);
                    
                    $world->broadcastPacketToViewers($p, $pkDrip);
                    $world->broadcastPacketToViewers($p, $pkBubble);
                }

                // Splash impact on player
                $splashLoc = $targetLoc->add(0, 1.0, 0);
                $pkSplash = SpawnParticleEffectPacket::create(0, -1, $splashLoc, "minecraft:water_splash_particle", null);
                $world->broadcastPacketToViewers($splashLoc, $pkSplash);

                $impactSound = PlaySoundPacket::create(
                    "random.splash",
                    $targetLoc->x, $targetLoc->y, $targetLoc->z,
                    1.0,
                    1.5,
                    null
                );
                $world->broadcastPacketToViewers($targetLoc, $impactSound);

                // 3. Deal damage for each shuriken
                $shurikenDamage = (float) (($config['damage'] ?? 24) / 3);
                $event = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $shurikenDamage);
                $target->attack($event);
            }
        }
    }
}
