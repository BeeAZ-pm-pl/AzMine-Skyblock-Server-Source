<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\AnimateEntityPacket;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class FireBlastSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossPos = $boss->getLocation();

        // 1. Play animation (attack) on Boss
        $animPacket = AnimateEntityPacket::create("attack", "", "", 0, "", 0.0, [$boss->getId()]);
        // 2. Play Charizard cry (mob.pokemon.6)
        $cryPacket = PlaySoundPacket::create("mob.pokemon.6", $bossPos->x, $bossPos->y, $bossPos->z, 1.5, 1.0, null);

        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($animPacket);
            $p->getNetworkSession()->sendDataPacket($cryPacket);
        }

        // 3. Projectile trajectory to target
        $start = $bossPos->add(0, $boss->getEyeHeight() * 1.5, 0);
        $end = $target->getLocation()->add(0, $target->getEyeHeight(), 0);
        $distance = $start->distance($end);
        $direction = $end->subtractVector($start)->normalize();

        // Spawn flying wisp trail
        for ($i = 0.5; $i <= $distance; $i += 0.4) {
            $pos = $start->addVector($direction->multiply($i));
            $partPacket = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:will_o_wisp", null);
            foreach ($world->getPlayers() as $p) {
                if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                    $p->getNetworkSession()->sendDataPacket($partPacket);
                }
            }
        }

        // 4. Explosion on target
        $explodePos = $target->getLocation()->add(0, 0.5, 0);
        
        // Spawn fire blast and medium fire explosion
        $blastPacket = SpawnParticleEffectPacket::create(0, -1, $explodePos, "serp:fire_blast", null);
        $mediumExplodePacket = SpawnParticleEffectPacket::create(0, -1, $explodePos, "serp:medium_fire_explosion", null);
        $explodeSoundPacket = PlaySoundPacket::create("random.explode", $explodePos->x, $explodePos->y, $explodePos->z, 1.0, 1.0, null);

        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distanceSquared($explodePos) <= 1024) {
                $p->getNetworkSession()->sendDataPacket($blastPacket);
                $p->getNetworkSession()->sendDataPacket($mediumExplodePacket);
                $p->getNetworkSession()->sendDataPacket($explodeSoundPacket);
            }
        }

        // 5. Deal damage and ignite target
        $damage = (float)($skillData['damage'] ?? 30.0);
        $ev = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_MAGIC, $damage);
        $target->attack($ev);
        $target->setOnFire(5);
    }
}
