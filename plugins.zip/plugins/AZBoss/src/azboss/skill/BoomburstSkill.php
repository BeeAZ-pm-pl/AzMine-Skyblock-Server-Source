<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;

class BoomburstSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();

        // Play loud sound blast sound at boss
        $sound = PlaySoundPacket::create("ambient.weather.thunder", $bossLoc->x, $bossLoc->y, $bossLoc->z, 1.5, 1.3, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Dense circle of expanding wind/smoke particles representing soundwaves
        for ($r = 1.0; $r <= 4.0; $r += 1.0) {
            $count = (int)($r * 8);
            for ($i = 0; $i < $count; $i++) {
                $angle = ($i / $count) * M_PI * 2;
                $pos = $bossLoc->add(cos($angle) * $r, 0.2, sin($angle) * $r);
                $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "minecraft:basic_smoke_particle", null);
                foreach ($world->getPlayers() as $p) {
                    if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                        $p->getNetworkSession()->sendDataPacket($particle);
                    }
                }
            }
        }

        // Deal damage to all players in a 6-block radius (AOE)
        $damage = (float)($skillData['damage'] ?? 25.0);
        foreach ($world->getPlayers() as $p) {
            if ($p->getLocation()->distance($bossLoc) <= 6.0) {
                $ev = new EntityDamageByEntityEvent($boss, $p, EntityDamageEvent::CAUSE_MAGIC, $damage);
                $p->attack($ev);
            }
        }
    }
}
