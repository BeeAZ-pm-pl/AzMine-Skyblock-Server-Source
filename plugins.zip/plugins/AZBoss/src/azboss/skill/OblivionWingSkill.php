<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class OblivionWingSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $config): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();
        $targetLoc = $target->getLocation();

        // 1. Play Yveltal Cry
        $pkSound = PlaySoundPacket::create(
            "mob.pokemon.717",
            $bossLoc->x, $bossLoc->y, $bossLoc->z,
            2.5,
            0.9,
            null
        );
        $world->broadcastPacketToViewers($bossLoc, $pkSound);

        // 2. Play Wither shoot sound at target
        $pkWitherSound = PlaySoundPacket::create(
            "mob.wither.shoot",
            $targetLoc->x, $targetLoc->y, $targetLoc->z,
            1.5,
            0.6,
            null
        );
        $world->broadcastPacketToViewers($targetLoc, $pkWitherSound);

        // 3. Spawn Oblivion ritual circle particles (Yveltal dark energy)
        $radius = 2.0;
        for ($angle = 0; $angle < 360; $angle += 24) {
            $rad = deg2rad($angle);
            $offset = $targetLoc->add(sin($rad) * $radius, 0.2, cos($rad) * $radius);
            
            $pkDust = SpawnParticleEffectPacket::create(0, -1, $offset, "minecraft:redstone_ore_dust_particle", null);
            $pkPortal = SpawnParticleEffectPacket::create(0, -1, $offset, "minecraft:portal_particle", null);
            
            $world->broadcastPacketToViewers($offset, $pkDust);
            $world->broadcastPacketToViewers($offset, $pkPortal);
        }

        // 4. Life drain: Deal damage and heal Yveltal
        $damage = (float) ($config['damage'] ?? 25);
        $event = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($event);

        // Heal the boss entity
        $boss->setHealth(min($boss->getMaxHealth(), $boss->getHealth() + $damage));

        // Spawn heal particles around the boss to show regeneration
        for ($i = 0; $i < 8; $i++) {
            $bossOffset = $bossLoc->add(
                (mt_rand(-10, 10) / 10),
                (mt_rand(0, 20) / 10),
                (mt_rand(-10, 10) / 10)
            );
            $pkHeal = SpawnParticleEffectPacket::create(0, -1, $bossOffset, "minecraft:villager_happy", null);
            $world->broadcastPacketToViewers($bossOffset, $pkHeal);
        }
    }
}
