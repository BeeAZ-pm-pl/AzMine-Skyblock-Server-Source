<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\math\Vector3;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;

class DualChopSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $config): void {
        if ($target === null) return;

        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();
        $targetLoc = $target->getLocation();

        // 1. Play Garchomp Cry
        $pkSound = PlaySoundPacket::create(
            "mob.pokemon.445",
            $bossLoc->x, $bossLoc->y, $bossLoc->z,
            2.5,
            1.0,
            null
        );
        $world->broadcastPacketToViewers($bossLoc, $pkSound);

        // 2. Dash boss towards player
        $dir = $targetLoc->subtractVector($bossLoc)->normalize();
        $boss->setMotion($dir->multiply(1.5)->add(0, 0.2, 0));

        // 3. Play slash sounds and claw particles
        $slashSound1 = PlaySoundPacket::create("item.trident.throw", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 1.5, null);
        $slashSound2 = PlaySoundPacket::create("item.trident.throw", $targetLoc->x, $targetLoc->y, $targetLoc->z, 1.2, 1.3, null);
        $world->broadcastPacketToViewers($targetLoc, $slashSound1);
        
        // Spawn slash particles (Dragon Breath) in X/Z shape
        for ($i = -5; $i <= 5; $i++) {
            $offset1 = $targetLoc->add($i * 0.2, 1.0 + $i * 0.2, 0);
            $offset2 = $targetLoc->add(-$i * 0.2, 1.0 + $i * 0.2, 0);
            $world->broadcastPacketToViewers($offset1, SpawnParticleEffectPacket::create(0, -1, $offset1, "minecraft:dragon_breath_fire", null));
            $world->broadcastPacketToViewers($offset2, SpawnParticleEffectPacket::create(0, -1, $offset2, "minecraft:dragon_breath_fire", null));
        }

        // 4. Deal damage with knockback and Bleed (Poison II)
        $damage = (float) ($config['damage'] ?? 20);
        $event = new EntityDamageByEntityEvent($boss, $target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $damage);
        $target->attack($event);

        // Apply knockback
        $target->setMotion($dir->multiply(1.2)->add(0, 0.4, 0));

        // Apply Poison II (simulate bleeding)
        $target->getEffects()->add(new EffectInstance(
            VanillaEffects::POISON(),
            80, // 4 seconds
            1,  // Poison II
            true
        ));
    }
}
