<?php

declare(strict_types=1);

namespace azboss\skill;

use azboss\entity\BossEntity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\player\Player;
use pocketmine\math\Vector3;

class PsychoBoostSkill extends BaseSkill {

    public function execute(BossEntity $boss, ?Player $target, array $skillData): void {
        $world = $boss->getWorld();
        $bossLoc = $boss->getLocation();

        // Play space blast sound
        $sound = PlaySoundPacket::create("respawn_anchor.charge", $bossLoc->x, $bossLoc->y, $bossLoc->z, 1.4, 0.8, null);
        foreach ($world->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($sound);
        }

        // Expand wave of psychic rings
        for ($r = 1.0; $r <= 6.0; $r += 1.5) {
            $count = (int)($r * 6);
            for ($i = 0; $i < $count; $i++) {
                $angle = ($i / $count) * M_PI * 2;
                $pos = $bossLoc->add(cos($angle) * $r, 0.5, sin($angle) * $r);
                $particle = SpawnParticleEffectPacket::create(0, -1, $pos, "serp:energy_psychic", null);
                foreach ($world->getPlayers() as $p) {
                    if ($p->getLocation()->distanceSquared($pos) <= 1024) {
                        $p->getNetworkSession()->sendDataPacket($particle);
                    }
                }
            }
        }

        // Push and damage all players within 6 blocks
        $damage = (float)($skillData['damage'] ?? 30.0);
        foreach ($world->getPlayers() as $p) {
            if ($p->isCreative() || $p->isSpectator()) continue;
            
            $dist = $bossLoc->distance($p->getLocation());
            if ($dist <= 6.0 && $dist > 0) {
                $diff = $p->getLocation()->subtractVector($bossLoc);
                $diff->y = 0.0;
                $dir = $diff->normalize();
                
                // Set knockback motion
                $p->setMotion(new Vector3($dir->x * 1.5, 0.4, $dir->z * 1.5));
                
                $ev = new EntityDamageByEntityEvent($boss, $p, EntityDamageEvent::CAUSE_MAGIC, $damage);
                $p->attack($ev);
            }
        }
    }
}
