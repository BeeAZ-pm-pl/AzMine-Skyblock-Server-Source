<?php

declare(strict_types=1);

namespace azboss\command;

use azboss\entity\BossEntity;
use azboss\Main;
use azboss\ui\MainMenu;
use azboss\utils\SkinLoader;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;

class BossCommand extends Command {

    public function __construct() {
        // Tên lệnh chính thức: "boss"
        parent::__construct("boss", "Mở menu quản lý AZBoss", "/boss [spawn|reload]");
        $this->setPermission("azboss.admin");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if (!$this->testPermission($sender)) return;

        if (isset($args[0])) {
            switch (strtolower($args[0])) {
                case "spawn":
                    if (!$sender instanceof Player) {
                        $sender->sendMessage("§cLệnh này chỉ dùng trong game!");
                        return;
                    }
                    if (!isset($args[1])) {
                        $sender->sendMessage("§cSử dụng: /boss spawn <id>");
                        return;
                    }
                    
                    $bossId = $args[1];
                    $bossData = Main::getInstance()->getBossManager()->getBossData($bossId);
                    
                    if ($bossData === null) {
                        $sender->sendMessage("§c[AZBoss] Không tìm thấy Boss mang ID: $bossId");
                        return;
                    }

                    $nbt = CompoundTag::create()->setString("BossID", $bossId);
                    $loc = clone $sender->getLocation(); 
                    
                    $boss = BossEntity::create($loc, $nbt);
                    $boss->spawnToAll();
                    
                    $sender->sendMessage("§a[AZBoss] Đã triệu hồi Boss §e" . $bossData['name'] . " §atại vị trí của bạn!");
                    break;

                case "reload":
                    Main::getInstance()->getBossManager()->loadBosses();
                    $sender->sendMessage("§a[AZBoss] Đã tải lại toàn bộ cấu hình thành công!");
                    break;

                default:
                    $sender->sendMessage("§cSử dụng: /boss [spawn|reload]");
                    break;
            }
            return;
        }

        if ($sender instanceof Player) {
            $sender->sendForm(new MainMenu());
        } else {
            $sender->sendMessage("§cVui lòng dùng lệnh này trong game để mở UI.");
        }
    }
}