<?php

declare(strict_types=1);

namespace azboss;

use azboss\command\BossCommand; // Bắt buộc phải có dòng này
use azboss\manager\BossManager;
use azboss\manager\RewardManager;
use azboss\manager\SkillManager;
use azboss\utils\SkinLoader;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;

class Main extends PluginBase {
    use SingletonTrait;

    private BossManager $bossManager;
    private SkillManager $skillManager;
    private RewardManager $rewardManager;

    protected function onLoad(): void {
        self::setInstance($this);
    }

    protected function onEnable(): void {
        $this->saveResource("config.yml");
        $this->saveResource("bosses.yml");
        
        if(!is_dir($this->getDataFolder() . "skins")){
            @mkdir($this->getDataFolder() . "skins", 0777, true);
        }

        SkinLoader::init($this->getDataFolder() . "skins/");

        $this->skillManager = new SkillManager();
        $this->rewardManager = new RewardManager();
        $this->bossManager = new BossManager($this);

        // ĐĂNG KÝ LỆNH DUY NHẤT Ở ĐÂY
        $this->getServer()->getCommandMap()->register("azboss", new BossCommand());

        $this->getLogger()->info("§aAZBoss đã được bật! Hãy dùng lệnh: /boss");
    }

    public function getBossManager(): BossManager {
        return $this->bossManager;
    }

    public function getSkillManager(): SkillManager {
        return $this->skillManager;
    }

    public function getRewardManager(): RewardManager {
        return $this->rewardManager;
    }
}