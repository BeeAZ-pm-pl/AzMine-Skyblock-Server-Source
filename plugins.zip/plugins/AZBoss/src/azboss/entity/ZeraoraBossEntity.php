<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class ZeraoraBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p807";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.6, 0.8);
    }
}
