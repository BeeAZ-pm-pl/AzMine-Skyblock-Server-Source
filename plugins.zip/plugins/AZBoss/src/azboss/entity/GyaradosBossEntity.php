<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class GyaradosBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p130";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(3.0, 2.5);
    }
}
