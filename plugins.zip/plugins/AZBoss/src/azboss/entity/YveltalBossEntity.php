<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class YveltalBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p717";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(2.5, 2.0);
    }
}
