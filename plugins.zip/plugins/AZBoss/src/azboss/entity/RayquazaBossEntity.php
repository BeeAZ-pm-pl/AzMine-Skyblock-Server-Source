<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class RayquazaBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p384";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(2.0, 1.2);
    }
}
