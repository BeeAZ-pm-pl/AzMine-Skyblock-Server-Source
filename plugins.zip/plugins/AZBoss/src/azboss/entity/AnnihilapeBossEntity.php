<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class AnnihilapeBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p979";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(1.8, 1.6);
    }
}
