<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class GroudonBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p383";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(3.5, 2.5);
    }
}
