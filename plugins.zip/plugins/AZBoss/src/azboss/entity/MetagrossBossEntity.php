<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class MetagrossBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p376";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(2.2, 2.0);
    }
}
