<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class SteelixBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p208";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(2.5, 2.0);
    }
}
