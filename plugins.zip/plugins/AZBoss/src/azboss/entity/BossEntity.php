<?php

declare(strict_types=1);

namespace azboss\entity;

use azboss\Main;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;
use pocketmine\world\particle\LavaParticle;
use pocketmine\network\mcpe\protocol\AnimatePacket;

class BossEntity extends Living {

    private string $bossId;
    private array $bossData;
    private ?Player $target = null;
    private int $findTargetTick = 0;
    private array $skillCooldowns = [];
    private bool $isEnraged = false;
    public bool $isDungeonBoss = false;

    public static function create(Location $location, ?CompoundTag $nbt = null): BossEntity {
        $bossId = $nbt?->getString("BossID", "charizard") ?? "charizard";
        if ($bossId === "rayquaza") {
            return new RayquazaBossEntity($location, null, $nbt);
        }
        if ($bossId === "groudon") {
            return new GroudonBossEntity($location, null, $nbt);
        }
        if ($bossId === "garchomp") {
            return new GarchompBossEntity($location, null, $nbt);
        }
        if ($bossId === "zeraora") {
            return new ZeraoraBossEntity($location, null, $nbt);
        }
        if ($bossId === "yveltal") {
            return new YveltalBossEntity($location, null, $nbt);
        }
        if ($bossId === "nidoking") {
            return new NidokingBossEntity($location, null, $nbt);
        }
        if ($bossId === "gyarados") {
            return new GyaradosBossEntity($location, null, $nbt);
        }
        if ($bossId === "steelix") {
            return new SteelixBossEntity($location, null, $nbt);
        }
        if ($bossId === "mewtwo") {
            return new MewtwoBossEntity($location, null, $nbt);
        }
        if ($bossId === "salamence") {
            return new SalamenceBossEntity($location, null, $nbt);
        }
        if ($bossId === "deoxys") {
            return new DeoxysBossEntity($location, null, $nbt);
        }
        if ($bossId === "metagross") {
            return new MetagrossBossEntity($location, null, $nbt);
        }
        if ($bossId === "noivern") {
            return new NoivernBossEntity($location, null, $nbt);
        }
        if ($bossId === "annihilape") {
            return new AnnihilapeBossEntity($location, null, $nbt);
        }
        if ($bossId === "tyranitar") {
            return new TyranitarBossEntity($location, null, $nbt);
        }
        if ($bossId === "kyogre") {
            return new KyogreBossEntity($location, null, $nbt);
        }
        return new CharizardBossEntity($location, null, $nbt);
    }

    public function __construct(Location $location, $skin = null, ?CompoundTag $nbt = null) {
        $this->bossId = $nbt?->getString("BossID", "default") ?? "default";
        $this->isDungeonBoss = $nbt?->getByte("IsDungeonBoss", 0) === 1;
        
        parent::__construct($location, $nbt);
    }

    public static function getNetworkTypeId(): string {
        return "pokemon:p6";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(2.0, 1.2);
    }

    public function getName(): string {
        return $this->getNameTag();
    }

    protected function initEntity(CompoundTag $nbt): void {
        $this->bossId = $nbt->getString("BossID", "default");
        $this->bossData = Main::getInstance()->getBossManager()->getBossData($this->bossId) ?? [];
        
        $maxHp = (int) ($this->bossData['max_health'] ?? 1000);
        $this->setMaxHealth($maxHp);

        parent::initEntity($nbt);
        
        $this->setCanSaveWithChunk(true);
        $this->setNameTagAlwaysVisible(true);

        if (empty($this->bossData)) {
            $this->flagForDespawn();
            return;
        }

        if ($nbt->getTag("Health") === null) {
            $this->setHealth((float)$maxHp);
        }

        $this->setScale((float) ($this->bossData['scale'] ?? 1.0));
        
        $this->updateNameTag();
    }

    public function saveNBT(): CompoundTag {
        $nbt = parent::saveNBT();
        $nbt->setString("BossID", $this->bossId);
        $nbt->setByte("IsDungeonBoss", $this->isDungeonBoss ? 1 : 0);
        return $nbt;
    }

    public function getBossId(): string {
        return $this->bossId;
    }

    public function getBaseName(): string {
        $data = Main::getInstance()->getBossManager()->getBossData($this->bossId);
        return $data['name'] ?? "Boss";
    }

    public function getDamage(): float {
        $dmg = (float) ($this->bossData['damage'] ?? 10);
        return $this->isEnraged ? $dmg * 1.5 : $dmg;
    }

    public function hasActiveMinions(): bool {
        foreach ($this->getWorld()->getEntities() as $entity) {
            if ($entity instanceof MinionEntity && $entity->getParentId() === $this->getId()) {
                return true;
            }
        }
        return false;
    }

    public function attack(EntityDamageEvent $source): void {
        if ($this->hasActiveMinions()) {
            $source->cancel();
            $this->getWorld()->addParticle($this->getLocation()->add(0, 1.5, 0), new LavaParticle());
            return;
        }
        parent::attack($source);
    }

    public function onUpdate(int $currentTick): bool {
        $hasUpdate = parent::onUpdate($currentTick);
        if (!$this->isAlive() || $this->isClosed()) return $hasUpdate;

        $this->updateNameTag();
        $this->tickAI($currentTick);
        $this->tickSkills();

        return $hasUpdate;
    }

    private function updateNameTag(): void {
        $maxHp = $this->getMaxHealth();
        $hp = $this->getHealth();
        $percent = max(0, min(1, $hp / $maxHp));
        $percentValue = (int)round($percent * 100);
        
        $greenBars = (int)round($percent * 20);
        $redBars = 20 - $greenBars;
        
        $barStr = "§a" . str_repeat("|", $greenBars) . "§c" . str_repeat("|", $redBars) . " §e" . $percentValue . "%";
        $name = $this->getBaseName();
        
        if ($this->hasActiveMinions()) {
            $name = "§l§e[BẤT TỬ] §r" . $name;
        }
        
        $this->setNameTag($name . "\n" . $barStr);
    }

    private function tickAI(int $currentTick): void {
        if ($this->hasActiveMinions()) {
            return;
        }

        if ($currentTick - $this->findTargetTick >= 10) {
            $this->findTargetTick = $currentTick;
            $this->target = $this->findNearestPlayer(20);
        }

        if ($this->target !== null && $this->target->isOnline() && !$this->target->isClosed() && $this->target->isAlive() && $this->target->getWorld() === $this->getWorld()) {
            $targetLoc = $this->target->getLocation();
            $myLoc = $this->getLocation();
            
            $dx = $targetLoc->x - $myLoc->x;
            $dz = $targetLoc->z - $myLoc->z;
            $distanceXZ = sqrt($dx * $dx + $dz * $dz);

            if ($distanceXZ > 1.5) {
                $speed = (float) ($this->bossData['speed'] ?? 0.25);
                if ($this->isEnraged) $speed *= 1.3;

                if ($distanceXZ > 0) {
                    $motion = $this->getMotion();
                    $motion->x = ($dx / $distanceXZ) * $speed;
                    $motion->z = ($dz / $distanceXZ) * $speed;
                    $this->setMotion($motion);
                }
                $this->lookAt($targetLoc);
            } else {
                if ($currentTick % 20 === 0) {
                    $pk = new AnimatePacket();
                    $pk->action = AnimatePacket::ACTION_SWING_ARM;
                    $pk->actorRuntimeId = $this->getId();
                    $this->getWorld()->broadcastPacketToViewers($this->getLocation(), $pk);

                    $ev = new EntityDamageByEntityEvent($this, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, $this->getDamage());
                    $this->target->attack($ev);
                }
            }
        }
    }

    private function tickSkills(): void {
        if (!isset($this->bossData['skills'])) return;

        $hpPercent = ($this->getHealth() / $this->getMaxHealth()) * 100;
        $skillBoost = $this->hasActiveMinions() ? 2 : 1;

        foreach ($this->bossData['skills'] as $skillData) {
            $type = $skillData['type'];
            
            if ($type === "rage" && !$this->isEnraged && $hpPercent <= ($skillData['trigger_hp_percent'] ?? 30)) {
                $this->isEnraged = true;
                Main::getInstance()->getSkillManager()->getSkill("rage")?->execute($this, null, $skillData);
                continue;
            }

            if (isset($this->skillCooldowns[$type]) && time() < $this->skillCooldowns[$type]) continue;

            $chance = $skillData['chance'] ?? 10;
            if ($type !== "summon") {
                $chance *= $skillBoost;
            }

            if (mt_rand(1, 100) <= $chance) {
                $skill = Main::getInstance()->getSkillManager()->getSkill($type);
                if ($skill !== null) {
                    $skill->execute($this, $this->target, $skillData);
                    $this->skillCooldowns[$type] = time() + ($skillData['cooldown'] ?? 10);
                }
            }
        }
    }

    private function findNearestPlayer(float $radius): ?Player {
        $nearest = null;
        $minDistance = $radius ** 2;
        foreach ($this->getWorld()->getPlayers() as $player) {
            if (!$player->isOnline() || $player->isClosed() || !$player->isAlive()) continue;
            if ($player->isCreative() || $player->isSpectator()) continue;
            $distSq = $this->getLocation()->distanceSquared($player->getLocation());
            if ($distSq < $minDistance) {
                $minDistance = $distSq;
                $nearest = $player;
            }
        }
        return $nearest;
    }

    protected function onDeath(): void {
        parent::onDeath();
        if (!$this->isDungeonBoss && isset($this->bossData['rewards'])) {
            $lastDamager = $this->getLastDamageCause();
            if ($lastDamager instanceof EntityDamageByEntityEvent) {
                $damager = $lastDamager->getDamager();
                if ($damager instanceof Player) {
                    Main::getInstance()->getRewardManager()->giveReward($damager, $this->bossData['rewards']);
                }
            }
        }
    }
}