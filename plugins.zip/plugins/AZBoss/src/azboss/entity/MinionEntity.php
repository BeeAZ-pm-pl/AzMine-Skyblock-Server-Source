<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\animation\ArmSwingAnimation;
use pocketmine\entity\Human;
use pocketmine\entity\Location;
use pocketmine\entity\Skin;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;

class MinionEntity extends Human {

    private ?Player $target = null;
    private int $lifespan = 20;
    private int $spawnTime;
    private int $parentId = -1;
    private string $parentName = "Boss";

    public function __construct(Location $location, Skin $skin, ?CompoundTag $nbt = null) {
        parent::__construct($location, $skin, $nbt);
        $this->spawnTime = time();
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        
        $this->setCanSaveWithChunk(false);
        $this->parentId = $nbt->getInt("ParentBossId", -1);
        $this->parentName = $nbt->getString("ParentName", "Boss");
        
        $bossMaxHp = $nbt->getFloat("BossMaxHealth", 1000.0);
        $minionHp = (int)max(1, $bossMaxHp * 0.1);
        
        $this->setMaxHealth($minionHp);
        $this->setHealth((float)$minionHp);
        $this->setScale(0.6);
        $this->setNameTagAlwaysVisible(true);
    }

    public function getParentId(): int {
        return $this->parentId;
    }

    public function getTarget(): ?Player {
        return $this->target;
    }

    public function onUpdate(int $currentTick): bool {
        $hasUpdate = parent::onUpdate($currentTick);
        if (!$this->isAlive() || $this->isClosed()) return $hasUpdate;

        // KIỂM TRA BOSS CHÍNH: Nếu Boss không tồn tại hoặc đã chết -> Minion tự sát
        $parent = $this->getWorld()->getEntity($this->parentId);
        if ($parent === null || !$parent->isAlive() || $parent->isClosed()) {
            $this->flagForDespawn();
            return $hasUpdate;
        }

        $this->updateNameTag();

        if (time() - $this->spawnTime > $this->lifespan) {
            $this->flagForDespawn();
            return $hasUpdate;
        }

        if ($currentTick % 10 === 0) {
            $this->target = $this->findNearestPlayer(15);
        }

        if ($this->target !== null && $this->target->isAlive()) {
            $targetLoc = $this->target->getLocation();
            $myLoc = $this->getLocation();
            
            // Đã fix lỗi mất trọng lực (bay lơ lửng) cho Minion
            $dx = $targetLoc->x - $myLoc->x;
            $dz = $targetLoc->z - $myLoc->z;
            $distanceXZ = sqrt($dx * $dx + $dz * $dz);

            if ($distanceXZ > 1.2) {
                if ($distanceXZ > 0) {
                    $motion = $this->getMotion();
                    $motion->x = ($dx / $distanceXZ) * 0.28;
                    $motion->z = ($dz / $distanceXZ) * 0.28;
                    $this->setMotion($motion);
                }
                $this->lookAt($targetLoc);
            } else {
                if ($currentTick % 15 === 0) {
                    $this->broadcastAnimation(new ArmSwingAnimation($this));
                    $ev = new EntityDamageByEntityEvent($this, $this->target, EntityDamageEvent::CAUSE_ENTITY_ATTACK, 5.0);
                    $this->target->attack($ev);
                }
            }
        }

        return $hasUpdate;
    }

    private function updateNameTag(): void {
        $maxHp = $this->getMaxHealth();
        $hp = $this->getHealth();
        $percent = max(0, min(1, $hp / $maxHp));
        $percentValue = (int)round($percent * 100);
        
        $greenBars = (int)round($percent * 20);
        $redBars = 20 - $greenBars;
        
        $barStr = "§a" . str_repeat("|", $greenBars) . "§c" . str_repeat("|", $redBars) . " §e" . $percentValue . "%";
        
        $parent = $this->getWorld()->getEntity($this->parentId);
        $displayName = $parent instanceof BossEntity ? $parent->getBaseName() : $this->parentName;
        
        $this->setNameTag($displayName . " §r§c(Tí hon)\n" . $barStr);
    }

    private function findNearestPlayer(float $radius): ?Player {
        $nearest = null;
        $minDistance = $radius ** 2;
        foreach ($this->getWorld()->getPlayers() as $player) {
            if ($player->isCreative() || $player->isSpectator()) continue;
            $distSq = $this->getLocation()->distanceSquared($player->getLocation());
            if ($distSq < $minDistance) {
                $minDistance = $distSq;
                $nearest = $player;
            }
        }
        return $nearest;
    }
}