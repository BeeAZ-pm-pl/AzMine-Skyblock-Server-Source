<?php

declare(strict_types=1);

namespace azboss\entity;

use pocketmine\entity\EntitySizeInfo;

class NoivernBossEntity extends BossEntity {

    public static function getNetworkTypeId(): string {
        return "pokemon:p715";
    }

    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(2.0, 1.8);
    }
}
