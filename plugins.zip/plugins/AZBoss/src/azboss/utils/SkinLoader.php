<?php

declare(strict_types=1);

namespace azboss\utils;

use pocketmine\entity\Skin;
use azboss\Main;

class SkinLoader {
    private static string $skinFolder;

    public static function init(string $folder): void {
        self::$skinFolder = $folder;
    }

    public static function getSkin(string $skinId): Skin {
        $pngPath = self::$skinFolder . $skinId . ".png";
        $jsonPath = self::$skinFolder . $skinId . ".json";

        $greyPixel = chr(128) . chr(128) . chr(128) . chr(255);
        $fallbackSkin = new Skin("Standard_Custom", str_repeat($greyPixel, 2048));

        if (!file_exists($pngPath)) {
            return $fallbackSkin;
        }

        $img = @imagecreatefrompng($pngPath);
        if ($img === false) {
            Main::getInstance()->getLogger()->warning("§c[AZBoss] Không thể đọc file ảnh: $pngPath");
            return $fallbackSkin;
        }

        $width = (int) @imagesx($img);
        $height = (int) @imagesy($img);

        if ($width <= 0 || $height <= 0) {
            @imagedestroy($img);
            Main::getInstance()->getLogger()->warning("§c[AZBoss] File $skinId.png không hợp lệ. Tạm dùng skin mặc định!");
            return $fallbackSkin;
        }

        $skinData = "";
        for ($y = 0; $y < $height; $y++) {
            for ($x = 0; $x < $width; $x++) {
                $rgba = @imagecolorat($img, $x, $y);
                $a = ((~((int)($rgba >> 24))) << 1) & 0xff;
                $r = ($rgba >> 16) & 0xff;
                $g = ($rgba >> 8) & 0xff;
                $b = $rgba & 0xff;
                $skinData .= chr($r) . chr($g) . chr($b) . chr($a);
            }
        }
        @imagedestroy($img);

        // THUẬT TOÁN ĐỌC GEOMETRY MỚI - CHỐNG TÀNG HÌNH
        $geometryName = "";
        $geometryData = "";
        
        if (file_exists($jsonPath)) {
            $geometryData = file_get_contents($jsonPath);
            $json = @json_decode($geometryData, true);
            
            if ($json !== null) {
                // Thử đọc theo chuẩn 1.12.0+
                if (isset($json["minecraft:geometry"][0]["description"]["identifier"])) {
                    $geometryName = $json["minecraft:geometry"][0]["description"]["identifier"];
                } 
                // Thử quét tìm theo chuẩn 1.8.0 cũ
                else {
                    foreach ($json as $key => $val) {
                        if (str_starts_with($key, "geometry.")) {
                            $geometryName = $key;
                            break;
                        }
                    }
                }
            }

            // Nếu đọc xong mà vẫn không ra tên Geometry -> Hủy load file JSON để Boss không bị tàng hình
            if ($geometryName === "") {
                Main::getInstance()->getLogger()->warning("§e[AZBoss] Không thể trích xuất tên Geometry từ $skinId.json. Đã bỏ qua file này để tránh lỗi tàng hình!");
                $geometryData = "";
            }
        }

        try {
            return new Skin("Boss_" . $skinId, $skinData, "", $geometryName, $geometryData);
        } catch (\Exception $e) {
            Main::getInstance()->getLogger()->warning("§c[AZBoss] Lỗi cấu trúc Skin $skinId: " . $e->getMessage());
            return $fallbackSkin;
        }
    }
}