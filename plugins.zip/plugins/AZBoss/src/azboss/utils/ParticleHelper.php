<?php

declare(strict_types=1);

namespace azboss\utils;

use azboss\Main;
use pocketmine\world\World;
use pocketmine\math\Vector3;
use pocketmine\world\particle\Particle;
use pocketmine\player\Player;

class ParticleHelper {
    
    /**
     * Gửi particle được tối ưu: Chỉ gửi cho những player đứng gần boss.
     * Tránh spam packet làm sập đường truyền server.
     */
    public static function spawnOptimized(World $world, Vector3 $pos, Particle $particle): void {
        $viewDistance = (float) Main::getInstance()->getConfig()->getNested("performance.particle_view_distance", 32.0);
        $nearby = [];

        foreach ($world->getPlayers() as $player) {
            if ($player->getLocation()->distanceSquared($pos) <= ($viewDistance ** 2)) {
                $nearby[] = $player;
            }
        }

        if (count($nearby) > 0) {
            $world->addParticle($pos, $particle, $nearby);
        }
    }

    /**
     * Gửi particle dạng vòng tròn (Dùng cho FireAura, Poison)
     */
    public static function spawnCircle(World $world, Vector3 $center, float $radius, int $points, Particle $particle): void {
        $angle = 2 * M_PI / $points;
        for ($i = 0; $i < $points; $i++) {
            $x = $center->x + $radius * cos($i * $angle);
            $z = $center->z + $radius * sin($i * $angle);
            self::spawnOptimized($world, new Vector3($x, $center->y, $z), $particle);
        }
    }
}