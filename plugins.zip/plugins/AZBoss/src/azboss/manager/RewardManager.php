<?php

declare(strict_types=1);

namespace azboss\manager;

use pocketmine\console\ConsoleCommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class RewardManager {

    public function giveReward(Player $player, array $rewardCommands): void {
        $server = Server::getInstance();
        $console = new ConsoleCommandSender($server, $server->getLanguage());
        $playerName = $player->getName();

        foreach ($rewardCommands as $cmd) {
            $finalCmd = str_replace("{player}", '"' . $playerName . '"', $cmd);
            $server->getCommandMap()->dispatch($console, $finalCmd);
        }
    }
}