<?php

declare(strict_types=1);

namespace azboss\manager;

use azboss\skill\BaseSkill;
use azboss\skill\RageSkill;
use azboss\skill\FireBlastSkill;
use azboss\skill\DragonClawSkill;
use azboss\skill\DracoMeteorSkill;
use azboss\skill\TwisterSkill;
use azboss\skill\HyperBeamSkill;
use azboss\skill\DragonAscentSkill;
use azboss\skill\PrecipiceBladesSkill;
use azboss\skill\DualChopSkill;
use azboss\skill\PlasmaFistsSkill;
use azboss\skill\OblivionWingSkill;
use azboss\skill\WaterShurikenSkill;
use azboss\skill\OriginPulseSkill;
use azboss\skill\EarthquakeSkill;
use azboss\skill\HydroPumpSkill;
use azboss\skill\IronTailSkill;
use azboss\skill\PsystrikeSkill;
use azboss\skill\DragonRushSkill;
use azboss\skill\PsychoBoostSkill;
use azboss\skill\MeteorMashSkill;
use azboss\skill\BoomburstSkill;
use azboss\skill\RageFistSkill;
use azboss\skill\StoneEdgeSkill;

class SkillManager {
    private array $skills = [];

    public function __construct() {
        $this->registerSkill("rage", new RageSkill());
        $this->registerSkill("fire_blast", new FireBlastSkill());
        $this->registerSkill("dragon_claw", new DragonClawSkill());
        $this->registerSkill("draco_meteor", new DracoMeteorSkill());
        $this->registerSkill("twister", new TwisterSkill());
        $this->registerSkill("hyper_beam", new HyperBeamSkill());
        $this->registerSkill("dragon_ascent", new DragonAscentSkill());
        $this->registerSkill("precipice_blades", new PrecipiceBladesSkill());
        $this->registerSkill("dual_chop", new DualChopSkill());
        $this->registerSkill("plasma_fists", new PlasmaFistsSkill());
        $this->registerSkill("oblivion_wing", new OblivionWingSkill());
        $this->registerSkill("water_shuriken", new WaterShurikenSkill());
        $this->registerSkill("origin_pulse", new OriginPulseSkill());
        $this->registerSkill("earthquake", new EarthquakeSkill());
        $this->registerSkill("hydro_pump", new HydroPumpSkill());
        $this->registerSkill("iron_tail", new IronTailSkill());
        $this->registerSkill("psystrike", new PsystrikeSkill());
        $this->registerSkill("dragon_rush", new DragonRushSkill());
        $this->registerSkill("psycho_boost", new PsychoBoostSkill());
        $this->registerSkill("meteor_mash", new MeteorMashSkill());
        $this->registerSkill("boomburst", new BoomburstSkill());
        $this->registerSkill("rage_fist", new RageFistSkill());
        $this->registerSkill("stone_edge", new StoneEdgeSkill());
    }

    public function registerSkill(string $id, BaseSkill $skill): void {
        $this->skills[$id] = $skill;
    }

    public function getSkill(string $id): ?BaseSkill {
        return $this->skills[$id] ?? null;
    }
}