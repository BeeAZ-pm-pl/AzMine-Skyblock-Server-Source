<?php

declare(strict_types=1);

namespace azboss\manager;

use azboss\Main;
use pocketmine\utils\Config;
use azboss\entity\BossEntity;
use azboss\entity\MinionEntity;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\world\World;
use pocketmine\nbt\tag\CompoundTag;
use azboss\utils\SkinLoader;
use azboss\entity\RayquazaBossEntity;
use azboss\entity\CharizardBossEntity;
use azboss\entity\GroudonBossEntity;
use azboss\entity\GarchompBossEntity;
use azboss\entity\ZeraoraBossEntity;
use azboss\entity\YveltalBossEntity;
use azboss\entity\KyogreBossEntity;
use azboss\entity\NidokingBossEntity;
use azboss\entity\GyaradosBossEntity;
use azboss\entity\SteelixBossEntity;
use azboss\entity\MewtwoBossEntity;
use azboss\entity\SalamenceBossEntity;
use azboss\entity\DeoxysBossEntity;
use azboss\entity\MetagrossBossEntity;
use azboss\entity\NoivernBossEntity;
use azboss\entity\AnnihilapeBossEntity;
use azboss\entity\TyranitarBossEntity;

class BossManager {
    private array $bossesData = [];

    public function __construct(private Main $plugin) {
        $this->loadBosses();
        $this->registerEntities();
    }

    public function loadBosses(): void {
        $config = new Config($this->plugin->getDataFolder() . "bosses.yml", Config::YAML);
        $this->bossesData = $config->getAll();
        $this->plugin->getLogger()->info("§aĐã tải " . count($this->bossesData) . " cấu hình boss.");
    }

    private function registerEntities(): void {
        EntityFactory::getInstance()->register(RayquazaBossEntity::class, function(World $world, CompoundTag $nbt): RayquazaBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new RayquazaBossEntity($location, null, $nbt);
        }, ['pokemon:p384', 'rayquaza_boss_entity']);

        EntityFactory::getInstance()->register(CharizardBossEntity::class, function(World $world, CompoundTag $nbt): CharizardBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new CharizardBossEntity($location, null, $nbt);
        }, ['pokemon:p6', 'charizard_boss_entity']);

        EntityFactory::getInstance()->register(GroudonBossEntity::class, function(World $world, CompoundTag $nbt): GroudonBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new GroudonBossEntity($location, null, $nbt);
        }, ['pokemon:p383', 'groudon_boss_entity']);

        EntityFactory::getInstance()->register(GarchompBossEntity::class, function(World $world, CompoundTag $nbt): GarchompBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new GarchompBossEntity($location, null, $nbt);
        }, ['pokemon:p445', 'garchomp_boss_entity']);

        EntityFactory::getInstance()->register(ZeraoraBossEntity::class, function(World $world, CompoundTag $nbt): ZeraoraBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new ZeraoraBossEntity($location, null, $nbt);
        }, ['pokemon:p807', 'zeraora_boss_entity']);

        EntityFactory::getInstance()->register(YveltalBossEntity::class, function(World $world, CompoundTag $nbt): YveltalBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new YveltalBossEntity($location, null, $nbt);
        }, ['pokemon:p717', 'yveltal_boss_entity']);

        EntityFactory::getInstance()->register(NidokingBossEntity::class, function(World $world, CompoundTag $nbt): NidokingBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new NidokingBossEntity($location, null, $nbt);
        }, ['pokemon:p34', 'nidoking_boss_entity']);

        EntityFactory::getInstance()->register(GyaradosBossEntity::class, function(World $world, CompoundTag $nbt): GyaradosBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new GyaradosBossEntity($location, null, $nbt);
        }, ['pokemon:p130', 'gyarados_boss_entity']);

        EntityFactory::getInstance()->register(SteelixBossEntity::class, function(World $world, CompoundTag $nbt): SteelixBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new SteelixBossEntity($location, null, $nbt);
        }, ['pokemon:p208', 'steelix_boss_entity']);

        EntityFactory::getInstance()->register(MewtwoBossEntity::class, function(World $world, CompoundTag $nbt): MewtwoBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new MewtwoBossEntity($location, null, $nbt);
        }, ['pokemon:p150', 'mewtwo_boss_entity']);

        EntityFactory::getInstance()->register(SalamenceBossEntity::class, function(World $world, CompoundTag $nbt): SalamenceBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new SalamenceBossEntity($location, null, $nbt);
        }, ['pokemon:p373', 'salamence_boss_entity']);

        EntityFactory::getInstance()->register(DeoxysBossEntity::class, function(World $world, CompoundTag $nbt): DeoxysBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new DeoxysBossEntity($location, null, $nbt);
        }, ['pokemon:p386', 'deoxys_boss_entity']);

        EntityFactory::getInstance()->register(MetagrossBossEntity::class, function(World $world, CompoundTag $nbt): MetagrossBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new MetagrossBossEntity($location, null, $nbt);
        }, ['pokemon:p376', 'metagross_boss_entity']);

        EntityFactory::getInstance()->register(NoivernBossEntity::class, function(World $world, CompoundTag $nbt): NoivernBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new NoivernBossEntity($location, null, $nbt);
        }, ['pokemon:p715', 'noivern_boss_entity']);

        EntityFactory::getInstance()->register(AnnihilapeBossEntity::class, function(World $world, CompoundTag $nbt): AnnihilapeBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new AnnihilapeBossEntity($location, null, $nbt);
        }, ['pokemon:p979', 'annihilape_boss_entity']);

        EntityFactory::getInstance()->register(TyranitarBossEntity::class, function(World $world, CompoundTag $nbt): TyranitarBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new TyranitarBossEntity($location, null, $nbt);
        }, ['pokemon:p248', 'tyranitar_boss_entity']);

        EntityFactory::getInstance()->register(KyogreBossEntity::class, function(World $world, CompoundTag $nbt): KyogreBossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return new KyogreBossEntity($location, null, $nbt);
        }, ['pokemon:p382', 'kyogre_boss_entity']);

        EntityFactory::getInstance()->register(BossEntity::class, function(World $world, CompoundTag $nbt): BossEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            return BossEntity::create($location, $nbt);
        }, ['AZBossEntity', 'azboss:boss']);

        // Inject custom entity identifier into static packet cache so the client renders it
        try {
            $instance = \pocketmine\network\mcpe\cache\StaticPacketCache::getInstance();
            $property = (new \ReflectionClass($instance))->getProperty("availableActorIdentifiers");
            $packet = $property->getValue($instance);
            $root = $packet->identifiers->getRoot();
            
            $idList = $root->getListTag("idlist");
            if ($idList !== null) {
                $registeredIds = [
                    "pokemon:p6", "pokemon:p384", "pokemon:p383", "pokemon:p445", "pokemon:p807", "pokemon:p717", "pokemon:p382",
                    "pokemon:p34", "pokemon:p130", "pokemon:p208", "pokemon:p150", "pokemon:p373", "pokemon:p386", "pokemon:p376", "pokemon:p715", "pokemon:p979", "pokemon:p248"
                ];
                $existingIds = [];
                foreach ($idList as $tag) {
                    if ($tag instanceof CompoundTag) {
                        $existingIds[] = $tag->getString("id", "");
                    }
                }
                foreach ($registeredIds as $regId) {
                    if (!in_array($regId, $existingIds)) {
                        $idList->push(CompoundTag::create()
                            ->setString("id", $regId)
                            ->setString("bid", "")
                        );
                    }
                }
                $packet->identifiers = new \pocketmine\network\mcpe\protocol\types\CacheableNbt($root);
            }
        } catch (\Exception $e) {
            $this->plugin->getLogger()->error("§cLỗi nạp actor identifier: " . $e->getMessage());
        }

        EntityFactory::getInstance()->register(MinionEntity::class, function(World $world, CompoundTag $nbt): MinionEntity {
            $location = clone $world->getSpawnLocation();
            try {
                $location = EntityDataHelper::parseLocation($nbt, $world);
            } catch (\Exception $e) {}
            
            $skinId = $nbt->getString("SkinID", "default");
            $skin = SkinLoader::getSkin($skinId);
            
            return new MinionEntity($location, $skin, $nbt);
        }, ['AZMinionEntity', 'azboss:minion']);
    }

    public function getBossData(string $id): ?array {
        return $this->bossesData[$id] ?? null;
    }

    public function getAllBosses(): array {
        return $this->bossesData;
    }
}