<?php

namespace BeeAZ;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\world\ChunkLoadEvent;
use pocketmine\data\bedrock\BiomeIds;
use pocketmine\world\format\SubChunk;
use pocketmine\world\format\PalettedBlockArray;
use pocketmine\block\VanillaBlocks;
use pocketmine\scheduler\ClosureTask;
use az\season\Main as AZSeason;

class Biome extends PluginBase implements Listener {
    private int $cachedBiomeId = BiomeIds::JUNGLE;
    private int $cachedSeasonIndex = -1;
    private bool $isWinter = false;

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->updateSeason();
        $this->getScheduler()->scheduleRepeatingTask(new ClosureTask(function(): void {
            $this->updateSeason();
        }), 20 * 60);
    }

    private function updateSeason(): void {
        $plugin = $this->getServer()->getPluginManager()->getPlugin("AZSeason");
        if ($plugin instanceof AZSeason) {
            $index = $plugin->getSeasonManager()->getCurrentSeasonIndex();
            if ($index === $this->cachedSeasonIndex) return;
            $this->cachedSeasonIndex = $index;
            $this->cachedBiomeId = match($index) {
                0 => BiomeIds::FLOWER_FOREST,
                1 => BiomeIds::SAVANNA,
                2 => BiomeIds::TAIGA,
                3 => BiomeIds::COLD_TAIGA,
                default => BiomeIds::JUNGLE,
            };
            $this->isWinter = ($index === 3);
            $this->getLogger()->info("Season changed: biome=" . $this->cachedBiomeId . " winter=" . ($this->isWinter ? "true" : "false"));

            foreach ($this->getServer()->getWorldManager()->getWorlds() as $world) {
                if ($world->getFolderName() === "resource") continue;
                foreach ($world->getLoadedChunks() as $hash => $chunk) {
                    $this->applyBiomeToChunk($chunk);
                    if ($this->isWinter) {
                        \pocketmine\world\World::getXZ($hash, $cx, $cz);
                        $this->applySnowToChunk($world, $cx, $cz);
                    } else {
                        \pocketmine\world\World::getXZ($hash, $cx, $cz);
                        $this->removeSnowFromChunk($world, $cx, $cz);
                    }
                }
            }
        }
    }

    private function applyBiomeToChunk(\pocketmine\world\format\Chunk $chunk): void {
        foreach ($chunk->getSubChunks() as $y => $subChunk) {
            $palette = $subChunk->getBiomeArray()->getPalette();
            if (count($palette) === 1 && $palette[0] === $this->cachedBiomeId) {
                continue;
            }
            $chunk->setSubChunk($y, new SubChunk(
                $subChunk->getEmptyBlockId(),
                $subChunk->getBlockLayers(),
                new PalettedBlockArray($this->cachedBiomeId),
                $subChunk->getBlockSkyLightArray(),
                $subChunk->getBlockLightArray()
            ));
        }
    }

    private function applySnowToChunk(\pocketmine\world\World $world, int $cx, int $cz): void {
        $snowLayer = VanillaBlocks::SNOW_LAYER();
        for ($x = 0; $x < 16; $x++) {
            for ($z = 0; $z < 16; $z++) {
                $wx = ($cx << 4) + $x;
                $wz = ($cz << 4) + $z;
                $highestY = $world->getHighestBlockAt($wx, $wz);
                if ($highestY === null) continue;
                $topBlock = $world->getBlockAt($wx, $highestY, $wz);
                $aboveY = $highestY + 1;
                if ($aboveY > $world->getMaxY()) continue;
                $aboveBlock = $world->getBlockAt($wx, $aboveY, $wz);
                if ($topBlock instanceof \pocketmine\block\Liquid) continue;
                if ($topBlock instanceof \pocketmine\block\SnowLayer) continue;
                if (!$topBlock->isSolid()) continue;
                if ($aboveBlock->getTypeId() !== VanillaBlocks::AIR()->getTypeId()) continue;
                $world->setBlockAt($wx, $aboveY, $wz, $snowLayer);
            }
        }
    }

    private function removeSnowFromChunk(\pocketmine\world\World $world, int $cx, int $cz): void {
        $air = VanillaBlocks::AIR();
        for ($x = 0; $x < 16; $x++) {
            for ($z = 0; $z < 16; $z++) {
                $wx = ($cx << 4) + $x;
                $wz = ($cz << 4) + $z;
                $highestY = $world->getHighestBlockAt($wx, $wz);
                if ($highestY === null) continue;
                $topBlock = $world->getBlockAt($wx, $highestY, $wz);
                if ($topBlock instanceof \pocketmine\block\SnowLayer) {
                    $world->setBlockAt($wx, $highestY, $wz, $air);
                }
            }
        }
    }

    public function onChunkLoad(ChunkLoadEvent $event): void {
        $chunk = $event->getChunk();
        $world = $event->getWorld();
        if ($world->getFolderName() === "resource") return;
        $this->applyBiomeToChunk($chunk);
        $cx = $event->getChunkX();
        $cz = $event->getChunkZ();
        if ($this->isWinter) {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($world, $cx, $cz): void {
                if ($world->isLoaded() && $world->isChunkLoaded($cx, $cz)) {
                    $this->applySnowToChunk($world, $cx, $cz);
                }
            }), 1);
        } else {
            $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($world, $cx, $cz): void {
                if ($world->isLoaded() && $world->isChunkLoaded($cx, $cz)) {
                    $this->removeSnowFromChunk($world, $cx, $cz);
                }
            }), 1);
        }
    }
}