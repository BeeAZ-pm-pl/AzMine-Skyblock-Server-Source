<?php

declare(strict_types=1);

namespace BeeAZ\AZAttendance\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use BeeAZ\AZAttendance\Main;
use BeeAZ\AZAttendance\menu\AttendanceMenu;

class AttendanceCommand extends Command {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("diemdanh", "Mở menu điểm danh tháng", "/diemdanh", ["azattendance"]);
        $this->setPermission("azattendance.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args) : bool {
        if(!$sender instanceof Player) return false;
        
        $menu = new AttendanceMenu($this->plugin);
        $menu->sendAttendanceMenu($sender);
        return true;
    }
}