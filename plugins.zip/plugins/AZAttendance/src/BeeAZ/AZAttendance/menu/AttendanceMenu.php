<?php

declare(strict_types=1);

namespace BeeAZ\AZAttendance\menu;

use pocketmine\player\Player;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\Server;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use BeeAZ\AZAttendance\Main;

class AttendanceMenu {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function sendAttendanceMenu(Player $player) : void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName("§l§0DIỂM DANH THÁNG " . date("m/Y"));

        $inventory = $menu->getInventory();
        
        $currentDay = (int)date("j");
        $monthYear = date("m-Y");
        $daysInMonth = (int)date("t");

        for ($i = 1; $i <= 54; $i++) {
            if ($i <= $daysInMonth) {
                $inventory->setItem($i - 1, $this->getItemForDay($player, $i, $currentDay, $monthYear));
            } else {
                $pane = StringToItemParser::getInstance()->parse("gray_stained_glass_pane");
                if($pane !== null) {
                    $pane->setCustomName(" ");
                    $inventory->setItem($i - 1, $pane);
                }
            }
        }

        $menu->setListener(function(InvMenuTransaction $transaction) use ($currentDay, $monthYear): InvMenuTransactionResult {
            $player = $transaction->getPlayer();
            $slot = $transaction->getAction()->getSlot();
            $day = $slot + 1;

            if ($day > (int)date("t") || $day > $currentDay) {
                return $transaction->discard();
            }

            if ($day === $currentDay) {
                if (!$this->plugin->hasAttended($player->getName(), $day, $monthYear)) {
                    $this->plugin->setAttended($player->getName(), $day, $monthYear);
                    $this->giveReward($player, $day);
                    $player->removeCurrentWindow();
                    $player->sendMessage("§a§l[AZ]§r§a Bạn đã điểm danh thành công ngày hôm nay!");
                } else {
                    $player->sendMessage("§c§l[AZ]§r§c Bạn đã điểm danh ngày hôm nay rồi.");
                }
            } else {
                $player->sendMessage("§c§l[AZ]§r§c Bạn đã bỏ lỡ ngày điểm danh này.");
            }

            return $transaction->discard();
        });

        $menu->send($player);
    }

    private function getRewardConfig(int $day) : array {
        $cfg = $this->plugin->getCfg();
        $rewards = $cfg->get("rewards", []);
        return $rewards[$day] ?? $cfg->get("default_reward", []);
    }

    private function getItemForDay(Player $player, int $day, int $currentDay, string $monthYear) : Item {
        $rewardCfg = $this->getRewardConfig($day);
        $rewardType = $rewardCfg["type"] ?? "none";
        
        $rewardDesc = "§r§dPhần thưởng: §f";
        $extraLore = [];
        if($rewardType === "item") {
            $rewardDesc .= ($rewardCfg["amount"] ?? 1) . "x " . ($rewardCfg["name"] ?? ucfirst($rewardCfg["item"] ?? "Item"));
            if(isset($rewardCfg["enchants"]) && is_array($rewardCfg["enchants"])) {
                foreach($rewardCfg["enchants"] as $enchantName => $level) {
                    $extraLore[] = "§r§7  - " . ucfirst($enchantName) . " " . $level;
                }
            }
        } elseif ($rewardType === "command") {
            $rewardDesc .= "Lệnh hệ thống";
        } else {
            $rewardDesc .= "Không có";
        }

        if ($this->plugin->hasAttended($player->getName(), $day, $monthYear)) {
            $item = StringToItemParser::getInstance()->parse("map");
            if($item !== null) {
                $item->setCustomName("§l§aNgày " . $day);
                $item->setLore(array_merge(["§r§7Trạng thái: §bĐÃ NHẬN", $rewardDesc], $extraLore));
                return $item;
            }
        }

        if ($day === $currentDay) {
            $item = StringToItemParser::getInstance()->parse("emerald");
            if($item !== null) {
                $item->setCustomName("§l§eNgày " . $day);
                $item->setLore(array_merge([
                    "§r§7Trạng thái: §aCÓ THỂ NHẬN",
                    $rewardDesc
                ], $extraLore, [
                    "",
                    "§r§fNhấn để điểm danh ngay!"
                ]));
                $item->getNamedTag()->setInt("day", $day);
                return $item;
            }
        }

        if ($day < $currentDay) {
            $item = StringToItemParser::getInstance()->parse("paper");
            if($item !== null) {
                $item->setCustomName("§l§8Ngày " . $day);
                $item->setLore(array_merge([
                    "§r§7Trạng thái: §cBỎ LỠ",
                    $rewardDesc
                ], $extraLore));
                return $item;
            }
        }

        $item = StringToItemParser::getInstance()->parse("iron_ingot");
        if($item !== null) {
            $item->setCustomName("§l§fNgày " . $day);
            $item->setLore(array_merge([
                "§r§7Trạng thái: §7CHƯA ĐẾN",
                $rewardDesc
            ], $extraLore));
            return $item;
        }

        return StringToItemParser::getInstance()->parse("dirt");
    }

    private function buildItem(array $data) : ?Item {
        $itemStr = $data["item"] ?? "dirt";
        $item = StringToItemParser::getInstance()->parse($itemStr);
        if($item === null) return null;
        
        $item->setCount((int)($data["amount"] ?? 1));
        
        if(isset($data["name"])) {
            $item->setCustomName($data["name"]);
        }
        
        if(isset($data["lore"]) && is_array($data["lore"])) {
            $item->setLore($data["lore"]);
        }

        if(isset($data["enchants"]) && is_array($data["enchants"])) {
            foreach($data["enchants"] as $enchantName => $level) {
                $enchantment = StringToEnchantmentParser::getInstance()->parse((string)$enchantName);
                if($enchantment !== null) {
                    $item->addEnchantment(new EnchantmentInstance($enchantment, (int)$level));
                }
            }
        }
        return clone $item;
    }

    private function giveReward(Player $player, int $day) : void {
        $rewardCfg = $this->getRewardConfig($day);
        $type = $rewardCfg["type"] ?? "none";

        if ($type === "command") {
            $cmd = $rewardCfg["command"] ?? "";
            if ($cmd !== "") {
                $cmd = str_replace("{player}", $player->getName(), $cmd);
                $server = Server::getInstance();
                $server->dispatchCommand(new ConsoleCommandSender($server, $server->getLanguage()), $cmd);
            }
        } elseif ($type === "item") {
            $item = $this->buildItem($rewardCfg);
            if ($item !== null) {
                if ($player->getInventory()->canAddItem($item)) {
                    $player->getInventory()->addItem($item);
                } else {
                    $player->getWorld()->dropItem($player->getPosition(), $item);
                    $player->sendMessage("§c⚠️ Túi đồ đầy, phần thưởng rớt dưới chân!");
                }
            }
        }
    }
}