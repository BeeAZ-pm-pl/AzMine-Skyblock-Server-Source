<?php

declare(strict_types=1);

namespace BeeAZ\AZAttendance;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use muqsit\invmenu\InvMenuHandler;
use BeeAZ\AZAttendance\command\AttendanceCommand;
use SQLite3;

class Main extends PluginBase {

    private SQLite3 $db;
    private Config $cfg;

    protected function onEnable() : void {
        if(!InvMenuHandler::isRegistered()){
            InvMenuHandler::register($this);
        }

        date_default_timezone_set('Asia/Ho_Chi_Minh');

        $this->saveResource("config.yml");
        $this->cfg = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        
        $this->db = new SQLite3($this->getDataFolder() . "attendance.db");
        $this->db->exec("CREATE TABLE IF NOT EXISTS attendance (player VARCHAR(32), day INT, month_year VARCHAR(10), PRIMARY KEY (player, day, month_year))");
        
        $this->getServer()->getCommandMap()->register("azattendance", new AttendanceCommand($this));
    }

    protected function onDisable() : void {
        if(isset($this->db)){
            $this->db->close();
        }
    }

    public function getCfg() : Config {
        return $this->cfg;
    }

    public function hasAttended(string $player, int $day, string $monthYear) : bool {
        $stmt = $this->db->prepare("SELECT 1 FROM attendance WHERE player = :player AND day = :day AND month_year = :month_year");
        $stmt->bindValue(":player", strtolower($player), SQLITE3_TEXT);
        $stmt->bindValue(":day", $day, SQLITE3_INTEGER);
        $stmt->bindValue(":month_year", $monthYear, SQLITE3_TEXT);
        
        $result = $stmt->execute();
        $has = $result->fetchArray() !== false;
        
        $stmt->close();
        return $has;
    }

    public function setAttended(string $player, int $day, string $monthYear) : void {
        $stmt = $this->db->prepare("INSERT OR IGNORE INTO attendance (player, day, month_year) VALUES (:player, :day, :month_year)");
        $stmt->bindValue(":player", strtolower($player), SQLITE3_TEXT);
        $stmt->bindValue(":day", $day, SQLITE3_INTEGER);
        $stmt->bindValue(":month_year", $monthYear, SQLITE3_TEXT);
        
        $stmt->execute();
        $stmt->close();
    }
}