<?php

namespace azrank\listener;

use azrank\Main;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\player\chat\ChatFormatter;

class ChatListener implements Listener {
    public function __construct(private Main $plugin) {}

    public function onJoin(PlayerJoinEvent $event): void {
        $this->plugin->rank->updatePlayer($event->getPlayer());
    }

    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $message = $event->getMessage();
        $format = $this->plugin->rank->getChatFormat($player, $message);

        $event->setFormatter(new class($format) implements ChatFormatter {
            public function __construct(private string $format) {}
            public function format(string $username, string $message): string {
                return $this->format;
            }
        });
    }
}