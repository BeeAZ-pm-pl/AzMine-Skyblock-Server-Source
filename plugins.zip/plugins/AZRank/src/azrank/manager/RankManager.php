<?php

namespace azrank\manager;

use azrank\Main;
use pocketmine\player\Player;
use pocketmine\permission\PermissionAttachment;

class RankManager {
    private array $attachments = [];

    public function __construct(private Main $plugin) {}

    public function getDefaultGroup(): string {
        foreach ($this->plugin->groups->getAll() as $group => $data) {
            if (isset($data['isDefault']) && $data['isDefault']) {
                return $group;
            }
        }
        return "Guest";
    }

    public function getRank(string $player): string {
        $p = strtolower($player);
        $data = $this->plugin->players->get($p);
        if (is_array($data)) {
            if (isset($data['exp']) && $data['exp'] > 0 && time() > $data['exp']) {
                $this->setRank($p, $this->getDefaultGroup());
                return $this->getDefaultGroup();
            }
            $rank = $data['rank'] ?? $this->getDefaultGroup();
            return $this->plugin->groups->exists($rank) ? $rank : $this->getDefaultGroup();
        }
        if (is_string($data)) {
            $this->setRank($p, $data);
            return $this->plugin->groups->exists($data) ? $data : $this->getDefaultGroup();
        }
        return $this->getDefaultGroup();
    }

    public function setRank(string $player, string $rank, int $days = 0): bool {
        if (!$this->plugin->groups->exists($rank)) return false;
        $exp = $days > 0 ? time() + ($days * 86400) : 0;
        $this->plugin->players->set(strtolower($player), ["rank" => $rank, "exp" => $exp]);
        $this->plugin->players->save();
        $p = $this->plugin->getServer()->getPlayerExact($player);
        if ($p !== null) $this->updatePlayer($p);
        return true;
    }

    public function addGroup(string $name): bool {
        if ($this->plugin->groups->exists($name)) return false;
        $this->plugin->groups->set($name, [
            "isDefault" => false,
            "chat" => "§8[§f$name §8] §f{display_name} §8> §7{msg}",
            "nametag" => "§8[§f$name §8] §f{display_name}",
            "permissions" => []
        ]);
        $this->plugin->groups->save();
        return true;
    }

    public function removeGroup(string $name): bool {
        if (!$this->plugin->groups->exists($name)) return false;
        if ($this->plugin->groups->getNested("$name.isDefault", false)) return false;
        $this->plugin->groups->remove($name);
        $this->plugin->groups->save();
        return true;
    }

    public function setGroupFormat(string $name, string $type, string $format): bool {
        if (!$this->plugin->groups->exists($name)) return false;
        if (!in_array($type, ["chat", "nametag"])) return false;
        $this->plugin->groups->setNested("$name.$type", $format);
        $this->plugin->groups->save();
        return true;
    }

    public function addGroupPerm(string $name, string $perm): bool {
        if (!$this->plugin->groups->exists($name)) return false;
        $perms = $this->plugin->groups->getNested("$name.permissions", []);
        if (!in_array($perm, $perms)) {
            $perms[] = $perm;
            $this->plugin->groups->setNested("$name.permissions", $perms);
            $this->plugin->groups->save();
            return true;
        }
        return false;
    }

    public function removeGroupPerm(string $name, string $perm): bool {
        if (!$this->plugin->groups->exists($name)) return false;
        $perms = $this->plugin->groups->getNested("$name.permissions", []);
        $key = array_search($perm, $perms);
        if ($key !== false) {
            unset($perms[$key]);
            $this->plugin->groups->setNested("$name.permissions", array_values($perms));
            $this->plugin->groups->save();
            return true;
        }
        return false;
    }

    // --- Hàm bổ trợ lấy thông tin liên kết ---
    private function getAddonTags(string $playerName) : array {
        $clan = "";
        $azfaction = $this->plugin->getServer()->getPluginManager()->getPlugin("AZFaction");
        if ($azfaction !== null) {
            $factionName = $azfaction->getDatabase()->getPlayerFaction($playerName);
            if ($factionName !== null) {
                $clan = $factionName;
            }
        }

        $levelDao = "0";
        $azskyblock = $this->plugin->getServer()->getPluginManager()->getPlugin("AZSkyBlock");
        if ($azskyblock !== null) {
            $islandId = $azskyblock->island->getIslandByPlayer($playerName);
            if ($islandId !== null) {
                $data = $azskyblock->db->cache[$islandId] ?? null;
                if ($data !== null) {
                    $levelDao = (string)($data['level'] ?? 1);
                }
            }
        }

        $canhgioi = "§7Phàm Nhân";
        $azcanhgioi = $this->plugin->getServer()->getPluginManager()->getPlugin("AZCanhGioi");
        if ($azcanhgioi !== null && $azcanhgioi->isEnabled()) {
            $canhgioi = $azcanhgioi->getPlayerRealmName($playerName);
        }

        return [
            "{clan}" => $clan,
            "{level_dao}" => $levelDao,
            "{canh_gioi}" => $canhgioi
        ];
    }

    public function updatePlayer(Player $player): void {
        $name = $player->getName();
        $rank = $this->getRank($name);
        $groupData = $this->plugin->groups->get($rank, []);
        
        if (isset($this->attachments[$name])) {
            $player->removeAttachment($this->attachments[$name]);
        }
        
        $attachment = $player->addAttachment($this->plugin);
        $this->attachments[$name] = $attachment;
        
        $perms = $groupData['permissions'] ?? [];
        foreach ($perms as $perm) {
            $attachment->setPermission($perm, true);
        }
        
        $nametag = $groupData['nametag'] ?? "{display_name}";
        $nametag = str_replace("{display_name}", $player->getDisplayName(), $nametag);
        
        // Thay thế các tags phụ
        $tags = $this->getAddonTags($name);
        $nametag = str_replace(array_keys($tags), array_values($tags), $nametag);

        // Clean up empty clan tag brackets if the player has no clan
        if ($tags["{clan}"] === "") {
            $nametag = str_replace(["§8[§b§8] ", "§8[§b§8]"], "", $nametag);
        }

        $player->setNameTag($nametag);
    }

    public function getChatFormat(Player $player, string $message): string {
        $name = $player->getName();
        $rank = $this->getRank($name);
        $groupData = $this->plugin->groups->get($rank, []);
        $format = $groupData['chat'] ?? "<{display_name}> {msg}";
        
        $format = str_replace(["{display_name}", "{msg}"], [$player->getDisplayName(), $message], $format);
        
        // Thay thế các tags phụ
        $tags = $this->getAddonTags($name);
        $format = str_replace(array_keys($tags), array_values($tags), $format);

        // Clean up empty clan tag brackets if the player has no clan
        if ($tags["{clan}"] === "") {
            $format = str_replace(["§8[§b§8] ", "§8[§b§8]"], "", $format);
        }

        return $format;
    }
}