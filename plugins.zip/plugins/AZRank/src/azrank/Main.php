<?php

namespace azrank;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use azrank\manager\RankManager;
use azrank\listener\ChatListener;
use azrank\command\RankCommand;

class Main extends PluginBase {
    private static self $instance;
    public Config $groups;
    public Config $players;
    public RankManager $rank;

    protected function onEnable(): void {
        self::$instance = $this;
        $this->saveResource("groups.yml");
        $this->groups = new Config($this->getDataFolder() . "groups.yml", Config::YAML);
        $this->players = new Config($this->getDataFolder() . "players.yml", Config::YAML);
        $this->rank = new RankManager($this);

        $this->getServer()->getPluginManager()->registerEvents(new ChatListener($this), $this);
        $this->getServer()->getCommandMap()->register("azrank", new RankCommand($this));
    }

    public static function getInstance(): self {
        return self::$instance;
    }
}