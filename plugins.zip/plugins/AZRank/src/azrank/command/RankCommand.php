<?php

namespace azrank\command;

use azrank\Main;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class RankCommand extends Command {
    public function __construct(private Main $plugin) {
        parent::__construct("azrank", "Hệ thống quản lý AZRank", "/azrank help", ["rank"]);
        $this->setPermission("azrank.command");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) return false;

        if (count($args) < 1) {
            $this->sendHelp($sender);
            return false;
        }

        $action = strtolower($args[0]);

        switch ($action) {
            case "set":
                if (count($args) < 3) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank set <tên> <rank>");
                    return false;
                }
                if ($this->plugin->rank->setRank($args[1], $args[2])) {
                    $sender->sendMessage("§a⚡ §lĐã cấp rank §f" . $args[2] . " §acho §f" . $args[1] . " §avĩnh viễn!");
                } else {
                    $sender->sendMessage("§c⚡ §lRank §f" . $args[2] . " §ckhông tồn tại!");
                }
                break;

            case "settemp":
                if (count($args) < 4) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank settemp <tên> <rank> <số_ngày>");
                    return false;
                }
                $days = (int)$args[3];
                if ($this->plugin->rank->setRank($args[1], $args[2], $days)) {
                    $sender->sendMessage("§a⚡ §lĐã cấp rank §f" . $args[2] . " §acho §f" . $args[1] . " §atrong §f" . $days . " §angày!");
                } else {
                    $sender->sendMessage("§c⚡ §lRank §f" . $args[2] . " §ckhông tồn tại!");
                }
                break;

            case "addgroup":
                if (count($args) < 2) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank addgroup <tên_nhóm>");
                    return false;
                }
                if ($this->plugin->rank->addGroup($args[1])) {
                    $sender->sendMessage("§a⚡ §lĐã tạo nhóm §f" . $args[1] . " §athành công!");
                } else {
                    $sender->sendMessage("§c⚡ §lNhóm này đã tồn tại!");
                }
                break;

            case "delgroup":
                if (count($args) < 2) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank delgroup <tên_nhóm>");
                    return false;
                }
                if ($this->plugin->rank->removeGroup($args[1])) {
                    $sender->sendMessage("§a⚡ §lĐã xóa nhóm §f" . $args[1] . " §athành công!");
                } else {
                    $sender->sendMessage("§c⚡ §lNhóm không tồn tại hoặc đây là nhóm mặc định!");
                }
                break;

            case "setformat":
                if (count($args) < 4) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank setformat <nhóm> <chat/nametag> <format...>");
                    return false;
                }
                $format = implode(" ", array_slice($args, 3));
                if ($this->plugin->rank->setGroupFormat($args[1], strtolower($args[2]), $format)) {
                    $sender->sendMessage("§a⚡ §lĐã thay đổi định dạng §f" . $args[2] . " §acủa nhóm §f" . $args[1] . "!");
                } else {
                    $sender->sendMessage("§c⚡ §lNhóm không tồn tại hoặc loại format không hợp lệ!");
                }
                break;

            case "addperm":
                if (count($args) < 3) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank addperm <nhóm> <quyền>");
                    return false;
                }
                if ($this->plugin->rank->addGroupPerm($args[1], $args[2])) {
                    $sender->sendMessage("§a⚡ §lĐã thêm quyền §f" . $args[2] . " §acho nhóm §f" . $args[1] . "!");
                } else {
                    $sender->sendMessage("§c⚡ §lNhóm không tồn tại hoặc đã có quyền này rồi!");
                }
                break;

            case "delperm":
                if (count($args) < 3) {
                    $sender->sendMessage("§c⚡ §lSử dụng: /azrank delperm <nhóm> <quyền>");
                    return false;
                }
                if ($this->plugin->rank->removeGroupPerm($args[1], $args[2])) {
                    $sender->sendMessage("§a⚡ §lĐã xóa quyền §f" . $args[2] . " §ckhỏi nhóm §f" . $args[1] . "!");
                } else {
                    $sender->sendMessage("§c⚡ §lNhóm không tồn tại hoặc không có quyền này!");
                }
                break;

            default:
                $this->sendHelp($sender);
                break;
        }

        if (in_array($action, ["setformat", "addperm", "delperm"])) {
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $p) {
                if ($this->plugin->rank->getRank($p->getName()) === $args[1]) {
                    $this->plugin->rank->updatePlayer($p);
                }
            }
        }

        return true;
    }

    private function sendHelp(CommandSender $sender): void {
        $sender->sendMessage("§e⚡ §lHỆ THỐNG AZRANK §r§e⚡");
        $sender->sendMessage("§f/azrank set <tên> <rank> §7- Cấp rank vĩnh viễn");
        $sender->sendMessage("§f/azrank settemp <tên> <rank> <ngày> §7- Cấp rank theo ngày");
        $sender->sendMessage("§f/azrank addgroup <tên> §7- Tạo nhóm mới");
        $sender->sendMessage("§f/azrank delgroup <tên> §7- Xóa nhóm");
        $sender->sendMessage("§f/azrank setformat <nhóm> <chat/nametag> <format> §7- Sửa hiển thị");
        $sender->sendMessage("§f/azrank addperm <nhóm> <quyền> §7- Thêm quyền cho nhóm");
        $sender->sendMessage("§f/azrank delperm <nhóm> <quyền> §7- Xóa quyền khỏi nhóm");
    }
}