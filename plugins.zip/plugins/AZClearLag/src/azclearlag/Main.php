<?php

namespace azclearlag;

use pocketmine\plugin\PluginBase;

class Main extends PluginBase {
    protected function onEnable(): void {
        $this->getScheduler()->scheduleRepeatingTask(new ClearTask(), 20);
    }
}