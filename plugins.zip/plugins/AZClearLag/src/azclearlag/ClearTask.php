<?php

namespace azclearlag;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\entity\object\ItemEntity;
use pocketmine\entity\object\ExperienceOrb;

class ClearTask extends Task {
    private int $time = 300; 

    public function onRun(): void {
        $this->time--;
        $server = Server::getInstance();
        $prefix = "§l§c[§eDọn Rác§c]§r ";

        if (in_array($this->time, [60, 30, 10, 5, 4, 3, 2, 1])) {
            $server->broadcastMessage($prefix . "§fHệ thống sẽ dọn sạch vật phẩm rơi vãi sau §a" . $this->time . " §fgiây nữa!");
        } elseif ($this->time <= 0) {
            $count = 0;
            
            foreach ($server->getWorldManager()->getWorlds() as $world) {
                foreach ($world->getEntities() as $entity) {
                    if ($entity instanceof ItemEntity || $entity instanceof ExperienceOrb) {
                        $entity->flagForDespawn();
                        $count++;
                    }
                }
            }
            
            $server->broadcastMessage($prefix . "§fĐã dọn sạch §a" . $count . " §fvật phẩm rác rớt trên mặt đất!");
            $this->time = 300;
        }
    }
}