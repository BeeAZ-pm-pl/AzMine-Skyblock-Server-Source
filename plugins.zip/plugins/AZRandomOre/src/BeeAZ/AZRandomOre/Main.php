<?php

declare(strict_types=1);

namespace BeeAZ\AZRandomOre;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\block\BlockSpreadEvent;
use pocketmine\block\VanillaBlocks;
use pocketmine\block\Block;
use pocketmine\block\Fence;
use pocketmine\block\Water;
use pocketmine\item\StringToItemParser;
use pocketmine\math\Facing;

class Main extends PluginBase implements Listener {

    /** @var array<string, float> block_name => chance (0-100) */
    private array $oreTable = [];
    private float $totalChance = 0.0;
    private array $enabledWorlds = [];

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->loadOreTable();

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    private function loadOreTable(): void {
        $this->oreTable = [];
        $this->totalChance = 0.0;
        $this->enabledWorlds = $this->getConfig()->get("enabled-worlds", []);

        $ores = $this->getConfig()->get("ores", []);
        foreach ($ores as $name => $chance) {
            $this->oreTable[(string)$name] = (float)$chance;
            $this->totalChance += (float)$chance;
        }

        $extras = $this->getConfig()->get("extra-blocks", []);
        foreach ($extras as $name => $chance) {
            $this->oreTable[(string)$name] = (float)$chance;
            $this->totalChance += (float)$chance;
        }
    }

    /**
     * Khi nước chảy lan (spread) vào vị trí kề bên fence → tạo random ore tại đó
     */
    public function onBlockSpread(BlockSpreadEvent $event): void {
        $newState = $event->getNewState();
        $pos = $event->getBlock()->getPosition();
        $world = $pos->getWorld();

        if (!in_array($world->getFolderName(), $this->enabledWorlds)) return;

        // Chỉ can thiệp khi nước đang lan ra
        if (!$newState instanceof Water) return;

        // Kiểm tra xem có fence nào kề bên vị trí nước sắp lan tới không
        $block = $event->getBlock();
        $hasFence = false;
        foreach (Facing::HORIZONTAL as $face) {
            $side = $block->getSide($face);
            if ($side instanceof Fence) {
                $hasFence = true;
                break;
            }
        }
        // Kiểm tra cả block phía dưới
        if (!$hasFence) {
            $below = $block->getSide(Facing::DOWN);
            if ($below instanceof Fence) {
                $hasFence = true;
            }
        }

        if ($hasFence) {
            $event->cancel();
            $randomBlock = $this->rollRandomBlock();
            $world->setBlock($pos, $randomBlock ?? VanillaBlocks::COBBLESTONE());
        }
    }

    private function rollRandomBlock(): ?Block {
        if (empty($this->oreTable) || $this->totalChance <= 0) return null;

        // Roll ngẫu nhiên 0 - 100
        $roll = mt_rand(0, 10000) / 100.0;

        // Nếu roll > totalChance → giữ nguyên cobblestone
        if ($roll > $this->totalChance) return null;

        // Xác định block nào trúng
        $cumulative = 0.0;
        foreach ($this->oreTable as $name => $chance) {
            $cumulative += $chance;
            if ($roll <= $cumulative) {
                return $this->parseBlock($name);
            }
        }

        return null;
    }

    private function parseBlock(string $name): ?Block {
        $item = StringToItemParser::getInstance()->parse($name);
        if ($item !== null) {
            $block = $item->getBlock();
            if (!$block->hasSameTypeId(VanillaBlocks::AIR())) {
                return $block;
            }
        }
        return null;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (strtolower($command->getName()) !== "azore") return false;

        if (!$sender->hasPermission("azrandomore.command")) {
            $sender->sendMessage("§cBạn không có quyền sử dụng lệnh này!");
            return true;
        }

        if (isset($args[0]) && strtolower($args[0]) === "reload") {
            $this->reloadConfig();
            $this->loadOreTable();
            $prefix = $this->getConfig()->getNested("messages.prefix", "");
            $sender->sendMessage($prefix . $this->getConfig()->getNested("messages.reload", "§aĐã tải lại!"));
            return true;
        }

        // Hiển thị bảng tỷ lệ
        $prefix = $this->getConfig()->getNested("messages.prefix", "");
        $sender->sendMessage($prefix . "§eBảng tỷ lệ quặng (Tổng: §6" . round($this->totalChance, 1) . "%§e):");
        foreach ($this->oreTable as $name => $chance) {
            $sender->sendMessage("  §7- §f" . $name . ": §a" . $chance . "%");
        }
        $cobblestoneChance = max(0, 100 - $this->totalChance);
        $sender->sendMessage("  §7- §fcobblestone: §7" . round($cobblestoneChance, 1) . "% (mặc định)");
        $sender->sendMessage($prefix . "§7Dùng §f/azore reload §7để tải lại cấu hình.");

        return true;
    }
}
