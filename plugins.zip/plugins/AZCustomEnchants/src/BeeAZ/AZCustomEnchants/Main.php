<?php
declare(strict_types=1);

namespace BeeAZ\AZCustomEnchants;

use pocketmine\plugin\PluginBase;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\Rarity;
use pocketmine\item\enchantment\ItemFlags;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use BeeAZ\AZCustomEnchants\command\CustomEnchantCommand;
use BeeAZ\AZCustomEnchants\listener\EventListener;
use BeeAZ\AZCustomEnchants\manager\StatsManager;
use BeeAZ\AZCustomEnchants\task\LoreRebuildTask;

class Main extends PluginBase {
    private static self $instance;

    protected function onEnable(): void {
        self::$instance = $this;

        $this->registerEnchantments();

        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getServer()->getCommandMap()->register("azcustomenchants", new CustomEnchantCommand($this));

        // Quét inventory định kỳ mỗi 3 giây để rebuild lore cho items từ config/command
        $this->getScheduler()->scheduleRepeatingTask(new LoreRebuildTask(), 60);
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    private function registerEnchantments(): void {
        foreach (StatsManager::STATS_DEFINITIONS as $key => $data) {
            $enchant = new Enchantment(
                $data['name'],
                Rarity::RARE,
                ItemFlags::ALL,
                ItemFlags::ALL,
                $data['max_level']
            );
            EnchantmentIdMap::getInstance()->register($data['id'], $enchant);
            StringToEnchantmentParser::getInstance()->register($data['name'], fn() => $enchant);
        }
        $this->getLogger()->info("§aRegistered AZCustomEnchants custom enchantments directly into PocketMine!");
    }
}
