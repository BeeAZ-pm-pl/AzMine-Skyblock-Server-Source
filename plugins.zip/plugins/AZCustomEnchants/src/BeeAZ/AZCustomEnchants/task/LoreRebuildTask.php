<?php
declare(strict_types=1);

namespace BeeAZ\AZCustomEnchants\task;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use BeeAZ\AZCustomEnchants\manager\StatsManager;

class LoreRebuildTask extends Task {

    public function onRun(): void {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $inv = $player->getInventory();
            foreach ($inv->getContents() as $slot => $item) {
                if (StatsManager::checkAndRebuildLore($item)) {
                    $inv->setItem($slot, $item);
                }
            }
            $armor = $player->getArmorInventory();
            foreach ($armor->getContents() as $slot => $item) {
                if (StatsManager::checkAndRebuildLore($item)) {
                    $armor->setItem($slot, $item);
                }
            }
        }
    }
}
