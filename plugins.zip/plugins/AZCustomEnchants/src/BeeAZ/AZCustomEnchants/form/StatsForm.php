<?php
declare(strict_types=1);

namespace BeeAZ\AZCustomEnchants\form;

use pocketmine\player\Player;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Dropdown;
use dktapps\pmforms\element\Input;
use BeeAZ\AZCustomEnchants\manager\StatsManager;
use BeeAZ\AZCustomEnchants\Main;

class StatsForm {

    public static function send(Player $player): void {
        $statsList = [
            "HP",
            "PVE",
            "CRIT",
            "PVP",
            "DEFENSE"
        ];

        $keysList = [
            "hp",
            "pve",
            "crit",
            "pvp",
            "defense"
        ];

        $item = $player->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $player->sendMessage("§c⚡ Bạn phải cầm một vật phẩm trên tay để chỉnh sửa chỉ số!");
            return;
        }

        $form = new CustomForm(
            "§e⚡ §lCÀI ĐẶT CẤP ĐỘ CHỈ SỐ",
            [
                new Dropdown("stat", "§fChọn chỉ số cần chỉnh sửa:", $statsList),
                new Input("level", "§fNhập cấp độ chỉ số (0 để xóa):", "1")
            ],
            function(Player $submitter, CustomFormResponse $response) use ($statsList, $keysList): void {
                $item = $submitter->getInventory()->getItemInHand();
                if ($item->isNull()) {
                    $submitter->sendMessage("§c⚡ Bạn phải cầm một vật phẩm trên tay để chỉnh sửa chỉ số!");
                    return;
                }

                $selectedIndex = $response->getInt("stat");
                $levelStr = $response->getString("level");

                if (!filter_var($levelStr, FILTER_VALIDATE_INT) && $levelStr !== "0") {
                    $submitter->sendMessage("§c⚡ Cấp độ phải là một số nguyên dương!");
                    return;
                }

                $level = (int)$levelStr;
                $statKey = $keysList[$selectedIndex];
                
                $data = StatsManager::STATS_DEFINITIONS[$statKey];
                $maxLevel = $data['max_level'];

                if ($level < 0 || $level > $maxLevel) {
                    $submitter->sendMessage("§c⚡ Cấp độ phải nằm trong khoảng từ 0 đến " . $maxLevel . " (0 để xóa)!");
                    return;
                }

                $currentStats = StatsManager::getItemStats($item);
                $multiplier = $data['multiplier'];
                $currentStats[$statKey] = $level * $multiplier;

                StatsManager::setItemStats($item, $currentStats);
                $submitter->getInventory()->setItemInHand($item);

                if ($statKey === "hp") {
                    StatsManager::updatePlayerHealth($submitter);
                }

                $submitter->sendMessage("§aĐã đặt cấp độ chỉ số §e" . $statsList[$selectedIndex] . " §athành §e" . $level . " §acho vật phẩm!");
            }
        );

        $player->sendForm($form);
    }
}
