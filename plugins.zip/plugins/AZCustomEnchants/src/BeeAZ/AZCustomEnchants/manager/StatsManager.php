<?php
declare(strict_types=1);

namespace BeeAZ\AZCustomEnchants\manager;

use pocketmine\item\Item;
use pocketmine\player\Player;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\StringToEnchantmentParser;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\lang\Translatable;
use BeeAZ\AZCustomEnchants\Main;

class StatsManager {

    public const STATS_DEFINITIONS = [
        "hp" => ["id" => 901, "name" => "HP", "max_level" => 1000000, "multiplier" => 1.0],
        "pve" => ["id" => 902, "name" => "PVE", "max_level" => 1000000, "multiplier" => 1.0],
        "crit" => ["id" => 903, "name" => "CRIT", "max_level" => 1000000, "multiplier" => 1.0],
        "pvp" => ["id" => 904, "name" => "PVP", "max_level" => 1000000, "multiplier" => 1.0],
        "defense" => ["id" => 905, "name" => "DEFENSE", "max_level" => 1000000, "multiplier" => 1.0]
    ];

    /**
     * Get all custom stats of an item.
     * Parses stats based on enchantment levels.
     *
     * @param Item $item
     * @return array
     */
    public static function getItemStats(Item $item): array {
        $stats = [
            "hp" => 0.0,
            "pve" => 0.0,
            "crit" => 0.0,
            "pvp" => 0.0,
            "defense" => 0.0
        ];

        if ($item->isNull()) {
            return $stats;
        }

        foreach ($item->getEnchantments() as $enchantInstance) {
            $enchant = $enchantInstance->getType();
            $level = $enchantInstance->getLevel();
            
            foreach (self::STATS_DEFINITIONS as $key => $data) {
                $enchantName = $enchant->getName();
                if ($enchantName instanceof Translatable) {
                    $enchantName = $enchantName->getText();
                }
                $enchantId = -1;
                try {
                    $enchantId = EnchantmentIdMap::getInstance()->toId($enchant);
                } catch (\InvalidArgumentException $e) {}

                if ($enchantName === $data['name'] || ($enchantId !== -1 && $enchantId === $data['id'])) {
                    $multiplier = $data['multiplier'];
                    $stats[$key] = $level * $multiplier;
                    break;
                }
            }
        }

        return $stats;
    }

    /**
     * Write custom stats to an item as enchantments.
     *
     * @param Item $item
     * @param array $stats
     */
    public static function setItemStats(Item $item, array $stats): void {
        // Remove existing AZCustomEnchants enchantments
        foreach (self::STATS_DEFINITIONS as $key => $data) {
            $enchant = StringToEnchantmentParser::getInstance()->parse($data['name']);
            if ($enchant !== null) {
                $item->removeEnchantment($enchant);
            }
        }

        // Add new ones
        foreach ($stats as $key => $value) {
            if (!isset(self::STATS_DEFINITIONS[$key])) continue;
            $data = self::STATS_DEFINITIONS[$key];
            
            $enchant = StringToEnchantmentParser::getInstance()->parse($data['name']);
            if ($enchant !== null && $value > 0.0) {
                $multiplier = $data['multiplier'];
                $level = (int)round($value / $multiplier);
                if ($level < 1) $level = 1;
                if ($level > $data['max_level']) $level = $data['max_level'];
                
                $item->addEnchantment(new EnchantmentInstance($enchant, $level));
            }
        }
        
        // Format lore
        $lore = $item->getLore();
        $newLore = [];
        
        foreach ($lore as $line) {
            $cleanLine = str_replace("§", "", $line);
            $cleanLine = trim(strtolower($cleanLine));
            $isEnchantLine = false;
            foreach (self::STATS_DEFINITIONS as $key => $data) {
                if (strpos($cleanLine, strtolower($data['name'])) !== false) {
                    $isEnchantLine = true;
                    break;
                }
            }
            if (!$isEnchantLine) {
                $newLore[] = $line;
            }
        }
        
        foreach ($stats as $key => $value) {
            if ($value > 0.0 && isset(self::STATS_DEFINITIONS[$key])) {
                $data = self::STATS_DEFINITIONS[$key];
                
                // Color mapping:
                // HP: Light Purple/Pink (§d)
                // PVE, CRIT: Yellow (§e)
                // PVP: Red (§c)
                // DEFENSE: Green (§a)
                $color = "§7";
                if ($key === "hp") {
                    $color = "§d";
                } elseif ($key === "pve" || $key === "crit") {
                    $color = "§e";
                } elseif ($key === "pvp") {
                    $color = "§c";
                } elseif ($key === "defense") {
                    $color = "§a";
                }

                if ($key === "hp") {
                    $newLore[] = "§r" . $color . "HP +" . (int)$value;
                } else {
                    $newLore[] = "§r" . $color . $data['name'] . " +" . (int)$value . "%";
                }
            }
        }
        $item->setLore($newLore);
    }

    /**
     * Aggregate total custom stats of a player.
     *
     * @param Player $player
     * @return array
     */
    public static function getPlayerStats(Player $player): array {
        $totals = [
            "hp" => 0.0,
            "pve" => 0.0,
            "crit" => 0.0,
            "pvp" => 0.0,
            "defense" => 0.0
        ];

        $items = [];
        $items[] = $player->getInventory()->getItemInHand();
        foreach ($player->getArmorInventory()->getContents() as $item) {
            if ($item !== null && !$item->isNull()) {
                $items[] = $item;
            }
        }
        if (method_exists($player, "getOffHandInventory")) {
            $items[] = $player->getOffHandInventory()->getItem(0);
        }

        foreach ($items as $item) {
            if ($item !== null && !$item->isNull()) {
                $itemStats = self::getItemStats($item);
                foreach ($totals as $key => $val) {
                    $totals[$key] += $itemStats[$key];
                }
            }
        }

        return $totals;
    }

    /**
     * Update player's max health based on hp stat.
     *
     * @param Player $player
     */
    public static function updatePlayerHealth(Player $player): void {
        $stats = self::getPlayerStats($player);
        $additionalHealth = (int)($stats["hp"] ?? 0.0);
        
        $newMax = 20 + $additionalHealth;
        if ($player->getMaxHealth() !== $newMax) {
            $player->setMaxHealth($newMax);
            if ($player->getHealth() > $newMax) {
                $player->setHealth($newMax);
            }
        }
    }

    /**
     * Check if the item's lore is missing the required stats description.
     * Rebuilds and updates the lore if needed.
     *
     * @param Item $item
     * @return bool True if lore was rebuilt/modified, false otherwise
     */
    public static function checkAndRebuildLore(Item $item): bool {
        if ($item->isNull()) {
            return false;
        }

        $modified = false;
        if (class_exists(\BeeAZ\AZCustomFishing\EventListener::class)) {
            $modified = \BeeAZ\AZCustomFishing\EventListener::checkAndRebuildLore($item);
        }

        $stats = self::getItemStats($item);
        
        $activeStatsCount = 0;
        foreach ($stats as $val) {
            if ($val > 0.0) {
                $activeStatsCount++;
            }
        }
        
        if ($activeStatsCount === 0) {
            return $modified;
        }

        $lore = $item->getLore();
        
        $foundCount = 0;
        foreach ($lore as $line) {
            $cleanLine = str_replace("§", "", $line);
            $cleanLine = trim(strtolower($cleanLine));
            foreach (self::STATS_DEFINITIONS as $key => $data) {
                if ($stats[$key] > 0.0 && strpos($cleanLine, strtolower($data['name'])) !== false) {
                    $foundCount++;
                    break;
                }
            }
        }

        if ($foundCount !== $activeStatsCount) {
            self::setItemStats($item, $stats);
            return true;
        }

        return $modified;
    }
}
