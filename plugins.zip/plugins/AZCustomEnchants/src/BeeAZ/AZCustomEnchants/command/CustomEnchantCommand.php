<?php
declare(strict_types=1);

namespace BeeAZ\AZCustomEnchants\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginOwned;
use pocketmine\plugin\PluginOwnedTrait;
use BeeAZ\AZCustomEnchants\Main;
use BeeAZ\AZCustomEnchants\manager\StatsManager;
use BeeAZ\AZCustomEnchants\form\StatsForm;

class CustomEnchantCommand extends Command implements PluginOwned {
    use PluginOwnedTrait {
        PluginOwnedTrait::__construct as private __traitConstruct;
    }

    public function __construct(private Main $plugin) {
        $this->__traitConstruct($plugin);
        parent::__construct("azce", "Đặt cấp độ chỉ số cho vật phẩm trên tay", "/azce [chỉ số] [cấp độ]", ["azcustomenchant", "azcustomenchants"]);
        $this->setPermission("azcustomenchants.command.azce");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) {
            return false;
        }

        if (count($args) === 0) {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§cVui lòng thực hiện lệnh này trong trò chơi!");
                return false;
            }
            StatsForm::send($sender);
            return true;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§cChỉ người chơi mới có thể đặt cấp độ chỉ số cho vật phẩm đang cầm!");
            return false;
        }

        if (count($args) < 2) {
            $sender->sendMessage("§cCách dùng: /azce [chỉ số] [cấp độ]");
            return false;
        }

        $item = $sender->getInventory()->getItemInHand();
        if ($item->isNull()) {
            $sender->sendMessage("§cBạn phải cầm một vật phẩm trên tay!");
            return false;
        }

        $statInput = strtolower(str_replace(" ", "_", $args[0]));
        $map = [
            "hp" => "hp", "health" => "hp", "mau" => "hp", "máu" => "hp",
            "pve" => "pve", "pvedmg" => "pve", "pve_dmg" => "pve",
            "crit" => "crit", "crits" => "crit", "critical" => "crit",
            "pvp" => "pvp", "pvpdmg" => "pvp", "pvp_dmg" => "pvp",
            "defense" => "defense", "def" => "defense", "giap" => "defense", "giáp" => "defense"
        ];

        if (!isset($map[$statInput])) {
            $sender->sendMessage("§cChỉ số không hợp lệ! Danh sách chỉ số: hp, pve, crit, pvp, defense");
            return false;
        }

        $statKey = $map[$statInput];
        $data = StatsManager::STATS_DEFINITIONS[$statKey];
        $maxLevel = $data['max_level'];

        if (!filter_var($args[1], FILTER_VALIDATE_INT) && $args[1] !== "0") {
            $sender->sendMessage("§cCấp độ phải là một số nguyên dương!");
            return false;
        }

        $level = (int)$args[1];
        if ($level < 0 || $level > $maxLevel) {
            $sender->sendMessage("§cCấp độ phải nằm trong khoảng từ 0 đến " . $maxLevel . " (0 để xóa)!");
            return false;
        }

        $currentStats = StatsManager::getItemStats($item);
        
        $multiplier = $data['multiplier'];
        $currentStats[$statKey] = $level * $multiplier;

        StatsManager::setItemStats($item, $currentStats);
        $sender->getInventory()->setItemInHand($item);

        if ($statKey === "hp") {
            StatsManager::updatePlayerHealth($sender);
        }

        $statName = $data['name'];
        $sender->sendMessage("§aĐã đặt cấp độ chỉ số §e" . $statName . " §athành §e" . $level . " §acho vật phẩm!");

        return true;
    }
}
