<?php
declare(strict_types=1);

namespace BeeAZ\AZCustomEnchants\listener;

use pocketmine\event\Listener;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\entity\Living;
use pocketmine\player\Player;
use pocketmine\world\particle\CriticalParticle;
use pocketmine\world\particle\DustParticle;
use pocketmine\color\Color;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\scheduler\Task;
use BeeAZ\AZCustomEnchants\Main;
use BeeAZ\AZCustomEnchants\manager\StatsManager;

class EventListener implements Listener {

    public function __construct(private Main $plugin) {}

    public function onDamage(EntityDamageByEntityEvent $event): void {
        $attacker = $event->getDamager();
        $defender = $event->getEntity();

        if (!$defender instanceof Living) {
            return;
        }

        // Case 1: Attacker is Player
        if ($attacker instanceof Player) {
            $attackerStats = StatsManager::getPlayerStats($attacker);
            $baseDamage = $event->getBaseDamage();

            // PVE Attack: Player hits Mob
            if (!$defender instanceof Player) {
                $pveDmgBuff = $attackerStats["pve"] ?? 0.0;
                if ($pveDmgBuff > 0.0) {
                    $baseDamage *= (1.0 + ($pveDmgBuff / 100.0));
                }

                // Crit logic
                $critChance = $attackerStats["crit"] ?? 0.0;
                if ($critChance > 0.0 && (mt_rand(1, 10000) / 100.0 <= $critChance)) {
                    $baseDamage *= 1.5;
                    $this->showCritEffects($defender, "pve");
                    $attacker->sendMessage("§e§lBẠO KÍCH PVE! §r§7Gây §c" . round($baseDamage, 1) . " §7sát thương!");
                }
                
                $event->setBaseDamage($baseDamage);
            } 
            // PVP Attack: Player hits Player
            else {
                $pvpDmgBuff = $attackerStats["pvp"] ?? 0.0;
                if ($pvpDmgBuff > 0.0) {
                    $baseDamage *= (1.0 + ($pvpDmgBuff / 100.0));
                }

                // DEFENSE reduction for defender
                $defenderStats = StatsManager::getPlayerStats($defender);
                $defense = $defenderStats["defense"] ?? 0.0;
                if ($defense > 0.0) {
                    $baseDamage *= (1.0 - ($defense / 100.0));
                    if ($baseDamage < 0.0) $baseDamage = 0.0;
                }

                // Crit logic
                $critChance = $attackerStats["crit"] ?? 0.0;
                if ($critChance > 0.0 && (mt_rand(1, 10000) / 100.0 <= $critChance)) {
                    $baseDamage *= 1.5;
                    $this->showCritEffects($defender, "pvp");
                    $attacker->sendMessage("§c§lBẠO KÍCH PVP! §r§7Gây §c" . round($baseDamage, 1) . " §7sát thương!");
                }
                
                $event->setBaseDamage($baseDamage);
            }
        } 
        // Case 2: Attacker is Mob, Defender is Player (PVE Defense)
        elseif ($defender instanceof Player) {
            $defenderStats = StatsManager::getPlayerStats($defender);
            $defense = $defenderStats["defense"] ?? 0.0;

            if ($defense > 0.0) {
                $baseDamage = $event->getBaseDamage();
                $baseDamage *= (1.0 - ($defense / 100.0));
                if ($baseDamage < 0.0) $baseDamage = 0.0;
                $event->setBaseDamage($baseDamage);
            }
        }
    }

    public function onInventoryTransaction(InventoryTransactionEvent $event): void {
        $player = $event->getTransaction()->getSource();
        $this->plugin->getScheduler()->scheduleDelayedTask(new class($player) extends Task {
            public function __construct(private Player $player) {}
            public function onRun(): void {
                if ($this->player->isOnline()) {
                    $inv = $this->player->getInventory();
                    $hand = $inv->getItemInHand();
                    if (StatsManager::checkAndRebuildLore($hand)) {
                        $inv->setItemInHand($hand);
                    }
                    foreach ($inv->getContents() as $slot => $item) {
                        if (StatsManager::checkAndRebuildLore($item)) {
                            $inv->setItem($slot, $item);
                        }
                    }
                    $armor = $this->player->getArmorInventory();
                    foreach ($armor->getContents() as $slot => $item) {
                        if (StatsManager::checkAndRebuildLore($item)) {
                            $armor->setItem($slot, $item);
                        }
                    }
                    StatsManager::updatePlayerHealth($this->player);
                }
            }
        }, 1);
    }

    public function onItemHeld(PlayerItemHeldEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        if (StatsManager::checkAndRebuildLore($item)) {
            $player->getInventory()->setItemInHand($item);
        }
        $this->plugin->getScheduler()->scheduleDelayedTask(new class($player) extends Task {
            public function __construct(private Player $player) {}
            public function onRun(): void {
                if ($this->player->isOnline()) {
                    StatsManager::updatePlayerHealth($this->player);
                }
            }
        }, 1);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $inv = $player->getInventory();
        foreach ($inv->getContents() as $slot => $item) {
            if (StatsManager::checkAndRebuildLore($item)) {
                $inv->setItem($slot, $item);
            }
        }
        $armor = $player->getArmorInventory();
        foreach ($armor->getContents() as $slot => $item) {
            if (StatsManager::checkAndRebuildLore($item)) {
                $armor->setItem($slot, $item);
            }
        }
        StatsManager::updatePlayerHealth($player);
    }

    private function showCritEffects(Living $entity, string $type): void {
        $world = $entity->getWorld();
        $pos = $entity->getPosition()->add(0, 1, 0);

        // Premium Crit Stars
        for ($i = 0; $i < 12; $i++) {
            $world->addParticle($pos, new CriticalParticle(mt_rand(1, 3)));
        }

        // Color theme Redstone dust particle splatter
        $color = $type === "pve" ? new Color(255, 215, 0) : new Color(220, 20, 60); // Gold for PvE, Crimson for PvP
        for ($i = 0; $i < 10; $i++) {
            $offset = $pos->add(
                (mt_rand(-10, 10) / 10.0),
                (mt_rand(-5, 15) / 10.0),
                (mt_rand(-10, 10) / 10.0)
            );
            $world->addParticle($offset, new DustParticle($color, 1.2));
        }

        // Premium sound
        $soundName = "random.orb";
        $pos = $entity->getPosition();
        $soundPacket = PlaySoundPacket::create($soundName, $pos->getX(), $pos->getY(), $pos->getZ(), 1.0, 1.4, null);
        foreach ($world->getPlayers() as $player) {
            if ($player->getPosition()->distance($pos) <= 16) {
                $player->getNetworkSession()->sendDataPacket($soundPacket);
            }
        }
    }
}
