<?php

declare(strict_types=1);

namespace BeeAZ\AZAIGuide;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\player\PlayerChatEvent;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Label;

class Main extends PluginBase implements Listener {

    private static self $instance;

    public static function getInstance(): self {
        return self::$instance;
    }

    protected function onLoad(): void {
        self::$instance = $this;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if ($command->getName() === "ai") {
            if (!$sender instanceof Player) {
                $sender->sendMessage("§c⚡ Lệnh này chỉ dành cho người chơi!");
                return true;
            }

            if (isset($args[0])) {
                $question = implode(" ", $args);
                $this->handleQuestionChat($sender, $question);
            } else {
                $this->sendMainForm($sender);
            }
            return true;
        }
        return false;
    }

    /**
     * Normalizes a string for searching/matching (lowercase, trim).
     */
    private function normalizeString(string $str): string {
        return mb_strtolower(trim($str), "UTF-8");
    }

    /**
     * Tries to find the best Q&A match in the local database.
     */
    public function matchQuestion(string $question): ?array {
        $cleanQuestion = $this->normalizeString($question);
        if ($cleanQuestion === "") {
            return null;
        }

        $db = $this->getConfig()->get("database", []);
        $bestMatch = null;
        $bestScore = 0;

        foreach ($db as $key => $data) {
            $keywords = $data["keywords"] ?? [];
            foreach ($keywords as $keyword) {
                $cleanKeyword = $this->normalizeString($keyword);
                if ($cleanKeyword === "") {
                    continue;
                }

                // Check if the keyword is inside the question, or vice versa
                if (str_contains($cleanQuestion, $cleanKeyword) || str_contains($cleanKeyword, $cleanQuestion)) {
                    $score = mb_strlen($cleanKeyword);
                    if ($score > $bestScore) {
                        $bestScore = $score;
                        $bestMatch = $data;
                    }
                }
            }
        }

        return $bestMatch;
    }

    /**
     * Checks if the message matches a database keyword.
     */
    public function hasKeywordMatch(string $message): bool {
        return $this->matchQuestion($message) !== null;
    }

    /**
     * Handles /ai <question> or chat triggers to answer in game.
     */
    private function handleQuestionChat(Player $player, string $question): void {
        $match = $this->matchQuestion($question);
        $prefix = $this->getConfig()->getNested("auto_chat_reply.prefix", "");
        if ($match !== null) {
            $player->sendMessage($prefix . $match["answer"]);
        } else {
            $noMatch = $this->getConfig()->getNested("messages.no_match", "");
            $player->sendMessage($prefix . $noMatch);
        }
    }

    /**
     * Chat Listener to automatically answer player questions.
     * @priority NORMAL
     * @ignoreCancelled true
     */
    public function onPlayerChat(PlayerChatEvent $event): void {
        if (!$this->getConfig()->getNested("auto_chat_reply.enabled", true)) {
            return;
        }

        $player = $event->getPlayer();
        $message = $event->getMessage();
        $cleanMsg = $this->normalizeString($message);

        $isTriggered = false;
        $question = $message;

        if (str_starts_with($cleanMsg, "ai ") || str_starts_with($cleanMsg, "ai?")) {
            $isTriggered = true;
            $question = substr($message, 3);
        } elseif (str_starts_with($cleanMsg, "@ai")) {
            $isTriggered = true;
            $question = substr($message, 3);
        } else {
            // Smart auto-response: trigger if any keyword matches directly in the chat message
            $match = $this->matchQuestion($message);
            if ($match !== null) {
                $isTriggered = true;
                $question = $message;
            }
        }

        if ($isTriggered) {
            $match = $this->matchQuestion($question);
            $prefix = $this->getConfig()->getNested("auto_chat_reply.prefix", "");
            
            if ($match !== null) {
                $answer = $match["answer"];
                $this->getScheduler()->scheduleDelayedTask(
                    new class($player, $prefix, $answer) extends \pocketmine\scheduler\Task {
                        private $player;
                        private $prefix;
                        private $answer;

                        public function __construct($player, $prefix, $answer) {
                            $this->player = $player;
                            $this->prefix = $prefix;
                            $this->answer = $answer;
                        }

                        public function onRun(): void {
                            if ($this->player->isOnline()) {
                                $this->player->sendMessage($this->prefix . $this->answer);
                            }
                        }
                    },
                    5
                );
            } else {
                // If they explicitly typed "ai <something>", reply with no-match message
                if (str_starts_with($cleanMsg, "ai ") || str_starts_with($cleanMsg, "@ai")) {
                    $noMatch = $this->getConfig()->getNested("messages.no_match", "");
                    $this->getScheduler()->scheduleDelayedTask(
                        new class($player, $prefix, $noMatch) extends \pocketmine\scheduler\Task {
                            private $player;
                            private $prefix;
                            private $noMatch;

                            public function __construct($player, $prefix, $noMatch) {
                                $this->player = $player;
                                $this->prefix = $prefix;
                                $this->noMatch = $noMatch;
                            }

                            public function onRun(): void {
                                if ($this->player->isOnline()) {
                                    $this->player->sendMessage($this->prefix . $this->noMatch);
                                }
                            }
                        },
                        5
                    );
                }
            }
        }
    }

    /**
     * Formats a button label with the black lightning bolts on both sides: §0⚡ §l{name} §r§0⚡
     */
    private function formatButtonText(string $name): string {
        $format = $this->getConfig()->get("button_format", "§0⚡ §l{name} §r§0⚡");
        return str_replace("{name}", $name, $format);
    }

    /**
     * Sends the main guide menu form to a player.
     */
    public function sendMainForm(Player $player): void {
        $cfg = $this->getConfig();
        $title = $cfg->getNested("ui.main.title", "§l§dAI HƯỚNG DẪN");
        $content = $cfg->getNested("ui.main.content", "");

        $btnAskText = $this->formatButtonText($cfg->getNested("ui.main.btn_ask", "Đặt câu hỏi"));
        $btnFaqText = $this->formatButtonText($cfg->getNested("ui.main.btn_faq", "Danh sách FAQ"));

        $form = new MenuForm(
            $title,
            $content,
            [
                new MenuOption($btnAskText),
                new MenuOption($btnFaqText)
            ],
            function(Player $submitter, int $selected): void {
                if ($selected === 0) {
                    $this->sendAskForm($submitter);
                } elseif ($selected === 1) {
                    $this->sendFaqListForm($submitter);
                }
            }
        );
        $player->sendForm($form);
    }

    /**
     * Sends the custom form where players can type their custom questions.
     */
    public function sendAskForm(Player $player): void {
        $cfg = $this->getConfig();
        $title = $cfg->getNested("ui.ask.title", "§l§dAI HỎI ĐÁP");
        $content = $cfg->getNested("ui.ask.content", "");
        $placeholder = $cfg->getNested("ui.ask.placeholder", "");

        $form = new CustomForm(
            $title,
            [
                new Input("question", $content, $placeholder)
            ],
            function(Player $submitter, CustomFormResponse $response): void {
                $question = $response->getString("question");
                if (trim($question) === "") {
                    $submitter->sendMessage("§c⚡ " . $this->getConfig()->getNested("messages.empty_question"));
                    return;
                }

                $match = $this->matchQuestion($question);
                if ($match !== null) {
                    $this->sendAnswerForm($submitter, $question, $match["answer"]);
                } else {
                    $noMatch = $this->getConfig()->getNested("messages.no_match", "");
                    $this->sendAnswerForm($submitter, $question, $noMatch);
                }
            }
        );
        $player->sendForm($form);
    }

    /**
     * Displays the answer to a question in a MenuForm with a back button.
     */
    public function sendAnswerForm(Player $player, string $question, string $answer): void {
        $cfg = $this->getConfig();
        $title = $cfg->getNested("ui.answer.title", "§l§dAI TRẢ LỜI");
        
        $contentTemplate = $cfg->getNested("ui.answer.content", "");
        $content = str_replace(["{question}", "{answer}"], [$question, $answer], $contentTemplate);

        $btnBackText = $this->formatButtonText($cfg->getNested("ui.answer.btn_back", "Quay lại"));

        $form = new MenuForm(
            $title,
            $content,
            [
                new MenuOption($btnBackText)
            ],
            function(Player $submitter, int $selected): void {
                $this->sendMainForm($submitter);
            }
        );
        $player->sendForm($form);
    }

    /**
     * Displays a list of all FAQ topics.
     */
    public function sendFaqListForm(Player $player): void {
        $cfg = $this->getConfig();
        $title = "§l§dFAQ - HƯỚNG DẪN";
        $content = "§7Danh sách các câu hỏi thường gặp. Chọn một chủ đề để xem câu trả lời:";

        $db = $cfg->get("database", []);
        $options = [];
        $keys = [];

        foreach ($db as $key => $data) {
            $options[] = new MenuOption($this->formatButtonText($data["title"] ?? $key));
            $keys[] = $key;
        }

        // Add back button
        $options[] = new MenuOption($this->formatButtonText($cfg->getNested("ui.answer.btn_back", "Quay lại")));

        $form = new MenuForm(
            $title,
            $content,
            $options,
            function(Player $submitter, int $selected) use ($keys, $db): void {
                // If back button selected (last option)
                if ($selected === count($keys)) {
                    $this->sendMainForm($submitter);
                    return;
                }

                $keySelected = $keys[$selected];
                $data = $db[$keySelected] ?? null;
                if ($data !== null) {
                    $this->sendAnswerForm($submitter, $data["title"], $data["answer"]);
                } else {
                    $this->sendMainForm($submitter);
                }
            }
        );
        $player->sendForm($form);
    }
}
