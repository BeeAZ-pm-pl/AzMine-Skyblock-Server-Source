<?php

declare(strict_types=1);

namespace BeeAZ\AZExchange;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\world\sound\XpLevelUpSound;
use pocketmine\world\sound\AnvilUseSound;
use dktapps\pmforms\CustomForm;
use dktapps\pmforms\CustomFormResponse;
use dktapps\pmforms\element\Input;
use dktapps\pmforms\element\Label;
use AZEconomy\AZEconomy;

class Main extends PluginBase {

    protected function onEnable(): void {
        $this->getLogger()->info("§aAZExchange v1.1.0 đã kích hoạt thành công!");
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cLệnh này chỉ dùng trong trò chơi!");
            return true;
        }

        if ($command->getName() === "doixu") {
            $this->openExchangeToCoinForm($sender);
            return true;
        }

        if ($command->getName() === "doicoin") {
            $this->openExchangeToXuForm($sender);
            return true;
        }

        return false;
    }

    /**
     * Lệnh /doixu: Đổi từ Xu sang Coin (20.000 Xu = 1 Coin)
     */
    public function openExchangeToCoinForm(Player $player): void {
        $economy = AZEconomy::getInstance();
        $xu = $economy->getMoney($player->getName());
        $coin = $economy->getCoin($player->getName());

        $form = new CustomForm(
            "§l§dĐỔI XU SANG COIN",
            [
                new Label("info", "§fSố Xu hiện có: §e" . number_format($xu) . " Xu\n§fSố Coin hiện có: §b" . number_format($coin) . " Coin\n\n§fTỷ lệ quy đổi: §a20.000 Xu §f= §e1 Coin"),
                new Input("amount", "§eNhập số COIN muốn nhận (đổi từ Xu):", "Ví dụ: 10")
            ],
            function(Player $player, CustomFormResponse $response) use ($economy): void {
                $amountStr = trim($response->getString("amount"));
                if ($amountStr === "") {
                    $player->sendMessage("§cVui lòng nhập số lượng Coin muốn đổi!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                if (!is_numeric($amountStr)) {
                    $player->sendMessage("§cSố lượng Coin phải là số hợp lệ!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $coinAmount = (int) $amountStr;
                if ($coinAmount <= 0) {
                    $player->sendMessage("§cSố lượng Coin muốn đổi phải lớn hơn 0!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $xuNeeded = $coinAmount * 20000;
                $currentXu = $economy->getMoney($player->getName());

                if ($currentXu < $xuNeeded) {
                    $player->sendMessage("§cBạn không có đủ Xu! Để nhận §b" . number_format($coinAmount) . " Coin §cbạn cần §e" . number_format($xuNeeded) . " Xu§c.");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                if ($economy->reduceMoney($player->getName(), $xuNeeded)) {
                    $economy->addCoin($player->getName(), $coinAmount);
                    $player->sendMessage("§a✨ Đổi thành công §e" . number_format($xuNeeded) . " Xu §alấy §b" . number_format($coinAmount) . " Coin§a!");
                    $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                } else {
                    $player->sendMessage("§cCó lỗi xảy ra trong quá trình giao dịch!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                }
            }
        );

        $player->sendForm($form);
    }

    /**
     * Lệnh /doicoin: Đổi từ Coin sang Xu (1 Coin = 2.000 Xu)
     */
    public function openExchangeToXuForm(Player $player): void {
        $economy = AZEconomy::getInstance();
        $xu = $economy->getMoney($player->getName());
        $coin = $economy->getCoin($player->getName());

        $form = new CustomForm(
            "§l§dĐỔI COIN SANG XU",
            [
                new Label("info", "§fSố Coin hiện có: §b" . number_format($coin) . " Coin\n§fSố Xu hiện có: §e" . number_format($xu) . " Xu\n\n§fTỷ lệ quy đổi: §a1 Coin §f= §e2.000 Xu"),
                new Input("amount", "§eNhập số COIN muốn đổi sang XU:", "Ví dụ: 10")
            ],
            function(Player $player, CustomFormResponse $response) use ($economy): void {
                $amountStr = trim($response->getString("amount"));
                if ($amountStr === "") {
                    $player->sendMessage("§cVui lòng nhập số lượng Coin muốn đổi!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                if (!is_numeric($amountStr)) {
                    $player->sendMessage("§cSố lượng Coin phải là số hợp lệ!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $coinAmount = (int) $amountStr;
                if ($coinAmount <= 0) {
                    $player->sendMessage("§cSố lượng Coin muốn đổi phải lớn hơn 0!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $currentCoin = $economy->getCoin($player->getName());
                if ($currentCoin < $coinAmount) {
                    $player->sendMessage("§cBạn không có đủ Coin! Bạn chỉ có §b" . number_format($currentCoin) . " Coin§c.");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                    return;
                }

                $xuGained = $coinAmount * 2000;

                if ($economy->reduceCoin($player->getName(), $coinAmount)) {
                    $economy->addMoney($player->getName(), $xuGained);
                    $player->sendMessage("§a✨ Đổi thành công §b" . number_format($coinAmount) . " Coin §alấy §e" . number_format($xuGained) . " Xu§a!");
                    $player->getWorld()->addSound($player->getLocation(), new XpLevelUpSound(1));
                } else {
                    $player->sendMessage("§cCó lỗi xảy ra trong quá trình giao dịch!");
                    $player->getWorld()->addSound($player->getLocation(), new AnvilUseSound());
                }
            }
        );

        $player->sendForm($form);
    }
}
