<?php

declare(strict_types=1);

namespace BeeAZ\AZMenu\ui;

use pocketmine\player\Player;
use pocketmine\Server;
use dktapps\pmforms\MenuForm;
use dktapps\pmforms\MenuOption;
use dktapps\pmforms\FormIcon;

class MenuUI {

    public static function send(Player $player): void {
        $options = [
            new MenuOption(
                "§0⚡ §lHỆ THỐNG ĐẢO BAY §r§0⚡\n§8Gõ /is - Quản lý đảo bay của bạn",
                new FormIcon("textures/items/diamond_pickaxe", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lCẢNH GIỚI TU TIÊN §r§0⚡\n§8Gõ /canhgioi - Đột phá cảnh giới",
                new FormIcon("textures/items/nether_star", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lCỬA HÀNG VẬT PHẨM §r§0⚡\n§8Gõ /shop - Mua bán bằng Xu",
                new FormIcon("textures/items/emerald", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lNGÂN HÀNG TIẾT KIỆM §r§0⚡\n§8Gõ /bank - Gửi tiền & Nhận lãi tiết kiệm",
                new FormIcon("textures/ui/cash_in", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lCỬA HÀNG PREMIUM §r§0⚡\n§8Gõ /pshop - Shop VIP & Đặc quyền",
                new FormIcon("textures/items/diamond", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lMUA CẤP BẬC / RANK §r§0⚡\n§8Gõ /muarank - Nâng cấp Rank VIP",
                new FormIcon("textures/items/diamond_chestplate", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lNHIỆM VỤ HẰNG NGÀY §r§0⚡\n§8Gõ /mission - Làm nhiệm vụ nhận quà",
                new FormIcon("textures/items/book_writable", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lKHU VỰC CÂU CÁ §r§0⚡\n§8Gõ /fishing - Bảng câu cá & cần câu",
                new FormIcon("textures/items/fishing_rod_cast", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lTHÚ CƯNG / PET §r§0⚡\n§8Gõ /pet - Quản lý thú cưng đồng hành",
                new FormIcon("textures/items/bone", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lBANG HỘI / CLAN §r§0⚡\n§8Gõ /f - Giao diện liên minh bang hội",
                new FormIcon("textures/items/banner_pattern", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lCHỢ ĐẤU GIÁ §r§0⚡\n§8Gõ /ah - Mua bán giữa người chơi",
                new FormIcon("textures/items/comparator", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lVÉ MÙA / SEASON PASS §r§0⚡\n§8Gõ /vemua - Nhận thưởng vé mùa",
                new FormIcon("textures/items/paper", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lCỬA HÀNG MÙA VỤ / SEASON SHOP §r§0⚡\n§8Gõ /seasonshop - Bán nông sản theo mùa vụ",
                new FormIcon("textures/items/wheat", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lCỬA HÀNG JACKPOT §r§0⚡\n§8Gõ /jackpot shop - Cửa hàng & máy quay Jackpot",
                new FormIcon("textures/items/gold_ingot", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lĐIỂM DANH HẰNG NGÀY §r§0⚡\n§8Gõ /diemdanh - Điểm danh nhận quà",
                new FormIcon("textures/items/clock_item", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lNHẬP MÃ GIFTCODE §r§0⚡\n§8Gõ /giftcode - Nhận quà từ GiftCode",
                new FormIcon("textures/items/name_tag", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lMUA CHỈ SỐ / STATS §r§0⚡\n§8Gõ /muachiso - Tăng chỉ số cho trang bị",
                new FormIcon("textures/items/blaze_powder", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lSKIN TRANG BỊ / SKIN §r§0⚡\n§8Gõ /muaskin - Trang bị skin vũ khí giáp",
                new FormIcon("textures/items/wood_sword", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lHIỆU ỨNG TẤN CÔNG §r§0⚡\n§8Gõ /hieuung - Hiệu ứng chém đặc biệt",
                new FormIcon("textures/items/magma_cream", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lPHÓ BẢN / DUNGEON §r§0⚡\n§8Gõ /dungeon - Săn Boss tìm bảo vật",
                new FormIcon("textures/items/iron_sword", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lĐỆ TỬ / MINION §r§0⚡\n§8Gõ /minion shop - Quản lý đệ tử tự động",
                new FormIcon("textures/items/lead", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lDỊCH CHUYỂN / WARP §r§0⚡\n§8Gõ /warp - Đi đến các khu vực nhanh",
                new FormIcon("textures/items/ender_eye", FormIcon::IMAGE_TYPE_PATH)
            ),
            new MenuOption(
                "§0⚡ §lVỀ HUB / SPAWN §r§0⚡\n§8Gõ /spawn - Dịch chuyển về spawn",
                new FormIcon("textures/items/compass", FormIcon::IMAGE_TYPE_PATH)
            )
        ];
 
        $form = new MenuForm(
            "§0⚡ §lDANH SÁCH TÍNH NĂNG §r§0⚡",
            "§eChào mừng §a" . $player->getName() . " §eđến với Menu SkyBlock!\n§fVui lòng chọn một tính năng bên dưới để truy cập nhanh:",
            $options,
            function(Player $submitter, int $selected): void {
                $commands = [
                    "is",
                    "canhgioi",
                    "shop",
                    "bank",
                    "pshop",
                    "muarank",
                    "mission",
                    "fishing",
                    "pet",
                    "f",
                    "ah",
                    "vemua",
                    "seasonshop",
                    "jackpot shop",
                    "diemdanh",
                    "giftcode",
                    "muachiso",
                    "muaskin",
                    "hieuung",
                    "dungeon",
                    "minion shop",
                    "warp",
                    "spawn"
                ];

                if (isset($commands[$selected])) {
                    $cmd = $commands[$selected];
                    Server::getInstance()->getCommandMap()->dispatch($submitter, $cmd);
                }
            }
        );

        $player->sendForm($form);
    }
}
