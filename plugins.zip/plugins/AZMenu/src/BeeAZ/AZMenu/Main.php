<?php

declare(strict_types=1);

namespace BeeAZ\AZMenu;

use pocketmine\plugin\PluginBase;
use BeeAZ\AZMenu\command\MenuCommand;

class Main extends PluginBase {

    private static self $instance;

    public function onLoad(): void {
        self::$instance = $this;
    }

    public function onEnable(): void {
        // Register the /menu command
        $this->getServer()->getCommandMap()->register("azmenu", new MenuCommand($this));
    }

    public static function getInstance(): self {
        return self::$instance;
    }
}
