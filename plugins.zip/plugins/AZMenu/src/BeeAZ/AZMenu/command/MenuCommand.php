<?php

declare(strict_types=1);

namespace BeeAZ\AZMenu\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginOwned;
use pocketmine\plugin\PluginOwnedTrait;
use BeeAZ\AZMenu\Main;
use BeeAZ\AZMenu\ui\MenuUI;

class MenuCommand extends Command implements PluginOwned {
    use PluginOwnedTrait;

    public function __construct(private Main $plugin) {
        parent::__construct(
            "menu",
            "Mở menu chức năng tổng hợp của máy chủ",
            "/menu",
            ["mainmenu", "chucnang", "help"]
        );
        $this->setPermission("azmenu.command.use");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$this->testPermission($sender)) {
            return false;
        }

        if (!$sender instanceof Player) {
            $sender->sendMessage("§cChỉ có thể sử dụng lệnh này trong trò chơi!");
            return true;
        }

        MenuUI::send($sender);
        return true;
    }

    public function getOwningPlugin(): Main {
        return $this->plugin;
    }
}
