<?php

declare(strict_types=1);

namespace BeeAZ\AZSkinManager;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\scheduler\ClosureTask;
use pocketmine\entity\Skin;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat;
use Ramsey\Uuid\Uuid;
use BeeAZ\AZSkinManager\task\PlayerSkinTask;

class Main extends PluginBase implements Listener {

    private array $originalSkins = [];

    protected function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        
        $this->getScheduler()->scheduleDelayedTask(new ClosureTask(function() use ($player): void {
            if ($player->isOnline()) {
                try {
                    $oldSkin = $player->getSkin();
                    $this->originalSkins[$player->getName()] = $oldSkin;

                    $newSkinId = Uuid::uuid4()->toString();
                    $newSkin = new Skin(
                        $newSkinId,
                        $oldSkin->getSkinData(),
                        $oldSkin->getCapeData(),
                        $oldSkin->getGeometryName(),
                        $oldSkin->getGeometryData()
                    );
                    $player->setSkin($newSkin);
                    $player->sendSkin();
                } catch (\Exception $e) {
                }
            }
        }), 10);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        unset($this->originalSkins[$event->getPlayer()->getName()]);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage(TextFormat::colorize("&cLệnh này chỉ có thể sử dụng trong game."));
            return true;
        }

        if ($command->getName() === "setskin") {
            if (!isset($args[0])) {
                $sender->sendMessage(TextFormat::colorize("&cCách dùng: /setskin <url|tên_người_chơi>"));
                return true;
            }

            $input = trim($args[0]);

            if (str_starts_with(strtolower($input), "http://") || str_starts_with(strtolower($input), "https://")) {
                $sender->sendMessage(TextFormat::colorize("&eĐang tải và áp dụng skin..."));
                $this->getServer()->getAsyncPool()->submitTask(new PlayerSkinTask($input, $sender->getName()));
            } else {
                $target = $this->getServer()->getPlayerByPrefix($input);
                if ($target === null) {
                    $sender->sendMessage(TextFormat::colorize("&cNgười chơi không tồn tại hoặc không online."));
                    return true;
                }

                try {
                    $targetSkinData = $target->getSkin()->getSkinData();
                    $oldSkin = $sender->getSkin();
                    $newSkinId = Uuid::uuid4()->toString();
                    
                    $newSkin = new Skin(
                        $newSkinId,
                        $targetSkinData,
                        $oldSkin->getCapeData(),
                        $target->getSkin()->getGeometryName(),
                        $target->getSkin()->getGeometryData()
                    );
                    
                    $sender->setSkin($newSkin);
                    $sender->sendSkin();
                    
                    $sender->sendMessage(TextFormat::colorize("&aĐã sao chép skin từ " . $target->getName() . " thành công!"));
                } catch (\Exception $e) {
                    $sender->sendMessage(TextFormat::colorize("&cLỗi khi áp dụng skin: &f" . $e->getMessage()));
                }
            }
            return true;
        }

        if ($command->getName() === "resetskin") {
            if (isset($this->originalSkins[$sender->getName()])) {
                try {
                    $originalSkin = $this->originalSkins[$sender->getName()];
                    $newSkinId = Uuid::uuid4()->toString();
                    
                    $newSkin = new Skin(
                        $newSkinId,
                        $originalSkin->getSkinData(),
                        $originalSkin->getCapeData(),
                        $originalSkin->getGeometryName(),
                        $originalSkin->getGeometryData()
                    );
                    
                    $sender->setSkin($newSkin);
                    $sender->sendSkin();
                    
                    $sender->sendMessage(TextFormat::colorize("&aĐã khôi phục skin gốc thành công!"));
                } catch (\Exception $e) {
                    $sender->sendMessage(TextFormat::colorize("&cLỗi khi khôi phục skin: &f" . $e->getMessage()));
                }
            } else {
                $sender->sendMessage(TextFormat::colorize("&cKhông tìm thấy dữ liệu skin gốc của bạn."));
            }
            return true;
        }

        return false;
    }
}